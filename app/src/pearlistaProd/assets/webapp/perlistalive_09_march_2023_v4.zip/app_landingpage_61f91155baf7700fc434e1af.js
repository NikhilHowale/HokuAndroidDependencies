
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
var totaldcard_topimage216560043190_collectioncontainer = 0;
$(document).ready(function () {
    $('.page-content').css({
        'height': 'calc(100vh - 62px)',
        'overflow-y': 'scroll',
        'padding-bottom': '0px',
    });
    if ($('.view_list_record').length) { $('.view_list_record').show(); }
    localStorage.removeItem('objParamsList');
    if ($('.js-candlestick').length) $("input[type='checkbox']").candlestick({ 'on': 'Yes', 'off': 'No', 'nc': 'NA', 'default': 'NA', 'swipe': false, 'allowManualDefault': true });
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    const appUser = JSON.parse(localStorage.getItem('appUser'));
    let objParamsList = {};
    skip = 0;
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    objParamsList.queryMode = queryMode;
    objParamsList.isMobile = isMobile;
    objParamsList.functionName = 'show_dcard_getCategoryListDetails';
    localStorage.setItem('objParamsList', JSON.stringify(objParamsList));
    $(document).on('click', '#bookapponmentbutton', function () {
        
            // var recordID = $(this).attr('recordID');
            // window.location.href = '/booksy/addservices/'+$('#tokenKey').val()+'/'+recordID+'/mylistedit';
            // localStorage.setItem('salonlocationid', recordID);

            // var categoryid = $(this).attr('recordID');// get record ID;
            var nextPage = 'app_addbooking';
            var queryParams = queryStringToJSON();
            if (queryMode) queryParams['queryMode'] = queryMode;
            // if (categoryid) queryParams['categoryid'] = categoryid;
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);


            var tokenKey = getParameterByName('tokenKey');
            var secretKey = getParameterByName('secretKey');
            var queryMode = getParameterByName('queryMode');


            var pageurl = nextPage + "_61f91155baf7700fc434e1af.html?queryMode=" + queryMode + "&tokenKey=" + tokenKey + "&secretKey=" + secretKey;
            window.location.href = pageurl;
            return false;
    
        // return false;
    });//end of Event 
    shopproductbutton
    $(document).on('click', '#shopproductbutton', function () {
        var recordID = $(this).attr('recordID');
        // window.location.href = '/booksy/addservices/'+$('#tokenKey').val()+'/'+recordID+'/mylistedit';
        localStorage.setItem('salonlocationid', recordID);

        var categoryid = $(this).attr('recordID');// get record ID;
        var nextPage = 'app_userhome';
        var queryParams = queryStringToJSON();
        if (queryMode) queryParams['queryMode'] = queryMode;
        if (categoryid) queryParams['categoryid'] = categoryid;
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);

        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = getParameterByName('queryMode');


        var pageurl = nextPage + "_61f91155baf7700fc434e1af.html?queryMode=" + queryMode + "&tokenKey=" + tokenKey + "&secretKey=" + secretKey + "&recordID=" + recordID;
        window.location.href = pageurl;
        return false;

        // return false;
    });//end of Event 

    // Back to login page if guest login
    if (appUser && appUser.rolename == 'Guest') {
        $('.back-to-login').removeClass('d-none');
    }
    $(document).on('click', '.back-to-login', () => {
        if (appUser && appUser.rolename == 'Guest') {
            window.location = 'login_cognito.html';
        }
    })
});//end of ready 2

function getDataProcessAfterCalldcard_topimage216560043190_collectioncontainerCategory62864e09ce661f57e6375105(response, callback) {
    callback();
}

function getdcard_topimage216560043190_collectioncontainerapp_programmecategorylistMobileView(response, tokenKey, queryMode) {
    var html = '';
    $('#display_loading').removeClass('hideme')
    if (response.data.length == 0 && !$('.dcard_categories_collectioncontainer').length) {
        html += '<div class="nodatafound">';
        html += '<img src="nodatafound.gif" width="100%">';
        html += '<br>';
        html += '<!-- span>No record found</span -->';
        html += '</div>';
        // $('#orderslistcontainer').html(html);
    } else {
        html = '';
        var radioGroups = [];
        if (!response.showShimmer) {
            skip = skip + response.data.length;
        }
        $.each(response.data, function (keyList, objList) {
            var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (0) {  // need to fix with native gyes.. images not getting download
                var mediaID = '';
                var fileName = '';
                // if (objList['imageupload'] && objList['imageupload'][0].mediaID) {
                //     P
                //     mediaID = objList['imageupload'][0].mediaID;
                //     fileName = objList['imageupload'][0].mediaID + '.png';
                // }
            } else {
                objList['customerid_name'] = objList['customerid_name'] ? objList['customerid_name'] : '';
                let customerid_name = objList['customerid_name'];

                objList['email'] = objList['email'] ? objList['email'] : '';
                let email = objList['email'];

                objList['contactnumber_dialcode'] = objList['contactnumber_dialcode'] ? objList['contactnumber_dialcode'] : '';
                let contactnumber_dialcode = objList['contactnumber_dialcode'];

                objList['contactnumber'] = objList['contactnumber'] ? objList['contactnumber'] : '';
                let contactnumber = objList['contactnumber'];

                objList['actualamount'] = objList['actualamount'] ? objList['actualamount'].toFixed(2) : '';
                let actualamount = objList['actualamount'];

                objList['status'] = objList['status'] ? objList['status'] : '';
                let status = objList['status'];
                html += '<div class="card card-style">';
                html += '   <div orderid="' + objList._id + '" class="content dcard_categories_collectioncontainer">';
                html += '       <span class="font-11">Customer Name</span>';
                html += '       <strong class="float-end color-green-dark">' + status + '</strong>';
                html += '       <p class="mt-n2 mb-1">';
                html += '           <strong class="color-theme">' + customerid_name + '</strong>';
                html += '       </p>';
                html += '       <div class="col-12">';
                html += '           <span class="font-11">Email</span>';
                html += '           <p class="mt-n2 mb-1">';
                html += '               <strong class="color-theme">' + email + '</strong>';
                html += '           </p>';
                html += '       </div>';
                html += '       <div class="col-12">';
                html += '           <span class="font-11">Phone</span>';
                html += '           <p class="mt-n2 mb-1">';
                html += '               <strong class="color-theme">+' + contactnumber_dialcode + '&nbsp;' + contactnumber + '</strong>';
                html += '           </p>';
                html += '       </div>';
                html += '       <div class="col-12">';
                html += '           <h1 class="text-end font-20 font-900 line-height-xl color-highlight">$' + actualamount + '</h1>';
                html += '       </div>';
                html += '   </div >';
                html += '</div >';
            }
        });
        var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        $('#orderstrip').removeClass('hideme');
        $('#orderslistcontainer').append(html);
        $('#orderslistcontainer').removeClass('hideme');
        $('#display_loading').addClass('hideme');
    };
};



function getDataAfterCallgetdcard_bannerimagelist(response, callback) {
    callback();
}

function getdcard_bannerimagelistMobileView(response) {
    let html = '';
    $('#display_loading').removeClass('hideme');
    $.each(response.data, function (keyList, objList) {
        html += '<div class="splide__slide">';
        html += '   <div class="card rounded-m shadow-l mx-3" style="height:200px;">';
        html += '       <div class="card-overlay bg-gradient"></div>';
        let imgUrl = '';
        if (objList.bannerimage && objList.bannerimage[0] && objList.bannerimage[0].mediaID) {
            imgUrl = CDN_PATH + objList.bannerimage[0].mediaID + '_compressed.png';
        }
        html += '       <img class="img-fluid" src="' + imgUrl + '">';
        html += '   </div>';
        html += '</div>';
    });
    $('.splide__list').html(html)
    $('#display_loading').addClass('hideme');
    var splide = document.getElementsByClassName('splide');
    if (splide.length) {
        var singleSlider = document.querySelectorAll('.single-slider');
        if (singleSlider.length) {
            singleSlider.forEach(function (e) {
                var single = new Splide('#' + e.id, {
                    type: 'loop',
                    autoplay: true,
                    interval: 4000,
                    perPage: 1,
                }).mount();
                var sliderNext = document.querySelectorAll('.slider-next');
                var sliderPrev = document.querySelectorAll('.slider-prev');
                sliderNext.forEach(el => el.addEventListener('click', el => { single.go('>'); }));
                sliderPrev.forEach(el => el.addEventListener('click', el => { single.go('<'); }));
            });
        }

        var doubleSlider = document.querySelectorAll('.double-slider');
        if (doubleSlider.length) {
            doubleSlider.forEach(function (e) {
                var double = new Splide('#' + e.id, {
                    type: 'loop',
                    autoplay: true,
                    interval: 4000,
                    arrows: false,
                    perPage: 2,
                }).mount();
            });
        }

        var trippleSlider = document.querySelectorAll('.tripple-slider');
        if (trippleSlider.length) {
            trippleSlider.forEach(function (e) {
                var tripple = new Splide('#' + e.id, {
                    type: 'loop',
                    autoplay: true,
                    padding: {
                        left: '0px',
                        right: '80px',
                    },
                    interval: 4000,
                    arrows: false,
                    perPage: 2,
                    perMove: 1,
                }).mount();
            });
        }
    }
}
