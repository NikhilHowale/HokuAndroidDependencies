
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
$(document).ready(function () {
    $('#display_loading').removeClass('hideme');
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    let objParamsList = {};
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.queryMode = queryMode;
    getprivacyListinfo(objParamsList);
});//end of ready 2

function getprivacyListinfo(objParamsList) {
    const url = objParamsList.ajaXCallURL + '/booksy/getListDetails_Privacypolicy61f91155baf7700fc434e1af_privacypolicyweb_privacypolicywebKendoList';
    $.ajax({
        url,
        type: 'POST',
        data: objParamsList,
        success: function (response) {
            if (response.status == 0 && response.data && response.data.length > 0) {
                let html = '';
                $.each(response.data,function(keyList,objList){
                    objList['description'] = objList['description'] ? objList['description'] : '';
                    let description = objList['description'];
                    objList['policytitle'] = objList['policytitle'] ? objList['policytitle'] : '';
                    let policytitle = objList['policytitle'];
                    html += '<h2>'+policytitle+'</h2>';
                    html += '<div class="divider"></div>';
                    html += '<p>'+description+'</p>';
                });
                $('#privacycontainer').html(html);
                $('#privacycontainer').removeClass('hideme');
                $('#display_loading').addClass('hideme');
            }
        },
        error: function (error) {
            console.log("error in getting privacy and policy : " + error);
            return;
        }
    })
}