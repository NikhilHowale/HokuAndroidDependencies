
var offlineDataID = randomString();
var arrAllMedia = [];
var count = 0;
var otpCode = 0;
var passwordchanged = 0;
var errorFields = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var loginInfo = null;
var signupInfo = null;
var forgotEmail = null;
var changePassword = null;
var deviceInfo = {};
var forgotEmailOtp = 0;
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var toastMsg = [];
let errorField = [];
localStorage.setItem('objGetUserDetailsWithmenu', '');
$(document).ready(function () {
    $('#sg4075').removeClass('hide')
    $(".cognitoError").hide();
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"))
    }

    var objParamsToken = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsToken.tokenKey = getParameterByName('tokenKey');
    objParamsToken.secretKey = getParameterByName('secretKey');

    var userRole = $('#userRole').val();
    var userID = $('#userID').val();
    var createrOfRecord = $('#createrOfRecord').val();
    var queryMode = getParameterByName('queryMode');
    var recordID = $.trim($('#recordID').val());
    var addSessionComments = [];
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('click', '#otpbackbutton1', function (e) {
        $(".cognitoError").hide();
        e.preventDefault();
        resetFormInputs();
        $('.outer_starcontainer').addClass('hide');
        if (signupInfo) {
            $('#page_usersignup').removeClass('hide');
        } else {
            $('#page_login').removeClass('hide');
        }
    });//end of Event 


    $(document).on('focus', '#newpassword7', function () {
        $('.sgstrongpasswordmessage').fadeIn('300');
    });
    $(document).on('focusout', '#newpassword7', function () {
        $('.sgstrongpasswordmessage').hide();
        $('#confirmnewpassword8').focus();
    });

    $(document).on('focus', '#password10', function () {
        $('.sgstrongpasswordmessage').fadeIn('300');
    });
    $(document).on('focusout', '#password10', function () {
        $('.sgstrongpasswordmessage').hide();
        $('#confirmpassword11').focus();
    });

    $(document).on('keyup', '#newpassword7', function () {
        var password = $(this).val();
        showPasswordStrength(password)
    });

    $(document).on('click', '#signup5', function (e) {
        $(".cognitoError").hide();
        e.preventDefault();
        resetFormInputs();
        $('.outer_starcontainer').addClass('hideme');
        $('#page_login').removeClass('hideme');
    });
    $(document).on('click', '#didntreceiveotp9', function (e) {
        $(".cognitoError").hide();
        $('#display_loading').removeClass('hideme');
        $('.otp-input').val("");
        if (loginInfo) {
            authenticateUser(loginInfo);
        } else if (signupInfo) {
            resendConfirmationCode(signupInfo);
        } else if (forgotEmail) {
            forgotPassword(forgotEmail);
        } else {
            $('#display_loading').addClass('hideme');
            $(".cognitoError").html('Error in sending OTP. Please try later.').addClass('error_message').removeClass('success_message');
            $(".cognitoError").show();
        }
    });
    $(document).on('click', '#terms_condition', function () {
        var appJSON = {
            fileName: 'acknowledgment.html',
            title: 'Terms & Conditions'
        };
        var isAndroid = navigator.userAgent.toLowerCase().indexOf('android');
        if (isAndroid > -1) {
            window.Android.showTermsAndConditions(JSON.stringify(appJSON));
        } else {
            setupWebViewJavascriptBridge(function (bridge) {
                bridgeObj = bridge;
                bridgeObj.callHandler('showTermsAndConditions', appJSON, function (response) { });
            });
        }
    });

    $(document).on('click', '#otpcodesubmit', function () {
        const otp = $.trim($('#otpcode').val());
        if (otp == '') {

        }

    })
    $(document).on("click", '#otpcodesubmit', function (e) {
        $(".cognitoError").hide();
        var val = $('#otpcode').val();
        // if (val) {
        //     $(this).attr('type', 'password');
        // } else {
        //     $(this).attr('type', 'tel');
        // }

        var currentTarget = $(e.target);
        var srno = currentTarget.attr('srno');
        if (e.keyCode == 8) {
        }
        var otp = val;
        $(".cognitoError").hide();
        if (otp) {
            var responseData = JSON.parse(localStorage.getItem('responseData'));
            validateOTPWrapper(otp, CognitoConfig.APPID);
            return false;
        } else if (val) {
            srno = parseInt(srno);
            srno = srno + 1;
            $("#hkotp" + srno).focus();
        } else {
            srno = parseInt(srno);
            srno = srno - 1;
            if (srno >= 1) {
                $("#hkotp" + srno).focus();
            }
        }
    });

    function isAllFill() {
        try {
            if ($.trim($('#hkotp1').val()) != '' && $.trim($('#hkotp2').val()) != '' && $.trim($('#hkotp3').val()) != '' && $.trim($('#hkotp4').val()) != '' && $.trim($('#hkotp5').val()) != '' && $.trim($('#hkotp6').val()) != '') {
                var otp = $.trim($('#hkotp1').val()) + $.trim($('#hkotp2').val()) + $.trim($('#hkotp3').val()) + $.trim($('#hkotp4').val()) + $.trim($('#hkotp5').val()) + $.trim($('#hkotp6').val());
                return otp;
            }
            return false;
        } catch (err) {
            console.log('Error in isAllFill', err);
        }
    }

    function validateOTPWrapper(otp, appID) {
        try {
            $('#display_loading').removeClass('hideme');
            if (signupInfo) {
                confirmRegistration(signupInfo, otp)
                return;
            }
            otpCode = otp;
            $('#display_loading').addClass('hideme');
            $('.outer_starcontainer').addClass('hide');
            $('#page_changepassword').removeClass('hide');
        } catch (err) {
            console.log('Error in validateOTPWrapper', err);
        }
        return false;
    }

    $(document).on('click', '#resetpassword8', function () {
        // $('.outer_starcontainer').addClass('hide');
        // $('#page_forgotpassword').removeClass('hide');
        // $('.strongpass').removeClass('valid');
        // resetAllInputs();
        // return false;

        var email = $("#email5").val();
        if (!email) {
            $("#email5_error").show();
            $("#email5").focus();
            return;
        }
        forgotEmailOtp = 1;
        forgotEmail = email.toLowerCase();
        $('.enterotpdivmain').removeClass('hide');
        forgotPassword(email.toLowerCase());

    });//end of Event Reset Password_is_click 

    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('click', '#createone14', function () {
        $(".error_message").hide();
        $('.outer_starcontainer').addClass('hideme');
        $('#page_signup').removeClass('hideme');
        $('.strongpass').removeClass('valid');
        return false;
    });//end of Event Create One_is_click 
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};
    // Materialize.updateTextFields();
    var gBrnach = [];
    $('#email5_error').hide();
    $('#password6_error').hide();
    $(document).on('click', '#login7,#guestlogin15', function (e) {
        e.preventDefault();
        $('#display_loading').removeClass('hideme');
        $('#error_message').hide();
   
        var objParams = {};
   
        var email = '';
        var password = '';
        if ($(this).is($('#login7'))) {
            
            email = $.trim($('#email5').val());
            if ($('#email5_div').is(':visible')) {
                if (email == '') {
                    $('#display_loading').addClass('hideme');
                    $('#email5_error').show();
                    $('#email5').focus();
                    return false;
                } else {
                    $('#email5_error').hide();
                }
            }
            
            

            password = $.trim($('#password6').val());
            if ($('#password6_div').is(':visible')) {
                if (password == '') {
                    $('#display_loading').addClass('hideme');
                    $('#password6_error').show();
                    $('#password6').focus();
                    return false;
                } else {
                    $('#password6_error').hide();
                }
            }
        }

        if ($(this).is($('#guestlogin15'))) {
            email = 'pearlistaguest@yopmail.com';
            password = 'Hoku@123';
        }
        localStorage.clear();
        objParams.email = email.trim().toLowerCase();
        objParams.username = email.trim().toLowerCase();
        objParams.password = password.trim();
        objParams.subdomain = CognitoConfig.SUBhokuapps;
        objParams['custom:subdomain'] = CognitoConfig.SUBhokuapps;
        objParams['custom:appId'] = CognitoConfig.APPID;
        signupInfo = null;
        loginInfo = objParams;

        $('#display_loading').removeClass('hideme');
        authenticateUser(loginInfo);
        return false
    }); //end of Event
    $(document).on('click', '#updatePassword9', function () {
        $(".error_message").hide();
        $(".cognitoError").hide();
        var errorField = [];
        var objParams = {};
        objParams.isDelete = 0;
        // otp
        const enterotp = $.trim($('#forgototp').val());
        if ($('#enterotpdivmain').is(':visible')) {
            if (enterotp == '') {
                toastMsg.push({ type: 'warning', msg: 'Please Enter OTP' });
            }
        }

        const password = $.trim($('#newpassword1').val());
        if (password == '') {
            errorField.push($('#newpassword1'));
        } else if (password != '' && $('#newpassword1').siblings('.valid').hasClass('disabled')) {
            errorField.push($('#newpassword1'));
        } else {
            objParams.password = password;
        }


        const confirmpassword = $.trim($('#newpassword2').val());
        if (confirmpassword == '') {
            errorField.push($('#newpassword2'));
        } else if (confirmpassword != '' && $('#newpassword2').siblings('.valid').hasClass('disabled')) {
            errorField.push($('#newpassword2'));
        } else {
            objParams.confirmpassword = confirmpassword;
        }

        // var password = $.trim($('#newpassword1').val());
        // if ($('#newpassword7_div').is(':visible')) {
        //     if (password == '') {
        //         $('#newpassword7_error').show();
        //         $('#newpassword7').fadeIn(1000);
        //         errorFields.push('newpassword7');
        //     }
        //     else {
        //         $('#newpassword7_error').hide();
        //     }
        // }
        // if ($('#newpassword7_div').is(':visible')) {
        //     objParams.password = password;
        // }
        // var confirmpassword = $.trim($('#confirmnewpassword8').val());
        // if ($('#confirmnewpassword8_div').is(':visible')) {
        //     if (confirmpassword == '') {
        //         $('#confirmnewpassword8_error').show();
        //         $('#confirmnewpassword8').fadeIn(1000);
        //         errorFields.push('confirmnewpassword8');
        //     }
        //     else {
        //         $('#confirmnewpassword8_error').hide();
        //     }
        // }
        // if ($('#confirmnewpassword8_div').is(':visible')) {
        //     objParams.confirmpassword = confirmpassword;
        // }

        // if (errorFields && errorFields.length) {
        //     return false;
        // }

        if (password != confirmpassword) {
            toastMsg.push({ type: 'warning', msg: 'Password and Confirm password should be same' })
            // $('#confirmnewpassword8_error').html('Password and Confirm password should be same.');
            // $('#confirmnewpassword8_error').show();
            // $('#confirmnewpassword8').focus();
            // return false;
        } else {
            $('#confirmnewpassword8_error').html('Confirm Password is required');
        }
        if (errorField.length) {
            errorField.forEach((el) => {
                showInvalidField(el);
                errorField[0].focus();
            });
            $('#display_loading').addClass('hideme');
            errorField = [];
            return;
        }
        if (toastMsg.length > 0) {
            const type = toastMsg[0].type;
            const message = toastMsg[0].msg;
            // showToast(type, message);
            toastMsg = [];
            return;
        }
        // check strong password before save
        // var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*?])(?=.{6,})");
        // if (strongRegex.test(password)) {

        // } else {
        //     $('#newpasswordisnotstrong_error').show();
        //     $('#newpassword7').focus();
        //     return false;
        // }

        var changePassParams = {};
        changePassParams.otp = enterotp;
        changePassParams.username = forgotEmail ? forgotEmail : (signupInfo ? signupInfo.username : loginInfo.username);
        changePassParams.password = objParams.password;

        //loginInfo = null;
        //signupInfo = null;
        forgotEmailOtp = 0;
        if (changePassword) {
            changePassword = null;
            completeNewPasswordChallenge(password);
        } else {
            $('#display_loading').removeClass('hideme');
            confirmForgotPassword(changePassParams);
            return false
        }
    });//end of Event 

    $(document).on('click', '#forgotpassword5', function () {
        $('.outer_starcontainer').addClass('hideme');
        $('#page_forgotpassword').removeClass('hideme');
        resetAllInputs();
        return false;
    });
    $(document).on('click', '#sendemail8', function () {
        $(".cognitoError").hide();
        $('#display_loading').removeClass('hideme');
        const email = $.trim($('#email5forgotpass').val());
        if (email == '') {
            errorField.push($('#email5forgotpass'));
        } else if (email != '' && $('#email5forgotpass').siblings('.valid').hasClass('disabled')) {
            errorField.push($('#email5forgotpass'));
        } else if (typeof EMAIL_REGEX !== 'undefined' && EMAIL_REGEX && !EMAIL_REGEX.test(email)) {
            errorField.push($('#email5forgotpass'));
        }
        if (errorField.length) {
            errorField.forEach((el) => {
                showInvalidField(el);
                errorField[0].focus();
            });
            $('#display_loading').addClass('hideme')
            return;
        }
        forgotEmailOtp = 1;
        forgotEmail = email.toLowerCase();
        $("#enterotpdivmain").removeClass("hideme");
        forgotPassword(email.toLowerCase());
    })

    $(document).on('click', '#loginasguestuser8', function (e) {
        var objParams = {};
        objParams.email = "webuser1@hokuapps.com";
        objParams.username = "webuser1@hokuapps.com";
        objParams.password = "Hoku@123";
        objParams.subdomain = CognitoConfig.SUBhokuapps;
        objParams['custom:subdomain'] = CognitoConfig.SUBhokuapps;
        objParams['custom:appId'] = CognitoConfig.APPID;
        signupInfo = null;
        loginInfo = objParams;

        $('#display_loading').removeClass('hideme');
        authenticateUser(loginInfo);
        return false;
    });
    $(document).on('click', '#signupclose', function () {
        $('#display_loading').removeClass('hideme');
        return window.location.href = "login_cognito.html";
    });


    $("#phone3").intlTelInput({
        initialCountry: "sg",
        preferredCountries: ["sg", "my"],
        separateDialCode: true,
        utilsScript: "countrycodes/js/utils.js",
    });
    var mask1 = "0000 0000";
    $("#phone3").attr("placeholder", mask1);
    $("#phone3").mask(mask1);
    $("#phone3").attr("dialCode", "65").attr("countryCode", "sg");

    $("#phone3").on("countrychange", function (e, countryData) {
        $("#phone3").val("");
        var dialCode = "+" + countryData.dialCode + " ";
        var iso2 = countryData.iso2;
        var sampleNumber = intlTelInputUtils.getExampleNumber(iso2, false, 1);
        var placeholder = sampleNumber.replace(dialCode, "");
        var mask1 = placeholder.replace(/[0-9]/g, 0);
        $("#phone3")
            .attr("placeholder", mask1)
            .attr("dialCode", countryData.dialCode)
            .attr("countryCode", iso2);
        $("#phone3").mask(mask1);
    });

    $(document).on("click", "#otpclose,#forgotclose,#resetclose", function () {
        $(".error_message").hide();
        resetFormInputs();
        $(".outer_starcontainer").addClass("hideme");
        if ($(this).is($('#otpclose'))) {
            $("#page_signup").removeClass("hideme");
        }
        if ($(this).is($('#forgotclose')) || $(this).is($('#resetclose'))) {
            $("#page_login").removeClass("hideme");
        }
        $(".strongpass").removeClass("valid");
        return false;
    }); //end of Event Create One_is_click

    $(document).on('click', '#facicon12', function () {

        $('#display_loading').removeClass('hideme');
        localStorage.setItem('objGetUserDetailsWithmenu', '');

        if (!navigator.onLine) {
            shareAppData('It looks like your internet connection is not working. Please try again later.', 'toast');
        } else {
            var appJSON = {};
            appJSON.nextButtonCallback = 'loginWithFacebookCallBack';
            appJSON.colorCode = '#3c3c3c';
            appJSON.launchNative = false;
            appJSON.roleName = "teacher";

            // appJSON.isFromSocialMedia = true;
            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (isAndroid > -1) {
                window.Android.loginWithFB(JSON.stringify(appJSON))
            } else {
                setupWebViewJavascriptBridge(function (bridge) {
                    bridgeObj.callHandler('loginWithFB', appJSON, function (response) { });
                    bridgeObj.registerHandler('loginWithFacebookCallBack', function (responseData, responseCallback) {
                        loginWithFacebookCallBack(responseData)
                    });
                });
            }
            return false;
        }
    });

    $(document).on('click', '#goicon13', function () {
        $('#display_loading').removeClass('hideme');
        localStorage.setItem('objGetUserDetailsWithmenu', '');

        if (!navigator.onLine) {
            shareAppData('It looks like your internet connection is not working. Please try again later.', 'toast');
        } else {
            var appJSON = {};
            appJSON.nextButtonCallback = 'loginWithGoogleCallBack';
            appJSON.colorCode = '#3c3c3c';
            appJSON.launchNative = false;
            appJSON.roleName = localStorage.getItem('roleName');
            appJSON.launchNextpage = 'app_home.html';
            appJSON.isFromSocialMedia = true;

            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (isAndroid > -1) {
                window.Android.loginWithGoogle(JSON.stringify(appJSON))
            } else {
                setupWebViewJavascriptBridge(function (bridge) {
                    bridgeObj.callHandler('loginWithGoogle', appJSON, function (response) { });
                    bridgeObj.registerHandler('loginWithGoogleCallBack', function (responseData, responseCallback) {
                        loginWithGoogleCallBack(responseData)
                    });
                });
            }
            $('#display_loading').addClass('hideme');
            return false;
        }
    });

    $(document).on('click', '#sharelogs8', function () {
        shareLog();
    });

});//end of ready

function loginWithGoogleCallBack(reseponseData) {
    try {
        CognitoConfig.GATEWAY_URL = 'https://gateway-sg.hokuapps.com/61f91155baf7700fc434e1afIAM';
        AWS.config.region = CognitoConfig.AWS_REGION;

        AWS.config.credentials = new AWS.CognitoIdentityCredentials({
            IdentityPoolId: CognitoConfig.AWS_IDENTITY_POOLID,
            Logins: {
                'accounts.google.com': reseponseData.googleIdToken
            }
        });
        AWS.config.credentials.get(function () {

            var AWSCredentials = {};
            // Credentials will be available when this function is called.
            AWSCredentials.accessKeyId = AWS.config.credentials.accessKeyId;
            AWSCredentials.secretAccessKey = AWS.config.credentials.secretAccessKey;
            AWSCredentials.sessionToken = AWS.config.credentials.sessionToken;
            AWSCredentials.Expiration = AWS.config.credentials.expireTime.getTime();
            AWSCredentials.identityProvider = 'google';
            AWSCredentials.accessToken = reseponseData.googleIdToken;

            localStorage.removeItem('AWSCredentials');
            localStorage.setItem('IS_IAMUSER', true);
            $("#ajaXCallURL").val("https://gateway-sg.hokuapps.com/61f91155baf7700fc434e1afIAM");
            localStorage.setItem('AWSCredentials', JSON.stringify(AWSCredentials));

            var appID = 'APPID';
            var queryMode = 'mylist';
            var id = reseponseData.googleIdToken;
            var email = reseponseData.email;
            var name = reseponseData.name;
            var role = getParameterByName('roleName');

            var objParams = {};
            objParams.appID = CognitoConfig.APPID;
            var id = reseponseData.fbIdToken;
            objParams.email = email ? email : id + '@google.com';
            objParams.emailid = objParams.email.toLowerCase();
            objParams.name = reseponseData.name;

            objParams.rolename = "teacher";
            objParams.subdomain = CognitoConfig.SUBhokuapps;
            //objParams.cit = body.idToken;

            loginInfo = objParams;
            var ajaXCallURL = 'https://enrichmentteamapp.hokuapps.com';
            var signupURL = 'https://gateway-sg.hokuapps.com/createAppUser61f91155baf7700fc434e1af';
            CognitoConfig.GATEWAY_URL = 'https://gateway-sg.hokuapps.com/61f91155baf7700fc434e1afIAM';

            var apigClient = apigClientFactory.newClient(signupURL);
            var params = {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            };
            var additionalParams = {};
            apigClient.rootPost(params, objParams, additionalParams).then(function (response) {

                //doAppLogin(IDENTITY_TOKEN, true)
                doAppLogin('');
            }).catch(function (result) {
                ;
                $('#display_loading').addClass('hideme');
                $('#didntreceiveotp9').removeProp('disabled');
            });
        });
    } catch (error) {
        ;
        console.log(error);
    }


}

function loginWithFacebookCallBack(reseponseData) {
    try {
        CognitoConfig.GATEWAY_URL = 'https://gateway-sg.hokuapps.com/61f91155baf7700fc434e1afIAM';
        AWS.config.region = CognitoConfig.AWS_REGION;

        AWS.config.credentials = new AWS.CognitoIdentityCredentials({
            IdentityPoolId: CognitoConfig.AWS_IDENTITY_POOLID,
            Logins: {
                'graph.facebook.com': reseponseData.token
            }
        });
        localStorage.setItem('accessToken', reseponseData.token);
        localStorage.setItem('identityProvider', 'facebook');

        AWS.config.credentials.get(function () {

            var AWSCredentials = {};
            // Credentials will be available when this function is called.
            AWSCredentials.accessKeyId = AWS.config.credentials.accessKeyId;
            AWSCredentials.secretAccessKey = AWS.config.credentials.secretAccessKey;
            AWSCredentials.sessionToken = AWS.config.credentials.sessionToken;
            AWSCredentials.Expiration = AWS.config.credentials.expireTime.getTime();
            AWSCredentials.identityProvider = 'facebook';
            AWSCredentials.accessToken = reseponseData.token;

            localStorage.removeItem('AWSCredentials');
            localStorage.setItem('IS_IAMUSER', true);

            $("#ajaXCallURL").val("https://gateway-sg.hokuapps.com/61f91155baf7700fc434e1afIAM");

            localStorage.setItem('AWSCredentials', JSON.stringify(AWSCredentials));
            var objParams = {};
            objParams.appID = CognitoConfig.APPID;
            var id = reseponseData.fbIdToken;
            objParams.email = id + 'f@hokuapps.com';
            objParams.emailid = id + '@f.com';
            objParams.name = reseponseData.name;


            objParams.rolename = "teacher";
            objParams.subdomain = CognitoConfig.SUBhokuapps;
            //objParams.cit = body.idToken;

            loginInfo = objParams;
            var ajaXCallURL = 'https://enrichmentteamapp.hokuapps.com';
            var signupURL = 'https://gateway-sg.hokuapps.com/61f91155baf7700fc434e1afIAM/createAppUser61f91155baf7700fc434e1af';
            CognitoConfig.GATEWAY_URL = 'https://gateway-sg.hokuapps.com/61f91155baf7700fc434e1afIAM';
            var apigClient = apigClientFactory.newClient(signupURL);
            var params = {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            };
            var additionalParams = {};
            apigClient.rootPost(params, objParams, additionalParams).then(function (response) {
                ;
                //doAppLogin(IDENTITY_TOKEN, true)
                doAppLogin('');
            }).catch(function (result) {
                ;
                $('#display_loading').addClass('hideme');
                $('#didntreceiveotp9').removeProp('disabled');
            });
        });
    } catch (error) {
        ;
        console.log(error);
    }
}

(function (global) {
    try {
        if (typeof (global) === "undefined") {
            throw new Error("window is undefined");
        }
        var _hash = "!";
        var noBackPlease = function () {
            global.location.href += "#";
            // making sure we have the fruit available for juice (^__^)
            global.setTimeout(function () {
                global.location.href += "!";
            }, 50);
        };

        global.onhashchange = function () {
            if (global.location.hash !== _hash) {
                global.location.hash = _hash;
            }
        };

        global.onload = function () {
            noBackPlease();
            // disables backspace on page except on input fields and textarea..
            document.body.onkeydown = function (e) {
                var elm = e.target.nodeName.toLowerCase();
                if (e.which === 8 && (elm !== 'input' && elm !== 'textarea')) {
                    e.preventDefault();
                }
                // stopping event bubbling up the DOM tree..
                e.stopPropagation();
            };
        }
    } catch (err) {
        // console.log('Error in global call', err);
    }

})(window);

function loginNativeCallWrapper(response, appID) {
    try {
        var queryMode = $('#queryMode').val();
        var appJSON = {};
        appJSON.organizationID = response.user.organizationId;
        appJSON.userID = response.user._id;
        appJSON.appID = CognitoConfig.APPID ? CognitoConfig.APPID : $('#appID').val();
        appJSON.nextButtonCallback = 'setloginNativeCallBack';
        appJSON.action = queryMode;
        appJSON.colorCode = '#3c3c3c';
        appJSON.response = response;
        appJSON.launchNative = false;
        appJSON.authToken = response.appTokenDetails.authToken;
        appJSON.authSecretKey = response.appTokenDetails.authSecretKey;
        appJSON.roleName = response.appTokenDetails.roleName;
        appJSON.expiredTime = response.appTokenDetails.expiredTime;
        appJSON.launchNextpage = 'userhome5c5bfb8d5cdfed047d18806f.html'

        var roleName = response.appTokenDetails.roleName;
        localStorage.setItem('roleName', roleName);
        var tokenKey = response.appTokenDetails.authToken;
        var secretKey = response.appTokenDetails.authSecretKey;
        var ISDEV_MODE = localStorage.getItem("ISDEV_MODE");
        var DEV_MODE = getParameterByName('devmode');
        if (ISDEV_MODE == "true" || DEV_MODE) {
            var queryMode = 'mylist';

            if (roleName == 'admin') {
                window.location.href = 'app_landingpage_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false
            }
            if (roleName == 'customer') {
                window.location.href = 'app_landingpage_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false
            }
            if (roleName == 'Logistics') {
                window.location.href = 'app_logistichome_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false
            }
            if (roleName == 'Guest') {
                window.location.href = 'app_landingpage_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false
            }

            return false;
        } else {
            var objParams = {};
            objParams.organizationID = appJSON.organizationID;
            objParams.userID = appJSON.userID;
            objParams.appID = appJSON.appID;
            objParams.roleName = roleName;
            objParams.isLogin = true;
            var ajaXCallURL = CognitoConfig.APP_URL;
            appJSON.apiName = ajaXCallURL + '/api/addUserDeviceForApp_61f91155baf7700fc434e1af';
            appJSON.Authorization = IDENTITY_TOKEN;
            appJSON.addDeviceObject = objParams;

            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (isAndroid > -1) {
                window.Android.loginNativeCallV2(JSON.stringify(appJSON))
            } else {
                bridgeObj.callHandler('loginNativeCall', appJSON, function (response) { });
                bridgeObj.registerHandler('setloginNativeCallBack', function (responseData, responseCallback) {
                    setloginNativeCallBack(responseData)
                });
            }

            //  if (roleName == 'customer') {   window.location.href = 'app_studentlist_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;   return false } if (roleName == 'parent') {   window.location.href = 'app_studentlist_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;   return false } if (roleName == 'student') {   window.location.href = 'app_studentlist_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;   return false } if (roleName == 'supervisor') {   window.location.href = 'app_supervisorhome_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;   return false } if (roleName == 'teacher') {   window.location.href = 'app_teacherhome_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;   return false } if (roleName == 'sales') {   window.location.href = 'app_userhome_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;   return false } if (roleName == 'executive') {   window.location.href = 'login_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;   return false }
            if (roleName == 'admin') {
                window.location.href = 'app_landingpage_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false
            }
            if (roleName == 'customer') {
                window.location.href = 'app_landingpage_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false
            }
            if (roleName == 'Logistics') {
                window.location.href = 'app_logistichome_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false
            }
            if (roleName == 'Guest') {
                window.location.href = 'app_landingpage_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false
            }
            return false;
        }
    } catch (err) {
        $('#display_loading').addClass('hideme');
    }
}

function setCurrentLocationOfUser(responseData, response) {
    try {
        var apiParams = {};
        if (responseData) {
            $('#display_loading').addClass('hideme');
            // Add Custome function Call here
            localStorage.setItem('locationPingJson', JSON.stringify(responseData));
            var userDeviceObj = responseData.userDeviceObj;
            if (responseData.data) {
                responseData = responseData.data;
            }
            var tokenKey = response.appTokenDetails.authToken;
            var secretKey = response.appTokenDetails.authSecretKey;
            var queryMode = 'mylist';
            var roleName = localStorage.getItem('roleName');

            if (roleName == 'customer') { window.location.href = 'app_studentlist_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false } if (roleName == 'parent') { window.location.href = 'app_studentlist_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false } if (roleName == 'student') { window.location.href = 'app_studentlist_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false } if (roleName == 'supervisor') { window.location.href = 'app_supervisorhome_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false } if (roleName == 'teacher') { window.location.href = 'app_teacherhome_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false } if (roleName == 'sales') { window.location.href = 'app_userhome_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false } if (roleName == 'executive') { window.location.href = 'login_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false }
        }
    } catch (err) {
    }
}


function apiCall(params, callback) {
    try {
        var https = new XMLHttpRequest();
        var URL = params.URL;
        https.open("POST", URL, true);
        https.setRequestHeader('content-type', 'application/json');
        https.setRequestHeader("token", params.token);
        if (params.token) delete params.token;

        https.onreadystatechange = function () {
            if (https.readyState == 4 && https.status == 200) {
                var response = https.responseText;
                if (typeof response != 'object') {
                    response = JSON.parse(response);
                }
                callback(response);
            }
        }
        params = JSON.stringify(params);
        https.send(params);
    } catch (err) {

    }
}

function setloginNativeCallBack(responseData) {

}
// function on login MFA Required
function authOtpReceived(codeDeliveryDetails) {
    try {
        resetFormInputs();
        if (forgotEmail) {
            // $('#page_changepassword').removeClass('hideme');
            //$('.otp-input').attr('type', 'tel');
            $('.outer_starcontainer').addClass('hideme');
            $('#newPasswordDiv').removeClass('hideme');
            $('#display_loading').addClass('hideme');
            // showToast('success', 'OTP has sent to your email');
            $('#display_loading').addClass('hideme');
        } else {
            $('#newPasswordDiv').addClass('hide');
            //$('.otp-input').attr('type', 'tel');
            $('.outer_starcontainer').addClass('hideme');
            $('#page_otpverify').removeClass('hideme');
            $('#display_loading').addClass('hideme');
            // showToast('success', 'OTP has sent to your email');
            // $(".cognitoError").show();
            $('#display_loading').addClass('hideme');
        }
    } catch (error) {
        console.log('Error in authOtpReceived', error);
    }
}

// function on auth Failure
function onAuthFailure(err, ERROR_CODE) {
    try {
        $('#sgstrongpasswordmessage').addClass('hide');
        console.log('----------------err.code--------------------', err.code);
        if (err && err.code && err.code == 'InvalidParameterException') {
            $('#display_loading').addClass('hideme');
            objCognitoUser = null;
            $('#sgstrongpasswordmessage').removeClass('hide');
            return;
        } else if (err && err.code && err.code == 'PasswordResetRequiredException') {
            objCognitoUser = null;
            $('#forogtPassword').trigger('click');
            return;
        } else if (err && err.code && err.code == 'CodeMismatchException') {
            $('.outer_starcontainer').addClass('hide');
            $('#page_otpverify').removeClass('hide');
            $('#display_loading').addClass('hideme');
            if (ERROR_CODE[err.code]) {
                message = ERROR_CODE[err.code];
            }
            $(".cognitoError").html(message).addClass('error_message').removeClass('success_message');
            $(".cognitoError").show();
        }
        else if (err && err.code && err.code == "UserNotConfirmedException") {
            signupInfo = loginInfo;
            changePassword = true;
            //signupInfo.username = loginInfo.username;
            resendConfirmationCode(signupInfo);
            $(".cognitoError").html(message).addClass('error_message').removeClass('success_message');
            $(".cognitoError").show();
            //$('.outer_starcontainer').addClass('hide');
            //$('#page_otpverify').removeClass('hide');
            //$('#display_loading').addClass('hideme');
        } else if (err && err.code && err.code == "ExpiredCodeException") {
            $('.outer_starcontainer').addClass('hide');
            $('#page_otpverify').removeClass('hide');
            $('#display_loading').addClass('hideme');
            $(".cognitoError").html(message).addClass('error_message').removeClass('success_message');
            $(".cognitoError").show();
        } else if (err && err.message == "User password cannot be reset in the current state.") {
            $(".cognitoError").html("Please contact administrator to reset the password. ").addClass('error_message').removeClass('success_message');
            $(".cognitoError").show();
            $('#display_loading').addClass('hideme');
        } else {
            $('#display_loading').addClass('hideme');
            var message = 'Processing error. Please try again';
            if (!(err.message.indexOf("registered/verified") > 0) && err.message.indexOf("password") > 0 && err.code != "NotAuthorizedException") {
                err.code = "InvalidPasswordException"
            }

            if (ERROR_CODE[err.code]) {
                message = ERROR_CODE[err.code];
            }
            if (err.code == "UsernameExistsException" && err.message.indexOf("email already exists")) {
                message = err.message;
            }

            if (err.message) {
                message = err.message;
            }

            $(".cognitoError").html(message).addClass('error_message').removeClass('success_message');
            $(".cognitoError").show();
        }
    } catch (error) {
        console.log('Error in authOtpReceived', error);
    }
}

// function on change password
function updateUserPassword() {
    try {
        changePassword = true;
        $('#display_loading').addClass('hideme');
        $('.outer_starcontainer').addClass('hideme');
        $('#newPasswordDiv').removeClass('hideme');
    } catch (error) {
        console.log('Error in authOtpReceived', error);
    }
}

// function on change password
function updateUserPasswordV2() {
    try {
        completeNewPasswordChallenge('Alh$' + CognitoConfig.APPID);
    } catch (error) {
        console.log('Error in authOtpReceived', error);
    }
}

// function on password chnaged
function onPasswordChanged(data) {
    try {
        $('#display_loading').addClass('hideme');
        resetFormInputs();
        $('.outer_starcontainer').addClass('hideme');
        $('#page_login').removeClass('hideme');
    } catch (error) {
        console.log('Error in onPasswordChanged', error);
    }
}

// function on signup done
function signupCompleted(data) {
    try {
        $('#display_loading').addClass('hideme');
        resetFormInputs();
        $('.outer_starcontainer').addClass('hideme');
        $('#page_login').removeClass('hideme');
    } catch (error) {
        console.log('Error in onPasswordChanged', error);
    }
}

// get mobile device info
function getDeviceInfo() {
    try {
        var appJSON = {};
        appJSON.nextButtonCallback = 'setDeviceInfo';
        var isAndroid = navigator.userAgent.toLowerCase().indexOf('android');
        if (isAndroid > -1) {
            window.Android.getDeviceInfo(JSON.stringify(appJSON));
        } else {
            setupWebViewJavascriptBridge(function (bridge) {
                bridgeObj = bridge;
                bridgeObj.callHandler('getDeviceInfo', JSON.stringify(appJSON), function (response) { });
                bridgeObj.registerHandler('setDeviceInfo', function (responseData, responseCallback) {
                    setDeviceInfo(responseData)
                });
            });
        }
    } catch (err) {
        console.log('Error in getDeviceInfo', err);
    }
}

// reset all inputs
function resetFormInputs() {
    try {
        $('.error_message').hide();
        $('.success_message').hide();
        $('input').val('');
        $('input').parent().removeClass('input-style-active');
        $('input').siblings('i').addClass('disabled');
        $('input').siblings('em').removeClass('disabled');
    } catch (error) {
        console.log('Error in resetFormInputs', error)
    }
}

// do app login
function doAppLogin(IDENTITY_TOKEN) {
    try {

        if (IDENTITY_TOKEN) {
            //Need to set authorization token in all gatway api calls
            $.ajaxSetup({
                headers: { 'Authorization': IDENTITY_TOKEN }
            });
            var apigClient = apigClientFactory.newClient(CognitoConfig.GATEWAY_URL);
            var params = {
                'Content-Type': 'application/json',
                'Authorization': IDENTITY_TOKEN
            };
        } else {
            var apigClient = apigClientFactory.newClient(CognitoConfig.GATEWAY_URL);
            //Need to set authorization token in all gatway api calls
            var params = {
                'Content-Type': 'application/json'
            }
        }

        var additionalParams = {};
        var objParams = deviceInfo ? deviceInfo : {};
        objParams.email = loginInfo.email;
        objParams.username = loginInfo.email;
        objParams.subdomain = 'enrichmentteamapporg';

        if (IDENTITY_TOKEN) {
            objParams.cit = IDENTITY_TOKEN;
        } else {
            objParams.password = "Hoku@123";
            objParams.roleName = "teacher";
        }

        objParams.appID = CognitoConfig.APPID;
        objParams.appUrl = CognitoConfig.APP_URL;
        objParams.POOLID = CognitoConfig.USER_POOL_ID;
        $('#display_loading').removeClass('hideme');
        $('#inactiveuser_error').hide();
        apigClient.rootPost(params, objParams, additionalParams)
            .then(function (response) {
                //This is where you would put a success callback
                response = response.data.responseParams ? response.data.responseParams : response;
                if (response.status == 0 && response.user) {

                    if (response.appUser && response.appUser.status && response.appUser.status == 'Pending') {
                        $('#display_loading').addClass('hideme');
                        $('#inactiveuser_error').html("Your account is wating for approval.");
                        $('#inactiveuser_error').show();
                        $('#email5').focus();
                        return false;
                    }

                    if (response.appUser && response.appUser.status && response.appUser.status == 'Inactive') {
                        $('#display_loading').addClass('hideme');
                        $('#inactiveuser_error').html("Your account is deactivated.");
                        $('#inactiveuser_error').show();
                        $('#email5').focus();
                        return false;
                    }

                    if (response.appUser && response.appUser.status && response.appUser.status == 'Rejected') {
                        $('#display_loading').addClass('hideme');
                        $('#inactiveuser_error').html("Your account is rejected.");
                        $('#inactiveuser_error').show();
                        $('#email5').focus();
                        return false;
                    }

                    if (response.appUser && JSON.stringify(response.appUser) != "{}" && response.objGetUserDetailsWithmenu) {
                        response.objGetUserDetailsWithmenu.userEmailDetails = response.appUser.email;
                    }
                    else {
                        //resetHokuPassword(objParams.username, response.appTokenDetails.authToken, IDENTITY_TOKEN);
                        return;
                    }

                    localStorage.setItem('IDENTITY_TOKEN', IDENTITY_TOKEN);
                    localStorage.setItem('roleName', response.appTokenDetails.roleName);
                    localStorage.setItem('userID', response.user.userId);

                    localStorage.setItem('objGetUserDetailsWithmenu', JSON.stringify(response.objGetUserDetailsWithmenu));
                    localStorage.setItem('perms', JSON.stringify(response.perms));
                    localStorage.setItem('user', JSON.stringify(response.user));
                    localStorage.setItem('appUser', JSON.stringify(response.appUser));
                    localStorage.setItem('organizationID', response.user.organizationId);
                    // localStorage.setItem('CDN_THUMB', response.CDN_THUMB);
                    // localStorage.setItem('CDN_THUMB', response.CDN_THUMB);

                    localStorage.setItem('CDN_PATH', response.CDN_PATH);
                    localStorage.setItem('CDN_THUMB', response.CDN_THUMB);

                    if (response.appUser && response.appUser.userphotoupload && response.appUser.userphotoupload[0]) {
                        localStorage.setItem('profileThumb', response.appUser.userphotoupload[0].mediaID);
                    } else {
                        localStorage.removeItem('profileThumb');
                    }
                    localStorage.setItem('tokenData', JSON.stringify(response.tokenData));
                    loginNativeCallWrapper(response, '5c5bfb8d5cdfed047d18806f');
                    return false;

                } else if (response && response.status == 2) {
                    shareAppData('Your account is disable. Please contact admin.')
                    return false;
                } else {
                    $(".cognitoError").html('').addClass('error_message').removeClass('success_message');
                    $(".cognitoError").show();
                }
                $('#display_loading').addClass('hideme');
            }).catch(function (result) {
                //This is where you would put an error callback
                $('#display_loading').addClass('hideme');
                $('#didntreceiveotp9').removeProp('disabled');
            });
    } catch (error) {
        console.log('Error in doAppLogin', error)
    }
}

function setDeviceInfo(response) {
    try {
        if (response) {
            deviceInfo = response;
        }
    } catch (err) {
        console.log('Error in setDeviceInfo', err);
    }
}

// function showToast(type, msg) {
//     if (type == 'success') {
//         $('#messagetoast').addClass('success_msg');
//         $('#toastBody').html('<i class="fa fa-check-circle me-2"></i>' + msg);
//     } else if (type == 'error') {
//         $('#messagetoast').addClass('error_msg');
//         $('#toastBody').html('<i class="fa fa-xmark-circle me-2"></i>' + msg);
//     } else if (type == 'warning') {
//         $('#messagetoast').addClass('warning_msg');
//         $('#toastBody').html('<i class="fa fa-circle-exclamation me-2"></i>' + msg);
//     }
//     $('#messagetoast').toast('show');
// }

function removeCls(el) {
    el.removeClass('success_msg');
    el.removeClass('error_msg');
    el.removeClass('warning_msg');
}
function showInvalidField(element) {
    element.parent().removeClass('input-style-active');
    element.siblings('.invalid').removeClass('disabled');
    element.siblings('.valid').addClass('disabled');
    element.siblings('em').addClass('disabled');
}
