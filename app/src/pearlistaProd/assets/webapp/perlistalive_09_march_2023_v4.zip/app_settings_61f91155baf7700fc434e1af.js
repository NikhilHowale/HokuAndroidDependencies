
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
$(document).ready(function () {
    $('#contactus').removeClass("hideme");
    var userstatus = localStorage.userRole;
    if(userstatus == "admin"){
        $('#dashboardbtn').removeClass("hideme");
        $('#chatdiscussion').removeClass("hideme");
        $('#contactus').addClass("hideme");
    }else{
        $('#contactus').removeClass("hideme");

    }
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    // dashBoard
    $(document).on('click', '#dashboardbtn', function () {
        var nextPage = 'app_admindashboard';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        window.location.href = pageurl;
        return false;
    });

    //chat
    $(document).on("click", "#chatdiscussion", function () {
        var queryMode = getParameterByName('queryMode');
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var ajaXCallURL = $('#ajaXCallURL').val();
        var appJSON = {};
        appJSON.title = 'Discussion'
        appJSON.hideGroupTab = true;
        appJSON.hideContactTab = true;
        appJSON.tokenKey = tokenKey;
        appJSON.secretKey = secretKey;
        appJSON.queryMode = queryMode;
        appJSON.action = queryMode;
        appJSON.ajaXCallURL = ajaXCallURL;
        appJSON.organizationID = $('#organizationID').val();
        appJSON.appID = $('#appID').val();
        appJSON.chatTabType = 5;
        appJSON.showInfoTab = true;
        appJSON.showRecentChatOnly = true;
        if (DEVICE_TYPE == 'ios') {
          setupWebViewJavascriptBridge(function (bridgeObj) {
            bridgeObj.callHandler('openChatWindow', appJSON, function (response) { });
          });
        } else {
          window.Android.openChatWindow(JSON.stringify(appJSON));
        }
      });

    // notifications
    $(document).on('click', '#notificationbtn', function () {
        var nextPage = 'app_notifications';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        window.location.href = pageurl;
        return false;
    });

    // terms and conditions
    $(document).on('click', '#termslistbtn', function () {
        var nextPage = 'app_termslist';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        window.location.href = pageurl;
        return false;
    });

    // privacy policy
    $(document).on('click', '#privacylistbtn', function () {
        var nextPage = 'app_privacylist';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        window.location.href = pageurl;
        return false;
    });

    // FAQ
    $(document).on('click', '#faqlistbtn', function () {
        var nextPage = 'app_faqlist';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        window.location.href = pageurl;
        return false;
    });

    // About App
    $(document).on('click', '#aboutappbtn', function () {
        var nextPage = 'app_aboutapp';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        window.location.href = pageurl;
        return false;
    });
    //contact us 
    $(document).on('click', '#contactus', function () {
        var nextPage = 'app_contactus';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        window.location.href = pageurl;
        return false;
    });
    $(document).on('click', '#logoutbtn', function () {
        try {
            var element = $(this);
            var objParams = {};
            objParams.recordID = getParameterByName('recordID');
            if ($(this).attr('recordID')) {
                objParams.recordID = $(this).attr('recordID');
            }
            customcodelogout(objParams, element, {}, function (processCustomcode) {
                return false;
            });
        } catch (error) {
            console.log('Error in customcode click', error);
        }
    })


// start sg 


$(document).on('click', '#deleteUserAccount', function() {
    // var recordID = $('#deleteRecordID').val();
    var paramsDelete = {};
    paramsDelete.tokenKey = getParameterByName('tokenKey');
    paramsDelete.secretKey = getParameterByName('secretKey')
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    paramsDelete.recordID = localStorage.getItem('userID');
    paramsDelete.queryMode = 'delete'
    paramsDelete.ajaXCallURL = ajaXCallURL;
    paramsDelete.isDelete = 1;
  
    var callUrl = '/booksy/deleteRecordcustomermanagementlistweb_Usermanagement61f91155baf7700fc434e1af';
    
    if(localStorage.IDENTITY_TOKEN){
        callUrl = '/booksy/deleteUser61f91155baf7700fc434e1af';
    }
    $.ajax({
        url: paramsDelete.ajaXCallURL + callUrl,
        data: paramsDelete,
        type: 'POST',
        success: function(response) {
            if (response.status == 0) {
                var element = $(this);
                var objParams = {};
                objParams.recordID = getParameterByName('recordID');
                if ($(this).attr('recordID')) {
                    objParams.recordID = $(this).attr('recordID');
                }
            
                customcodelogout(objParams, element,{}, function (processCustomcode) {
                    return false;
                });
            } else {
                
            }
        },
        error: function(xhr, status, error) {
            
        },
    });
    return false;
});

// end sg










});//end of ready 2

function customcodelogout(objParams, element, response, callback) {
    try {
        var queryMode = 'add';
        var ajaXCallURL = getParameterByName('ajaXCallURL');
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        logoutNativeCall(tokenKey, queryMode, secretKey, ajaXCallURL);
        return false;
        callback();
    } catch (err) {
        callback();
        // console.log('Error in customcode', err);
    }
}
