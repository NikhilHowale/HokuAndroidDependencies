function setupWebViewJavascriptBridge(callback) {
  try {
    if (window.WebViewJavascriptBridge) {
      return callback(WebViewJavascriptBridge);
    }
    if (window.WVJBCallbacks) {
      return window.WVJBCallbacks.push(callback);
    }
    window.WVJBCallbacks = [callback];
    var WVJBIframe = document.createElement("iframe");
    WVJBIframe.style.display = "none";
    WVJBIframe.src = "wvjbscheme://__BRIDGE_LOADED__";
    document.documentElement.appendChild(WVJBIframe);
    setTimeout(function () {
      document.documentElement.removeChild(WVJBIframe);
    }, 0);
  } catch (error) {
    console.log("Error in setupWebViewJavascriptBridge");
  }
}

setupWebViewJavascriptBridge(function (bridge) {
  bridgeObj = bridge;

  // download complete trigger
  bridgeObj.registerHandler("downloadCompleted", function (responseData, responseCallback) {
    downloadCompleted(responseData);
  });
});

function writeLog(logText) {
  if (localStorage.loggerID) {
    var appJSON = {};
    appJSON.log = logText;
    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    if (isAndroid === -1) {
      setupWebViewJavascriptBridge(function (bridge) {
        bridge.callHandler("writeLogs", appJSON, function (response) { });
      });
    } else {
      window.Android.writeLogs(JSON.stringify(appJSON));
    }
  }
}

function shareLog() {
  var appJSON = {};
  var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
  if (isAndroid === -1) {
    setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler("shareLogs", appJSON, function (response) { });
    });
  } else {
    window.Android.shareLogs(JSON.stringify(appJSON));
  }
}
