var dropdownvalues = {};
$(document).ready(function () {

    var locationParams = {};
    getSearchBySalonLocation(locationParams);

    // var staffParams = {};
    // getStaff(staffParams);

    $(document).on("change", "#starttimeid43", function () {
        var hoursselected = $("#serviceid41 option:selected").attr("hours");
        var minutesselected = $("#serviceid41 option:selected").attr("minutes");

        console.log(hoursselected);
        console.log(minutesselected);

        var appointmentdate = $("#date42").val();
        var appointmentstarttime = $("#starttimeid43 option:selected").text().replace("AM", " AM").replace("PM", " PM");
        var computeddate = moment(new Date(appointmentdate + ", " + appointmentstarttime)).format("DD-MMM-YYYY, hh:mm A");
        var computeddatenextdate = moment(new Date(computeddate)).add(hoursselected, 'hours').add(minutesselected, 'minutes').format("hh:mmA");

        console.log(computeddate);
        console.log(computeddatenextdate);

        var objParams = {};
        objParams.starttimeappointment = computeddatenextdate;
        objParams.queryMode = $('#queryMode').val();
        objParams.callUrl = '/booksy/getListDetails_Timeslot61f91155baf7700fc434e1af_timeslotweb_timeslotwebKendoList';

        if (localStorage.getItem('salonlocationid')) {
            objParams.salonlocationid = localStorage.getItem('salonlocationid');
        }

        $.ajax({
            url: objParams.callUrl,
            data: objParams,
            type: 'POST',
            success: function (response) {

                $('#endtime44').prop('disabled', false);
                $('#endtime44').material_select();

                if (response.status == 0 && response.data && response.data[0]) {



                    var enddateselectedvalues = response.data[0]._id.toString();
                    // $('#endtime44').val(enddateselectedvalues);
                    // // $('#endtime44').prop('disabled', true);
                    // $('#endtime44').material_select();

                    // $('#endtime44').val(enddateselectedvalues);

                    var paramsType = {};
                    paramsType.selected = enddateselectedvalues;
                    getEndTime(paramsType);



                } else {
                    // $('#endtime44').val("");
                    // // $('#endtime44').prop('disabled', true);
                    // $('#endtime44').material_select();

                    // $('#endtime44').val("");
                    var paramsType = {};
                    paramsType.selected = "A";
                    getEndTime(paramsType);
                }

                // Materialize.updateTextFields();

            },
            error: function (xhr, status, error) {
                // $('#display_loading').addClass('hideme');
            },
        });

    });

    $(document).on('change', '#salonlocationid44', function () {

        var selectedlocationid = $('#salonlocationid44').val();
        var paramsServiceType = {};
        paramsServiceType.salonlocationid = selectedlocationid;
        getService(paramsServiceType);
        getStaff(paramsServiceType);
        getStartTime(paramsServiceType);

        $('#sg20761').removeClass('hide');
        // $('#sg20762').removeClass('hide');
        $('#sg20763').removeClass('hide');
        $('#sg20764').removeClass('hide');
        $('#sg20765').removeClass('hide');
        $('#sg20766').removeClass('hide');
        $('#sg20767').removeClass('hide');
        $('#sg20768').removeClass('hide');

    });

    var addSessionComments = [];
    var errorFields = [];
    var validAll = true;
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('click', '#saveguest37', function () {
        var recordID = $(this).attr('recordID');
        // window.location.href = '/booksy/addservices/'+$('#tokenKey').val()+'/'+recordID+'/mylistedit';
        localStorage.setItem('salonlocationid', recordID);

        var categoryid = $(this).attr('recordID');// get record ID;
        var nextPage = 'app_categorylist';
        var queryParams = queryStringToJSON();
        if (queryMode) queryParams['queryMode'] = queryMode;
        if (categoryid) queryParams['categoryid'] = categoryid;
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);

        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = getParameterByName('queryMode');


        var pageurl = nextPage + "_61f91155baf7700fc434e1af.html?queryMode=" + queryMode + "&tokenKey=" + tokenKey + "&secretKey=" + secretKey + "&recordID=" + recordID;
        window.location.href = pageurl;
        return false;

        // return false;
    });//end of Event 

}); //end of ready 4

async function processBeforeCallForSaveappointmentappointmentschedularweb_61f91155baf7700fc434e1af(objParams, callback) {
    objParams.appointmentdate = moment(objParams.date).format('DD MMMM, YYYY')
    callback();
}
async function processAfterCallForSaveappointmentappointmentschedularweb_61f91155baf7700fc434e1af(response, responseData, callback) {
    // location.reload(true);
    callback();
}



function processBeforeCallForgetfromothertable_appointmentschedularweb_salonlocation_61f91155baf7700fc434e1af_SearchBySalonLocation(paramsType, callback) {
    var response = paramsType;
    callback();
}

function processAfterCallForgetfromothertable_appointmentschedularweb_salonlocation_61f91155baf7700fc434e1af_SearchBySalonLocation(data, response, callback) {
    callback();
}

function getSearchBySalonLocation(paramsType) {
    processBeforeCallForgetfromothertable_appointmentschedularweb_salonlocation_61f91155baf7700fc434e1af_SearchBySalonLocation(paramsType, function (processBeforeRes) {

        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        paramsType.ajaXCallURL = ajaXCallURL;


        var queryMode = getParameterByName('queryMode');
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');

        paramsType.tokenKey = tokenKey;
        paramsType.secretKey = secretKey;
        paramsType.queryMode = queryMode;
        $('#display_loading').removeClass('hideme');
        $.ajax({
            url: paramsType.ajaXCallURL + '/booksy/getfromothertable_appointmentschedularweb_salonlocation_61f91155baf7700fc434e1af_SearchBySalonLocation',
            data: paramsType,
            type: 'POST',
            success: function (response) {
                if (response.status == 0) {
                    processAfterCallForgetfromothertable_appointmentschedularweb_salonlocation_61f91155baf7700fc434e1af_SearchBySalonLocation(response.data, response, function (processBeforeRes) {

                        let btnHtml = '';
                        let isMobile = $('#isMobile').val();
                        if (isMobile == 'true') {
                            response.data.forEach((element, key) => {
                                btnHtml += '<div id="sg6821" classname="primary" class="col s12 primary">'
                                btnHtml += '<div  id="saveguest37_div" class="" >'
                                btnHtml += '<div class="text-center" style="padding: 5px;font-size: 15px;text-transform: uppercase !important;">' + element.branchname + ' </div>'
                                // btnHtml += '<a id="saveguest37" class="hoku_button text-center" recordID="' + element._id + '" href="#"  tabindex="" style="" >'
                                // btnHtml += '    BOOK NOW'
                                // btnHtml += '</a>'

                                btnHtml += '<div class=""><div class=""><a id="saveguest37" recordID="' + element._id + '" class="btn shadow-bg shadow-bg-m btn-m btn-full mb-3 rounded-s text-uppercase font-900 shadow-s bg-red-light">Shop NOW</a></div></div>';

                                btnHtml += '<div class="text-center" style="padding: 5px;color: #9d9a9a;font-size: 14px;font-weight: bold;">powered by <span style="color:#667459 !important">Pearlista<span> </div>'
                                btnHtml += '</div>'
                                btnHtml += '</div>'

                                if (response.data.length != key + 1) {
                                    btnHtml += '<div class="divider divider-margins"></div>'
                                }

                            });
                        } else {
                            response.data.forEach(element => {
                                btnHtml += '<div id="sg6821" classname="primary" class="col s3 primary">'
                                btnHtml += '<div  id="saveguest37_div" class="" >'
                                btnHtml += '<div class="text-center" style="padding: 5px;font-size: 17px;text-transform: uppercase !important;">' + element.branchname + ' </div>'
                                btnHtml += '<a id="saveguest37" class="hoku_button text-center" recordID="' + element._id + '"  href="#"  tabindex="" style="height: 40px;line-height: 35px;border-radius: 12px;font-size:17px" >'
                                btnHtml += '    BOOK NOW'
                                btnHtml += '</a>'
                                btnHtml += '<div style="padding: 5px;color: #9d9a9a;font-size: 16px;font-weight: bold;" class="text-center">powered by <span style="color:#667459 !important">Pearlista<span> </div>'
                                btnHtml += '</div>'
                                btnHtml += '</div>'
                            });
                        }

                        console.log();
                        $('#locationbuttons').append(btnHtml);

                        //var selectOptionHtml = '<option value="">Search By Salon Location</option>';
                        var selectOptionHtml = '<option disabled selected value="">Select</option>';
                        $.each(response.data, function (keyList, objList) {
                            selectOptionHtml += '<option data-addr="' + objList.salonaddress + '"  value="' + objList._id + '">' + objList.branchname + '</option>';
                        });
                        $('#salonlocationid44').html(selectOptionHtml); //2
                        // if (dropdownvalues['salonlocationid']) { $('#salonlocationid44').val(dropdownvalues['salonlocationid']); }
                        if (localStorage.getItem('salonlocationid')) {
                            $('#salonlocationid44').val(localStorage.getItem('salonlocationid'));
                        }

                        if (paramsType.selectedlocation) {
                            $('#salonlocationid44').val(paramsType.selectedlocation);
                            localStorage.setItem('salonlocationid', paramsType.selectedlocation);
                        }
                        // $('#salonlocationid44').material_select();
                        //data-addr searchlocation
                        var selectedlocation = $("#salonlocationid44 option:selected").attr('data-addr');

                        if (selectedlocation) {
                            $('#searchlocation').html(selectedlocation);
                        }
                    });
                    $('#display_loading').addClass('hideme');
                } else {
                    $('#display_loading').addClass('hideme');
                }


            },
            error: function (xhr, status, error) {
                $('#display_loading').addClass('hideme');
            },
        });
    });
}

function processBeforeCallForgetfromothertable_appointmentschedularweb_usermanagement_61f91155baf7700fc434e1af_Staff(paramsType, callback) {
    var response = paramsType;
    callback();
}

function processAfterCallForgetfromothertable_appointmentschedularweb_usermanagement_61f91155baf7700fc434e1af_Staff(data, response, callback) {
    callback();
}

function getStaff(paramsType) {
    processBeforeCallForgetfromothertable_appointmentschedularweb_usermanagement_61f91155baf7700fc434e1af_Staff(paramsType, function (processBeforeRes) {
        // if(localStorage.getItem('salonlocationid')){
        //     paramsType.salonlocationid = localStorage.getItem('salonlocationid');
        // }
        $.ajax({
            url: '/booksy/getfromothertable_appointmentschedularweb_usermanagement_61f91155baf7700fc434e1af_Staff',
            data: paramsType,
            type: 'POST',
            success: function (response) {
                if (response.status == 0) {
                    processAfterCallForgetfromothertable_appointmentschedularweb_usermanagement_61f91155baf7700fc434e1af_Staff(response.data, response, function (processBeforeRes) {
                        //var selectOptionHtml = '<option value="">Staff</option>';
                        var selectOptionHtml = '<option disabled selected value="">Select</option>';
                        $.each(response.data, function (keyList, objList) {
                            selectOptionHtml += '<option  value="' + objList._id + '">' + objList.name + '</option>';
                        });
                        $('#staffid45').html(selectOptionHtml); //2
                        if (dropdownvalues['staffid']) {
                            $('#staffid45').val(dropdownvalues['staffid']);
                        }
                        $('#staffid45').material_select();

                        $('#addcustomername34').html(selectOptionHtml); //2
                        if (dropdownvalues['addcustomername34']) {
                            $('#addcustomername34').val(dropdownvalues['addcustomername34']);
                        }

                        $('#staffid45new').html(selectOptionHtml); //2
                        if (dropdownvalues['staffid']) {
                            $('#staffid45new').val(dropdownvalues['staffid']);
                        }
                        $('#staffid45new').material_select();


                        //$('#staffid45new').material_select();
                        $('#addcustomername34').change();

                    })
                } else {

                }

            },
            error: function (xhr, status, error) {

            },
        });
    });
}


function processBeforeCallForgetfromothertable_appointmentschedularweb_services_61f91155baf7700fc434e1af_Service(paramsType, callback) {
    var response = paramsType;
    callback();
}

function processAfterCallForgetfromothertable_appointmentschedularweb_services_61f91155baf7700fc434e1af_Service(data, response, callback) {
    callback();
}

function getService(paramsType) {
    processBeforeCallForgetfromothertable_appointmentschedularweb_services_61f91155baf7700fc434e1af_Service(paramsType, function (processBeforeRes) {

        if (localStorage.getItem('salonlocationid')) {
            paramsType.salonlocationid = localStorage.getItem('salonlocationid');
        }

        $.ajax({
            url: '/booksy/getfromothertable_appointmentschedularweb_services_61f91155baf7700fc434e1af_Service',
            data: paramsType,
            type: 'POST',
            success: function (response) {
                if (response.status == 0) {
                    processAfterCallForgetfromothertable_appointmentschedularweb_services_61f91155baf7700fc434e1af_Service(response.data, response, function (processBeforeRes) {
                        //var selectOptionHtml = '<option value="">Service</option>';
                        var selectOptionHtml = '<option disabled selected value="">Select</option>';
                        $.each(response.data, function (keyList, objList) {
                            selectOptionHtml += '<option  value="' + objList._id + '" hours="' + objList.hours.replace("h", "") + '" minutes="' + objList.minutes.replace("min", "") + '">' + objList.servicename + '</option>';
                        });
                        $('#serviceid41').html(selectOptionHtml); //2
                        // if (dropdownvalues['serviceid']) {
                        //     $('#serviceid41').val(dropdownvalues['serviceid']);
                        // }
                        $('#serviceid41').material_select();

                        $('#servicename29').html(selectOptionHtml); //2
                        // if (dropdownvalues['servicename29']) {
                        //     $('#servicename29').val(dropdownvalues['servicename29']);
                        // }
                        $('#servicename29').material_select();


                    })
                } else {

                }

            },
            error: function (xhr, status, error) {

            },
        });
    });
}

function processBeforeCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_StartTime(paramsType, callback) {
    var response = paramsType;
    callback();
}

function processAfterCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_StartTime(data, response, callback) {
    callback();
}

function getStartTime(paramsType) {
    processBeforeCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_StartTime(paramsType, function (processBeforeRes) {

        if (localStorage.getItem('salonlocationid')) {
            paramsType.salonlocationid = localStorage.getItem('salonlocationid');
        }

        $.ajax({
            url: '/booksy/getfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_StartTime',
            data: paramsType,
            type: 'POST',
            success: function (response) {
                if (response.status == 0) {
                    processAfterCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_StartTime(response.data, response, function (processBeforeRes) {
                        //var selectOptionHtml = '<option value="">Start Time</option>';
                        var selectOptionHtml = '<option disabled selected value="">Select</option>';
                        $.each(response.data, function (keyList, objList) {
                            selectOptionHtml += '<option  sequence="' + objList.sequence + '" value="' + objList._id + '">' + objList.starttime + '</option>';
                        });
                        $('#starttimeid43').html(selectOptionHtml); //2
                        if (dropdownvalues['starttimeid']) {
                            $('#starttimeid43').val(dropdownvalues['starttimeid']);
                        }
                        $('#starttimeid43').material_select();
                    })
                } else {

                }

            },
            error: function (xhr, status, error) {

            },
        });
    });
}

function processBeforeCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_EndTime(paramsType, callback) {
    var response = paramsType;
    callback();
}

function processAfterCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_EndTime(data, response, callback) {
    callback();
}

function getEndTime(paramsType) {
    processBeforeCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_EndTime(paramsType, function (processBeforeRes) {

        if (localStorage.getItem('salonlocationid')) {
            paramsType.salonlocationid = localStorage.getItem('salonlocationid');
        }
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        paramsType.ajaXCallURL = ajaXCallURL;
        $.ajax({
            url: paramsType.ajaXCallURL + '/booksy/getfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_EndTime',
            data: paramsType,
            type: 'POST',
            success: function (response) {
                if (response.status == 0) {
                    processAfterCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_EndTime(response.data, response, function (processBeforeRes) {
                        //var selectOptionHtml = '<option value="">End Time</option>';
                        var selectOptionHtml = '<option disabled selected value="">Select</option>';
                        $.each(response.data, function (keyList, objList) {
                            selectOptionHtml += '<option sequence="' + objList.sequence + '" value="' + objList._id + '">' + objList.starttime + '</option>';
                        });
                        $('#endtime44').html(selectOptionHtml); //2
                        $('#endtime44').prop('disabled', true);
                        // if (dropdownvalues['endtimeid']) { $('#endtime44').val(dropdownvalues['endtimeid']); }

                        if (paramsType.selected != "A") {
                            $('#endtime44').val(paramsType.selected);
                        }

                        $('#endtime44').material_select();
                    })
                } else {

                }

            },
            error: function (xhr, status, error) {

            },
        });
    });
}
