
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
var totaldcard_topimage216560043190_collectioncontainer = 0;
$(document).ready(function () {
    $('.page-content').css({
        'height': 'calc(100vh - 62px)',
        'overflow-y': 'scroll',
        'padding-bottom': '0px',
    });
    $('#servicedate').val(moment(new Date()).format('YYYY-MM-DD'));
    if ($('.view_list_record').length) { $('.view_list_record').show(); }
    localStorage.removeItem('objParamsList');
    if ($('.js-candlestick').length) $("input[type='checkbox']").candlestick({ 'on': 'Yes', 'off': 'No', 'nc': 'NA', 'default': 'NA', 'swipe': false, 'allowManualDefault': true });
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    skip = 0;
    let paramsType = {};
    paramsType.ajaXCallURL = ajaXCallURL;
    paramsType.tokenKey = tokenKey;
    paramsType.secretKey = secretKey;
    paramsType.functionName = 'getStafferListDetails';
    localStorage.setItem('objParamsList', JSON.stringify(paramsType));
    getStafferListDetails(paramsType);

    $(document).on('click', '.staffer_dcard', function () {
        let id = getParameterByName('serviceid');
        let stylishid = $(this).attr('stylishid');
        let name = $(this).attr('service');
        let mediaid = $(this).attr('mediaid');
        let custaddedservices = JSON.parse(localStorage.getItem('custaddedservices')) || [];
        const index = custaddedservices.findIndex(item => item.serviceid == id);
        if (index >= 0) {
            const data = custaddedservices[index];
            data.stylistid = stylishid;
            data.stylistid_name = name;
            data.mediaid = mediaid;
        }
        localStorage.setItem('custaddedservices', JSON.stringify(custaddedservices));
        let nextPage = 'app_servicepickdateandtime';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        return false;
    });

});//end of ready 2

function getStafferListDetails(objParamsList) {
    objParamsList.salonlocationid = getParameterByName('salonlocationid');
    objParamsList.rolename = 'stylist';
    objParamsList.queryMode = 'mylist';
    objParamsList.skip = skip;
    objParamsList.fetch = fetchRecord;
    const url = objParamsList.ajaXCallURL + '/booksy/getListDetails_Usermanagement61f91155baf7700fc434e1af_usermanagementlistweb_usermanagementlistwebKendoList';
    $('#display_loading').removeClass('hideme');
    $.ajax({
        url,
        type: 'POST',
        data: objParamsList,
        success: function (response) {
            if (response.status == 0) {
                stafferlistdcard_mobileView(response);
            }
        },
        error: function (error) {
            $('#display_loading').addClass('hideme');
            console.log(error);
        }
    })
}


function stafferlistdcard_mobileView(response) {
    var html = '';
    $('#display_loading').removeClass('hideme')
    if (response.data.length == 0 && !$('.staffer_dcard').length) {
        html += '<div class="mx-0 card card-style bg-secondary animated fadeInUp">';
        html += '    <div class="content">';
        html += '        <h2 class="text-center color-white my-4">No record Found!</h2>';
        html += '    </div>';
        html += '</div>';
        $('#stafferList').html(html);
        $('#display_loading').addClass('hideme');
    } else {
        html = '';
        var radioGroups = [];
        if (!response.showShimmer) {
            skip = skip + response.data.length;
        }
        $.each(response.data, function (keyList, objList) {
            let imgUrl = '';
            let mediaId = '';
            if (objList.userphotoupload && objList.userphotoupload[0].mediaID) {
                mediaId = objList.userphotoupload[0].mediaID;
                imgUrl = CDN_PATH + objList.userphotoupload[0].mediaID + '_compressed.png';
            }
            let name = objList['name'] ? objList['name'] : '';
            let status = objList['status'] ? objList['status'] : '';
            html += '<div class="card card-style mb-3 p-3">'
            html += '<div class="d-flex staffer_dcard align-items-center" stylishid="' + objList._id + '" service="' + name + '" mediaId="' + mediaId + '">';
            html += '    <div>';
            html += '        <img onerror="this.src =\'https://appscdn-us.hokuapps.com/card.png\'" src="' + imgUrl + '" class="rounded-circle shadow-xl" width="50" height="50" style="object-fit: cover;">';
            html += '    </div>';
            html += '    <div class="ms-3">';
            html += '        <div class="font-16 font-600 text-capitalize">' + name + '</div>';
            html += '        <div class="font-12 font-500 text-info">' + status + '</div>';
            html += '    </div>';
            html += '</div>';
            html += '</div>';
        });
        var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        $('#stafferList').append(html);
        $('#display_loading').addClass('hideme');
    };
};
