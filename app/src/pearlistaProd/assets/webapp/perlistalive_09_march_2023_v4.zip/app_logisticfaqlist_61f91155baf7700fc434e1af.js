
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
$(document).ready(function () {
    $('#display_loading').removeClass('hideme');
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    let objParamsList = {};
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.queryMode = queryMode;
    getfaqinfo(objParamsList);

    $(document).on('click', '.accordion-btn', function () {
        $(this).children('i').toggleClass('fa-rotate-180');
    })

});//end of ready 2

function getfaqinfo(objParamsList) {
    const url = objParamsList.ajaXCallURL + '/booksy/getListDetails_Faq61f91155baf7700fc434e1af_faqweb_faqwebKendoList';
    $.ajax({
        url,
        type: 'POST',
        data: objParamsList,
        success: function (response) {
            if (response.status == 0 && response.data && response.data.length > 0) {
                let html = '';
                $.each(response.data, function (keyList, objList) {
                    objList['question'] = objList['question'] ? objList['question'] : '';
                    let question = objList['question'];
                    objList['answer'] = objList['answer'] ? objList['answer'] : '';
                    let answer = $.trim(objList['answer']);
                    html += `
                    <div class="mb-0">
                        <button class="border-0 btn accordion-btn no-effect" data-bs-toggle="collapse" data-bs-target="#faq${keyList}">${question}
                            <i class="fa fa-chevron-down font-10 accordion-icon"></i>
                        </button>
                        <div id="faq${keyList}" class="collapse" data-bs-parent="#accordion-1">
                            <div class="answerdiv pt-1 pb-2 ps-3 pe-3">${answer}</div>
                        </div>
                    </div>`;
                });
                $('#accordion-1').html(html);
                $('#accordion-1').removeClass('hideme');
                $('#display_loading').addClass('hideme');
                $('.answerdiv p').css('margin', '0px');

            }
        },
        error: function (error) {
            console.log("error in getting privacy and policy : " + error);
            return;
        }
    })
}