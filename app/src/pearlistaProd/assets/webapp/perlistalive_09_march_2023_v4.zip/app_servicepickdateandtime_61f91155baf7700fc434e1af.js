var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
var toastMsg = [];
let arrPastTimes = [];
var dates = ["06/01/2023"];

var totaldcard_topimage216560043190_collectioncontainer = 0;
$(document).ready(function() {


    // $('.mydatepicker').val(moment(new Date()).format('DD MMMM, YYYY'));
    $('#servicetotalprice').html('$' + localStorage.getItem('total-price'));
    $('#servicetotaltime').html(localStorage.getItem('total-hours') + 'h ' + localStorage.getItem('total-minutes') + 'min');

    $('#servicedate').val(moment(new Date()).format('YYYY-MM-DD'));
    if ($('.view_list_record').length) {
        $('.view_list_record').show();
    }
    localStorage.removeItem('objParamsList');
    if ($('.js-candlestick').length) $("input[type='checkbox']").candlestick({
        'on': 'Yes',
        'off': 'No',
        'nc': 'NA',
        'default': 'NA',
        'swipe': false,
        'allowManualDefault': true
    });
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    let objParamsList = {};
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    objParamsList.isMobile = isMobile;
    getservicetimeslotlistdetails(objParamsList);
    const custaddedservices = JSON.parse(localStorage.getItem('custaddedservices')) || [];
    if (custaddedservices && custaddedservices.length) {
        makeServicesList(custaddedservices);
    }
    $(document).on('click', '#backbutton1', function(e) {
        var queryParams = queryStringToJSON();
        var nextPage = 'app_addbookingsalonlocation';
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        return false;
    });

    $(document).on('click', '.stafferList', function() {
        let nextPage = 'app_stylishlist';
        let serviceid = $(this).attr('id');
        var queryParams = queryStringToJSON();
        if (serviceid) queryParams['serviceid'] = serviceid;
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        return false;
    });

    $(document).on('click', '#addService', function() {
        let nextPage = 'app_serviceslist';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        return false;
    });

    $(document).on('click', '.removeService', function() {
        const id = $(this).attr('id');
        const currentService = JSON.parse(localStorage.getItem('custaddedservices')) || [];
        const _serviceArr = currentService.filter((item) => {
            return item.serviceid != id;
        });
        localStorage.setItem('custaddedservices', JSON.stringify(_serviceArr));

        let strHr = parseInt($(this).attr('data-hr').replace("h", ""));
        let strMin = parseInt($(this).attr('data-min').replace("min", ""));
        let strPrice = parseFloat($(this).attr('data-price'));

        let totalHours = parseInt(localStorage.getItem('total-hours')) - strHr;
        let totalMinutes = parseInt(localStorage.getItem('total-minutes')) - strMin;
        let totalPrice = parseFloat(localStorage.getItem('total-price')) - strPrice;

        var hours = Math.floor(totalMinutes / 60) + totalHours;
        var positivehours = Math.abs(hours);
        var minutes = totalMinutes % 60;
        var positiveminutes = Math.abs(minutes);

        localStorage.setItem('total-hours', positivehours);
        localStorage.setItem('total-minutes', positiveminutes);
        localStorage.setItem('total-price', totalPrice);

        $('#servicetotalprice').html('$' + totalPrice.toFixed(2));
        $('#servicetotaltime').html(positivehours + 'h ' + positiveminutes + 'min');

        makeServicesList(_serviceArr);
    });
    $(document).on('change', '#servicedate', function(e) {
        let objParamsList = {};
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.tokenKey = tokenKey;
        objParamsList.secretKey = secretKey;
        objParamsList.isMobile = isMobile;
        getservicetimeslotlistdetails(objParamsList);

    })

    $(document).on('click', '#confirmservice87', async function() {

        var objParams = localStorage.getItem('objParams');
        if (objParams) {
            objParams = JSON.parse(objParams);
        } else {
            objParams = {};
        }

        var starttimeid = $.trim($('#servicetime').val());
        if ($('#servicetime_div').is(':visible')) {
            if (starttimeid == '') {
                $('#servicetime_error').show();
                if (!Object.keys(errorFields).length) errorFields['servicetime'] = 'dropdown';
                validAll = false;
            } else {
                $('#servicetime_error').hide();
            }
        }
        var material_pattern = /^Select/;
        if ($("#servicetime option:selected").text() && $("#servicetime option:selected").text().match(material_pattern)) {
            var tmpvalsanitized = $("#servicetime option:selected").map(function() {
                return $(this).text();
            }).get().join(',').replace("Select Start Time,", "");
            tmpvalsanitized = tmpvalsanitized ? tmpvalsanitized.replace('Select,', '') : tmpvalsanitized;
            $('[id^=starttimeid_name]').val(tmpvalsanitized);
        } else {
            objParams.starttimeid_name = $("#servicetime option:selected").map(function() {
                return $(this).text();
            }).get().join(',');
            $('[id^=starttimeid_name]').val(objParams.starttimeid_name);
        }
        if (starttimeid) objParams.starttimeid = starttimeid;

        var hoursselected = localStorage.getItem('data-hours');
        var minutesselected = localStorage.getItem('data-minutes');

        console.log(hoursselected);
        console.log(minutesselected);

        var appointmentdate = $("#servicedate").val();
        var appointmentstarttime = $("#servicetime option:selected").text().replace("AM", " AM").replace("PM", " PM");
        var computeddate = moment(new Date(appointmentdate + ", " + appointmentstarttime)).format("DD-MMM-YYYY, hh:mm A");
        var computeddatenextdate = moment(new Date(computeddate)).add(hoursselected, 'hours').add(minutesselected, 'minutes').format("hh:mmA");

        let endTimeParams = {};
        endTimeParams.starttimeappointment = computeddatenextdate;
        // objParams.endtimeid_name = computeddatenextdate;
        // await calculateEndTime(endTimeParams);

        var endtimeid = $.trim($('#endtime44').val());
        if ($('#endtime44_div').is(':visible')) {
            if (endtimeid == '') {
                $('#endtime44_error').show();
                if (!Object.keys(errorFields).length) errorFields['endtime44'] = 'dropdown';
                validAll = false;
            } else {
                $('#endtime44_error').hide();
            }
        }

        if (endtimeid) {
            objParams.endtimeid = endtimeid;
        }


        var pax43 = $("#form5").val();
        objParams.pax = pax43;

        var date = $.trim($('#servicedate').val());
        if ($('#servicedate_div').is(':visible')) {
            if (date == '') {
                $('#servicedate_error').show();
                if (!Object.keys(errorFields).length) errorFields['servicedate'] = 'datecontrol';
                validAll = false;
            } else {
                $('#servicedate_error').hide();
            }
        }
        if (date) {
            objParams.date = date;
            objParams.datedisplaystring = date;
        }

        if (errorFields && Object.keys(errorFields).length) {
            $('#display_loading').addClass('hideme');
            for (var firstErrorField in errorFields) {
                var controlType = errorFields[firstErrorField];
                errorFields = []
                var errField = $('#' + firstErrorField);
                if (controlType == 'dropdown') {
                    errField.prev().prev().focus();
                } else {
                    errField.focus()
                }
                validAll = true;
                return false;
            }
        }
        if (!validAll) {
            validAll = true;
            return false;
        }
        var totalduration = $('#servicetotaltime').text();
        if (totalduration) objParams.totalduration = totalduration;

        objParams.mailsalonlocationid = localStorage.getItem('salonlocationid');
        objParams.salonlocationid_name = localStorage.getItem('salonlocationname');

        $('.confirmdate').html(date);
        $('.confirmduration').attr('totalduration', totalduration);
        $('.salonlocationname').html(localStorage.getItem('salonlocationname'));


        var custaddedservices = localStorage.getItem('custaddedservices');
        if (custaddedservices) {
            custaddedservices = JSON.parse(custaddedservices);
            let latestEndTime = '';
            custaddedservices.forEach((service, key) => {

                if (key == 0) {
                    service.starttime = objParams.starttimeid_name;
                    service.endtime = serviceEndTime(objParams.starttimeid_name, service);
                    latestEndTime = service.endtime;
                    latestEndTimeDisplay = service.endtime;



                } else {
                    service.starttime = latestEndTime;
                    service.endtime = serviceEndTime(latestEndTime, service);
                    latestEndTime = service.endtime;
                    latestEndTimeDisplay = service.endtime;

                    // objParams.endtimeid_name = service.endtime;

                }


            });
            localStorage.setItem('custaddedservices', JSON.stringify(custaddedservices))
        }
        localStorage.setItem('latestEndTimeDisplay', latestEndTimeDisplay)
        // $('.confirmduration').html(objParams.starttimeid_name + ' - ' + latestEndTimeDisplay + ' ('+ totalduration +')');


        localStorage.setItem('objParams', JSON.stringify(objParams));
        // check salon end date based on services
        // for Saturday and Sunday calculation
        var dayofweeknumber = moment(new Date($("#servicedate").val())).weekday();
        if (dayofweeknumber == 0 || dayofweeknumber == 6) {
            var starttimeslotecheck = moment().format('DD MMMM, YYYY') + " 05:00 PM";
        } else {
            var starttimeslotecheck = moment().format('DD MMMM, YYYY') + " " + salonendtime;
        }
        var endtimeslotecheck = moment().format('DD MMMM, YYYY') + " " + latestEndTimeDisplay.replace('AM', ' AM').replace('PM', ' PM');

        console.log(starttimeslotecheck);
        console.log(endtimeslotecheck);

        var momstarttimeslotecheck = moment(starttimeslotecheck);
        var momendtimeslotecheck = moment(endtimeslotecheck);

        var slotemindiffcheck = momendtimeslotecheck.diff(momstarttimeslotecheck, 'minutes');

        console.log(slotemindiffcheck);

        if (slotemindiffcheck > 0) {
            if (dayofweeknumber == 0 || dayofweeknumber == 6) {
                Materialize.toast('Salon is closed at 05:00 PM and your end time of service is ' + latestEndTimeDisplay.replace('AM', ' AM').replace('PM', ' PM') + ', Please select different time slot.', 2000);
            } else {
                Materialize.toast('Salon is closed at ' + salonendtime + ' and your end time of service is ' + latestEndTimeDisplay.replace('AM', ' AM').replace('PM', ' PM') + ', Please select different time slot.', 2000);
            }
        } else {

            // check slot available details
            var paramsServicesSlotCheck = {};
            paramsServicesSlotCheck.salonlocationid = localStorage.getItem('salonlocationid');
            if ($('#servicedate').val()) {
                paramsServicesSlotCheck.checkslotdatestart = moment(new Date($.trim($('#servicedate').val()))).startOf('day').utc().format('YYYY-MM-DDTHH:mm:ssZ');
                paramsServicesSlotCheck.checkslotdateend = moment(new Date($.trim($('#servicedate').val()))).endOf('day').utc().format('YYYY-MM-DDTHH:mm:ssZ');
            }
            var servicesarrslot = localStorage.getItem('custaddedservices');
            if (servicesarrslot) {
                paramsServicesSlotCheck.servicesarr = JSON.parse(servicesarrslot);
            }

            var arrPax = [];
            var pax43 = $("#form5").val();
            pax43 = parseInt(pax43);

            for (var i = 1; i <= pax43; i++) {
                arrPax.push(i);
            }
            paramsServicesSlotCheck.checkpax = arrPax;
            var ajaXCallURL = $.trim($('#ajaXCallURL').val());
            var queryMode = getParameterByName('queryMode');
            var tokenKey = getParameterByName('tokenKey');
            var secretKey = getParameterByName('secretKey');
            var isMobile = $.trim($('#isMobile').val());
            paramsServicesSlotCheck.queryMode = queryMode;
            paramsServicesSlotCheck.tokenKey = tokenKey;
            paramsServicesSlotCheck.secretKey = secretKey;
            paramsServicesSlotCheck.isMobile = isMobile;
            if (paramsServicesSlotCheck.servicesarr) {
                $('#display_loading').removeClass('hideme');
                $.ajax({
                    url: ajaXCallURL + '/booksy/checkoutappointmentschedularweb',
                    data: paramsServicesSlotCheck,
                    type: 'POST',
                    success: function(response) {
                        $('#display_loading').addClass('hideme');
                        if (response.status == 0) {

                            if (response.isfounderror == 0) {
                                // let newCustAddServices = [];
                                // arrPax.forEach((pax) => {
                                //     response.data.forEach((record) => {

                                //     // for(const pax of arrPax){
                                //         if(pax == 2){
                                //             record["pax"+pax] = pax.toString();
                                //         }
                                //         newCustAddServices.push({ ...record });    //push(record);
                                //         // console.log('######333333333 myloop pax : ',pax,record.pax);
                                //     });
                                //     console.log('######333333333 newCustAddServices : ',newCustAddServices);
                                // });

                                localStorage.setItem('custaddedservices', JSON.stringify(response.data));
                                addConfirmServiceCard();

                                let nextPage = 'app_confirmserviceslist';
                                var queryParams = queryStringToJSON();
                                var queryString = $.param(queryParams);
                                queryString = queryString.replace(/\+/g, "%20");
                                queryString = decodeURIComponent(queryString);
                                window.location.href = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
                                return false;

                                // $('#confimdetailsmodal').modal({dismissible:false});
                                // $('#confimdetailsmodal').modal('open');
                            } else {
                                toastMsg.push({
                                    type: 'warning',
                                    msg: 'Services that are selected by you have slots available to others, Please select different slots.'
                                })
                                var paramsType = {};
                                paramsType.salonlocationid = $('#recordID').val();
                                // getStartTime(paramsType);
                            }
                        } else {
                            toastMsg.push({
                                type: 'warning',
                                msg: 'No services are selected, Please select atleast one service.'
                            })

                        }

                    },
                    error: function(xhr, status, error) {
                        $('#display_loading').addClass('hideme');
                        toastMsg.push({
                            type: 'warning',
                            msg: 'No services are selected, Please select atleast one service.'
                        })


                    },
                });

            } else {
                toastMsg.push({
                    type: 'warning',
                    msg: 'No services are selected, Please select atleast one service.'
                })

            }
            $(document).ajaxStop(function() {
                if (toastMsg.length > 0) {
                    const type = toastMsg[0].type;
                    const message = toastMsg[0].msg;
                    showToast(type, message);
                    toastMsg = [];
                    return;
                }
            })



            // addConfirmServiceCard();
            // $('#confimdetailsmodal').modal({dismissible:false});
            // $('#confimdetailsmodal').modal('open');
        }



    });

    let paramsTypeHoliday = {};
    paramsTypeHoliday.isDelete = 0;
    if (localStorage.getItem('salonlocationid')) {
        paramsTypeHoliday.salonlocationid = localStorage.getItem('salonlocationid');
    }
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    paramsTypeHoliday.queryMode = queryMode;
    paramsTypeHoliday.tokenKey = tokenKey;
    paramsTypeHoliday.secretKey = secretKey;
    paramsTypeHoliday.isMobile = isMobile;
    $.ajax({
        url: ajaXCallURL + '/booksy/getListDetails_Holiday61f91155baf7700fc434e1af_holidaylistweb_holidaylistwebKendoList',
        data: paramsTypeHoliday,
        type: 'POST',
        success: function(response) {
            if (response.status == 0) {
                let arrHoliday = [];
                response.data.forEach(element => {
                    arrHoliday.push(moment(new Date(element.holidaydate)).format('YYYY-MM-DD'));
                });
                console.log(arrHoliday)
                $('.mydatepicker').datepicker({
                    format: 'yyyy-mm-dd',
                    // format: 'dd MM, yyyy',
                    startDate: moment(new Date()).format('YYYY-MM-DD'),
                    autoclose: true,
                    datesDisabled: arrHoliday
                });

            }
        },
        error: function(xhr, status, error) {},
    });


}); //end of ready 2

function renderStartDate() {
    arrPastTimes = [];
    var currentdate = moment();
    var selecteddatefuture = moment(new Date($("#servicedate").val()));

    if (selecteddatefuture > currentdate) {
        console.log("Future 123");
    } else {
        var startofdayv1 = moment().startOf('day');
        var calculatedminites = moment().diff(startofdayv1, 'minutes');
        console.log(calculatedminites);

        var addedalready = 0;
        if (calculatedminites > 0) {
            var calculatedminitesinter = Math.ceil(calculatedminites / 15);
            for (var i = 0; i < calculatedminitesinter; i++) {
                var cuculatedtimemoment = moment(new Date()).startOf('day').add(i * 15, 'minutes').format('hh:mmA');
                if (addedalready == 0) {
                    arrPastTimes.push(cuculatedtimemoment);
                }
            }
        } else {

        }
    }

    var paramsType = {};
    paramsType.salonlocationid = $('#recordID').val();
    getStartTime(paramsType);


}

function DisableDates(date) {
    var string = moment(date).format('dd/mm/yy');
    return [dates.indexOf(string) == -1];
}

function addConfirmServiceCard() {
    $('#confirmservicescard').html('');
    var getServices = localStorage.getItem('custaddedservices');
    var totalPrice = 0;
    var totalHours = 0;
    var totalMinutes = 0;
    if (getServices) {
        getServices = JSON.parse(getServices);

        var htmlMoreService = ''

        htmlMoreService += '<div style="margin: 10px 30px;background-color: #e9e9e9;border-radius: 8px;padding: 10px;">'

        getServices.forEach(element => {
            if (element.checkpax == 2) {

                //if(element.stylistid){
                //  htmlMoreService += '				<div id="modalservicedescription" style="font-size: 15;">'+ element.stylistid_name +'</div>'
            } else {
                element.serviceprice = parseFloat(element.serviceprice);
                htmlMoreService += '		<div class="row" style="margin: 5px;padding: 0px 10px 10px 10px;font-size: 16px;">'
                htmlMoreService += '			<div class="col s8" >'
                htmlMoreService += '				<div id="modalservicename" style="font-weight: bold;">' + element.servicename + '</div>'

                if (element.stylistid) {
                    htmlMoreService += '				<div id="modalservicedescription" style="font-size: 15;">' + element.stylistid_name + '</div>'
                    getServices.forEach(innerRecord => {
                        if (innerRecord.serviceid == element.serviceid && innerRecord.checkpax == 2) {
                            htmlMoreService += '				<div id="modalservicedescription" style="font-size: 15;">' + innerRecord.stylistid_name + '</div>'
                        }
                    });
                } else {
                    htmlMoreService += '				<div id="modalservicedescription" style="font-size: 15;">Anyone</div>'
                }

                htmlMoreService += '			</div>'
                htmlMoreService += '			<div class="col s4" style="text-align: right;">'
                htmlMoreService += '				<div id="modalserviceprice" style="font-weight: bold;">$' + element.serviceprice.toFixed(2) + '</div> '
                htmlMoreService += '				<div id="modalservicetime" style="font-size: 12px;">' + element.serviceduration + '</div>'
                htmlMoreService += '			</div>'
                htmlMoreService += '		</div>'
                htmlMoreService += '		<hr>'


                totalHours += parseInt(element.servicehours.replace("h", ""));
                totalMinutes += parseInt(element.serviceminuts.replace("min", ""));

                totalPrice += parseFloat(element.serviceprice);
            }
        });


        var hours = Math.floor(totalMinutes / 60) + totalHours;
        var minutes = totalMinutes % 60;

        htmlMoreService += '		<div class="row" style="margin: 5px;font-size: 16px;">'
        htmlMoreService += '			<div class="col s12" style="text-align: right;">'
        htmlMoreService += '				<div id="" style="">Total</div> '
        htmlMoreService += '				<div id="" style="font-size: 20px;font-weight:bold;">$' + totalPrice.toFixed(2) + '</div>'
        htmlMoreService += '				<div id="" style="font-size: 12px;">' + hours + 'h ' + minutes + 'min</div> '
        htmlMoreService += '			</div>'
        htmlMoreService += '		</div>'
        htmlMoreService += '	</div>'
        htmlMoreService += '	<div id="sg0827" class="row internalnote" style="margin: 10px 30px;">'
        htmlMoreService += '		<div id="sg1827" class="col s12">'
        htmlMoreService += '			<div style="" id="name21_div" class="input-field margin_bottom_5px  no_margin">'
        htmlMoreService += '				<i class="material-icons prefix " style="margin-top: 13px;font-size: 20px !important;">message</i>'
        htmlMoreService += '				<input id="additionalnote89" autocomplete="off" placeholder="Leave a note (optional)" style="border-radius: 5px !important;height: 40px !important;font-size: 16px !important;" id="name21" type="text" class="searchname input" >'
        htmlMoreService += '			</div>'
        htmlMoreService += '		</div>'
        htmlMoreService += '	</div>'



        $('#grandtotalservice').html('$' + totalPrice.toFixed(2));
        $('#grandtotalservice').attr('grandtotal', totalPrice.toFixed(2));
        $('#servicetotaltime').html(hours + 'h ' + minutes + 'min');
        localStorage.setItem('data-hours', hours);
        localStorage.setItem('data-minutes', minutes);
    }
    $('#confirmservicescard').append(htmlMoreService);


}

function serviceEndTime(starttime, service) {
    // let starttime = objParams.starttimeid_name;
    let [hours, allmin] = starttime.split(':');
    let allminarr = allmin.match(/.{1,2}/g);
    let minutes = allminarr[0]
    let ampm = allminarr[1];
    hours = parseInt(hours)
    minutes = parseInt(minutes)
    if (ampm == "PM" && hours < 12) hours = hours + 12;
    if (ampm == "AM" && hours == 12) hours = hours - 12;
    if (hours < 10) hours = "0" + hours;
    if (minutes < 10) minutes = "0" + minutes;

    let durationHours = parseInt(service.servicehours.replace('h', ''));
    let durationMinutes = parseInt(service.serviceminuts.replace('min', ''));
    hours = hours + durationHours
    minutes = minutes + durationMinutes
    if (hours >= 24) hours = hours - 24

    hours = Math.floor((minutes) / 60) + hours;
    minutes = (minutes) % 60;
    if (hours < 10) hours = "0" + hours;
    if (minutes < 10) minutes = "0" + minutes;


    var suffix = hours >= 12 ? "PM" : "AM";
    hours = (hours + 11) % 12 + 1;
    if (hours < 10) hours = "0" + hours;
    // if(minutes<10) minutes = "0" + minutes;
    finalTime = hours + ':' + minutes + suffix

    console.log(finalTime);

    return finalTime;
}

// renderStartDate();
function getservicetimeslotlistdetails(paramsType) {
    paramsType.salonlocationid = getParameterByName('salonlocationid');
    paramsType.checkslotdatestart = moment(new Date($.trim($('#servicedate').val()))).startOf('day').utc().format('YYYY-MM-DDTHH:mm:ssZ');
    paramsType.checkslotdateend = moment(new Date($.trim($('#servicedate').val()))).endOf('day').utc().format('YYYY-MM-DDTHH:mm:ssZ');
    const url = paramsType.ajaXCallURL + '/booksy/getfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_StartTime';
    $('#display_loading').removeClass('hideme');
    $.ajax({
        url,
        type: 'POST',
        data: paramsType,
        success: function(response) {
            if (response.status == 0 && response.data) {
                var arrSalonLocationHours = [];
                arrPastTimes = [];
                var currentdate = moment();
                var selecteddatefuture = moment(new Date($("#servicedate").val()));

                if (selecteddatefuture > currentdate) {
                    console.log("Future 123");
                } else {
                    var startofdayv1 = moment().startOf('day');
                    var calculatedminites = moment().diff(startofdayv1, 'minutes');
                    console.log(calculatedminites);

                    var addedalready = 0;
                    if (calculatedminites > 0) {
                        var calculatedminitesinter = Math.ceil(calculatedminites / 15);
                        for (var i = 0; i < calculatedminitesinter; i++) {
                            var cuculatedtimemoment = moment(new Date()).startOf('day').add(i * 15, 'minutes').format('hh:mmA');
                            if (addedalready == 0) {
                                arrPastTimes.push(cuculatedtimemoment);
                            }
                        }
                    } else {

                    }
                }

                if (paramsType.salonlocationid) {
                    var slonestartcount = 0;
                    $.each(response.data, function(keyList, objList) {
                        arrSalonLocationHours.push(objList.starttime);
                        slonestartcount++;
                        if (slonestartcount == 1) {
                            salonstarttime = objList.starttime.replace('AM', ' AM').replace('PM', ' PM');
                        }
                        if (response.data.length == slonestartcount) {
                            salonendtime = objList.starttime.replace('AM', ' AM').replace('PM', ' PM');
                        }
                    });
                }
                if (response.slotserviceslist) {
                    $.each(response.data, function(keySalonSlotList, objSalonSlotList) {
                        var totalCount = 0;
                        $.each(response.slotserviceslist, function(keySloteList, objSloteList) {
                            var arrSelectedservicesSlotsStylist = [];
                            $.each(objSloteList, function(keySloteServiceList, objSloteServiceList) {
                                if (objSloteServiceList.starttimeid_name && objSloteServiceList.endtimeid_name) {
                                    var starttimeslote = moment().format('DD MMMM, YYYY') + " " + objSloteServiceList.starttimeid_name.replace('AM', ' AM').replace('PM', ' PM');
                                    var endtimeslote = moment().format('DD MMMM, YYYY') + " " + objSloteServiceList.endtimeid_name.replace('AM', ' AM').replace('PM', ' PM');
                                    var momstarttimeslote = moment(starttimeslote);
                                    var momendtimeslote = moment(endtimeslote);
                                    var slotemindiff = momendtimeslote.diff(momstarttimeslote, 'minutes');
                                    if (slotemindiff > 0) {
                                        var slotemindiffinter = Math.ceil(slotemindiff / 15);
                                        var cuculatedtimemoment = moment(new Date(starttimeslote)).format('hh:mmA');
                                        arrSelectedservicesSlotsStylist.push(cuculatedtimemoment);
                                        for (var i = 1; i < slotemindiffinter; i++) {
                                            var cuculatedtimemoment = moment(new Date(starttimeslote)).add(i * 15, 'minutes').format('hh:mmA');
                                            arrSelectedservicesSlotsStylist.push(cuculatedtimemoment);
                                        }
                                    }
                                }
                            });
                            if (arrSelectedservicesSlotsStylist.indexOf(objSalonSlotList.starttime) >= 0) {
                                totalCount++;
                            }
                        });
                        if (totalCount == response.locationstylistcount) {
                            arrPastTimes.push(objSalonSlotList.starttime);
                        }
                    });
                }

                let custaddedservices = localStorage.getItem('custaddedservices');
                if (custaddedservices) {
                    custaddedservices = JSON.parse(custaddedservices);
                    let obj = {};
                    let servicehours = 0,
                        serviceminuts = 0;
                    $.each(custaddedservices, (key, val) => {
                        servicehours += parseInt(val.servicehours.replace(/\D/g, ''));
                        serviceminuts += parseInt(val.serviceminuts.replace(/\D/g, ''));
                    })
                    servicehours = servicehours + 'h';
                    serviceminuts = serviceminuts + 'min';
                    obj.servicehours = servicehours;
                    obj.serviceminuts = serviceminuts;
                    $.each(response.data, function(keyList, objList) {
                        let timeSlotArr = [];
                        if (custaddedservices !== "") {
                            let selectedServiceEndTimeTimeOnly = serviceEndTime(objList.starttime, obj);
                            let startTime = moment().format('DD MMMM, YYYY') + " " + objList.starttime.replace('AM', ' AM').replace('PM', ' PM')
                            var selectedServiceEndTime = moment().format('DD MMMM, YYYY') + " " + selectedServiceEndTimeTimeOnly.replace('AM', ' AM').replace('PM', ' PM')
                            let totalMinutes = moment(selectedServiceEndTime).diff(moment(startTime), 'minutes');
                            if (totalMinutes > 0) {
                                let slotemindiffinter = Math.ceil(totalMinutes / 15);
                                let cuculatedtimemoment = moment(new Date(startTime)).format('hh:mmA');
                                timeSlotArr.push(cuculatedtimemoment);
                                for (var i = 1; i < slotemindiffinter; i++) {
                                    let cuculatedtimemomentDiff = moment(new Date(startTime)).add(i * 15, 'minutes').format('hh:mmA');
                                    timeSlotArr.push(cuculatedtimemomentDiff);
                                }
                                $.each(timeSlotArr, (key, val) => {
                                    if (arrPastTimes.indexOf(val) >= 0) {
                                        arrPastTimes.push(objList.starttime);
                                    }
                                });
                                var dayofweeknumber = moment(new Date($("#servicedate").val())).weekday();
                                if (dayofweeknumber == 0 || dayofweeknumber == 6) {
                                    var starttimesloteone = moment(new Date($("#servicedate").val())).format('DD MMMM, YYYY') + " 05:00 PM";
                                    var endtimesloteone = moment(new Date($("#servicedate").val())).format('DD MMMM, YYYY') + " " + selectedServiceEndTimeTimeOnly.replace('AM', ' AM').replace('PM', ' PM');
                                } else {

                                    var starttimesloteone = moment(new Date($("#servicedate").val())).format('DD MMMM, YYYY') + " 08:00 PM";
                                    var endtimesloteone = moment(new Date($("#servicedate").val())).format('DD MMMM, YYYY') + " " + selectedServiceEndTimeTimeOnly.replace('AM', ' AM').replace('PM', ' PM');
                                }
                                console.log(starttimesloteone);
                                console.log(endtimesloteone);
                                var momstarttimesloteone = moment(starttimesloteone);
                                var momendtimesloteone = moment(endtimesloteone);
                                var slotemindiff = momendtimesloteone.diff(momstarttimesloteone, 'minutes');
                                console.log("####slotemindiff");
                                console.log(slotemindiff);
                                if (slotemindiff > 0) {
                                    arrPastTimes.push(objList.starttime);
                                }
                            }
                        }
                    });
                }

                var selectOptionHtml = '<option disabled selected value="">Select Start Time</option>';
                let datalength = response.data.length;
                $.each(response.data, function(keyList, objList) {
                    if (keyList < (datalength - 3)) {
                        // for Saturday and Sunday calculation
                        var dayofweeknumber = moment(new Date($("#servicedate").val())).weekday();
                        if (dayofweeknumber == 0 || dayofweeknumber == 6) {
                            var starttimesloteone = moment(new Date($("#servicedate").val())).format('DD MMMM, YYYY') + " 05:00 PM";
                            var endtimesloteone = moment(new Date($("#servicedate").val())).format('DD MMMM, YYYY') + " " + objList.starttime.replace('AM', ' AM').replace('PM', ' PM');
                            var momstarttimesloteone = moment(starttimesloteone);
                            var momendtimesloteone = moment(endtimesloteone);
                            var slotemindiff = momendtimesloteone.diff(momstarttimesloteone, 'minutes');
                            if (slotemindiff >= 0 || slotemindiff == -30 || slotemindiff == -15) {
                                arrPastTimes.push(objList.starttime);
                            }
                            if (slotemindiff >= 0 || slotemindiff == -30 || slotemindiff == -15) {} else {
                                // check pass values
                                if (arrPastTimes.indexOf(objList.starttime) >= 0) {
                                    selectOptionHtml += '<option  sequence="' + objList.sequence + '" value="' + objList._id + '" disabled style="background:#a7a7a7;color:#fff;">' + objList.starttime + '</option>';
                                } else {
                                    selectOptionHtml += '<option  sequence="' + objList.sequence + '" value="' + objList._id + '">' + objList.starttime + '</option>';
                                }
                            }
                        } else {
                            // check pass values
                            if (arrPastTimes.indexOf(objList.starttime) >= 0) {
                                selectOptionHtml += '<option  sequence="' + objList.sequence + '" value="' + objList._id + '" disabled style="background:#a7a7a7;color:#fff;">' + objList.starttime + '</option>';
                            } else {
                                selectOptionHtml += '<option  sequence="' + objList.sequence + '" value="' + objList._id + '">' + objList.starttime + '</option>';
                            }
                        }
                    }
                });
                $('#servicetime').html(selectOptionHtml); //2
                $('#display_loading').addClass('hideme');
            }
        },
        error: function(error) {
            console.log(error);
        }
    })
}

function makeServicesList(response) {
    let html = '';
    $.each(response, function(index, data) {
        let servicename = data['servicename'] ? data['servicename'] : '';
        let servicedescription = data['servicedescription'] ? data['servicedescription'] : '';
        let serviceprice = data['serviceprice'] ? data['serviceprice'] : '0';
        let serviceduration = data['serviceduration'] ? data['serviceduration'] : '';
        let stylistid_name = data['stylistid_name'] ? data['stylistid_name'] : '';
        let serviceid = data['serviceid'] ? data['serviceid'] : '';
        let mediaId = data['mediaid'] ? data['mediaid'] : '';
        let imgUrl = '';
        if (mediaId != '') {
            imgUrl = CDN_PATH + mediaId + '_compressed.png';
        }
        html += '<div class="card card-style mb-3 mx-0 overflow-visible">';
        html += '    <div class="content overflow-hidden">';
        html += '        <div class="d-flex gap-2 justify-content-between">';
        html += '            <div>';
        html += '                <h3 class="text-capitalize">' + servicename + '</h3>';
        html += `                <p class="lh-base"> ${servicedescription === "undefined" ? '' : servicedescription} </p>`;
        html += '            </div>';
        html += '            <div class="text-nowrap text-end">';
        html += '                <strong class="color-black">$' + serviceprice + '</strong>';
        html += '                <div class="">' + serviceduration + '</div>';
        html += '            </div>';
        html += '        </div>';
        html += '       <div class="divider my-2"></div>';
        html += '       <div class="d-flex justify-content-between align-items-center">';
        html += '           <div class="d-flex align-items-center justify-content-start">';
        html += '               <img onerror="this.src =\'https://appscdn-us.hokuapps.com/card.png\'" src="' + imgUrl + '" style="object-fit: cover;min-width:40px;min-height:40px;width:40px;height:40px;" class="rounded-circle">';
        html += '               <h6 class="ps-2">' + stylistid_name + '</h6>';
        html += '           </div>';
        // html += '           <div>';
        html += '               <a id="' + serviceid + '" class="stafferList btn bg-green-dark py-1 px-2 font-12 rounded-xl">Change</a>';
        // html += '           </div>';
        html += '       </div>';
        html += '    </div>';
        if (response.length > 1) {
            html += '    <div id="' + serviceid + '" data-hr="' + data.servicehours + '" data-min="' + data.serviceminuts + '" data-price="' + data.serviceprice + '" class="position-fixed removeService" style="top: -5px;right:-5px;"><i class="fa fa-circle-xmark color-highlight font-22"></i></div>';
        }

        html += '</div>';
    });
    $('#selectedservices').html(html);
}


function showToast(type, msg) {
    if (type == 'success') {
        $('#messagetoast').addClass('success_msg');
        $('#toastBody').html('<i class="fa fa-check-circle me-2"></i>' + msg);
    } else if (type == 'error') {
        $('#messagetoast').addClass('error_msg');
        $('#toastBody').html('<i class="fa fa-xmark-circle me-2"></i>' + msg);
    } else if (type == 'warning') {
        $('#messagetoast').addClass('warning_msg');
        $('#toastBody').html('<i class="fa fa-circle-exclamation me-2"></i>' + msg);
    }
    $('#messagetoast').toast('show');
    toastMsg = [];
}
