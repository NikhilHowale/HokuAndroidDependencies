
var dropdownvalues = {};
var custaddedservices = [];
var salonLocatioName = '';
var currChangeServiceId = '';
var arrPastTimes = [];
var arrHoliday = [];
var salonstarttime = "";
var salonendtime = "";
let latestEndTimeDisplay = '';
var mainTopStylistID = "";

var daysArr = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
$(document).ready(function () {
    localStorage.setItem('custaddedservices', '');
    localStorage.setItem('total-price', '');
    localStorage.setItem('total-minutes', '');
    localStorage.setItem('total-hours', '');
    localStorage.setItem('objParams', '');
    $('#endtime44').prop('disabled', true);
    //   var locationParams = {};
    //   getSearchBySalonLocation(locationParams);
    var paramsService = {};
    paramsService.salonlocationid = getParameterByName('recordID');
    var salonLocationParams = {};
    getSalonLocationById(salonLocationParams);
    //   getService(paramsService);
    var staffParams = {};
    staffParams.salonlocationid = getParameterByName('recordID');
    staffParams.rolename = 'stylist';
    staffParams.queryMode = 'mylist';
    getStaff(staffParams);

    var categoryserviceparams = {}
    categoryserviceparams.queryMode = 'mylist';
    categoryserviceparams.salonaddressid = getParameterByName('recordID');

    getCategoryServices(categoryserviceparams);

    var serviceTimeParams = {};
    serviceTimeParams.queryMode = 'mylist';
    serviceTimeParams.salonlocationid = getParameterByName('recordID');
    serviceTimeParams.recordID = getParameterByName('recordID');
    serviceTimeParams.fetch = 50;

    getServiceTime(serviceTimeParams);

    $(document).on('change', '#salonlocationid44', function () {

        var selectedlocationid = $('#salonlocationid44').val();
        var paramsServiceType = {};
        paramsServiceType.salonlocationid = selectedlocationid;
        // getService(paramsServiceType);
        // getStaff(paramsServiceType);
        getStartTime(paramsServiceType);

        $('#sg20761').removeClass('hide');
        // $('#sg20762').removeClass('hide');
        $('#sg20763').removeClass('hide');
        $('#sg20764').removeClass('hide');
        $('#sg20765').removeClass('hide');
        $('#sg20766').removeClass('hide');
        $('#sg20767').removeClass('hide');
        $('#sg20768').removeClass('hide');

    });

    var addSessionComments = [];
    var errorFields = [];
    var validAll = true;
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('click', '#saveguest37', function () {
        var recordID = $(this).attr('recordID');
        window.location.href = '/booksy/addservices/' + $('#tokenKey').val() + '/mylistedit/' + recordID;
        return false;
    });//end of Event 


    $(document).on('click', '#backtopearlista', function () {
        var recordID = $(this).attr('recordID');
        window.location.href = "https://pearlista.net/pages/appointment";
        return false;
    });//end of Event

    $(document).on('click', '#backtolocation45', function () {
        var recordID = $(this).attr('recordID');
        window.location.href = '/booksy/bookyourappointment/' + $('#tokenKey').val() + '/mylistedit/';
        return false;
    });//end of Event 

    $(document).on('click', '.back-button', ()=>{
        let queryMode = getParameterByName('queryMode');
        let tokenKey = getParameterByName('tokenKey');
        let secretKey = getParameterByName('secretKey');
        window.location = 'app_addbooking_61f91155baf7700fc434e1af.html?queryMode='+ queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
    });

    $(document).on('click', '#bookappointment', function () {
        var currRecordID = $(this).attr('recordID');
        var currServiceName = $(this).attr('data-servicename');
        var currCategoryId = $(this).attr('data-categoryid');
        var currcurrCategoryIdName = $(this).attr('data-categoryid_name');
        var currServicePrice = $(this).attr('data-serviceprice');
        var currServiceDescription = $(this).attr('data-servicedescription');
        var currServiceDuration = $(this).attr('data-serviceduration');
        var currServiceHours = $(this).attr('data-servicehours');
        var currServiceMinuts = $(this).attr('data-serviceminuts');
        var currSalonlocationid = localStorage.getItem('salonlocationid');
        var currSalonlocationname = localStorage.getItem('salonlocationname');

        var objParams = localStorage.getItem('objParams');
        if(objParams){
            objParams = JSON.parse(objParams);
        } else {
            objParams = {};
        }
        objParams.categoryid = currCategoryId;
        objParams.categoryid_name = currcurrCategoryIdName;
        localStorage.setItem('objParams',JSON.stringify(objParams));
        
        var serviceObj = {};
        currServicePrice = parseFloat(currServicePrice);
        serviceObj.serviceid = currRecordID;
        serviceObj.servicename = currServiceName;
        serviceObj.categoryid = currCategoryId;
        serviceObj.categoryid_name = currcurrCategoryIdName;
        serviceObj.servicedescription = currServiceDescription;
        serviceObj.serviceprice = currServicePrice.toFixed(2);
        serviceObj.serviceduration = currServiceDuration;
        serviceObj.servicehours = currServiceHours;
        serviceObj.serviceminuts = currServiceMinuts;
        serviceObj.salonlocationid = currSalonlocationid;
        serviceObj.salonlocationid_name = currSalonlocationname;
        serviceObj.stylistid_name = "Anyone";

        custaddedservices.push(serviceObj);
        localStorage.setItem('custaddedservices', JSON.stringify(custaddedservices));

        localStorage.setItem('data-hours', parseInt(currServiceHours));
        localStorage.setItem('data-minutes', parseInt(currServiceMinuts));

        localStorage.setItem('total-hours', parseInt(currServiceHours));
        localStorage.setItem('total-minutes', parseInt(currServiceMinuts));
        localStorage.setItem('total-price', currServicePrice.toFixed(2));

        var nextPage = 'app_servicepickdateandtime';
        var queryParams = queryStringToJSON();
        if (currSalonlocationid) queryParams['salonlocationid'] = currSalonlocationid;
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        return false;
        console.log(nextPage + queryString);
        // $('.deleteserviceitem').html(currRecordID);
        // $('#modalservicename').html(currServiceName);
        // if (currServiceDescription !== "undefined") {
        //     $('#modalservicedescription').html(currServiceDescription);
        // } else {
        //     $('#modalservicedescription').html('-');
        // }

        // $('#modalserviceprice').html('$' + serviceObj.serviceprice);
        // $('#modalservicetime').html(currServiceDuration);

        // $('#servicetotalprice').html('$' + serviceObj.serviceprice);
        // $('#servicetotaltime').html(currServiceDuration);

        // addServiceCard();

        // var paramsType = {};
        // paramsType.salonlocationid = getParameterByName('recordID');
        // getStartTime(paramsType);

        // $('#pickdatetime').modal({ dismissible: false });
        // $('#pickdatetime').modal('open');
    });




    $(document).on('click', '.bookmoreappointment', function () {

        $('#starttimeid43').val('');
        $('#starttimeid43').change();
        var currRecordID = $(this).attr('recordID');
        var currServiceName = $(this).attr('data-servicename');
        var currCategoryId = $(this).attr('data-categoryid');
        var currcurrCategoryIdName = $(this).attr('data-categoryid_name');
        var currServicePrice = $(this).attr('data-serviceprice');
        var currServiceDescription = $(this).attr('data-servicedescription');
        var currServiceDuration = $(this).attr('data-serviceduration');
        var currServiceHours = $(this).attr('data-servicehours');
        var currServiceMinuts = $(this).attr('data-serviceminuts');
        var currSalonlocationid = localStorage.getItem('salonlocationid');
        var currSalonlocationname = localStorage.getItem('salonlocationname');
        console.log(currServicePrice);
        return;
        var floatPrice = parseFloat(currServicePrice);
        var serviceObj = {};
        serviceObj.serviceid = currRecordID;
        serviceObj.servicename = currServiceName;
        serviceObj.categoryid = currCategoryId;
        serviceObj.categoryid_name = currcurrCategoryIdName;
        serviceObj.servicedescription = currServiceDescription;
        serviceObj.serviceprice = floatPrice.toFixed(2)
        serviceObj.serviceduration = currServiceDuration;
        serviceObj.servicehours = currServiceHours;
        serviceObj.serviceminuts = currServiceMinuts;
        serviceObj.salonlocationid = currSalonlocationid;
        serviceObj.salonlocationid_name = currSalonlocationname;
        serviceObj.stylistid_name = "Anyone";

        var getServices = localStorage.getItem('custaddedservices');
        if (getServices) {
            getServices = JSON.parse(getServices);
            console.log(getServices);
            if (getServices[0].serviceid !== currRecordID) {
                // console.log("element doesn't exist");
                getServices.push(serviceObj);
                localStorage.setItem('custaddedservices', JSON.stringify(getServices));
                addServiceCard();
            }
        }
        $('#moreservicemodal').modal({ dismissible: false });
        $('#moreservicemodal').modal('close');

        var paramsType = {};
        paramsType.salonlocationid = getParameterByName('recordID');
        getStartTime(paramsType);

    });


    $(document).on('click', '.deleteserviceitem', function () {
        $('#starttimeid43').val('');
        $('#starttimeid43').change();
        var getServices = localStorage.getItem('custaddedservices');
        var currRecordID = $(this).attr('recordID');
        if (getServices) {
            getServices = JSON.parse(getServices);
            console.log(getServices);
            getServices.forEach((element, key) => {
                if (element.serviceid == currRecordID) {
                    console.log(key);
                    // delete getServices[key]
                    getServices.splice(0, 1);
                }
            });
            console.log(getServices);
            if (getServices.length == 1) {
                localStorage.setItem('custaddedservices', JSON.stringify(getServices));
                addServiceCard();
                $('#deleteserviceitem' + getServices[0].serviceid).hide();
            } else {
                localStorage.setItem('custaddedservices', JSON.stringify(getServices));
                addServiceCard();
            }

        }
    });

    $(document).on('click', '#addmoreservice', function () {
        var categoryserviceparams = {}
        categoryserviceparams.queryMode = 'mylist';
        categoryserviceparams.salonaddressid = getParameterByName('recordID');

        getCategoryModalServices(categoryserviceparams);
        $('#moreservicemodal').modal({ dismissible: false });
        $('#moreservicemodal').modal('open');
    });


    $(document).on('click', '#confirmandbook87', function () {

        var objParams = localStorage.getItem('objParams');
        if (objParams) {
            objParams = JSON.parse(objParams);

            var internalnote = $.trim($('#additionalnote89').val());
            if (internalnote) objParams.internalnote = internalnote;

            localStorage.setItem('objParams', JSON.stringify(objParams));
        }

        $('#confimandbookmodal').modal({ dismissible: false });
        $('#confimandbookmodal').modal('open');



    });

    $(document).on('click', '#submitappointment658', function () {
        $('#display_loading').removeClass('hideme');
        var recordID = getParameterByName('recordID');
        var hasModalPopup = 'articlemodal'
        hasModalPopup = hasModalPopup.toLowerCase();

        var objParams = localStorage.getItem('objParams');
        if (objParams) {
            objParams = JSON.parse(objParams);

            objParams.isDelete = 0;
            var clientid_name = $.trim($('#customername57').val());
            if ($('#customername57_div').is(':visible')) {
                if (clientid_name == '') {
                    $('#customername57_error').show();
                    if (!Object.keys(errorFields).length) errorFields['customername57'] = 'dropdown';
                    validAll = false;
                } else {
                    $('#customername57_error').hide();
                }
            }
            if (clientid_name) objParams.clientid_name = clientid_name;

            var contactnumber = $.trim($('#contactnumber45').val());
            if ($('#contactnumber45_div').is(':visible')) {
                if (contactnumber == '') {
                    $('#contactnumber45_error').show();
                    if (!Object.keys(errorFields).length) errorFields['contactnumber45'] = 'textbox';
                    validAll = false;
                } else {
                    $('#contactnumber45_error').hide();
                }
            }
            if ($('#contactnumber45_div').is(':visible')) {
                contactnumber = $.trim($('#contactnumber45').val());
                var dialCode = $('#contactnumber45').attr('dialCode');
                var countryCode = $('#contactnumber45').attr('countryCode');
                var placeholder = $('#contactnumber45').attr('placeholder');
                if (placeholder.length != contactnumber.length) {
                    $('#contactnumber45_error').html('Valid Phone Number is required').show();
                    $('#contactnumber45').fadeIn(1000);
                    errorFields.push('contactnumber45');
                }
                if (contactnumber) contactnumber = '+' + dialCode + contactnumber;
                objParams.contactnumber = contactnumber;
                objParams.contactnumber_dialcode = dialCode;
                objParams.contactnumber_countrycode = countryCode;
            }
            if ($('#contactnumber45_div').is(':visible')) {
                contactnumber = $.trim($('#contactnumber45').val());
                var dialCode = $('#contactnumber45').attr('dialCode');
                var countryCode = $('#contactnumber45').attr('countryCode');
                var placeholder = $('#contactnumber45').attr('placeholder');
                if (placeholder.length != contactnumber.length) {
                    $('#contactnumber45_error').html('Valid Phone Number is required').show();
                    $('#contactnumber45').fadeIn(1000);
                    errorFields.push('contactnumber45');
                }
                if (contactnumber) contactnumber = '+' + dialCode + contactnumber;
                objParams.contactnumber = contactnumber;
                objParams.contactnumber_dialcode = dialCode;
                objParams.contactnumber_countrycode = countryCode;
            }
            var email = $.trim($('#email28').val());
            if ($('#email28_div').is(':visible')) {
                if (email == '') {
                    $('#email28_error').show();
                    $('#email28_error').html('Email is required');
                    if (!Object.keys(errorFields).length) errorFields['email28'] = 'textbox';
                    validAll = false;
                } else if (!isEmail(email)) {
                    $('#email28_error').html('Please enter valid email').show();
                    if (!Object.keys(errorFields).length) errorFields['email28'] = 'textbox';
                    validAll = false;
                } else {
                    $('#email28_error').hide();
                }
            }
            if (email) objParams.email = email;

            objParams.externalbooking = true;



            var servicesarr = localStorage.getItem('custaddedservices');
            if (servicesarr) {
                servicesarr = JSON.parse(servicesarr);
                objParams.servicesarr = servicesarr;
                objParams.serviceid = servicesarr[0].serviceid;
                objParams.serviceid_name = servicesarr[0].servicename;
                objParams.categoryid = servicesarr[0].categoryid;
                objParams.categoryid_name = servicesarr[0].categoryid_name;
                objParams.staffid = servicesarr[0].stylistid;
                objParams.staffid_name = servicesarr[0].stylistid_name;
                objParams.endtimeid = servicesarr[0].endtimeid;
                objParams.endtimeid_name = servicesarr[0].endtimeid_name;
            }
        }

        objParams.ispublicrequest = 1;
        objParams.salonlocationame = salonLocatioName;
        objParams.totalduration = $('.confirmduration').attr('totalduration');
        objParams.grandtotal = parseFloat($('#grandtotalservice').attr('grandtotal'));
        objParams.offlineDataID = localStorage.getItem("offlineDataID");
        var queryMode = $('#queryMode').val();
        objParams.endtimeid_name = latestEndTimeDisplay;


        objParams.checkslotdatestart = moment(new Date($.trim($('#date42').val()))).startOf('day').utc().format('YYYY-MM-DDTHH:mm:ssZ');
        objParams.checkslotdateend = moment(new Date($.trim($('#date42').val()))).endOf('day').utc().format('YYYY-MM-DDTHH:mm:ssZ');


        var createNew = false;
        // if (recordIDForUpdate == '') {
        objParams.callUrl = '/booksy/saveAjaxappointmentappointmentschedularweb';
        //     var createNew = true;
        // } else {
        //     objParams.callUrl = '/booksy/updateAjaxappointmentappointmentschedularweb';
        //     objParams.updatedslotsID = JSON.parse(localStorage.getItem("Slots"));
        //     objParams.recordID = recordIDForUpdate;
        // }
        if (errorFields && Object.keys(errorFields).length) {
            $('#display_loading').addClass('hideme');
            for (var firstErrorField in errorFields) {
                var controlType = errorFields[firstErrorField];
                errorFields = []
                var errField = $('#' + firstErrorField);
                if (controlType == 'dropdown') {
                    errField.prev().prev().focus();
                } else {
                    errField.focus()
                }
                validAll = true;
                return false;
            }
        }
        if (!validAll) {
            validAll = true;
            return false;
        }
        $('#submitappointment658').prop('disabled', true);
        $('#display_loading').removeClass('hideme');
        if (addSessionComments.length > 0) {
            objParams.addSessionComments = addSessionComments;
        } else {
            objParams.addSessionComments = [];
        }
        var parentID = $('#parentID').val();
        var parentName = $('#parentName').val();
        if (parentID != '') {
            objParams.parentID = parentID;
            objParams.parentName = parentName
        } else { }
        if (typeof (addedFiles) != "undefined" && addedFiles && addedFiles.length > 0) {
            objParams.addedFiles = addedFiles;
        }
        //convert12To24Hours
        objParams.salonlocationidcheck = getParameterByName('recordID');
        // objParams.startdate = 
        objParams.isCheckAppointmentExists = 1;
        objParams.datestring = $.trim($('#date42').val());
        // check slot is already assigned
        // if (recordIDForUpdate == '') {

        // } else {

        // var paramsCheck = {};
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());

        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParams.ajaXCallURL = ajaXCallURL;


        var queryMode = getParameterByName('queryMode');
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');

        objParams.tokenKey = tokenKey;
        objParams.secretKey = secretKey;
        objParams.queryMode = queryMode;


        var callUrl = objParams.ajaXCallURL + '/booksy/get_data_by_record_Appointment61f91155baf7700fc434e1afappointmentschedularweb';
        $.ajax({
            url: callUrl,
            data: objParams,
            type: 'POST',
            success: function (responseCheckExists) {
                $('#display_loading').addClass('hideme');
                $('#submitappointment658').prop('disabled', false);
                if (responseCheckExists.status != undefined && responseCheckExists.status == 2) {
                    // window.location.reload();
                    Materialize.toast('There is holiday on that date for that Location.', 3000);
                    // } else if (responseCheckExists.status != undefined && responseCheckExists.status == 0 && responseCheckExists.recordDetails != undefined) {
                    //     // window.location.reload();
                    //     Materialize.toast('Selected staff is already booked for this slot, please select a different slot or change staff.', 2000);
                } else {
                    processBeforeCallForSaveappointmentappointmentschedularweb_61f91155baf7700fc434e1af(objParams, function (processBeforeRes) {
                        $.ajax({
                            url: objParams.callUrl,
                            data: objParams,
                            type: 'POST',
                            success: function (response) {
                                if (response.status == 0) { //appointmentnumber
                                    $('#display_loading').addClass('hideme');

                                    processAfterCallForSaveappointmentappointmentschedularweb_61f91155baf7700fc434e1af(objParams, response, function (processAfterRes) {

                                        var tokenKey = $('#tokenKey').val();
                                        $('#submitappointment658').prop('disabled', false);
                                        recordIDForUpdate = ""
                                        $('#submitappointment658').removeProp('disabled');
                                        var objParamsList = {};
                                        objParamsList.queryMode = $('#queryMode').val();
                                        objParamsList.tokenKey = $('#tokenKey').val();
                                        objParamsList.isMobile = $('#isMobile').val();

                                        // defaultServiceEntry(response, response.data._id);

                                        $('#staffid49').val("");

                                        $('#test16').val("");
                                        $('#serviceid_name33').val("");
                                        $('#slotid_name41').val("");
                                        $('#clientid_name37').val("");
                                        $('#clientid36').val("");
                                        $('#staffid45').val("");
                                        $('#serviceid41').val("");
                                        $('#date42').val("");
                                        $('#starttimeid43').val("");
                                        $('#endtime44').val("");
                                        $('#slotid41').val("");
                                        $('#endtime44').val("");
                                        $('#internalnote39').val("");
                                        $('#messageforclient40').val("");
                                        $('#schedulingnumber45').val("");
                                        $('#duration34').val("");
                                        $('#starttimeid_name45').val("");
                                        $('#endtimeid_name46').val("");
                                        $('#price35').val("");
                                        $('#serviceid41').material_select();

                                        // window.location.href = '/booksy/thankyouguest/' + $('#tokenKey').val() + '/add'

                                        // show_555555555
                                        // show_appointmentschedularwebappointment_Details(objParamsList);

                                        $('#bookeddate').html(response.data.datestring + ' ' + response.data.starttimeid_name)
                                        $('#pickdatetime').modal('close')
                                        $('#confimdetailsmodal').modal('close')
                                        $('#confimandbookmodal').modal('close')
                                        $('#appointmentbookedmodal').modal({ dismissible: false })
                                        $('#appointmentbookedmodal').modal('open')
                                        return false;
                                    }); // End of After Process
                                } else {
                                    $('#display_loading').addClass('hideme');
                                    if (!$('.saveerror').length) {
                                        $('a[id^="save"]').closest('.row').prepend('<p class="saveerror"></p>')
                                    }
                                    $('.saveerror').html(response.error);
                                    $('.saveerror').show();
                                }
                                $('#submitappointment658').removeProp('disabled');
                            },
                            error: function (xhr, status, error) {
                                $('#display_loading').addClass('hideme');
                                $('#submitappointment658').removeProp('disabled');
                            },
                        });
                        return false;
                    }); // End of process
                }
            },
            error: function (xhr, status, error) {

            },
        });
        return false;
        // }

    }); //end of Event 

    $(document).on('click', '.discardservices', function () {
        $('#discardservicemodal').modal({ dismissible: false });
        $('#discardservicemodal').modal('open');
    });

    $(document).on('click', '#discardbtn', function () {
        $('#display_loading').removeClass('hideme');

        window.location.reload();
    });

    $(document).on('click', '#confirmservice87', async function () {

        var objParams = localStorage.getItem('objParams');
        if (objParams) {
            objParams = JSON.parse(objParams);
        } else {
            objParams = {};
        }

        var starttimeid = $.trim($('#starttimeid43').val());
        if ($('#starttimeid43_div').is(':visible')) {
            if (starttimeid == '') {
                $('#starttimeid43_error').show();
                if (!Object.keys(errorFields).length) errorFields['starttimeid43'] = 'dropdown';
                validAll = false;
            } else {
                $('#starttimeid43_error').hide();
            }
        }
        var material_pattern = /^Select/;
        if ($("#starttimeid43 option:selected").text() && $("#starttimeid43 option:selected").text().match(material_pattern)) {
            var tmpvalsanitized = $("#starttimeid43 option:selected").map(function () {
                return $(this).text();
            }).get().join(',').replace("Select Start Time,", "");
            tmpvalsanitized = tmpvalsanitized ? tmpvalsanitized.replace('Select,', '') : tmpvalsanitized;
            $('[id^=starttimeid_name]').val(tmpvalsanitized);
        } else {
            objParams.starttimeid_name = $("#starttimeid43 option:selected").map(function () {
                return $(this).text();
            }).get().join(',');
            $('[id^=starttimeid_name]').val(objParams.starttimeid_name);
        }
        if (starttimeid) objParams.starttimeid = starttimeid;

        var hoursselected = localStorage.getItem('data-firsthours');
        var minutesselected = localStorage.getItem('data-firstminutes');

        console.log(hoursselected);
        console.log(minutesselected);

        var appointmentdate = $("#date42").val();
        var appointmentstarttime = $("#starttimeid43 option:selected").text().replace("AM", " AM").replace("PM", " PM");
        var computeddate = moment(new Date(appointmentdate + ", " + appointmentstarttime)).format("DD-MMM-YYYY, hh:mm A");
        var computeddatenextdate = moment(new Date(computeddate)).add(hoursselected, 'hours').add(minutesselected, 'minutes').format("hh:mmA");

        let endTimeParams = {};
        endTimeParams.starttimeappointment = computeddatenextdate;
        // objParams.endtimeid_name = computeddatenextdate;
        // await calculateEndTime(endTimeParams);

        var endtimeid = $.trim($('#endtime44').val());
        if ($('#endtime44_div').is(':visible')) {
            if (endtimeid == '') {
                $('#endtime44_error').show();
                if (!Object.keys(errorFields).length) errorFields['endtime44'] = 'dropdown';
                validAll = false;
            } else {
                $('#endtime44_error').hide();
            }
        }
        // var material_pattern = /^Select/;
        // if ($("#endtime44 option:selected").text() && $("#endtime44 option:selected").text().match(material_pattern)) {
        //     var tmpvalsanitized = $("#endtime44 option:selected").map(function () {
        //         return $(this).text();
        //     }).get().join(',').replace("Select End Time,", "");
        //     tmpvalsanitized = tmpvalsanitized ? tmpvalsanitized.replace('Select,', '') : tmpvalsanitized;
        //     $('[id^=endtimeid_name]').val(tmpvalsanitized);
        // } else {
        //     objParams.endtimeid_name = $("#endtime44 option:selected").map(function () {
        //         return $(this).text();
        //     }).get().join(',');
        //     $('[id^=endtimeid_name]').val(objParams.endtimeid_name);
        // }
        if (endtimeid) {
            objParams.endtimeid = endtimeid;
        }


        var pax43 = $("#pax43").val();
        objParams.pax = pax43;

        var date = $.trim($('#date42').val());
        if ($('#date42_div').is(':visible')) {
            if (date == '') {
                $('#date42_error').show();
                if (!Object.keys(errorFields).length) errorFields['date42'] = 'datecontrol';
                validAll = false;
            } else {
                $('#date42_error').hide();
            }
        }
        if (date) {
            objParams.date = date;
            objParams.datedisplaystring = date;
        }

        if (errorFields && Object.keys(errorFields).length) {
            $('#display_loading').addClass('hideme');
            for (var firstErrorField in errorFields) {
                var controlType = errorFields[firstErrorField];
                errorFields = []
                var errField = $('#' + firstErrorField);
                if (controlType == 'dropdown') {
                    errField.prev().prev().focus();
                } else {
                    errField.focus()
                }
                validAll = true;
                return false;
            }
        }
        if (!validAll) {
            validAll = true;
            return false;
        }
        var totalduration = $('#servicetotaltime').text();
        if (totalduration) objParams.totalduration = totalduration;

        objParams.mailsalonlocationid = localStorage.getItem('salonlocationid');
        objParams.salonlocationid_name = salonLocatioName;

        $('.confirmdate').html(date);
        $('.confirmduration').attr('totalduration', totalduration);
        $('.salonlocationname').html(salonLocatioName);


        var custaddedservices = localStorage.getItem('custaddedservices');
        if (custaddedservices) {
            custaddedservices = JSON.parse(custaddedservices);
            let latestEndTime = '';
            custaddedservices.forEach((service, key) => {

                if (key == 0) {
                    service.starttime = objParams.starttimeid_name;
                    service.endtime = serviceEndTime(objParams.starttimeid_name, service);
                    latestEndTime = service.endtime;
                    latestEndTimeDisplay = service.endtime;



                } else {
                    service.starttime = latestEndTime;
                    service.endtime = serviceEndTime(latestEndTime, service);
                    latestEndTime = service.endtime;
                    latestEndTimeDisplay = service.endtime;

                    // objParams.endtimeid_name = service.endtime;

                }


            });
            localStorage.setItem('custaddedservices', JSON.stringify(custaddedservices))
        }

        $('.confirmduration').html(objParams.starttimeid_name + ' - ' + latestEndTimeDisplay + ' (' + totalduration + ')');


        localStorage.setItem('objParams', JSON.stringify(objParams));
        // check salon end date based on services
        // for Saturday and Sunday calculation
        var dayofweeknumber = moment(new Date($("#date42").val())).weekday();
        if (dayofweeknumber == 0 || dayofweeknumber == 6) {
            var starttimeslotecheck = moment().format('DD MMMM, YYYY') + " 05:00 PM";
        } else {
            var starttimeslotecheck = moment().format('DD MMMM, YYYY') + " " + salonendtime;
        }
        var endtimeslotecheck = moment().format('DD MMMM, YYYY') + " " + latestEndTimeDisplay.replace('AM', ' AM').replace('PM', ' PM');

        console.log(starttimeslotecheck);
        console.log(endtimeslotecheck);

        var momstarttimeslotecheck = moment(starttimeslotecheck);
        var momendtimeslotecheck = moment(endtimeslotecheck);

        var slotemindiffcheck = momendtimeslotecheck.diff(momstarttimeslotecheck, 'minutes');

        console.log(slotemindiffcheck);

        if (slotemindiffcheck > 0) {
            if (dayofweeknumber == 0 || dayofweeknumber == 6) {
                Materialize.toast('Salon is closed at 05:00 PM and your end time of service is ' + latestEndTimeDisplay.replace('AM', ' AM').replace('PM', ' PM') + ', Please select different time slot.', 2000);
            } else {
                Materialize.toast('Salon is closed at ' + salonendtime + ' and your end time of service is ' + latestEndTimeDisplay.replace('AM', ' AM').replace('PM', ' PM') + ', Please select different time slot.', 2000);
            }
        } else {

            // check slot available details
            var paramsServicesSlotCheck = {};
            paramsServicesSlotCheck.salonlocationid = getParameterByName('recordID');
            if ($('#date42').val()) {
                paramsServicesSlotCheck.checkslotdatestart = moment(new Date($.trim($('#date42').val()))).startOf('day').utc().format('YYYY-MM-DDTHH:mm:ssZ');
                paramsServicesSlotCheck.checkslotdateend = moment(new Date($.trim($('#date42').val()))).endOf('day').utc().format('YYYY-MM-DDTHH:mm:ssZ');
            }
            var servicesarrslot = localStorage.getItem('custaddedservices');
            if (servicesarrslot) {
                paramsServicesSlotCheck.servicesarr = JSON.parse(servicesarrslot);
            }

            var arrPax = [];
            var pax43 = $("#pax43").val();
            pax43 = parseInt(pax43);

            for (var i = 1; i <= pax43; i++) {
                arrPax.push(i);
            }
            paramsServicesSlotCheck.checkpax = arrPax;

            if (paramsServicesSlotCheck.servicesarr) {
                $('#display_loading').removeClass('hideme');
                $.ajax({
                    url: '/booksy/checkoutappointmentschedularweb',
                    data: paramsServicesSlotCheck,
                    type: 'POST',
                    success: function (response) {
                        $('#display_loading').addClass('hideme');
                        if (response.status == 0) {

                            if (response.isfounderror == 0) {
                                localStorage.setItem('custaddedservices', JSON.stringify(response.data));
                                addConfirmServiceCard();
                                $('#confimdetailsmodal').modal({ dismissible: false });
                                $('#confimdetailsmodal').modal('open');
                            } else {
                                Materialize.toast('Services that are selected by you have slots available to others, Please select different slots.', 2000);
                                var paramsType = {};
                                paramsType.salonlocationid = getParameterByName('recordID');
                                getStartTime(paramsType);
                            }
                        } else {
                            Materialize.toast('No services are selected, Please select atleast one service.', 2000);
                        }
                    },
                    error: function (xhr, status, error) {
                        $('#display_loading').addClass('hideme');
                        Materialize.toast('No services are selected, Please select atleast one service.', 2000);
                    },
                });

            } else {
                Materialize.toast('No services are selected, Please select atleast one service.', 2000);
            }



            // addConfirmServiceCard();
            // $('#confimdetailsmodal').modal({dismissible:false});
            // $('#confimdetailsmodal').modal('open');
        }



    });


    $(document).on("change", "#starttimeid43", function () {


        var hoursselected = localStorage.getItem('data-hours');
        var minutesselected = localStorage.getItem('data-minutes');

        console.log(hoursselected);
        console.log(minutesselected);

        var appointmentdate = $("#date42").val();
        var appointmentstarttime = $("#starttimeid43 option:selected").text().replace("AM", " AM").replace("PM", " PM");
        var computeddate = moment(new Date(appointmentdate + ", " + appointmentstarttime)).format("DD-MMM-YYYY, hh:mm A");
        var computeddatenextdate = moment(new Date(computeddate)).add(hoursselected, 'hours').add(minutesselected, 'minutes').format("hh:mmA");

        console.log(computeddate);
        console.log(computeddatenextdate);

        var objParams = {};
        objParams.starttimeappointment = computeddatenextdate;
        objParams.queryMode = $('#queryMode').val();

        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParams.ajaXCallURL = ajaXCallURL;


        var queryMode = getParameterByName('queryMode');
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');

        objParams.tokenKey = tokenKey;
        objParams.secretKey = secretKey;
        objParams.queryMode = queryMode;

        objParams.callUrl = objParams.ajaXCallURL + '/booksy/getListDetails_Timeslot61f91155baf7700fc434e1af_timeslotweb_timeslotwebKendoList';

        if (localStorage.getItem('salonlocationid')) {
            objParams.salonlocationid = localStorage.getItem('salonlocationid');
        }

        $.ajax({
            url: objParams.callUrl,
            data: objParams,
            type: 'POST',
            success: function (response) {

                $('#endtime44').prop('disabled', false);
                $('#endtime44').material_select();

                if (response.status == 0 && response.data && response.data[0]) {

                    var enddateselectedvalues = response.data[0]._id.toString();
                    // $('#endtime44').val(enddateselectedvalues);
                    // // $('#endtime44').prop('disabled', true);
                    // $('#endtime44').material_select();

                    // $('#endtime44').val(enddateselectedvalues);

                    var paramsType = {};
                    paramsType.selected = enddateselectedvalues;
                    getEndTime(paramsType);

                } else {
                    // $('#endtime44').val("");
                    // // $('#endtime44').prop('disabled', true);
                    // $('#endtime44').material_select();

                    // $('#endtime44').val("");
                    var paramsType = {};
                    paramsType.selected = "A";
                    getEndTime(paramsType);

                    var objLocalParams = {};
                    // if(objLocalParams){
                    // objLocalParams = JSON.parse(objLocalParams);
                    objLocalParams.endtimeid_name = computeddatenextdate;

                    localStorage.setItem('objParams', JSON.stringify(objLocalParams));
                    // }
                }

                // Materialize.updateTextFields();

            },
            error: function (xhr, status, error) {
                // $('#display_loading').addClass('hideme');
            },
        });

    });


    $(document).on("click", "#changestylist", function () {

        currChangeServiceId = $(this).attr('data-serviceid');
        $('#currstylistid').html(currChangeServiceId);
        $('#changestylistmodal').modal({ dismissible: false });
        $('#changestylistmodal').modal('open');
    });


    $(document).on("click", "#defaultstylistselect", function () {

        var getServices = localStorage.getItem('custaddedservices');
        if (getServices) {
            getServices = JSON.parse(getServices);

            getServices.forEach((element, key) => {
                if (element.serviceid == currChangeServiceId) {
                    if (element.stylistid) {
                        delete getServices[key].stylistid
                        delete getServices[key].mediaid
                        getServices[key].stylistid_name = "Anyone";
                        // element.stylistid = "";
                    } else {
                        getServices[key].stylistid_name = "Anyone";
                    }
                }
            });

        }
        localStorage.setItem('custaddedservices', JSON.stringify(getServices));
        addServiceCard()
        $('#changestylistmodal').modal({ dismissible: false });
        $('#changestylistmodal').modal('close');

        renderStartDate();

    });

    $(document).on("click", "#selectedstylist", function () {
        // var serviceObj = {};
        var objParams = localStorage.getItem('objParams');
        if (objParams) {
            objParams = JSON.parse(objParams);
        } else {
            objParams = {};
        }
        var currServiceId = $(this).attr('data-service');
        var currStylistId = $(this).attr('data-stylistid');
        mainTopStylistID = currStylistId;
        var currStylistIdName = $(this).attr('data-stylistid_name');
        var currMediaId = $(this).attr('data-mediaId');

        objParams.stylistid = currStylistId;
        objParams.stylistid_name = currStylistIdName + '-' + localStorage.getItem('salonlocationname');

        // objParams.userphotoupload = currMediaId;

        localStorage.setItem('objParams', JSON.stringify(objParams));


        var getServices = localStorage.getItem('custaddedservices');
        if (getServices) {
            getServices = JSON.parse(getServices);
            if (getServices.length == 1) {

                var currUserPhotoUpload = '';
                if (currMediaId) {
                    var url = CDN_PATH + currMediaId + '_compressed.png';
                    var errorurl = 'https://appcdn.beepup.com/card.png';
                    currUserPhotoUpload += "<img class='circle' style='border-radius: 50%;width: 30px;height: 30px;' onerror=this.src='" + errorurl + "' src='" + url + "'/>"
                } else {
                    var url = 'https://appcdn.beepup.com/card.png';
                    var errorurl = 'https://appcdn.beepup.com/card.png';
                    currUserPhotoUpload += "<img class='circle' style='border-radius: 50%;width: 30px;height: 30px;' onerror=this.src='" + errorurl + "' src='" + url + "'/>"
                }

                $('#slectedstylistname').html(currStylistIdName);
                $('#selectedstylistphoto').html(currUserPhotoUpload);

                getServices[0].stylistid = currStylistId;
                getServices[0].stylistid_name = currStylistIdName + '-' + localStorage.getItem('salonlocationname');;
                // if(currMediaId && currMediaId !== ""){
                getServices[0].mediaid = currMediaId;
                // }
                localStorage.setItem('custaddedservices', JSON.stringify(getServices));

            } else if (getServices.length > 1) {
                var currUserPhotoUpload = '';
                if (currMediaId) {
                    var url = CDN_PATH + currMediaId + '_compressed.png';
                    var errorurl = 'https://appcdn.beepup.com/card.png';
                    currUserPhotoUpload += "<img class='circle' style='border-radius: 50%;width: 30px;height: 30px;' onerror=this.src='" + errorurl + "' src='" + url + "'/>"
                } else {
                    var url = 'https://appcdn.beepup.com/card.png';
                    var errorurl = 'https://appcdn.beepup.com/card.png';
                    currUserPhotoUpload += "<img class='circle' style='border-radius: 50%;width: 30px;height: 30px;' onerror=this.src='" + errorurl + "' src='" + url + "'/>"
                }

                $('#slectedstylistname' + currChangeServiceId).html(currStylistIdName);
                $('#slectedstylistname' + currChangeServiceId).attr('data-stylistid', currStylistId);
                $('#selectedstylistphoto' + currChangeServiceId).html(currUserPhotoUpload);

                getServices.forEach((element, key) => {
                    if (element.serviceid == currChangeServiceId) {
                        getServices[key].stylistid = currStylistId;
                        getServices[key].stylistid_name = currStylistIdName + '-' + localStorage.getItem('salonlocationname');;
                        // if(currMediaId && currMediaId !== ""){
                        getServices[key].mediaid = currMediaId;
                        // }

                    }
                });
                localStorage.setItem('custaddedservices', JSON.stringify(getServices));
            }


        }

        addServiceCard();
        $('#changestylistmodal').modal({ dismissible: false });
        $('#changestylistmodal').modal('close');


        renderStartDate();

    });

    $(document).on("click", ".finalPopupClose", function () {
        window.location.reload();
    });

    let paramsTypeHoliday = {};
    paramsTypeHoliday.isDelete = 0;
    if (localStorage.getItem('salonlocationid')) {
        paramsTypeHoliday.salonlocationid = localStorage.getItem('salonlocationid');
    }
    paramsTypeHoliday.queryMode = 'mylist';

    var ajaXCallURL = $.trim($('#ajaXCallURL').val());

    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    paramsTypeHoliday.ajaXCallURL = ajaXCallURL;


    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');

    paramsTypeHoliday.tokenKey = tokenKey;
    paramsTypeHoliday.secretKey = secretKey;
    paramsTypeHoliday.queryMode = queryMode;

    $.ajax({
        url: paramsTypeHoliday.ajaXCallURL + '/booksy/getListDetails_Holiday61f91155baf7700fc434e1af_holidaylistweb_holidaylistwebKendoList',
        data: paramsTypeHoliday,
        type: 'POST',
        success: function (response) {
            if (response.status == 0) {
                response.data.forEach(element => {
                    arrHoliday.push(new Date(element.holidaydate));
                });
                console.log(arrHoliday)
                // uncomment
                // $('#date42').pickadate({
                //     selectMonths: true, // Creates a dropdown to control month
                //     selectYears: 150, // Creates a dropdown of 15 years to control year
                //     dateFormat: 'd mmmm, yyyy',
                //     min: new Date(),
                //     disable: arrHoliday,
                //     onOpen: function() {
                //         // var date = new Date();
                //         if($("#date42").val()){
                //             var date = new Date($("#date42").val());
                //         } else if($("#date42").val()){
                //             var date = new Date($("#date42").val());
                //         } else {
                //             var date = new Date();
                //         }

                //         $('.picker__select--month').val(date.getMonth()).material_select();
                //         $('.picker__select--year').val(date.getFullYear()).material_select();
                //     },
                //     onStart: function ()
                //     { 
                //         if($("#date42").val()){
                //             var date = new Date($("#date42").val());
                //         } else if($("#date42").val()){
                //             var date = new Date($("#date42").val());
                //         } else {
                //             var date = new Date();
                //         }

                //         this.set('select', [date.getFullYear(), date.getMonth() , date.getDate()]);
                //     },
                //     onSet: function (arg) {
                //         if ('select' in arg) { //prevent closing on selecting month/year
                //             this.close();
                //             console.log("closed");
                //             // call dates validation
                //             renderStartDate();


                //             // $('.fixed-action-btn').show();
                //         }
                //     }
                // });
                $('#date42').on('mousedown', function (event) {
                    event.preventDefault();
                })
            }
        },
        error: function (xhr, status, error) { },
    });

    //backtomain
    $(document).on("click", "#backtomain", function () {
        var getServices = localStorage.getItem('custaddedservices');
        // var currRecordID = $(this).attr('recordID');
        if (getServices) {
            getServices = JSON.parse(getServices);
            console.log(getServices);
            // getServices.forEach((element,key) => {
            //     if (element.pax == "1") {
            //         console.log(key);
            //         // delete getServices[key]
            //         // getServices.splice(0, 1);
            //     }
            // });
            getServices = getServices.filter(function (obj) {
                return obj.deletepax !== 2;
            });
            console.log(getServices);
            if (getServices.length == 1) {
                localStorage.setItem('custaddedservices', JSON.stringify(getServices));
                addServiceCard();
                $('#deleteserviceitem' + getServices[0].serviceid).hide();
            } else {
                localStorage.setItem('custaddedservices', JSON.stringify(getServices));
                addServiceCard();
            }

        }
    });


    var paramsStylist = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    paramsStylist.ajaXCallURL = ajaXCallURL;
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    paramsStylist.salonlocationid = localStorage.getItem('salonlocationid');
    paramsStylist.rolename = "stylist";
    paramsStylist.tokenKey = tokenKey;
    paramsStylist.secretKey = secretKey;
    paramsStylist.queryMode = queryMode;

    $.ajax({
        url: paramsStylist.ajaXCallURL + '/booksy/getListDetails_Usermanagement61f91155baf7700fc434e1af_usermanagementlistweb_usermanagementlistwebKendoList',
        data: paramsStylist,
        type: 'POST',
        success: function (response) {
            if (response.status == 0) {
                if (response && response.data && response.data.length > 0) {
                    var htmlStylists = '';
                    response.data.forEach(element => {
                        htmlStylists += '<div class="col-6 pe-0">'
                        htmlStylists += '    <div class="text-center">'
                        if (element.userphotoupload) {
                            var html = [];
                            var userphotoupload = element.userphotoupload;
                            if (userphotoupload && userphotoupload.length) {
                                var url = CDN_PATH + userphotoupload[0].mediaID + '_compressed.png';
                                //var errorurl = CDN_PATH + userphotoupload[0].mediaID + '_128_128.png';
                                var errorurl = 'https://appcdn.beepup.com/card.png';
                                htmlStylists += "<img class='circle' onerror=this.src='" + errorurl + "' src='" + url + "'/>"
                            } else {
                                var url = 'https://appcdn.beepup.com/card.png';
                                var errorurl = 'https://appcdn.beepup.com/card.png';
                                htmlStylists += "<img class='circle' onerror=this.src='" + errorurl + "' src='" + url + "'/>"
                            }
                        } else {
                            var url = 'https://appcdn.beepup.com/card.png';
                            var errorurl = 'https://appcdn.beepup.com/card.png';
                            htmlStylists += "<img class='circle' onerror=this.src='" + errorurl + "' src='" + url + "'/>"
                        }
                        // htmlStylists += '        <img class="rounded-m mb-3 preload-img entered loaded" src="images/pictures/faces/1s.png" data-src="images/pictures/faces/1s.png" width="120" data-ll-status="loaded">'
                      
                      // sg start
                        htmlStylists += '        <h1 class="font-17 mb-n2">' + element.name + '</h1>'                        
                        htmlStylists += '        <p class="mt-n2 color-highlight font-11 mb-3"></p>'
                        // sg end 

                        htmlStylists += '    </div>'
                        htmlStylists += '</div>'
                    });

                    $('#locationstylistsdiv').append(htmlStylists);
                }
            } else {

            }

        },
        error: function (xhr, status, error) {

        },
    });

    //
    // $(document).on("click", ".pickdatetimeclass", function () {
    //     $('.menu-hider,#pickdatetimemodal').addClass('menu-active');
    // });

    $(document).on("click", ".discardservices", function () {
        $('.menu-hider,#discardmodal').addClass('menu-active');
    });

    //
    $(document).on("click", ".discardyesmodal", function () {
        window.location.reload();
    });


}); //end of ready 4

function calculateEndTime(objParams) {

    var custaddedservices = localStorage.getItem('custaddedservices');
    if (custaddedservices) {
        custaddedservices = JSON.parse(custaddedservices);
        custaddedservices[0].endtimeid_name = objParams.starttimeappointment;

        localStorage.setItem('custaddedservices', JSON.stringify(custaddedservices));
    }

    // $('#display_loading').removeClass('hideme');

    // objParams.queryMode = $('#queryMode').val();
    // objParams.callUrl = '/booksy/getListDetails_Timeslot61f91155baf7700fc434e1af_timeslotweb_timeslotwebKendoList';

    // if (localStorage.getItem('salonlocationid')) {
    //     objParams.salonlocationid = localStorage.getItem('salonlocationid');
    // }

    // $.ajax({
    //     url: objParams.callUrl,
    //     data: objParams,
    //     type: 'POST',
    //     success: function (response) {


    //         $('#display_loading').addClass('hideme');

    //         $('#endtime44').prop('disabled', false);
    //         $('#endtime44').material_select();

    //         if (response.status == 0 && response.data && response.data[0]) {

    //             var endtimeid = response.data[0]._id.toString();
    //             var endtimeid_name = response.data[0].starttime;

    //             var custaddedservices = localStorage.getItem('custaddedservices');
    //             if(custaddedservices){
    //                 custaddedservices = JSON.parse(custaddedservices);

    //                 custaddedservices[0].endtimeid = endtimeid;
    //                 custaddedservices[0].endtimeid_name = endtimeid_name;

    //                 localStorage.setItem('custaddedservices', JSON.stringify(custaddedservices));
    //             }
    //             // $('#endtime44').val(enddateselectedvalues);
    //             // // $('#endtime44').prop('disabled', true);
    //             // $('#endtime44').material_select();

    //             // $('#endtime44').val(enddateselectedvalues);

    //             // var paramsType = {};
    //             // paramsType.selected = enddateselectedvalues;
    //             // getEndTime(paramsType);

    //         } else {

    //             var custaddedservices = localStorage.getItem('custaddedservices');
    //             if(custaddedservices){
    //                 custaddedservices = JSON.parse(custaddedservices);
    //                 custaddedservices[0].endtimeid_name = objParams.starttimeappointment;

    //                 localStorage.setItem('custaddedservices', JSON.stringify(custaddedservices));
    //             }

    //         }

    //         // Materialize.updateTextFields();

    //     },
    //     error: function (xhr, status, error) {
    //         // $('#display_loading').addClass('hideme');
    //     },
    // });
}

function addServiceCard() {
    $('#selectedserviceshtml').html('');
    var getServices = localStorage.getItem('custaddedservices');
    var totalPrice = 0;
    var totalHours = 0;
    var totalMinutes = 0;

    var firstAppointmentHours = 0;
    var firstAppointmentMinutes = 0;

    if (getServices) {
        getServices = JSON.parse(getServices);

        // console.log(getServices);
        getServices.forEach((element, key) => {
            var htmlMoreService = ''

            htmlMoreService += '<div style="margin: 18px 0px;background-color: #e9e9e9;border-radius: 8px;padding: 5px;font-size: 16px;">'
            if (getServices.length !== 1) {
                htmlMoreService += '    <i id="deleteserviceitem' + element.serviceid + '" recordID="' + element.serviceid + '" class="deleteserviceitem material-icons prefix " style="float: right;position: relative;top: -20px;right: -15px;background: #aba9a9;border-radius: 12px;color:#fff;cursor: pointer;">close</i>'
            }

            htmlMoreService += '    <div class="row" style="margin: 5px;border-bottom: 1px solid #a9a4a4;">'
            htmlMoreService += '        <div class="col s8" >'
            htmlMoreService += '            <div id="modalservicename" style="font-weight: bold;">' + element.servicename + '</div>'
            if (element.servicedescription !== "undefined") {
                htmlMoreService += '            <div id="modalservicedescription" style="font-size: 15;">' + element.servicedescription + '</div>'
            } else {
                htmlMoreService += '            <div id="modalservicedescription" style="font-size: 15;">-</div>'
            }

            htmlMoreService += '        </div>'
            htmlMoreService += '        <div class="col s4" style="text-align: right;">'
            htmlMoreService += '            <div id="modalserviceprice" style="font-weight: bold;">$' + element.serviceprice + '</div> '
            htmlMoreService += '            <div id="modalservicetime" style="font-size: 12px;">' + element.serviceduration + '</div>'
            htmlMoreService += '        </div>'
            htmlMoreService += '    </div>'

            htmlMoreService += '<div class="row" style="margin: 10px 5px 5px 5px;">'
            htmlMoreService += '    <div class="col s2" id="selectedstylistphoto' + element.serviceid + '">'
            if (element.mediaid) {
                var url = CDN_PATH + element.mediaid + '_compressed.png';
                var errorurl = 'https://appcdn.beepup.com/card.png';
                htmlMoreService += '        <img class="circle" src="' + url + '" style="border-radius: 50%;width: 30px;height: 30px;" alt="">'
            } else {
                var url = 'https://appcdn.beepup.com/card.png';
                var errorurl = 'https://appcdn.beepup.com/card.png';
                htmlMoreService += '        <img class="circle" src="' + url + '" style="border-radius: 50%;width: 30px;height: 30px;" alt="">'
            }

            htmlMoreService += '    </div>'
            htmlMoreService += '    <div class="col s6">'
            htmlMoreService += '        <span id="slectedstylistname' + element.serviceid + '">' + element.stylistid_name + '</span>'
            htmlMoreService += '    </div>'
            htmlMoreService += '    <div class="col s4">'
            htmlMoreService += '        <div  id="save28_div" class=" " style="">'
            htmlMoreService += '            <a id="changestylist" class="hoku_button" data-serviceid="' + element.serviceid + '" element" href="#"  tabindex="" style="color:#667459;background:#fff !important;" >Change</a>'
            htmlMoreService += '        </div>'
            htmlMoreService += '    </div>'
            htmlMoreService += '</div>'

            htmlMoreService += '</div>'

            totalHours += parseInt(element.servicehours.replace("h", ""));
            totalMinutes += parseInt(element.serviceminuts.replace("min", ""));

            if (key == 0) {
                firstAppointmentHours = parseInt(element.servicehours.replace("h", ""));
                firstAppointmentMinutes = parseInt(element.serviceminuts.replace("min", ""));
            }


            totalPrice += parseFloat(element.serviceprice);
            $('#selectedserviceshtml').append(htmlMoreService);

        });

        var hours = Math.floor(totalMinutes / 60) + totalHours;
        var minutes = totalMinutes % 60;

        $('#servicetotalprice').html('$' + totalPrice.toFixed(2));
        $('#servicetotaltime').html(hours + 'h ' + minutes + 'min');
        localStorage.setItem('data-hours', hours);
        localStorage.setItem('data-minutes', minutes);

        localStorage.setItem('data-firsthours', firstAppointmentHours);
        localStorage.setItem('data-firstminutes', firstAppointmentMinutes);
    }



}

function addConfirmServiceCard() {
    $('#confirmservicescard').html('');
    var getServices = localStorage.getItem('custaddedservices');
    var totalPrice = 0;
    var totalHours = 0;
    var totalMinutes = 0;
    if (getServices) {
        getServices = JSON.parse(getServices);

        var htmlMoreService = ''

        htmlMoreService += '<div style="margin: 15px;background-color: #e9e9e9;border-radius: 8px;padding: 5px;">'

        getServices.forEach(element => {
            if (element.checkpax == 2) {

                //                if(element.stylistid){
                // htmlMoreService += '        <div id="modalservicedescription" style="font-size: 15;">'+ element.stylistid_name +'</div>'
            } else {
                element.serviceprice = parseFloat(element.serviceprice);
                htmlMoreService += '    <div class="row" style="margin: 5px;padding: 5px;font-size: 16px;">'
                htmlMoreService += '      <div class="col s8" >'
                htmlMoreService += '        <div id="modalservicename" style="font-weight: bold;">' + element.servicename + '</div>'


                if (element.stylistid) {
                    htmlMoreService += '        <div id="modalservicedescription" style="font-size: 15;">' + element.stylistid_name + '</div>'
                    getServices.forEach(innerRecord => {
                        if (innerRecord.serviceid == element.serviceid && innerRecord.checkpax == 2) {
                            htmlMoreService += '        <div id="modalservicedescription" style="font-size: 15;">' + innerRecord.stylistid_name + '</div>'
                        }
                    });
                } else {
                    htmlMoreService += '        <div id="modalservicedescription" style="font-size: 15;">Anyone</div>'
                }

                htmlMoreService += '      </div>'
                htmlMoreService += '      <div class="col s4" style="text-align: right;">'
                htmlMoreService += '        <div id="modalserviceprice" style="font-weight: bold;">$' + element.serviceprice.toFixed(2) + '</div> '
                htmlMoreService += '        <div id="modalservicetime" style="font-size: 12px;">' + element.serviceduration + '</div>'
                htmlMoreService += '      </div>'
                htmlMoreService += '    </div>'
                htmlMoreService += '    <hr>'


                totalHours += parseInt(element.servicehours.replace("h", ""));
                totalMinutes += parseInt(element.serviceminuts.replace("min", ""));

                totalPrice += parseFloat(element.serviceprice);
            }

            //htmlMoreService += '      </div>'
            //htmlMoreService += '      <div class="col s4" style="text-align: right;">'
            //htmlMoreService += '        <div id="modalserviceprice" style="font-weight: bold;">$'+ element.serviceprice.toFixed(2) +'</div> '
            //htmlMoreService += '        <div id="modalservicetime" style="font-size: 12px;">'+ element.serviceduration +'</div>'
            //  htmlMoreService += '      </div>'
            //  htmlMoreService += '    </div>'
            //htmlMoreService += '    <hr>'


            //totalHours += parseInt(element.servicehours.replace("h",""));
            //totalMinutes += parseInt(element.serviceminuts.replace("min",""));

            //totalPrice += parseFloat(element.serviceprice);


        });


        var hours = Math.floor(totalMinutes / 60) + totalHours;
        var minutes = totalMinutes % 60;

        htmlMoreService += '    <div class="row" style="margin: 5px;font-size: 16px;">'
        htmlMoreService += '      <div class="col s12" style="text-align: right;">'
        htmlMoreService += '        <div id="" style="">Total</div> '
        htmlMoreService += '        <div id="" style="font-size: 20px;font-weight:bold;">$' + totalPrice.toFixed(2) + '</div>'
        htmlMoreService += '        <div id="" style="font-size: 12px;">' + hours + 'h ' + minutes + 'min</div> '
        htmlMoreService += '      </div>'
        htmlMoreService += '    </div>'
        htmlMoreService += '  </div>'
        htmlMoreService += '  <div id="sg0827" class="row internalnote" style="margin: 10px;">'
        htmlMoreService += '    <div id="sg1827" class="col s12">'
        htmlMoreService += '      <div style="" id="name21_div" class="input-field margin_bottom_5px  no_margin">'
        htmlMoreService += '        <i class="material-icons prefix " style="margin-top: 13px;font-size: 20px !important;">message</i>'
        htmlMoreService += '        <input id="additionalnote89" autocomplete="off" placeholder="Leave a note (optional)" style="border-radius: 5px !important;height: 40px !important;font-size: 16px !important;" id="name21" type="text" class="searchname input" >'
        htmlMoreService += '      </div>'
        htmlMoreService += '    </div>'
        htmlMoreService += '  </div>'



        $('#grandtotalservice').html('$' + totalPrice.toFixed(2));
        $('#grandtotalservice').attr('grandtotal', totalPrice.toFixed(2));
        $('#servicetotaltime').html(hours + 'h ' + minutes + 'min');
        localStorage.setItem('data-hours', hours);
        localStorage.setItem('data-minutes', minutes);
    }
    $('#confirmservicescard').append(htmlMoreService);


}

function enterSearch(e) {
    //See notes about 'which' and 'key'
    var globalsearchtext = $('#searchservices').val();
    if (globalsearchtext.length >= 3 || globalsearchtext.length == 0) {
        $('#display_loading').addClass('hideme');

        skip = 0;
        fetchRecord = 0;
        // if(globalsearchtext){
        //     $('.searchicon').show();
        // } else {
        //     $('.searchicon').hide();
        // }
        var categoryserviceparams = {}
        categoryserviceparams.queryMode = 'mylist';
        categoryserviceparams.salonaddressid = getParameterByName('recordID');
        categoryserviceparams.globalsearch = globalsearchtext;
        getCategoryServices(categoryserviceparams);
    }
}

function enterModalSearch(e) {
    //See notes about 'which' and 'key'
    var globalsearchtext = $('#searchinmodal').val();
    if (globalsearchtext.length >= 3 || globalsearchtext.length == 0) {
        $('#display_loading').addClass('hideme');

        skip = 0;
        fetchRecord = 0;
        // if(globalsearchtext){
        //     $('.searchicon').show();
        // } else {
        //     $('.searchicon').hide();
        // }
        var categoryserviceparams = {}
        categoryserviceparams.queryMode = 'mylist';
        categoryserviceparams.salonaddressid = getParameterByName('recordID');
        categoryserviceparams.globalsearch = globalsearchtext;
        getCategoryModalServices(categoryserviceparams);
    }
}


async function processBeforeCallForSaveappointmentappointmentschedularweb_61f91155baf7700fc434e1af(objParams, callback) {
    objParams.appointmentdate = moment(objParams.date).format('DD MMMM, YYYY')
    callback();
}
async function processAfterCallForSaveappointmentappointmentschedularweb_61f91155baf7700fc434e1af(response, responseData, callback) {
    // location.reload(true);
    callback();
}



function processBeforeCallForgetfromothertable_appointmentschedularweb_salonlocation_61f91155baf7700fc434e1af_SearchBySalonLocation(paramsType, callback) {
    var response = paramsType;
    callback();
}

function processAfterCallForgetfromothertable_appointmentschedularweb_salonlocation_61f91155baf7700fc434e1af_SearchBySalonLocation(data, response, callback) {
    callback();
}

function getSearchBySalonLocation(paramsType) {
    processBeforeCallForgetfromothertable_appointmentschedularweb_salonlocation_61f91155baf7700fc434e1af_SearchBySalonLocation(paramsType, function (processBeforeRes) {
        $.ajax({
            url: '/booksy/getfromothertable_appointmentschedularweb_salonlocation_61f91155baf7700fc434e1af_SearchBySalonLocation',
            data: paramsType,
            type: 'POST',
            success: function (response) {
                if (response.status == 0) {
                    processAfterCallForgetfromothertable_appointmentschedularweb_salonlocation_61f91155baf7700fc434e1af_SearchBySalonLocation(response.data, response, function (processBeforeRes) {

                        let btnHtml = '';
                        let isMobile = $('#isMobile').val();
                        if (isMobile == 'true') {
                            response.data.forEach((element, key) => {
                                btnHtml += '<div id="sg6821" classname="primary" class="col s12 primary">'
                                btnHtml += '<div  id="submitappointment658_div" class="" >'
                                btnHtml += '<div style="padding: 5px;font-size: 15px;text-transform: uppercase !important;">' + element.branchname + ' </div>'
                                btnHtml += '<a id="saveguest37" class="hoku_button " recordID="' + element._id + '" href="#"  tabindex="" style="height: 40px;line-height: 35px;border-radius: 12px;font-size:15px" >'
                                btnHtml += '    BOOK NOW'
                                btnHtml += '</a>'
                                btnHtml += '<div style="padding: 5px;color: #9d9a9a;font-size: 14px;font-weight: bold;">powered by <span style="color:#667459 !important">Peralista<span> </div>'
                                btnHtml += '</div>'
                                btnHtml += '</div>'

                                if (response.data.length != key + 1) {
                                    btnHtml += '<div style="border-bottom: 2px solid #d7d7d7;margin-top: 7px;margin-bottom: 7px;">&nbsp;</div>'
                                }

                            });
                        } else {
                            response.data.forEach(element => {
                                btnHtml += '<div id="sg6821" classname="primary" class="col s3 primary">'
                                btnHtml += '<div  id="saveguest37_div" class="" >'
                                btnHtml += '<div style="padding: 5px;font-size: 17px;text-transform: uppercase !important;">' + element.branchname + ' </div>'
                                btnHtml += '<a id="saveguest37" class="hoku_button " recordID="' + element._id + '"  href="#"  tabindex="" style="height: 40px;line-height: 35px;border-radius: 12px;font-size:17px" >'
                                btnHtml += '    BOOK NOW'
                                btnHtml += '</a>'
                                btnHtml += '<div style="padding: 5px;color: #9d9a9a;font-size: 16px;font-weight: bold;">powered by <span style="color:#667459 !important">Peralista<span> </div>'
                                btnHtml += '</div>'
                                btnHtml += '</div>'
                            });
                        }

                        console.log();
                        $('#locationbuttons').append(btnHtml);

                        //var selectOptionHtml = '<option value="">Search By Salon Location</option>';
                        var selectOptionHtml = '<option disabled selected value="">Select</option>';
                        $.each(response.data, function (keyList, objList) {
                            selectOptionHtml += '<option data-addr="' + objList.salonaddress + '"  value="' + objList._id + '">' + objList.branchname + '</option>';
                        });
                        $('#salonlocationid44').html(selectOptionHtml); //2
                        // if (dropdownvalues['salonlocationid']) { $('#salonlocationid44').val(dropdownvalues['salonlocationid']); }
                        if (localStorage.getItem('salonlocationid')) {
                            $('#salonlocationid44').val(localStorage.getItem('salonlocationid'));
                        }

                        if (paramsType.selectedlocation) {
                            $('#salonlocationid44').val(paramsType.selectedlocation);
                            localStorage.setItem('salonlocationid', paramsType.selectedlocation);
                        }
                        $('#salonlocationid44').material_select();
                        //data-addr searchlocation
                        var selectedlocation = $("#salonlocationid44 option:selected").attr('data-addr');

                        if (selectedlocation) {
                            $('#searchlocation').html(selectedlocation);
                        }
                    })
                } else {

                }

            },
            error: function (xhr, status, error) {

            },
        });
    });
}

function processBeforeCallForgetfromothertable_appointmentschedularweb_usermanagement_61f91155baf7700fc434e1af_Staff(paramsType, callback) {
    var response = paramsType;
    callback();
}

function processAfterCallForgetfromothertable_appointmentschedularweb_usermanagement_61f91155baf7700fc434e1af_Staff(data, response, callback) {
    callback();
}

function getStaff(paramsType) {
    processBeforeCallForgetfromothertable_appointmentschedularweb_usermanagement_61f91155baf7700fc434e1af_Staff(paramsType, function (processBeforeRes) {
        // if(localStorage.getItem('salonlocationid')){
        //     paramsType.salonlocationid = localStorage.getItem('salonlocationid');
        // }

        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        paramsType.ajaXCallURL = ajaXCallURL;


        var queryMode = getParameterByName('queryMode');
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');

        paramsType.tokenKey = tokenKey;
        paramsType.secretKey = secretKey;
        paramsType.queryMode = queryMode;

        $.ajax({
            url: paramsType.ajaXCallURL + '/booksy/getListDetails_Usermanagement61f91155baf7700fc434e1af_usermanagementlistweb_usermanagementlistwebKendoList',
            data: paramsType,
            type: 'POST',
            success: function (response) {
                if (response.status == 0) {
                    processAfterCallForgetfromothertable_appointmentschedularweb_usermanagement_61f91155baf7700fc434e1af_Staff(response.data, response, function (processBeforeRes) {

                        let htmlStaffs = '';
                        let htmlStylistCard = '';

                        htmlStylistCard += '<div id="defaultstylistselect" class="row " style="margin: 10px;cursor:pointer">'
                        htmlStylistCard += '    <div class="col s3">'
                        htmlStylistCard += '        <img class="circle" src="https://appcdn.beepup.com/card.png" style="border-radius: 50%;width: 50px;height: 50px;" alt="">    '
                        htmlStylistCard += '    </div>'
                        htmlStylistCard += '    <div class="col s9" style="">'
                        htmlStylistCard += '        <div style="font-size: 16px;font-weight: bold;">Anyone</div>'
                        htmlStylistCard += '        <div style="color:#00c4ff">Default</div>'
                        htmlStylistCard += '    </div>'
                        htmlStylistCard += '</div>'

                        response.data.forEach(element => {
                            htmlStaffs += '<div id="" class="col s4" style="text-align: center;">'
                            htmlStaffs += '<div style="padding: 10px 0px;">'

                            if (element.userphotoupload) {
                                var html = [];
                                var userphotoupload = element.userphotoupload;
                                if (userphotoupload && userphotoupload.length) {
                                    var url = CDN_PATH + userphotoupload[0].mediaID + '_compressed.png';
                                    //var errorurl = CDN_PATH + userphotoupload[0].mediaID + '_128_128.png';
                                    var errorurl = 'https://appcdn.beepup.com/card.png';
                                    htmlStaffs += "<img class='circle' onerror=this.src='" + errorurl + "' src='" + url + "'/>"
                                } else {
                                    var url = 'https://appcdn.beepup.com/card.png';
                                    var errorurl = 'https://appcdn.beepup.com/card.png';
                                    htmlStaffs += "<img class='circle' onerror=this.src='" + errorurl + "' src='" + url + "'/>"
                                }
                            } else {
                                var url = 'https://appcdn.beepup.com/card.png';
                                var errorurl = 'https://appcdn.beepup.com/card.png';
                                htmlStaffs += "<img class='circle' onerror=this.src='" + errorurl + "' src='" + url + "'/>"
                            }

                            // htmlStaffs += '  <img class="circle" src="https://encrypted-tbn0.gstatic.com/images?q=tbn:ANd9GcSE26NjQaonqTRt7BXD_87Iuukitk_kcGBv3w&usqp=CAU" />'
                            htmlStaffs += ' <div style="font-weight: bold;font-size:12px">' + element.name + '</div>'
                            htmlStaffs += '</div>'
                            htmlStaffs += '</div>'



                            htmlStylistCard += '<hr>'
                            if (element.userphotoupload) {
                                htmlStylistCard += '<div id="selectedstylist" class="row " style="margin: 10px;cursor:pointer" data-stylistid="' + element._id + '" data-stylistid_name="' + element.name + '" data-mediaId="' + element.userphotoupload[0].mediaID + '">'
                            } else {
                                htmlStylistCard += '<div id="selectedstylist" class="row " style="margin: 10px;cursor:pointer" data-stylistid="' + element._id + '" data-stylistid_name="' + element.name + '" data-mediaId="">'
                            }

                            htmlStylistCard += '    <div class="col s3">'
                            if (element.userphotoupload) {
                                var html = [];
                                var userphotoupload = element.userphotoupload;
                                if (userphotoupload && userphotoupload.length) {
                                    var url = CDN_PATH + userphotoupload[0].mediaID + '_compressed.png';
                                    //var errorurl = CDN_PATH + userphotoupload[0].mediaID + '_128_128.png';
                                    var errorurl = 'https://appcdn.beepup.com/card.png';
                                    htmlStylistCard += "<img class='circle' style='border-radius: 50%;width: 50px;height: 50px;' onerror=this.src='" + errorurl + "' src='" + url + "'/>"
                                } else {
                                    var url = 'https://appcdn.beepup.com/card.png';
                                    var errorurl = 'https://appcdn.beepup.com/card.png';
                                    htmlStylistCard += "<img class='circle' style='border-radius: 50%;width: 50px;height: 50px;' onerror=this.src='" + errorurl + "' src='" + url + "'/>"
                                }
                            } else {
                                var url = 'https://appcdn.beepup.com/card.png';
                                var errorurl = 'https://appcdn.beepup.com/card.png';
                                htmlStylistCard += "<img class='circle' style='border-radius: 50%;width: 50px;height: 50px;' onerror=this.src='" + errorurl + "' src='" + url + "'/>"
                            }
                            htmlStylistCard += '    </div>'
                            htmlStylistCard += '    <div class="col s9" style="">'
                            htmlStylistCard += '        <div  style="font-size: 16px;font-weight: bold;">' + element.name + '</div>'
                            htmlStylistCard += '        <div style="color:#00c4ff">Available</div>'
                            htmlStylistCard += '    </div>'
                            htmlStylistCard += '</div>'

                        });

                        $('#allstaffcards').append(htmlStaffs);
                        $('#selectstylistcard').append(htmlStylistCard);
                    })
                } else {

                }

            },
            error: function (xhr, status, error) {

            },
        });
    });
}


function processBeforeCallForgetfromothertable_appointmentschedularweb_services_61f91155baf7700fc434e1af_Service(paramsType, callback) {
    var response = paramsType;
    callback();
}

function processAfterCallForgetfromothertable_appointmentschedularweb_services_61f91155baf7700fc434e1af_Service(data, response, callback) {
    callback();
}

function getService(paramsType) {
    processBeforeCallForgetfromothertable_appointmentschedularweb_services_61f91155baf7700fc434e1af_Service(paramsType, function (processBeforeRes) {

        $.ajax({
            url: '/booksy/getfromothertable_appointmentschedularweb_services_61f91155baf7700fc434e1af_Service',
            data: paramsType,
            type: 'POST',
            success: function (response) {
                if (response.status == 0) {
                    processAfterCallForgetfromothertable_appointmentschedularweb_services_61f91155baf7700fc434e1af_Service(response.data, response, function (processBeforeRes) {
                        //var selectOptionHtml = '<option value="">Service</option>';


                        let htmlCollapse = '';

                        response.data.forEach(element => {
                            htmlCollapse += '<li>'
                            htmlCollapse += '    <div class="collapsible-header active"><i class="material-icons">arrow_downward</i>' + element.categoryid_name + '</div>'
                            htmlCollapse += '    <div class="collapsible-body"><span>Lorem ipsum dolor sit amet.</span></div>'
                            htmlCollapse += '</li>'
                        });

                        //   $('#servicesdatacollapse').append(htmlCollapse);

                    })
                } else {

                }

            },
            error: function (xhr, status, error) {

            },
        });
    });
}

function processBeforeCallForgetfromothertable_appointmentschedularweb_time_61f91155baf7700fc434e1af_BussinsessTime(paramsType, callback) {
    var response = paramsType;
    callback();
}

function processAfterCallForgetfromothertable_appointmentschedularweb_time_61f91155baf7700fc434e1af_BussinessTime(data, response, callback) {
    callback();
}

function getServiceTime(paramsType) {
    processBeforeCallForgetfromothertable_appointmentschedularweb_time_61f91155baf7700fc434e1af_BussinsessTime(paramsType, function (processBeforeRes) {

        //   if (localStorage.getItem('salonlocationid')) {
        //       paramsType.salonlocationid = localStorage.getItem('salonlocationid');
        //   }

        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        paramsType.ajaXCallURL = ajaXCallURL;


        var queryMode = getParameterByName('queryMode');
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');

        paramsType.tokenKey = tokenKey;
        paramsType.secretKey = secretKey;
        paramsType.queryMode = queryMode;

        $.ajax({
            url: paramsType.ajaXCallURL + '/booksy/getListDetails_Timeslot61f91155baf7700fc434e1af_timeslotweb_timeslotwebKendoList',
            data: paramsType,
            type: 'POST',
            success: function (response) {
                if (response.status == 0) {
                    processAfterCallForgetfromothertable_appointmentschedularweb_time_61f91155baf7700fc434e1af_BussinessTime(response.data, response, function (processBeforeRes) {
                        if (response && response.data && response.data.length > 0) {
                            var htmltiming = '';
                            var arrLength = response.data.length - 1;
                            var slotcount = 0;
                            daysArr.forEach(element => {
                                slotcount++;
                                if (slotcount == 1 || slotcount == 7) {
                                    htmltiming += '<div id="" class="row col s12" style="margin-bottom: 10px !important;">'
                                    htmltiming += '<div id="" class=" col s4" style="">' + element + '</div>'
                                    htmltiming += '<div id="" class=" col s8" style="text-align: right;font-weight:bold;">11:00AM To 05:00PM</div>'
                                    htmltiming += '</div>'
                                } else {
                                    htmltiming += '<div id="" class="row col s12" style="margin-bottom: 10px !important;">'
                                    htmltiming += '<div id="" class=" col s4" style="">' + element + '</div>'
                                    htmltiming += '<div id="" class=" col s8" style="text-align: right;font-weight:bold;">' + response.data[0].starttime + ' To ' + response.data[arrLength].starttime + '</div>'
                                    htmltiming += '</div>'
                                }

                            });

                            $('#bussinesshours').append(htmltiming);
                        }


                    })
                } else {

                }

            },
            error: function (xhr, status, error) {

            },
        });
    });
}

function processBeforeCallForgetfromothertable_appointmentschedularweb_services_61f91155baf7700fc434e1af_CategoryServices(paramsType, callback) {
    var response = paramsType;
    callback();
}

function processAfterCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_CategoryServices(data, response, callback) {
    callback();
}

function getCategoryServices(paramsType) {
    processBeforeCallForgetfromothertable_appointmentschedularweb_services_61f91155baf7700fc434e1af_CategoryServices(paramsType, function (processBeforeRes) {
        $('#display_loading').removeClass('hideme');

        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        paramsType.ajaXCallURL = ajaXCallURL;


        var queryMode = getParameterByName('queryMode');
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');

        paramsType.tokenKey = tokenKey;
        paramsType.secretKey = secretKey;
        paramsType.queryMode = queryMode;

        $.ajax({
            url: paramsType.ajaXCallURL + '/booksy/getListDetails_Category61f91155baf7700fc434e1af_servicecategorylistweb_servicecategorylistwebKendoList',
            data: paramsType,
            type: 'POST',
            success: function (response) {
                if (response.status == 0) {
                    processAfterCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_CategoryServices(response.data, response, function (processBeforeRes) {

                        var htmlServicesByCategory = '';
                        $('#servicesbycategory').html('');
                        response.data.forEach(element => {
                            if (element.services && element.services.length !== 0) {
                                // htmlServicesByCategory += '<div class="accordion1 row" data-status="active" style="margin-bottom: 0px !important;border-top: 1px solid #ddd;">'
                                // // htmlServicesByCategory += '<div id="" class="col s1" style="width: 5%;margin-top: 3px;"><i class="material-icons">keyboard_arrow_down</i></div>'
                                // htmlServicesByCategory += '<div id="" class="col s8" >'+ element.categoryname +'</div>'
                                // htmlServicesByCategory += '<div id="" class="col s4" style="text-align: right;"><span style="font-size: 13px;background: #ddd;border-radius: 5px;padding: 2px 6px 2px 6px;">'+ element.services.length +' Services</span></div>'
                                // htmlServicesByCategory += '</div>'

                                htmlServicesByCategory += '<div id="servicesbycategory123">';
                                htmlServicesByCategory += '    <div class="card card-style">';
                                htmlServicesByCategory += '        <div class="content">';
                                htmlServicesByCategory += '            <div class="d-flex">';
                                htmlServicesByCategory += '                <div class="align-self-center">';
                                htmlServicesByCategory += '                    <h2 class="mb-0">' + element.categoryname + '</h2>';
                                htmlServicesByCategory += '                </div>';
                                htmlServicesByCategory += '                <div class="align-self-center ms-auto">';
                                htmlServicesByCategory += '                    <h6 class="mb-0 bg-theme-color font-13 badge bg-blue-dark color-white">' + element.services.length + ' Services</h6>';
                                htmlServicesByCategory += '                </div>';
                                htmlServicesByCategory += '            </div>';
                                htmlServicesByCategory += '            <div class="divider mt-3 mb-3"></div>';

                                htmlServicesByCategory += '<div class="list-group list-custom-large">'
                                element.services.forEach(service => {
                                    // htmlServicesByCategory += '<div class="row">'
                                    // htmlServicesByCategory += '    <div id="" class="col s6" style="padding: 2px;" >'
                                    // htmlServicesByCategory += '        <div style="font-size: 16px;font-weight: bold;color:#5e5e5e">'+ service.servicename +'</div>'
                                    // if(service.description){
                                    //     htmlServicesByCategory += '        <div style="color: #858181;">'+ service.description +'</div>'
                                    // } else {
                                    //     htmlServicesByCategory += '        <div style="color: #858181;">-</div>'
                                    // }

                                    // htmlServicesByCategory += '    </div>'
                                    // htmlServicesByCategory += '    <div id="" class="col s3" style="font-size: 13px;text-align: right;padding: 0px 5px;">'
                                    // htmlServicesByCategory += '        <div style="font-weight: bold;">$'+ service.price.toFixed(2) +'</div>'
                                    // htmlServicesByCategory += '        <div style="color: #858181;">'+ service.duration +'</div>'
                                    // htmlServicesByCategory += '    </div>'
                                    // htmlServicesByCategory += '    <div id="" class="col s3" style="padding: 2px;"  >'
                                    // htmlServicesByCategory += '        <a id="bookappointment" class="hoku_button  element" href="#" tabindex="" style="" data-categoryid="'+ service.categoryid +'" data-categoryid_name="'+ service.categoryid_name +'" data-servicename="'+ service.servicename +'" data-serviceprice="'+ service.price +'" data-servicedescription="'+ service.description +'" data-serviceduration="'+ service.duration +'" recordID="'+ service._id +'" data-servicehours="'+ service.hours +'" data-serviceminuts="'+ service.minutes +'" >Book</a>'
                                    // // htmlServicesByCategory += '       <input type="checkbox" name="'+ service._id +'" value="'+ service._id +'" id="bookappointment'+ service._id +'" /><label><span>&nbsp;</span></label>'
                                    // htmlServicesByCategory += '    </div>'
                                    // htmlServicesByCategory += '</div>'

                                    // htmlServicesByCategory += '<a data-trigger-switch="switch-1" class="border-0" href="#">';
                                    // htmlServicesByCategory += '    <i class="fa font-14 fa-mobile-alt shadow-s bg-yellow-dark"></i>';
                                    // htmlServicesByCategory += '    <span>Apptastic Mobile</span>';
                                    // htmlServicesByCategory += '    <strong>iOS Designed Style</strong>';
                                    // htmlServicesByCategory += '    <div class="custom-control ios-switch scale-switch">';
                                    // // htmlServicesByCategory += '        <input type="checkbox" class="ios-input" id="switch-1">';
                                    // // htmlServicesByCategory += '        <label class="custom-control-label" for="switch-1"></label>';
                                    // htmlServicesByCategory += '           <a href="#" class="btn shadow-bg shadow-bg-m btn-m btn-full mb-3 rounded-s text-uppercase font-900 shadow-s bg-red-light">Buton</a>';
                                    // htmlServicesByCategory += '    </div>';
                                    // // htmlServicesByCategory += '    <i class="fa fa-angle-right"></i>';
                                    // htmlServicesByCategory += '</a>';


                                    // htmlServicesByCategory += '<a href="#">';
                                    // // htmlServicesByCategory += '    <i class="fa font-14 fa-tint rounded-sm shadow-m bg-green-dark"></i>';
                                    // htmlServicesByCategory += '    <span>'+ service.servicename +'</span>';
                                    // htmlServicesByCategory += '    <span class="badge bg-theme-color font-13">Book</span>';
                                    // htmlServicesByCategory += '    <strong>'+ service.description +'</strong>';
                                    // htmlServicesByCategory += '    <i class="fa fa-angle-right"></i>';
                                    // htmlServicesByCategory += '</a> ';

                                    htmlServicesByCategory += '<div class="row">';
                                    htmlServicesByCategory += '    <div class="col-5">';
                                    htmlServicesByCategory += '        <h4>' + service.servicename + '</h4>';
                                    htmlServicesByCategory += '        <p class="mt-n1 pb-0 line-height-m">';
                                    htmlServicesByCategory +=           typeof(service.description) !== "undefined" ? service.description : '';
                                    htmlServicesByCategory += '        </p>';
                                    htmlServicesByCategory += '    </div>';

                                    htmlServicesByCategory += '    <div class="col-3">';
                                    htmlServicesByCategory += '        <h4>$' + service.price.toFixed(2) + '</h4>';
                                    htmlServicesByCategory += '        <p class="mt-n1 pb-0 line-height-m">';
                                    htmlServicesByCategory += service.duration;
                                    htmlServicesByCategory += '        </p>';
                                    htmlServicesByCategory += '    </div>';

                                    htmlServicesByCategory += '    <div class="col-4">';
                                    htmlServicesByCategory += '    <a id="bookappointment" class="pickdatetimeclass btn shadow-bg shadow-bg-m btn-m rounded-s text-uppercase font-900 shadow-s bg-green-dark" href="#" tabindex="" style="line-height: 0;" data-categoryid="' + service.categoryid + '" data-categoryid_name="' + service.categoryid_name + '" data-servicename="' + service.servicename + '" data-serviceprice="' + service.price + '" data-servicedescription="' + service.description + '" data-serviceduration="' + service.duration + '" recordID="' + service._id + '" data-servicehours="' + service.hours + '" data-serviceminuts="' + service.minutes + '" >Book</a>';
                                    // htmlServicesByCategory += '         <a href="#" id="bookappointment" data-menu="pickdatetimemodal" class="pickdatetimeclass btn shadow-bg shadow-bg-m btn-m rounded-s text-uppercase font-900 shadow-s bg-red-light" style="line-height: 0;">Book</a>';
                                    htmlServicesByCategory += '    </div>';

                                    // <div class="col-3">
                                    //     <img src="images/pictures/1s.jpg" class="rounded-s mx-auto mt-1" width="65">
                                    // </div>
                                    htmlServicesByCategory += '</div>';

                                });

                                htmlServicesByCategory += '</div>'

                                htmlServicesByCategory += '</div>';
                                htmlServicesByCategory += '</div>';

                            }
                        });

                        $('#servicesbycategory').append(htmlServicesByCategory);

                        // var acc = document.getElementsByClassName("accordion1");
                        // var i;

                        // for (i = 0; i < acc.length; i++) {
                        //     acc[i].addEventListener("click", function() {

                        //         this.classList.toggle("active");
                        //         var panel = this.nextElementSibling;
                        //         if (panel.style.display === "none") {
                        //             panel.style.display = "block";
                        //             $(this).attr('data-status','active');
                        //             //$('.material-icons').text('keyboard_arrow_down')
                        //         } else {
                        //             panel.style.display = "none";
                        //             $(this).attr('data-status','inactive');
                        //             //$('.material-icons').text('keyboard_arrow_right')
                        //         }

                        //         console.log($(this).attr('data-status'))
                        //     });
                        // }
                        $('#display_loading').addClass('hideme');

                    })
                } else {

                }

            },
            error: function (xhr, status, error) {

            },
        });
    });
}

function processBeforeCallForgetfromothertable_appointmentschedularweb_servicesmodal_61f91155baf7700fc434e1af_CategoryModalServices(paramsType, callback) {
    var response = paramsType;
    callback();
}

function processAfterCallForgetfromothertable_appointmentschedularweb_servicemodal_61f91155baf7700fc434e1af_CategoryModalServices(data, response, callback) {
    callback();
}
function getCategoryModalServices(paramsType) {
    processBeforeCallForgetfromothertable_appointmentschedularweb_servicesmodal_61f91155baf7700fc434e1af_CategoryModalServices(paramsType, function (processBeforeRes) {
        $('#display_loading').removeClass('hideme');

        if (localStorage.getItem('salonlocationid')) {
            paramsType.salonlocationid = localStorage.getItem('salonlocationid');
        }

        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        paramsType.ajaXCallURL = ajaXCallURL;


        var queryMode = getParameterByName('queryMode');
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');

        paramsType.tokenKey = tokenKey;
        paramsType.secretKey = secretKey;
        paramsType.queryMode = queryMode;

        $.ajax({
            url: paramsType.ajaXCallURL + '/booksy/getListDetails_Category61f91155baf7700fc434e1af_servicecategorylistweb_servicecategorylistwebKendoList',
            data: paramsType,
            type: 'POST',
            success: function (response) {
                if (response.status == 0) {
                    processAfterCallForgetfromothertable_appointmentschedularweb_servicemodal_61f91155baf7700fc434e1af_CategoryModalServices(response.data, response, function (processBeforeRes) {
                        var getServices = localStorage.getItem('custaddedservices');
                        getServices = JSON.parse(getServices);
                        // console.log(getServices);
                        var modalServiceHtml = '';
                        $('#modalservicesbycategory').html('');


                        var modalServiceHtml = '';
                        response.data.forEach(element => {
                            if (element.services && element.services.length !== 0) {
                                modalServiceHtml += '<div class="accordion1 row" data-status="active" style="margin-bottom: 0px !important;border-top: 1px solid #ddd;">'
                                //   modalServiceHtml += '<div id="" class="col s1" style="width: 5%;margin-top: 3px;"><i class="material-icons">keyboard_arrow_down</i></div>'
                                modalServiceHtml += '<div id="" class="col s8" >' + element.categoryname + '</div>'
                                modalServiceHtml += '<div id="" class="col s4" style="text-align: right;"><span style="font-size: 13px;background: #ddd;border-radius: 5px;padding: 2px 6px 2px 6px;">' + element.services.length + ' Services</span></div>'
                                modalServiceHtml += '</div>'
                                modalServiceHtml += '<div class="panel">'
                                element.services.forEach(service => {
                                    modalServiceHtml += '<div class="row">'
                                    modalServiceHtml += '    <div id="" class="col s6" style="padding: 2px;">'
                                    modalServiceHtml += '        <div style="font-size: 16px;font-weight: bold;color:#5e5e5e">' + service.servicename + '</div>'
                                    if (service.description) {
                                        modalServiceHtml += '        <div style="color: #858181;">' + service.description + '</div>'
                                    } else {
                                        modalServiceHtml += '        <div style="color: #858181;">-</div>'
                                    }

                                    modalServiceHtml += '    </div>'
                                    modalServiceHtml += '    <div id="" class="col s3" style="font-size: 13px;text-align: right;padding: 0px 5px;">'
                                    modalServiceHtml += '        <div style="font-weight: bold;">$' + service.price.toFixed(2) + '</div>'
                                    modalServiceHtml += '        <div style="color: #858181;">' + service.duration + '</div>'
                                    modalServiceHtml += '    </div>'
                                    modalServiceHtml += '    <div id="" class="col s3"  style="padding: 2px;">'

                                    var isAlreadyBooked = '';
                                    var isAlreadyBookedName = "Book";
                                    if (getServices) {
                                        getServices.forEach(element => {
                                            if (element.serviceid == service._id) {
                                                isAlreadyBooked = "background:grey !important;pointer-events: none;padding: 0px 3px !important;";
                                                isAlreadyBookedName = "Booked";

                                            }

                                        });
                                    }
                                    modalServiceHtml += '<a id="bookmoreappointment' + service._id + '" class="hoku_button  element bookmoreappointment" href="#" tabindex="" style="' + isAlreadyBooked + '" data-categoryid="' + service.categoryid + '" data-categoryid_name="' + service.categoryid_name + '" data-servicename="' + service.servicename + '" data-serviceprice="' + service.price + '" data-servicedescription="' + service.description + '" data-serviceduration="' + service.duration + '" recordID="' + service._id + '" data-servicehours="' + service.hours + '" data-serviceminuts="' + service.minutes + '" >' + isAlreadyBookedName + '</a>'
                                    // modalServiceHtml += '       <input type="checkbox" name="'+ service._id +'" value="'+ service._id +'" id="bookappointment'+ service._id +'" /><label><span>&nbsp;</span></label>'
                                    modalServiceHtml += '    </div>'
                                    modalServiceHtml += '</div>'
                                });

                                modalServiceHtml += '</div>'
                            }
                        });

                        $('#modalservicesbycategory').append(modalServiceHtml);

                        //   var acc = document.getElementsByClassName("accordion1");
                        //   var i;

                        //   for (i = 0; i < acc.length; i++) {
                        //       acc[i].addEventListener("click", function() {

                        //           this.classList.toggle("active");
                        //           var panel = this.nextElementSibling;
                        //           if (panel.style.display === "none") {
                        //               panel.style.display = "block";
                        //               $(this).attr('data-status','active');
                        //               //$('.material-icons').text('keyboard_arrow_down')
                        //           } else {
                        //               panel.style.display = "none";
                        //               $(this).attr('data-status','inactive');
                        //               //$('.material-icons').text('keyboard_arrow_right')
                        //           }

                        //           console.log($(this).attr('data-status'))
                        //       });
                        //   }
                        $('#display_loading').addClass('hideme');

                    })
                } else {

                }

            },
            error: function (xhr, status, error) {

            },
        });
    });
}

function getSalonLocationById(paramsType) {
    paramsType.recordID = getParameterByName('recordID');

    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    paramsType.ajaXCallURL = ajaXCallURL;


    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');

    paramsType.tokenKey = tokenKey;
    paramsType.secretKey = secretKey;
    paramsType.queryMode = queryMode;

    // paramsType.tokenKey = $('#tokenKey').val();
    $.ajax({
        url: paramsType.ajaXCallURL + '/booksy/get_data_by_record_Salonlocation61f91155baf7700fc434e1afsalonlocationlistweb',
        data: paramsType,
        type: 'POST',
        success: function (response) {
            if (response.status == 0) {
                salonLocatioName = response.recordDetails[0].branchname;
                $('.salonlocationname').append(response.recordDetails[0].branchname);
                $('#salonlocationaddress').append(response.recordDetails[0].salonaddress);
                localStorage.setItem('salonlocationid', response.recordDetails[0]._id)
                localStorage.setItem('salonlocationname', response.recordDetails[0].branchname)
                // $('#modalsalonlocationname').append(response.recordDetails[0].branchname);
                $('#modalsalonlocationaddress').append(response.recordDetails[0].salonaddress);

            } else {

            }

        },
        error: function (xhr, status, error) {

        },
    });

}

function processBeforeCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_StartTime(paramsType, callback) {
    var response = paramsType;
    callback();
}

function processAfterCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_StartTime(data, response, callback) {
    callback();
}

function renderStartDate() {
    arrPastTimes = [];
    var currentdate = moment();
    var selecteddatefuture = moment(new Date($("#date42").val()));



    if (selecteddatefuture > currentdate) {
        console.log("Future 123");
    } else {
        var startofdayv1 = moment().startOf('day');
        var calculatedminites = moment().diff(startofdayv1, 'minutes');
        console.log(calculatedminites);

        var addedalready = 0;
        if (calculatedminites > 0) {
            var calculatedminitesinter = Math.ceil(calculatedminites / 15);
            for (var i = 0; i < calculatedminitesinter; i++) {
                var cuculatedtimemoment = moment(new Date()).startOf('day').add(i * 15, 'minutes').format('hh:mmA');
                if (addedalready == 0) {
                    arrPastTimes.push(cuculatedtimemoment);
                }
            }
        } else {

        }
    }

    var paramsType = {};
    paramsType.salonlocationid = getParameterByName('recordID');
    getStartTime(paramsType);


}

function getStartTime(paramsType) {

    // check validation of slots
    var staffArrayMain = [];
    var servicesarr = localStorage.getItem('custaddedservices');
    if (servicesarr) {

        servicesarr = JSON.parse(servicesarr);


        for (var servicesarrField in servicesarr) {

            if (servicesarr[servicesarrField] && servicesarr[servicesarrField].stylistid) {
                staffArrayMain.push(servicesarr[servicesarrField].stylistid);
            }

        }

        paramsType.staffArrayMain = staffArrayMain;



    }

    if ($('#date42').val()) {

        paramsType.checkslotdatestart = moment(new Date($.trim($('#date42').val()))).startOf('day').utc().format('YYYY-MM-DDTHH:mm:ssZ');
        paramsType.checkslotdateend = moment(new Date($.trim($('#date42').val()))).endOf('day').utc().format('YYYY-MM-DDTHH:mm:ssZ');

    }

    processBeforeCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_StartTime(paramsType, function (processBeforeRes) {

        // if (localStorage.getItem('salonlocationid')) {
        //     paramsType.salonlocationid = localStorage.getItem('salonlocationid');
        // }
        $('#display_loading').removeClass('hideme');
        $.ajax({
            url: '/booksy/getfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_StartTime',
            data: paramsType,
            type: 'POST',
            success: function (response) {
                if (response.status == 0) {
                    processAfterCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_StartTime(response.data, response, function (processBeforeRes) {
                        //var selectOptionHtml = '<option value="">Start Time</option>';

                        // set pass values
                        // gConfig.moment(new Date()).utc().startOf('day').format('THH:mm:ssZ');
                        // .format('YYYY-MM-DDTHH:mm:ssZ')
                        if (paramsType.salonlocationid) {
                            var slonestartcount = 0;
                            $.each(response.data, function (keyList, objList) {
                                slonestartcount++;
                                if (slonestartcount == 1) {
                                    salonstarttime = objList.starttime.replace('AM', ' AM').replace('PM', ' PM');
                                }
                                if (response.data.length == slonestartcount) {
                                    salonendtime = objList.starttime.replace('AM', ' AM').replace('PM', ' PM');
                                }
                            });
                        }


                        // var currentdate = moment();
                        // var selecteddatefuture = moment(new Date($("#date42").val()));
                        // // var currentdatestartofday = moment(new Date(calculatedate));

                        // // console.log(currentdate.format('YYYY-MM-DDTHH:mm:ssZ'));
                        // // console.log(calculatedate);
                        // // console.log(currentdatestartofday.format('YYYY-MM-DDTHH:mm:ssZ'));

                        // if(selecteddatefuture > currentdate){
                        //     console.log("Future");
                        // } else {
                        //     console.log("Past");
                        // }

                        // var startofdayv1 = moment().startOf('day');
                        // var calculatedminites = moment().diff(startofdayv1, 'minutes');
                        // console.log(calculatedminites);

                        // var addedalready = 0;
                        // if (calculatedminites > 0) {
                        //     var calculatedminitesinter = Math.ceil(calculatedminites/15);
                        //     for (var i = 0; i < calculatedminitesinter; i++) {
                        //         var cuculatedtimemoment = moment(new Date()).startOf('day').add(i*15,'minutes').format('HH:mmA');
                        //         // if(cuculatedtimemoment == salonstartdate.replace(' AM','AM').replace(' PM','PM')){
                        //         //     addedalready = 1;
                        //         //     arrPastTimes.push(cuculatedtimemoment);
                        //         // } else {

                        //         // }

                        //         if(addedalready == 0){
                        //             arrPastTimes.push(cuculatedtimemoment);
                        //         }

                        //     }
                        // } else {

                        // }



                        // arrPastTimes.push("11:00AM");

                        // arrPastTimes = [];
                        // var currentdate = moment();
                        // var selecteddatefuture = moment(new Date($("#date42").val()));

                        // if(selecteddatefuture > currentdate){
                        //     console.log("Future");
                        // } else {
                        //     var startofdayv1 = moment().startOf('day');
                        //     var calculatedminites = moment().diff(startofdayv1, 'minutes');
                        //     console.log(calculatedminites);

                        //     var addedalready = 0;
                        //     if (calculatedminites > 0) {
                        //         var calculatedminitesinter = Math.ceil(calculatedminites/15);
                        //         for (var i = 0; i < calculatedminitesinter; i++) {
                        //             var cuculatedtimemoment = moment(new Date()).startOf('day').add(i*15,'minutes').format('HH:mmA');
                        //             if(addedalready == 0){
                        //                 arrPastTimes.push(cuculatedtimemoment);
                        //             }
                        //         }
                        //     } else {

                        //     }
                        // }

                        // if(response.slotlist){
                        //     var arrSelectedTimeSlot = [];
                        //     $.each(response.slotlist, function (keySloteList, objSloteList) {
                        //         if(objSloteList.starttimeid_name && objSloteList.endtimeid_name){
                        //             var starttimeslote = moment().format('DD MMMM, YYYY') + " " + objSloteList.starttimeid_name.replace('AM',' AM').replace('PM',' PM');
                        //             var endtimeslote = moment().format('DD MMMM, YYYY') + " " + objSloteList.endtimeid_name.replace('AM',' AM').replace('PM',' PM');

                        //             console.log(starttimeslote);
                        //             console.log(endtimeslote);

                        //             var momstarttimeslote = moment(starttimeslote);
                        //             var momendtimeslote = moment(endtimeslote);

                        //             var slotemindiff = momendtimeslote.diff(momstarttimeslote, 'minutes');

                        //             console.log(slotemindiff);

                        //             // var addedalready = 0;
                        //             if (slotemindiff > 0) {
                        //                 var slotemindiffinter = Math.ceil(slotemindiff/15);

                        //                 var cuculatedtimemoment = moment(new Date(starttimeslote)).format('hh:mmA');
                        //                 arrSelectedTimeSlot.push(cuculatedtimemoment);

                        //                 for (var i = 1; i < slotemindiffinter; i++) {
                        //                     var cuculatedtimemoment = moment(new Date(starttimeslote)).add(i*15,'minutes').format('hh:mmA');
                        //                     arrSelectedTimeSlot.push(cuculatedtimemoment);
                        //                 }
                        //             } else {

                        //             }

                        //         }
                        //     });

                        //     if(arrSelectedTimeSlot.length > 0 && mainTopStylistID == ""){

                        //         const set = new Set(arrSelectedTimeSlot);

                        //         const duplicates = arrSelectedTimeSlot.filter(item => {
                        //             if (set.has(item)) {
                        //                 set.delete(item);
                        //             } else {
                        //                 return item;
                        //             }
                        //         });

                        //         console.log(duplicates);

                        //         arrPastTimes = $.merge( duplicates, arrPastTimes )

                        //     } else {

                        //         $.each(response.slotlist, function (keySloteList, objSloteList) {
                        //             if(objSloteList.starttimeid_name && objSloteList.endtimeid_name){
                        //                 var starttimeslote = moment().format('DD MMMM, YYYY') + " " + objSloteList.starttimeid_name.replace('AM',' AM').replace('PM',' PM');
                        //                 var endtimeslote = moment().format('DD MMMM, YYYY') + " " + objSloteList.endtimeid_name.replace('AM',' AM').replace('PM',' PM');

                        //                 console.log(starttimeslote);
                        //                 console.log(endtimeslote);

                        //                 var momstarttimeslote = moment(starttimeslote);
                        //                 var momendtimeslote = moment(endtimeslote);

                        //                 var slotemindiff = momendtimeslote.diff(momstarttimeslote, 'minutes');

                        //                 console.log(slotemindiff);

                        //                 // var addedalready = 0;
                        //                 if (slotemindiff > 0) {
                        //                     var slotemindiffinter = Math.ceil(slotemindiff/15);

                        //                     var cuculatedtimemoment = moment(new Date(starttimeslote)).format('hh:mmA');
                        //                     arrPastTimes.push(cuculatedtimemoment);

                        //                     for (var i = 1; i < slotemindiffinter; i++) {
                        //                         var cuculatedtimemoment = moment(new Date(starttimeslote)).add(i*15,'minutes').format('hh:mmA');
                        //                         arrPastTimes.push(cuculatedtimemoment);
                        //                     }
                        //                 } else {

                        //                 }

                        //             }
                        //         });


                        //     }


                        // }

                        if (response.slotserviceslist) {
                            $.each(response.data, function (keySalonSlotList, objSalonSlotList) {
                                var totalCount = 0;
                                $.each(response.slotserviceslist, function (keySloteList, objSloteList) {
                                    console.log(objSloteList);
                                    var arrSelectedservicesSlotsStylist = [];
                                    $.each(objSloteList, function (keySloteServiceList, objSloteServiceList) {
                                        console.log(objSloteServiceList);
                                        if (objSloteServiceList.starttimeid_name && objSloteServiceList.endtimeid_name) {
                                            var starttimeslote = moment().format('DD MMMM, YYYY') + " " + objSloteServiceList.starttimeid_name.replace('AM', ' AM').replace('PM', ' PM');
                                            var endtimeslote = moment().format('DD MMMM, YYYY') + " " + objSloteServiceList.endtimeid_name.replace('AM', ' AM').replace('PM', ' PM');

                                            console.log(starttimeslote);
                                            console.log(endtimeslote);

                                            var momstarttimeslote = moment(starttimeslote);
                                            var momendtimeslote = moment(endtimeslote);

                                            var slotemindiff = momendtimeslote.diff(momstarttimeslote, 'minutes');

                                            console.log(slotemindiff);

                                            // var addedalready = 0;
                                            if (slotemindiff > 0) {
                                                var slotemindiffinter = Math.ceil(slotemindiff / 15);

                                                var cuculatedtimemoment = moment(new Date(starttimeslote)).format('hh:mmA');
                                                arrSelectedservicesSlotsStylist.push(cuculatedtimemoment);

                                                for (var i = 1; i < slotemindiffinter; i++) {
                                                    var cuculatedtimemoment = moment(new Date(starttimeslote)).add(i * 15, 'minutes').format('hh:mmA');
                                                    arrSelectedservicesSlotsStylist.push(cuculatedtimemoment);
                                                }
                                            }
                                        }
                                    });
                                    if (arrSelectedservicesSlotsStylist.indexOf(objSalonSlotList.starttime) >= 0) {
                                        totalCount++;
                                    }
                                });
                                if (totalCount == response.locationstylistcount) {
                                    arrPastTimes.push(objSalonSlotList.starttime);
                                }
                            });
                        }

                        var selectOptionHtml = '<option disabled selected value="">Select</option>';
                        let datalength = response.data.length;
                        $.each(response.data, function (keyList, objList) {
                            if (keyList < (datalength - 3)) {


                                // for Saturday and Sunday calculation
                                var dayofweeknumber = moment(new Date($("#date42").val())).weekday();

                                if (dayofweeknumber == 0 || dayofweeknumber == 6) {

                                    var starttimesloteone = moment(new Date($("#date42").val())).format('DD MMMM, YYYY') + " 05:00 PM";
                                    var endtimesloteone = moment(new Date($("#date42").val())).format('DD MMMM, YYYY') + " " + objList.starttime.replace('AM', ' AM').replace('PM', ' PM');

                                    console.log(starttimesloteone);
                                    console.log(endtimesloteone);

                                    var momstarttimesloteone = moment(starttimesloteone);
                                    var momendtimesloteone = moment(endtimesloteone);

                                    var slotemindiff = momendtimesloteone.diff(momstarttimesloteone, 'minutes');

                                    console.log(slotemindiff);

                                    if (slotemindiff >= 0 || slotemindiff == -30 || slotemindiff == -15) {
                                        arrPastTimes.push(objList.starttime);
                                    }

                                    if (slotemindiff >= 0 || slotemindiff == -30 || slotemindiff == -15) {

                                    } else {
                                        // check pass values
                                        if (arrPastTimes.indexOf(objList.starttime) >= 0) {
                                            selectOptionHtml += '<option  sequence="' + objList.sequence + '" value="' + objList._id + '" disabled>' + objList.starttime + '</option>';
                                        } else {
                                            selectOptionHtml += '<option  sequence="' + objList.sequence + '" value="' + objList._id + '">' + objList.starttime + '</option>';
                                        }
                                    }


                                } else {
                                    // check pass values
                                    if (arrPastTimes.indexOf(objList.starttime) >= 0) {
                                        selectOptionHtml += '<option  sequence="' + objList.sequence + '" value="' + objList._id + '" disabled>' + objList.starttime + '</option>';
                                    } else {
                                        selectOptionHtml += '<option  sequence="' + objList.sequence + '" value="' + objList._id + '">' + objList.starttime + '</option>';
                                    }
                                }



                            }
                        });
                        $('#starttimeid43').html(selectOptionHtml); //2
                        if (dropdownvalues['starttimeid']) {
                            $('#starttimeid43').val(dropdownvalues['starttimeid']);
                        }
                        $('#starttimeid43').material_select();

                        $('#display_loading').addClass('hideme');
                    })
                } else {
                    $('#display_loading').addClass('hideme');
                }

            },
            error: function (xhr, status, error) {
                $('#display_loading').addClass('hideme');
            },
        });
    });
}


function processBeforeCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_EndTime(paramsType, callback) {
    var response = paramsType;
    callback();
}

function processAfterCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_EndTime(data, response, callback) {
    callback();
}

function getEndTime(paramsType) {
    processBeforeCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_EndTime(paramsType, function (processBeforeRes) {

        // if (localStorage.getItem('salonlocationid')) {
        //     paramsType.salonlocationid = localStorage.getItem('salonlocationid');
        // }

        $.ajax({
            url: '/booksy/getfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_EndTime',
            data: paramsType,
            type: 'POST',
            success: function (response) {
                if (response.status == 0) {
                    processAfterCallForgetfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_EndTime(response.data, response, function (processBeforeRes) {
                        //var selectOptionHtml = '<option value="">End Time</option>';
                        var selectOptionHtml = '<option disabled selected value="">Select</option>';
                        $.each(response.data, function (keyList, objList) {
                            selectOptionHtml += '<option sequence="' + objList.sequence + '" value="' + objList._id + '">' + objList.starttime + '</option>';
                        });
                        $('#endtime44').html(selectOptionHtml); //2
                        $('#endtime44').prop('disabled', true);
                        // if (dropdownvalues['endtimeid']) { $('#endtime44').val(dropdownvalues['endtimeid']); }

                        if (paramsType.selected != "A") {
                            $('#endtime44').val(paramsType.selected);
                        }

                        $('#endtime44').material_select();
                    })
                } else {

                }

            },
            error: function (xhr, status, error) {

            },
        });
    });
}

function serviceEndTime(starttime, service) {
    // let starttime = objParams.starttimeid_name;
    let [hours, allmin] = starttime.split(':');
    let allminarr = allmin.match(/.{1,2}/g);
    let minutes = allminarr[0]
    let ampm = allminarr[1];
    hours = parseInt(hours)
    minutes = parseInt(minutes)
    if (ampm == "PM" && hours < 12) hours = hours + 12;
    if (ampm == "AM" && hours == 12) hours = hours - 12;
    if (hours < 10) hours = "0" + hours;
    if (minutes < 10) minutes = "0" + minutes;

    let durationHours = parseInt(service.servicehours.replace('h', ''));
    let durationMinutes = parseInt(service.serviceminuts.replace('min', ''));
    hours = hours + durationHours
    minutes = minutes + durationMinutes
    if (hours >= 24) hours = hours - 24

    hours = Math.floor((minutes) / 60) + hours;
    minutes = (minutes) % 60;
    if (hours < 10) hours = "0" + hours;
    if (minutes < 10) minutes = "0" + minutes;


    var suffix = hours >= 12 ? "PM" : "AM";
    hours = (hours + 11) % 12 + 1;
    if (hours < 10) hours = "0" + hours;
    // if(minutes<10) minutes = "0" + minutes;
    finalTime = hours + ':' + minutes + suffix

    console.log(finalTime);

    return finalTime;
}

function convert12To24Hours(starttime) {
    let [hours, allmin] = starttime.split(':');
    let allminarr = allmin.match(/.{1,2}/g);
    let minutes = allminarr[0]
    let ampm = allminarr[1];
    hours = parseInt(hours)
    minutes = parseInt(minutes)
    if (ampm == "PM" && hours < 12) hours = hours + 12;
    if (ampm == "AM" && hours == 12) hours = hours - 12;
    if (hours < 10) hours = "0" + hours;
    if (minutes < 10) minutes = "0" + minutes;

    return hours + ":" + minutes + ":00";
}
