
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
$(document).ready(function () {
    $('#display_loading').removeClass('hideme');
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    let objParamsList = {};
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.queryMode = "adminlist";
    objParamsList.isadmin = 1;
    $(document).on('click', '#chatbutton', function () {
        var adminrecordID = $(this).attr('adminrecordID');
        var queryMode = getParameterByName('queryMode');
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var ajaXCallURL = $('#ajaXCallURL').val();
        var appJSON = {};
        appJSON.title = 'Discussion'
        appJSON.chatSegmentTitle = 'Recent';
        appJSON.groupSegmentTitle = 'Classes';
        appJSON.groupByTitle = 'People';
        appJSON.hideContactTab = true;
        appJSON.tokenKey = tokenKey;
        appJSON.secretKey = secretKey;
        appJSON.queryMode = queryMode;
        appJSON.action = queryMode;
        appJSON.ajaXCallURL = ajaXCallURL;
        appJSON.organizationID = $('#organizationID').val();
        appJSON.appID = $('#appID').val();
        appJSON.chatTabType = 6;
        appJSON.userID = adminrecordID;
        appJSON.recordID = adminrecordID;
        if (DEVICE_TYPE == 'ios') {
            setupWebViewJavascriptBridge(function (bridgeObj) {
                bridgeObj.callHandler('loadNativeChatIndivisualWindow', appJSON, function (response) { });
            });
        } else {
            window.Android.loadNativeChatIndivisualWindow(JSON.stringify(appJSON));
        }
    })
    getcontactusinfo(objParamsList);
});//end of ready 2

function getcontactusinfo(objParamsList) {
    const url = objParamsList.ajaXCallURL + '/booksy/getListDetails_Usermanagement61f91155baf7700fc434e1af_usermanagementlistweb_usermanagementlistwebKendoList';
    $.ajax({
        url,
        type: 'POST',
        data: objParamsList,
        success: function (response) {
            if (response.status == 0 && response.data && response.data.length > 0) {
                let html = '';
                $.each(response.data, function (keyList, objList) {
                    let imgUrl = '';
                    if (objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID) {
                        imgUrl = CDN_PATH + objList.userphotoupload[0].mediaID + '_compressed.png';
                    }
                    objList['name'] = objList['name'] ? objList['name'] : '';
                    let title = objList['name'];
                    html += '<div class="card card-style mx-0 mb-3 dcard_categories_collectioncontainer">';
                    html += '    <div class="content">';
                    html += '       <div class="d-flex">';
                    html += '           <div>';
                    html += '               <img onerror="this.src =\'https://appscdn-us.hokuapps.com/card.png\'" src="' + imgUrl + '" class="rounded-m me-3" alt="" width="100" height="100" style="object-fit:cover;">';
                    html += '           </div>';
                    html += '           <div class="w-100 ">';
                    html += '               <h3 class="text-capitalize">' + title + '</h3>';
                    // html += '               <div class="float-start stepper rounded-s scale-switch ms-n1">';
                    // html += '                   <a max="' + availQty + '" class="stepper-sub"><i class="fa fa-minus color-theme opacity-40"></i></a>';
                    html += '                   <a adminrecordID="'+objList._id+'"  id="chatbutton" class="btn btn-xs mb-3 rounded-s text-uppercase font-900 shadow-s bg-green-dark">Chat</span></a>';
                    // html += '                   <a max="' + availQty + '" class="stepper-add"><i class="fa fa-plus color-theme opacity-40"></i></a>';
                    // html += '               </div>';
                    html += '           </div>';
                    html += '       </div>';
                    html += '   </div>';
                    html += '</div>';



                });
                $('#aboutappcontainer').html(html);
                $('#aboutappcontainer').removeClass('hideme');
                $('#display_loading').addClass('hideme');
            }
        },
        error: function (error) {
            console.log("error in getting privacy and policy : " + error);
            return;
        }
    })
}