
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
let serviceidarr = [];
var totaldcard_topimage216560043190_collectioncontainer = 0;
$(document).ready(function () {
    $('.page-content').css({
        'height': 'calc(100vh - 62px)',
        'overflow-y': 'scroll',
        'padding-bottom': '0px',
    });
    const custaddedservices = JSON.parse(localStorage.getItem('custaddedservices')) || [];
    for (let x of custaddedservices) {
        serviceidarr.push(x.serviceid);
    }
    $('#servicedate').val(moment(new Date()).format('YYYY-MM-DD'));
    if ($('.view_list_record').length) { $('.view_list_record').show(); }
    localStorage.removeItem('objParamsList');
    if ($('.js-candlestick').length) $("input[type='checkbox']").candlestick({ 'on': 'Yes', 'off': 'No', 'nc': 'NA', 'default': 'NA', 'swipe': false, 'allowManualDefault': true });
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    skip = 0;
    let paramsType = {};
    paramsType.ajaXCallURL = ajaXCallURL;
    paramsType.tokenKey = tokenKey;
    paramsType.secretKey = secretKey;
    paramsType.functionName = 'servicesList';
    servicesList(paramsType);

    $(document).on('click', '.staffer_dcard', function () {
        let stylishid = $(this).attr('stylishid');
        let name = $(this).attr('service');
        let mediaid = $(this).attr('mediaid');
        let custaddedservices = JSON.parse(localStorage.getItem('custaddedservices')) || [];
        if (custaddedservices && custaddedservices.length > 0) {
            custaddedservices[0].stylistid = stylishid;
            custaddedservices[0].stylistid_name = name;
            custaddedservices[0].mediaid = mediaid;
        }
        localStorage.setItem('custaddedservices', JSON.stringify(custaddedservices));
        let nextPage = 'app_servicepickdateandtime';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        return false;
    });
    $(document).on('click', '#backbutton', function(e) {
        var queryParams = queryStringToJSON();
        var nextPage = 'app_servicepickdateandtime';
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        return false;
    });

    $(document).on('click', '.bookbtn', function () {
        if ($(this).hasClass('booked')) return;
        $(this).removeClass('bg-green-dark').addClass('bg-secondary booked').html('Booked');
        const currentService = JSON.parse(localStorage.getItem('custaddedservices')) || [];
        let categoryid = $(this).attr('categoryid');
        let categoryid_name = $(this).attr('categoryname');
        let salonlocationid = localStorage.getItem('salonlocationid');
        let salonlocationid_name = localStorage.getItem('salonlocationname');
        let servicedescription = $(this).attr('servicedescription');
        let serviceduration = $(this).attr('serviceduration');
        let servicehours = $(this).attr('servicehours');
        let serviceminuts = $(this).attr('serviceminuts');
        let serviceid = $(this).attr('serviceid');
        let servicename = $(this).attr('servicename');
        let serviceprice = $(this).attr('serviceprice');
        let stylistid_name = 'Anyone';

        let totalHours = parseInt(localStorage.getItem('total-hours')) + parseInt(servicehours);
        let totalMinutes = parseInt(localStorage.getItem('total-minutes')) + parseInt(serviceminuts);
        let totalPrice = parseFloat(localStorage.getItem('total-price')) + parseFloat(serviceprice);

        var hours = Math.floor(totalMinutes / 60) + totalHours;          
        var minutes = totalMinutes % 60;

        localStorage.setItem('total-hours',hours);
        localStorage.setItem('total-minutes',minutes);
        localStorage.setItem('total-price',totalPrice);
        

        let newService = {};
        newService.categoryid = categoryid;
        newService.categoryid_name = categoryid_name;
        newService.salonlocationid = salonlocationid;
        newService.salonlocationid_name = salonlocationid_name;
        newService.servicedescription = servicedescription;
        newService.serviceduration = serviceduration;
        newService.servicehours = servicehours;
        newService.serviceminuts = serviceminuts;
        newService.serviceid = serviceid;
        newService.servicename = servicename;
        newService.serviceprice = parseFloat(serviceprice).toFixed(2);
        newService.stylistid_name = stylistid_name;
        console.log(newService);
        currentService.push(newService);
        localStorage.setItem('custaddedservices', JSON.stringify(currentService));
        $('#backbutton').trigger('click');
    })


});//end of ready 2


function servicesList(paramsType) {
    paramsType.salonaddressid = localStorage.salonlocationid;
    paramsType.queryMode = 'mylist';
    paramsType.skip = skip;
    paramsType.fetch = fetchRecord;
    localStorage.setItem('objParamsList', JSON.stringify(paramsType));
    const url = paramsType.ajaXCallURL + '/booksy/getListDetails_Category61f91155baf7700fc434e1af_servicecategorylistweb_servicecategorylistwebKendoList';
    $('#display_loading').removeClass('hideme');
    $.ajax({
        url,
        type: 'POST',
        data: paramsType,
        success: function (response) {
            showserviceslistdcardMobileView(response);
        },
        error: function (error) {
            $('#display_loading').addClass('hideme');
            console.log(error);
        }
    })
}

function showserviceslistdcardMobileView(response) {
    let custaddedservices = JSON.parse(localStorage.getItem('custaddedservices')) || [];
    if (custaddedservices && custaddedservices.length) {
    }
    var html = '';
    $('#display_loading').removeClass('hideme')
    if (response.data.length == 0 && !$('.services_dcard').length) {
        html += '<div class="mx-0 card card-style bg-secondary animated swing">';
        html += '    <div class="content">';
        html += '        <h2 class="text-center color-white my-4">No record Found!</h2>';
        html += '    </div>';
        html += '</div>';
        $('#servicelist').html(html);
        $('#display_loading').addClass('hideme');
    } else {
        html = '';
        var radioGroups = [];
        if (!response.showShimmer) {
            skip = skip + response.data.length;
        }
        $.each(response.data, function (keyList, objList) {
            const servicesLength = objList.services.length;
            let categoryname = objList['categoryname'] ? objList['categoryname'] : '';
            html += '<div class="card card-style shadow-0 mb-2 services_dcard">';
            html += '   <button class="border-0 btn accordion-btn no-effect text-capitalize pe-2 mb-0" data-bs-toggle="collapse" data-bs-target="#service' + (servicesLength > 0 ? keyList : '') + '">';
            html += '       <div class="row mb-0 px-0 align-items-center">';
            html += '       <div class="col-9">';
            html += '           <i class="fa fa-chevron-down font-10 accordion-icon float-start me-3"></i>';
            html += '           <div class="text-truncate">' + categoryname + '</div>';
            html += '       </div>';
            html += '       <div class="col-3">';
            html += '           <div class="float-end text-nowrap bg-highlight px-2 py-1 rounded-l">' + servicesLength + ' Services</div>'
            html += '       </div>';
            html += '   </button>';

            html += '   <div id="service' + keyList + '" class="collapse bg-theme show" data-bs-parent="#servicelist">';
            html += '       <div class="">';
            $.each(objList.services, function (index, data) {
                let bookedStatus = false;
                if (serviceidarr.includes(data._id)) {
                    bookedStatus = true;
                }
                let servicename = data['servicename'] ? data['servicename'] : '';
                let description = data['description'] ? data['description'] : '';
                let price = data['price'] ? '$' + data['price'].toFixed(2) : '';
                let duration = data['duration'] ? data['duration'] : '';
                let categoryid = data['categoryid'] ? data['categoryid'] : '';
                let categoryid_name = data['categoryid_name'] ? data['categoryid_name'] : '';
                let salonlocationid_name = data['salonlocationid_name'] ? data['salonlocationid_name'] : '';
                let hours = data['hours'] ? data['hours'] : '';
                let minutes = data['minutes'] ? data['minutes'] : '';
                html += '<div class="content">';
                html += '    <div class="row align-items-start mb-0">';
                // html += '        <div class="col-9">';
                // html += '            <div class="d-flex justify-content-between gap-2">';
                html += '                <div class="col-5">';
                html += '                    <h3 class="text-capitalize">' + servicename + '</h3>';
                html += '                    <p class="lh-base">' + description + '</p>';
                html += '                </div>';
                html += '                <div class="text-end col-3">';
                html += '                    <strong class="color-black text-nowrap">' + price + '</strong>';
                html += '                    <div class="text-nowrap">' + duration + '</div>';
                html += '                </div>';
                // html += '            </div>';
                // html += '        </div>';
                html += '        <div class="col-4">';
                html += '            <a categoryid="' + categoryid + '" categoryname="' + categoryid_name + '" salonlocationid_name="' + salonlocationid_name + '" servicedescription="' + description + '" serviceduration="' + duration + '" servicehours="' + hours + '" serviceid="' + data._id + '" serviceminuts="' + minutes + '" servicename="' + servicename + '" serviceprice="' + data.price + '" class="bookbtn font-14 btn ' + (bookedStatus ? 'bg-secondary booked' : 'bg-green-dark') + ' color-white rounded-xl py-1 px-3 float-end" style="width:fit-content;" '+(bookedStatus ? '' : 'data-back-button')+'>' + (bookedStatus ? 'Booked' : 'Book') + '</a>';
                html += '        </div>';
                html += '    </div>';
                html += '</div>';
            })
            html += '       </div>';
            html += '   </div>';
            html += '</div>';
            html += '</div>';
        });
        var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        $('#servicelist').append(html);
        $('#display_loading').addClass('hideme');
        //Accordion Rotate
        const accordionBtn = document.querySelectorAll('.accordion-btn');
        if (accordionBtn.length) {
            accordionBtn.forEach(el => el.addEventListener('click', event => {
                el.querySelector('i').classList.toggle('fa-rotate-180');
            }));
        }
    };
};
