var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
$(document).ready(function() {
    // $('#display_loading').removeClass('hideme');
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());

    // terms and conditions
    $(document).on('click', '#termslistbtn', function() {
        var nextPage = 'app_logistictermslist';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        window.location.href = pageurl;
        return false;
    });

    // privacy policy
    $(document).on('click', '#privacylistbtn', function() {
        var nextPage = 'app_logisticprivacylist';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        window.location.href = pageurl;
        return false;
    });

    // FAQ
    $(document).on('click', '#faqlistbtn', function() {
        var nextPage = 'app_logisticfaqlist';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        window.location.href = pageurl;
        return false;
    });

    // About App
    $(document).on('click', '#aboutappbtn', function() {
        var nextPage = 'app_logisticaboutapp';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        window.location.href = pageurl;
        return false;
    });
    //contact us 
    $(document).on('click', '#contactus', function() {
        var nextPage = 'app_contactus';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        window.location.href = pageurl;
        return false;
    });
    $(document).on('click', '#logoutbtn', function() {
        try {
            var element = $(this);
            var objParams = {};
            objParams.recordID = getParameterByName('recordID');
            if ($(this).attr('recordID')) {
                objParams.recordID = $(this).attr('recordID');
            }
            customcodelogout(objParams, element, {}, function(processCustomcode) {
                return false;
            });
        } catch (error) {
            console.log('Error in customcode click', error);
        }
    })




    $(document).on('click', '#deleteUserAccount', function() {
        // var recordID = $('#deleteRecordID').val();
        var paramsDelete = {};
        paramsDelete.tokenKey = getParameterByName('tokenKey');
        paramsDelete.secretKey = getParameterByName('secretKey')
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        paramsDelete.recordID = localStorage.getItem('userID');
        paramsDelete.queryMode = 'delete'
        paramsDelete.ajaXCallURL = ajaXCallURL;
        paramsDelete.isDelete = 1;

        var callUrl = '/booksy/deleteRecordcustomermanagementlistweb_Usermanagement61f91155baf7700fc434e1af';

        if (localStorage.IDENTITY_TOKEN) {
            callUrl = '/booksy/deleteUser61f91155baf7700fc434e1af';
        }
        $.ajax({
            url: paramsDelete.ajaXCallURL + callUrl,
            data: paramsDelete,
            type: 'POST',
            success: function(response) {
                if (response.status == 0) {
                    var element = $(this);
                    var objParams = {};
                    objParams.recordID = getParameterByName('recordID');
                    if ($(this).attr('recordID')) {
                        objParams.recordID = $(this).attr('recordID');
                    }

                    customcodelogout(objParams, element, {}, function(processCustomcode) {
                        return false;
                    });
                } else {

                }
            },
            error: function(xhr, status, error) {

            },
        });
        return false;
    });




}); //end of ready 2

function customcodelogout(objParams, element, response, callback) {
    try {
        var queryMode = 'add';
        var ajaXCallURL = getParameterByName('ajaXCallURL');
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        logoutNativeCall(tokenKey, queryMode, secretKey, ajaXCallURL);
        return false;
        callback();
    } catch (err) {
        callback();
        // console.log('Error in customcode', err);
    }
}
