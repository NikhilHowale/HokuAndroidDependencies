
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
let grandTotal = 0;
let toastMsg = [];
var transportationamount = 0;
var parentresponceid = "";
var isorderguestuser = 0;
var totaldcard_topimage216560043190_collectioncontainer = 0;
const appUser = JSON.parse(localStorage.getItem('appUser')) || {};

$(document).ready(function () {
    var guestuserstatus = localStorage.getItem('userRole');
    if(guestuserstatus == "guest" || guestuserstatus == "Guest"){
        isorderguestuser = 1;
    }
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var queryMode = getParameterByName('queryMode');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    $("#userphone").intlTelInput({
        initialCountry: "sg",
        preferredCountries: ["sg", "my"],
        separateDialCode: true,
        utilsScript: "countrycodes/js/utils.js",
    });
    let objParamsList = {};
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    objParamsList.queryMode = queryMode;

    var mask1 = "0000 0000";
    $("#userphone").attr("placeholder", mask1);
    $("#userphone").mask(mask1);
    $("#userphone").attr("dialCode", "65").attr("countryCode", "sg");

    $("#userphone").on("countrychange", function (e, countryData) {
        $("#userphone").val("");
        var dialCode = "+" + countryData.dialCode + " ";
        var iso2 = countryData.iso2;
        var sampleNumber = intlTelInputUtils.getExampleNumber(iso2, false, 1);
        var placeholder = sampleNumber.replace(dialCode, "");
        var mask1 = placeholder.replace(/[0-9]/g, 0);
        $("#userphone")
            .attr("placeholder", mask1)
            .attr("dialCode", countryData.dialCode)
            .attr("countryCode", iso2);
        $("#userphone").mask(mask1);
    });
    displayCartData();

    $(document).on('click', '.removeCart', function (e) {
        const id = $(this).prop('id');
        const cart = JSON.parse(localStorage.getItem('cart'));
        let _cart = [...cart];
        const updatedCart = _cart.filter((item) => {
            return item.id != id;
        });
        localStorage.setItem('cart', JSON.stringify(updatedCart));
        displayCartData();
    });
    var reload = localStorage.getItem('onrelaod');
    if(reload == 1){
        localStorage.setItem('onrelaod',0);
        window.location.reload();
    }
    $(document).on('click', '#placeorderbtn', function () {
        localStorage.setItem('onrelaod',1);
        const cart = JSON.parse(localStorage.getItem('cart')) || [];
        let objParams = {};
        objParams.tokenKey = tokenKey;
        objParams.secretKey = secretKey;
        objParams.ajaXCallURL = ajaXCallURL;
        let errorField = [];

        const fullname = $.trim($('#fullname').val());
        if (fullname == '') {
            errorField.push($('#fullname'));
        } else if (fullname != '' && $('#fullname').siblings('.valid').hasClass('disabled')) {
            errorField.push($('#fullname'));
        } else {
            objParams.customerid_name = fullname;
        }
        objParams.customerid = localStorage.userID;
        const email = $.trim($('#useremail').val());
        if (email == '') {
            errorField.push($('#useremail'));
        } else if (email != '' && $('#useremail').siblings('.valid').hasClass('disabled')) {
            errorField.push($('#useremail'));
        } else {
            objParams.email = email;
        }

        let phone = $.trim($('#userphone').val());
        var placeholder = $('#userphone').attr('placeholder');
        phone = phone.replace(/[^0-9]/gi, '');
        placeholder = placeholder.replace(/[^0-9]/gi, '');
        if (phone == '') {
            toastMsg.push({ type: "warning", msg: "Mobile Number is required" });
        } else if (phone && placeholder.length != phone.length) {
            toastMsg.push({ type: "warning", msg: "Valid Mobile Number is required" });
        } else {
            const countryData = $("#userphone").intlTelInput("getSelectedCountryData");
            objParams.contactnumber_countrycode = countryData.iso2;
            objParams.contactnumber_dialcode = countryData.dialCode;
            objParams.contactnumber = phone;
        }

        const address = $.trim($('#useraddress').val());
        if (address == '') {
            errorField.push($('#useraddress'));
        } else if (address != '' && $('#useraddress').siblings('.valid').hasClass('disabled')) {
            errorField.push($('#useraddress'));
        } else {
            objParams.address = address;
        }

        const notes = $.trim($('#usernotes').val());
        if (notes != '') {
            objParams.notes = notes;
        }

        if (errorField.length <= 0 && toastMsg.length <= 0) {
            const cart = JSON.parse(localStorage.getItem('cart')) || [];
            const objList = cart[0];
            $('#display_loading').removeClass('hideme');
            objParams.productid_name = objList.name;
            objParams.quentity = objList.quantity;
            objParams.productid = objList.id;
            objParams.productcost = objList.price;
            objParams.totalcost = parseFloat(objList.price) * parseFloat(objList.quantity);
            objParams.gst = objParams.totalcost * parseFloat(objList.gst) / 100;
            objParams.grandtotal = objParams.totalcost + objParams.gst + transportationamount;
            objParams.userId = localStorage.userID;
            objParams.isDelete = 0;
            objParams.actualamount = grandTotal + transportationamount;
            objParams.transportationamount = transportationamount;
            objParams.isExternalBooking = 1;
            objParams.rolename = "customer";
            objParams.isParentProduct = 1;
            objParams.isorderfrommobile = 1;
            objParams.isorderguestuser = isorderguestuser;
            objParams.purchasetype = "Product";
            objParams.orderconfirmdate = moment(new Date()).utc().format('YYYY-MM-DDTHH:mm:ssZ');
            objParams.status = 'Confirmed';
            objParams.callUrl = '/booksy/saveProductCheckout61f91155baf7700fc434e1af';
            $('#display_loading').removeClass('hideme');
            $.ajax({
                url: objParams.ajaXCallURL + objParams.callUrl,
                data: objParams,
                type: 'POST',
                success: function (response) {
                    if (response.status == 0) {
                        parentresponceid = response.data._id;
                          if (cart.length > 1) {
                            groupProduct(objParams, response.data._id);
                        } else {
                            $('.menu-hider,#page').addClass('pe-none');
                            $('#display_loading').addClass('hideme');
                        }
                    //     var appJSON = {};
                    //     appJSON.successPage = 'app_paymentsuccessthankyou_61f91155baf7700fc434e1af.html';
                    //     appJSON.failurePage = 'app_paymentfailed_61f91155baf7700fc434e1af.html';
                    //     appJSON.extraparams = 'recordID=' + response.data._id;
                    //     var AWSCredentials = localStorage.getItem("AWSCredentials");
                    //     if (localStorage.IDENTITY_TOKEN) {
                    //         var token = localStorage.IDENTITY_TOKEN;
                    //         var playload = JSON.parse(atob(token.split(".")[1]));
                    //         appJSON.Authorization = token;
                    //         appJSON.Expiration = playload.exp;
                    //     } else if (AWSCredentials) {
                    //         AWSCredentials = JSON.parse(AWSCredentials);
                    //         appJSON.accessKeyId = AWSCredentials.accessKeyId;
                    //         appJSON.secretAccessKey = AWSCredentials.secretAccessKey;
                    //         appJSON.sessionToken = AWSCredentials.sessionToken;
                    //         appJSON.Expiration = AWSCredentials.Expiration;
                    //     }
                    //     var tokenKey = getParameterByName('tokenKey');
                    //     var secretKey = getParameterByName('secretKey');
                    //     var queryMode = getParameterByName('queryMode');
                    //     var recordID = getParameterByName('recordID');
                    //     var ios = navigator.userAgent.toLowerCase().indexOf("ios");
                    //     var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
                    //     // if (DEVICE_TYPE == 'ios') {
                    //     //     bridgeObj.callHandler('setRedirectPagesforExternal', appJSON, function (response) {
                    //     //     });
                    //     // } else {
                    //     //     window.Android.setRedirectPagesforExternal(JSON.stringify(appJSON));
                    //     // }
                    //     var ajaXCallURL = $('#ajaXCallURL').val();
                    //     var appurl = CognitoConfig.APP_URL;
                    //     IDENTITY_TOKEN = localStorage.IDENTITY_TOKEN;
                    //     window.location.href = appurl + '/payment/61f91155baf7700fc434e1af/payment.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&totalamount=' + objParams.actualamount + '&queryMode=mylist' + '&ordersid=' + response.data._id + '&recordID=' + response.data._id + '&transactionID=' + response.data._id + '&authorization=' + IDENTITY_TOKEN;
                    }
                },
                error: function (error) {
                    console.log('Error in order placing : ' + error);
                }
            });
            $(document).ajaxStop(function(){
                console.log('inside stop');

                var appJSON = {};
                appJSON.successPage = 'app_paymentsuccessthankyou_61f91155baf7700fc434e1af.html';
                appJSON.failurePage = 'app_paymentfailed_61f91155baf7700fc434e1af.html';
                // appJSON.extraparams = 'recordID=' + response.data._id;
                appJSON.extraparams = 'recordID=' + parentresponceid;
                var AWSCredentials = localStorage.getItem("AWSCredentials");
                if (localStorage.IDENTITY_TOKEN) {
                    var token = localStorage.IDENTITY_TOKEN;
                    var playload = JSON.parse(atob(token.split(".")[1]));
                    appJSON.Authorization = token;
                    appJSON.Expiration = playload.exp;
                } else if (AWSCredentials) {
                    AWSCredentials = JSON.parse(AWSCredentials);
                    appJSON.accessKeyId = AWSCredentials.accessKeyId;
                    appJSON.secretAccessKey = AWSCredentials.secretAccessKey;
                    appJSON.sessionToken = AWSCredentials.sessionToken;
                    appJSON.Expiration = AWSCredentials.Expiration;
                }
                var tokenKey = getParameterByName('tokenKey');
                var secretKey = getParameterByName('secretKey');
                var queryMode = getParameterByName('queryMode');
                var recordID = getParameterByName('recordID');
                var ios = navigator.userAgent.toLowerCase().indexOf("ios");
                var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
                if (DEVICE_TYPE == 'ios') {
                    bridgeObj.callHandler('setRedirectPagesforExternal', appJSON, function (response) {
                    });
                } else {
                    window.Android.setRedirectPagesforExternal(JSON.stringify(appJSON));
                }
                var ajaXCallURL = $('#ajaXCallURL').val();
                var appurl = CognitoConfig.APP_URL;
                IDENTITY_TOKEN = localStorage.IDENTITY_TOKEN;
                window.location.href = appurl + '/payment/61f91155baf7700fc434e1af/payment.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&totalamount=' + objParams.actualamount + '&queryMode=mylist' + '&ordersid=' + parentresponceid + '&recordID=' + parentresponceid + '&transactionID=' + parentresponceid + '&authorization=' + IDENTITY_TOKEN;
            });
        } else {
            if (errorField.length > 0) {
                errorField.forEach((el) => {
                    showInvalidField(el);
                });
                return;
            }
            if (toastMsg.length > 0) {
                const type = toastMsg[0].type;
                const message = toastMsg[0].msg;
                showToast(type, message);
                toastMsg = [];
                return;
            }
            $('#display_loading').addClass('hideme')
            return;
        }


    });

    $(document).on('click', '#orderokbtn', function () {
        let nextPage = 'app_userhome';
        var queryParams = queryStringToJSON();
        if (queryParams['recordID']) delete queryParams['recordID'];
        if (queryParams['categoryid']) delete queryParams['categoryid'];
        if (queryParams['orderid']) delete queryParams['orderid'];
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + "_61f91155baf7700fc434e1af.html?queryMode=" + queryString;
        window.location.href = pageurl;
        return false;
    });

    $(document).on('click', '#shopnowbtn', function () {
        let nextPage = 'app_userhome';
        var queryParams = queryStringToJSON();
        if (queryParams['recordID']) delete queryParams['recordID'];
        if (queryParams['categoryid']) delete queryParams['categoryid'];
        if (queryParams['orderid']) delete queryParams['orderid'];
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + "_61f91155baf7700fc434e1af.html?" + queryString;
        window.location.href = pageurl;
        return false;
    });
    if (appUser.rolename == 'Guest') {
        // return false;
    } else {
        populateUserData();
    }
    Get_Transaction_Details(objParamsList);

});//end of ready 2


function showCartData(data) {
    grandTotal = 0;
    $('#display_loading').removeClass('hideme');
    let html = '';
    let totalPrice = 0;
    let gstamount = 0;
    const length = Object.keys(data).length;
    if (length > 0) {
        $.each(data, function (keyList, objList) {
            objList.price = Number(objList.price) * Number(objList.quantity);
            gstamount += objList.price * (Number(objList.gst) / 100);
            totalPrice += objList.price;
            if (!Number.isInteger(objList.price)) {
                objList.price = objList.price.toFixed(2);
            }
            html += '<div class="d-flex mb-4">';
            html += '   <div>';
            objList.url = objList.url != '' ? objList.url : 'https://appscdn-us.hokuapps.com/card.png';
            html += '       <img src="' + objList.url + '" class="rounded-m shadow-xl" width="100" height="85" style="object-fit:cover;" alt="img">';
            html += '   </div>';
            html += '   <div class="ms-3 w-100">';
            html += '       <h4 class="text-capitalize">' + objList.name + '</h4>';
            html += '       <h4 class="pt-1 color-highlight">$' + objList.price + '</h4>';
            html += '       <span class="color-theme font-12 text-capitalize">Quantity : ' + objList.quantity + '</span>';
            html += '       <a id="' + objList.id + '" class="removeCart float-end icon icon-xxs bg-green-dark rounded-s"><i class="fa fa-xmark"></i></a>';
            html += '   </div>';
            html += '</div>';
        });

        // sg start 
        $(document).on('click', '.fa-xmark', function () {
            window.location.reload();
        });
       // sg end  
       
        $('#cartitemcontainer').html(html);
    } else {
        // return;
    }

    $('#totalPrice').html('$' + totalPrice.toFixed(2));
    $('#gstcost').html('$' + gstamount.toFixed(2));
    grandTotal = totalPrice + gstamount;
    $('#grandtotalamount').html('$' + grandTotal.toFixed(2));
    $('#placeorderbtn').attr('grandtotal', grandTotal.toFixed(2));
    $('#display_loading').addClass('hideme');
}

function displayCartData() {
    $('#cartitemcontainer').html('');
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
    if (cart.length > 0) {
        showCartData(cart);
        $('#cartItems').removeClass('hideme');
        $('#emptyCart').addClass('hideme');
        $('#transportation').removeClass('hideme');
    } else {
        $('#emptyCart').removeClass('hideme');
        $('#cartItems').addClass('hideme');
    }

}

function populateUserData() {
    $('#display_loading').removeClass('hideme');
    appUser.name = appUser.name ? appUser.name : '';
    if (appUser.name != '') {
        $('#fullname').val(appUser.name);
        validateField($('#fullname'));
    }

    appUser.email = appUser.email ? appUser.email : '';
    if (appUser.email != '') {
        $('#useremail').val(appUser.email);
        validateField($('#useremail'));
    }

    if (appUser.contactnumber && appUser.contactnumber_dialcode && appUser.contactnumber_countrycode) {
        appUser.contactnumber = appUser.contactnumber.toString();
        appUser.contactnumber = appUser.contactnumber.replace('+' + appUser.contactnumber_dialcode, '');
        $('#userphone').intlTelInput('setCountry', appUser.contactnumber_countrycode);
        var sampleNumber = intlTelInputUtils.getExampleNumber(appUser.contactnumber_countrycode, false, 1);
        var placeholder = sampleNumber.replace('+' + appUser.contactnumber_dialcode + ' ', '');
        var mask1 = placeholder.replace(/[0-9]/g, 0);
        $('#userphone').val(appUser.contactnumber);
        $('#userphone').mask(mask1);
        $('#userphone').val($('#userphone').masked(appUser.contactnumber));
        $('#userphone').attr('dialCode', appUser.contactnumber_dialcode);
        $('#userphone').attr('countryCode', appUser.contactnumber_countrycode);
    }

    appUser.custadds = appUser.custadds ? appUser.custadds : '';
    if (appUser.custadds != '') {
        $('#useraddress').val(appUser.custadds);
        validateField($('#useraddress'));
    }
    $('#display_loading').addClass('hideme');
}
function validateField(element) {
    element.parent().addClass('input-style-active');
    element.siblings('.invalid').addClass('disabled');
    element.siblings('.valid').removeClass('disabled');
    element.siblings('em').addClass('disabled');
}
function showInvalidField(element) {
    element.parent().removeClass('input-style-active');
    element.siblings('.invalid').removeClass('disabled');
    element.siblings('.valid').addClass('disabled');
    element.siblings('em').addClass('disabled');
}

function groupProduct(objParams, parentproductid) {
    if (objParams.actualamount) delete objParams['actualamount'];
    // if (objParams.userId) delete objParams['userId'];
    const cart = JSON.parse(localStorage.getItem('cart')) || [];
        for (let x = 1; x < cart.length; x++) { 
        const objList = cart[x];
        objParams.parentproductid = parentproductid;
        objParams.productid_name = objList.name;
        objParams.quentity = objList.quantity;
        objParams.productid = objList.id;
        objParams.productcost = objList.price;
        objParams.totalcost = parseFloat(objList.price) * parseFloat(objList.quantity);
        objParams.gst = objParams.totalcost * parseFloat(objList.gst) / 100;
        objParams.grandtotal = objParams.totalcost + objParams.gst ;
        objParams.actualamount = grandTotal + transportationamount;
        objParams.isDelete = 0;
        objParams.isExternalBooking = 0;
        objParams.transportationamount = transportationamount;
        objParams.rolename = "customer";
        objParams.isParentProduct = 0;
        objParams.purchasetype = "Product";
        objParams.isorderfrommobile = 1;
        objParams.isorderguestuser = isorderguestuser;
        objParams.orderconfirmdate = moment(new Date()).utc().format('YYYY-MM-DDTHH:mm:ssZ');
        objParams.status = 'Confirmed';
        objParams.callUrl = '/booksy/saveProductCheckout61f91155baf7700fc434e1af';
        $.ajax({
            url: objParams.ajaXCallURL + objParams.callUrl,
            data: objParams,
            type: 'POST',
            success: function (response) {
                if (response.status == 0) {
                    // if (x == cart.length - 1) {

                    //     // $('.menu-hider,#page').addClass('pe-none');
                    //     // $('.menu-hider,#menu-accepted').addClass('menu-active');
                    //     // $('#display_loading').addClass('hideme');
                    //     // localStorage.removeItem('cart');
                        
                    //     // sudhir
                    //     $('.menu-hider,#page').addClass('pe-none');
                    //     // $('.menu-hider,#menu-accepted').addClass('menu-active');
                    //     $('#display_loading').addClass('hideme');


                    // }
                }
            },
            error: function (error) {
                console.log('Error in order placing : ' + error);
            }
        });
    }
}

function showToast(type, msg) {
    if (type == 'success') {
        $('#messagetoast').addClass('success_msg');
        $('#toastBody').html('<i class="fa fa-check-circle me-2"></i>' + msg);
    } else if (type == 'error') {
        $('#messagetoast').addClass('error_msg');
        $('#toastBody').html('<i class="fa fa-xmark-circle me-2"></i>' + msg);
    } else if (type == 'warning') {
        $('#messagetoast').addClass('warning_msg');
        $('#toastBody').html('<i class="fa fa-circle-exclamation me-2"></i>' + msg);
    }
    $('#messagetoast').toast('show');
    toastMsg = [];
}

function Get_Transaction_Details(objParamsList) {
    // objParamsList.salonaddressid = getParameterByName('recordID');
    $('#display_loading').removeClass('hideme');

    objParamsList.skip = skip;
    objParamsList.fetch = fetchRecord;


    $.ajax({
        url: objParamsList.ajaXCallURL + '/booksy/getListDetails_Transportationcharges61f91155baf7700fc434e1af_transportationchargesweb_transportationchargeswebKendoList',
        data: objParamsList,
        type: 'POST',
        success: function (response) {
            if (response && response.status == 0) {
                transportationamount = response.data[0].transportationamount;
                $('#transportationamount').append('$' + transportationamount.toFixed(2));

                let totalamount = parseFloat(grandTotal + transportationamount);

                $('#grandtotalamount').html('$' + totalamount.toFixed(2));
            $('#display_loading').addClass('hideme')

            }
        },
        error: function (xhr, status, error) {
            $('#display_loading').addClass('hideme')
            handleError(xhr, status, error);
        },
    });
} // end of function   
