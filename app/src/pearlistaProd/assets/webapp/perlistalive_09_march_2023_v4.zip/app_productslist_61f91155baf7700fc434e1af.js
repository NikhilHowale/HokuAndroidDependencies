var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
var totaldcard_topimage216560043190_collectioncontainer = 0;
$(document).ready(function() {
    $('.page-content').css({
        'height': 'calc(100vh - 62px)',
        'overflow-y': 'scroll',
        'padding-bottom': '0px',
    });
    if ($('.view_list_record').length) {
        $('.view_list_record').show();
    }
    localStorage.removeItem('objParamsList');
    if ($('.js-candlestick').length) $("input[type='checkbox']").candlestick({
        'on': 'Yes',
        'off': 'No',
        'nc': 'NA',
        'default': 'NA',
        'swipe': false,
        'allowManualDefault': true
    });
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    let objParamsList = {};
    skip = 0;
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    objParamsList.queryMode = queryMode;
    objParamsList.isMobile = isMobile;
    objParamsList.functionName = 'show_dcard_getCategoryListDetails';
    if (queryMode != '') {
        localStorage.setItem('objParamsList', JSON.stringify(objParamsList));
        show_dcard_getCategoryListDetails(objParamsList);
    }

    $(document).on('click', '.addcartbtn', function() {
        var toastData = '';
        const id = $(this).attr('id');
        const productname = $(this).attr('productname');
        const productdesc = $(this).attr('productdesc');
        const productQty = $(this).siblings('.stepper').children('input').val();
        const imgUrl = $(this).attr('imgUrl');
        const price = $(this).attr('price');
        const gst = $(this).attr('gst');
        if (Number(productQty) > 0) {
            toastData = 'snackbar-1'
            const product = {};
            product.id = id;
            product.name = productname;
            product.description = productdesc;
            product.url = imgUrl;
            product.price = price;
            product.quantity = productQty;
            product.gst = gst;
            const cart = JSON.parse(localStorage.getItem('cart')) || [];
            let _cart = [...cart];
            const index = _cart.findIndex(item => item.id == id);
            if (index >= 0) {
                _cart[index].quantity = productQty;
            } else {
                _cart.push(product);
            }
            localStorage.setItem('cart', JSON.stringify(_cart));
        } else {
            toastData = 'snackbar-2'
        }
        var notificationToast = document.getElementById(toastData);
        var notificationToast = new bootstrap.Toast(notificationToast);
        notificationToast.show();
    });

    $(document).on('click', '#cartbtn', function() {
        var nextPage = 'app_productcheckout';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        window.location.href = pageurl;
        return false;
    })
    // seeproductdetails
    $(document).on('click', '#seeproductdetails', function() {
        var productrecordid = $(this).attr('productrecordid');
        var nextPage = 'app_productdetails';
        var queryParams = queryStringToJSON();
        queryParams['productid'] = productrecordid;
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        window.location.href = pageurl;
        return false;
    })


    $(document).on('keyup', '#searchproducts', function() {
        var globalsearchtext = $('#searchproducts').val();
        if (globalsearchtext == '') {
            skip = 0;
            fetchRecord = 0;
            if (globalsearchtext) {
                $('#globalsearchcloseicon_img').show();
            } else {
                $('#globalsearchcloseicon_img').hide();
            }
            var objParamsList = {};
            objParamsList.queryMode = 'mylist';
            var ajaXCallURL = $.trim($('#ajaXCallURL').val());
            objParamsList.tokenKey = getParameterByName('tokenKey');
            objParamsList.secretKey = getParameterByName('secretKey');
            objParamsList.ajaXCallURL = ajaXCallURL;
            objParamsList.isMobile = 'true';
            objParamsList.isiPad = false;
            $('#display_loading').addClass('hideme');
            objParamsList.globalsearchvalue = globalsearchtext;
            $('#totaldcard_topimage216560043190_collectioncontainer').html('');
            $('#totaldcard_topimage216560043190_collectioncontainer').find('.view_list_record').removeClass('shimmer');
            show_dcard_getCategoryListDetails(objParamsList)
        }

    });
    $(document).on('click', '.stepper-minus', function() {
        const currentValue = parseInt($(this).siblings('input').val());
        const avlQty = Number($(this).attr('max'));
        if (currentValue > 0) {
            $(this).siblings('input').val(currentValue - 1);
        }
    });

    $(document).on('click', '.stepper-plus', function() {
        const currentValue = parseInt($(this).siblings('input').val());
        const avlQty = Number($(this).attr('max'));
        if (currentValue < avlQty) {
            $(this).siblings('input').val(currentValue + 1);
        }
    });
}); //end of ready 2


function show_dcard_getCategoryListDetails(objParamsList) {
    $('#display_loading').removeClass('hideme');
    objParamsList.categoryid = getParameterByName('categoryid');
    objParamsList.skip = skip;
    objParamsList.fetch = fetchRecord;
    $.ajax({
        url: objParamsList.ajaXCallURL + '/booksy/getListDetails_Products61f91155baf7700fc434e1af_productlistweb_productlistwebKendoList',
        data: objParamsList,
        type: 'POST',
        success: function(response) {
            getDataProcessAfterCalldcard_topimage216560043190_collectioncontainerCategory62864e09ce661f57e6375105(response, function() {
                if (response.status != undefined && response.status == 0) {
                    if (objParamsList.isMobile == 'true') {
                        if (!objParamsList.isLazyLoading || objParamsList.fromSync) {
                            $('#productlistcontainer').html('');
                        } else {
                            scrollCached = 0;
                        }
                        getdcard_topimage216560043190_collectioncontainerapp_programmecategorylistMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    } else if (objParamsList.isiPad == 'true') {} else {}
                    $('#display_loading').addClass('hideme');
                } else {
                    $('#display_loading').addClass('hideme')
                }
            });
        },
        error: function(xhr, status, error) {
            $('#display_loading').addClass('hideme')
            handleError(xhr, status, error);
        },
    });
} // end of function     

function getDataProcessAfterCalldcard_topimage216560043190_collectioncontainerCategory62864e09ce661f57e6375105(response, callback) {
    callback();
}

function getdcard_topimage216560043190_collectioncontainerapp_programmecategorylistMobileView(response, tokenKey, queryMode) {
    var html = '';
    $('#display_loading').removeClass('hideme');
    if (response.data.length == 0 && !$('.dcard_categories_collectioncontainer').length) {
        html += '<div class="mx-0 card card-style bg-secondary animated swing">';
        html += '    <div class="content">';
        html += '        <h2 class="text-center color-white my-4">No record Found!</h2>';
        html += '    </div>';
        html += '</div>';
        $('#productlistcontainer').html(html);
        $('#display_loading').removeClass('hideme');
    } else {
        html = '';
        if (!response.showShimmer) {
            skip = skip + response.data.length;
        }
        $.each(response.data, function(keyList, objList) {
            var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (0) { // need to fix with native gyes.. images not getting download
                var mediaID = '';
                var fileName = '';

            } else {
                objList['productname'] = objList['productname'] ? objList['productname'] : '';
                let productname = objList['productname'];

                objList['info'] = objList['info'] ? objList['info'] : '';
                let info = objList['info'];


                objList['cost'] = objList['cost'] ? objList['cost'] : '0';
                let cost = objList['cost'];
                var twoPlacedcostFloat = parseFloat(cost).toFixed(2);

                let imgUrl = '';
                if (objList.productimage && objList.productimage[0] && objList.productimage[0].mediaID) {
                    imgUrl = CDN_PATH + objList.productimage[0].mediaID + '_compressed.png';
                }
                let availQty = objList['totalproductquentity'] ? objList['totalproductquentity'] : 0;
                html += '<div class="card card-style mx-0 mb-3 dcard_categories_collectioncontainer">';
                html += '    <div class="content">';
                html += '       <div class="d-flex">';
                html += '           <div>';
                html += '               <img onerror="this.src =\'https://appscdn-us.hokuapps.com/card.png\'" src="' + imgUrl + '" class="rounded-m me-3" alt="" width="100" height="100" style="object-fit:cover;">';
                html += '               <div class="content">';
                html += '               <a productrecordid="' + objList._id + '" href="#" id="seeproductdetails">SeeMore >></a>';
                html += '               </div>';
                html += '           </div>';
                html += '           <div class="w-100">';
                html += '               <h3 class="text-capitalize">' + productname + '</h3>';
                html += '               <p class="text-capitalize line-height-s mb-3">' + info + '</p>'; //sg comment
                html += '               <h4 class="pb-3">$' + twoPlacedcostFloat + '</h4>';
                if (availQty <= 0) {
                    html += '<img src="soldout.png" class="position-absolute" style="top:10px !important;right:10px !important;">'
                } else {
                    html += '               <div class="float-start stepper rounded-s scale-switch ms-n1">';
                    html += '                   <a max="' + availQty + '" class="stepper-minus"><i class="fa fa-minus color-theme opacity-40"></i></a>';
                    html += '                   <input disabled type="number" value="0">';
                    html += '                   <a max="' + availQty + '" class="stepper-plus"><i class="fa fa-plus color-theme opacity-40"></i></a>';
                    html += '               </div>';
                    html += '<a gst="' + objList.gst + '" id="' + objList._id + '" productname="' + productname + '" productdesc="' + productname + '" imgUrl="' + imgUrl + '" price="' + cost + '" class="float-end icon icon-xxs bg-green-dark rounded-s addcartbtn" data-toast="snackbar-2"><i class="fa fa-shopping-bag"></i></a>';
                }
                html += '           </div>';
                html += '       </div>';
                html += '   </div>';
                html += '</div>';
            }
        });
        var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        $('#productlistcontainer').append(html);
        $('#display_loading').addClass('hideme');
        $('#searchproduct').removeClass('hideme');
    };
};

function enterSearch(e) {
    const objParamsList = JSON.parse(localStorage.getItem('objParamsList'));
    var globalsearchtext = $('#searchproducts').val();
    if (globalsearchtext.length >= 3 || globalsearchtext.length == 0) {
        $('#display_loading').addClass('hideme');
        console.log(globalsearchtext);
        skip = 0;
        objParamsList.globalsearch = globalsearchtext;
        show_dcard_getCategoryListDetails(objParamsList);
    }
}
