
var offlineDataID = randomString();
var arrAllMedia = [];
var count = 0;
var passwordchanged = 0;
var errorFields = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"))
    }

    var objParamsToken = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsToken.tokenKey = getParameterByName('tokenKey');
    objParamsToken.secretKey = getParameterByName('secretKey');

    var userRole = $('#userRole').val();
    var userID = $('#userID').val();
    var createrOfRecord = $('#createrOfRecord').val();
    var queryMode = getParameterByName('queryMode');
    var recordID = $.trim($('#recordID').val());
    var addSessionComments = [];
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('keyup', '#password10', function () {
        var password = $(this).val();
        showPasswordStrength(password)
    });

    $(document).on('click', '#signup14', function () {
        var objParams = {};
        let errorField = [];
        let toastMsg = [];
        objParams.isDelete = 0;
        $(".cognitoError").hide();
        // full name 
        const fullname = $.trim($('#fullname1').val());
        if (fullname == '') {
            errorField.push($('#fullname1'));
        } else if (fullname != '' && $('#fullname1').siblings('.valid').hasClass('disabled')) {
            errorField.push($('#fullname1'));
        } else {
            objParams.name = fullname;
        }

        const email = $.trim($('#email2').val());
        if (email == '') {
            errorField.push($('#email2'));
        } else if (email != '' && $('#email2').siblings('.valid').hasClass('disabled')) {
            errorField.push($('#email2'));
        } else if (typeof EMAIL_REGEX !== 'undefined' && EMAIL_REGEX && !EMAIL_REGEX.test(email)) {
            errorField.push($('#email2'));
        }
        else {
            objParams.email = email;
        }

        let contactnumber = $.trim($('#phone3').val());
        if (contactnumber == '') {
            toastMsg.push({ type: "warning", msg: "Mobile Number is required" });
        } else {
            var dialCode = $('#phone3').attr('dialCode');
            var countryCode = $('#phone3').attr('countryCode');
            var placeholder = $('#phone3').attr('placeholder');
            contactnumber = contactnumber.replace(/[^0-9]/gi, '');
            placeholder = placeholder.replace(/[^0-9]/gi, '');
            if (contactnumber && placeholder.length != contactnumber.length) {
                toastMsg.push({ type: "warning", msg: "Valid Mobile Number is required" });
            }
            objParams.contactnumber = '+' + dialCode + contactnumber;
            objParams.contactnumber_dialcode = dialCode;
            objParams.contactnumber_countrycode = countryCode;
        }

        const password = $.trim($('#password5').val());
        if (password == '') {
            errorField.push($('#password5'));
        } else if (password != '' && $('#password5').siblings('.valid').hasClass('disabled')) {
            errorField.push($('#password5'));
        } else {
            objParams.password = password;
        }


        const confirmpassword = $.trim($('#confirmpassword6').val());
        if (confirmpassword == '') {
            errorField.push($('#confirmpassword6'));
        } else if (confirmpassword != '' && $('#confirmpassword6').siblings('.valid').hasClass('disabled')) {
            errorField.push($('#confirmpassword6'));
        } else {
            objParams.confirmpassword = confirmpassword;
        }


        if (password != confirmpassword) {
            toastMsg.push({ type: "warning", msg: "Password and Confirm password should be same" });
        }
        if (errorField.length) {
            errorField.forEach((el) => {
                showInvalidField(el);
                errorField[0].focus();
            });
            $('#display_loading').addClass('hideme')
            return;
        }
        if (toastMsg.length) {
            const type = toastMsg[0].type;
            const message = toastMsg[0].msg;
            // showToast(type, message);
            toastMsg = [];
            return;
        }

        // if (errorFields && errorFields.length) {
        //     $('#display_loading').addClass('hideme');
        //     var firstErrorField = errorFields[0];
        //     errorFields = [];
        //     $('#' + firstErrorField).focus();
        //     $('#' + firstErrorField).focus();
        //     return false;
        // }
        objParams.offlineDataID = localStorage.getItem("offlineDataID");
        $('#undefined').prop('disabled', true);
        $('#display_loading').removeClass('hideme');
        var recordID = $('#recordID').val();
        if (forwardChekbox.length > 0) {
            objParams.forwardChekbox = forwardChekbox;
        } else {
            objParams.forwardChekbox = [];
        }
        if (addSessionComments.length > 0) {
            objParams.addSessionComments = addSessionComments;
        } else {
            objParams.addSessionComments = [];
        }
        if (typeof (addedFiles) != 'undefined' && addedFiles.length > 0) {
            objParams.addedFiles = addedFiles;
        } else {
            objParams.addedFiles = [];
        }
        var parentID = $('#parentID').val();
        var parentName = $('#parentName').val();
        objParams.isDelete = 0;
        if (parentID != '') {
            objParams.parentID = parentID;
            objParams.parentName = parentName
        }
        objParams.lastpage = 'usersignup'
        localStorage.setItem('usersignup', JSON.stringify(objParams))
        var dataObj = {};
        var tokenKey = $('#tokenKey').val();
        var queryMode = $('#queryMode').val();
        var secretKey = $('#secretKey').val();
        if (dataObj && Object.keys(dataObj).length > 0) {
            objParams = dataObj;
        }
        objParams.IsAdmin = "No";
        var ajaXCallURL = $('#ajaXCallURL').val();
        // const signuprole = $('input[name="signupaccess"]:checked').val();
        objParams.rolename = 'customer';//admin
        objParams.subdomain = CognitoConfig.SUBDOMAIN;
        objParams.appID = CognitoConfig.APPID;
        objParams.integrationName = 'incorv56';
        localStorage.clear();
        objParams.email = objParams.email.trim().toLowerCase();
        var hokuusername = objParams.contactnumber
        var objString = JSON.stringify(objParams);
        var signupParams = objParams;
        signupParams.attributes = []
        signupParams.attributes.push({ Name: 'custom:role', Value: objParams.rolename });
        // signupParams.attributes.push({ Name: 'custom:firstname', Value: objParams.firstname });
        // signupParams.attributes.push({ Name: 'custom:lastname', Value: objParams.lastname });
        // signupParams.attributes.push({ Name: 'custom:nationalityid', Value: objParams.nationalityid });
        // signupParams.attributes.push({ Name: 'custom:nationalityid_name', Value: objParams.nationalityid_name });
        signupParams.attributes.push({ Name: 'name', Value: objParams.name });
        signupParams.attributes.push({ Name: 'nickname', Value: objParams.name });
        signupParams.attributes.push({ Name: 'email', Value: objParams.email });

        //if(objParams.referralbycode){
        // signupParams.attributes.push({ Name: 'custom:referralbycode', Value: objParams.referralbycode });
        //}

        signupParams.attributes.push({ Name: 'custom:appId', Value: CognitoConfig.APPID });
        signupParams.attributes.push({ Name: 'custom:subdomain', Value: CognitoConfig.SUBDOMAIN });
        signupParams.attributes.push({ Name: 'custom:hosturl', Value: CognitoConfig.APP_URL });
        signupParams.attributes.push({ Name: 'custom:contactnumber', Value: objParams.contactnumber });
        signupParams.attributes.push({ Name: 'custom:contactd', Value: objParams.contactnumber_dialcode });
        signupParams.attributes.push({ Name: 'custom:contactc', Value: objParams.contactnumber_countrycode });
        // signupParams.attributes.push({ Name: 'custom:displayname', Value: objParams.name });
        //signupParams.attributes.push({ Name: 'custom:metadata', Value: objString });

        signupParams.username = objParams.email;
        signupParams.rolename = objParams.rolename;
        signupParams.email = objParams.email;
        signupParams.password = objParams.password;
        signupParams.useremail = objParams.email;
        signupParams.contactnumber = objParams.contactnumber;
        signupParams.countrycode = objParams.contactnumber_countrycode;
        signupParams.dialcode = objParams.contactnumber_dialcode;
        // signupParams.referralbycode = objParams.referralbycode;
        // signupParams.nationalityid = objParams.nationalityid;
        // signupParams.nationalityid_name = objParams.nationalityid_name;
        loginInfo = null;
        forgotEmail = null;
        signupInfo = signupParams;

        $('#display_loading').removeClass('hideme');
        signUP(signupInfo);
        // createNewThingINProcessBeforeCallsignup14(objParams, function (processBeforeRes) {
        //     $.ajax({
        //         url: ajaXCallURL + '/incorv56/hokuexternalsignup5ce2e616f9039e46f12edc4d',
        //         data: objParams,
        //         type: 'POST',
        //         success: function (response) {
        //             if (response.status != undefined && response.status == 0) {
        //                 localStorage.setItem('objGetUserDetailsWithmenu', JSON.stringify(response.objGetUserDetailsWithmenu));
        //                 localStorage.setItem('perms', JSON.stringify(response.perms));
        //                 localStorage.setItem('user', JSON.stringify(response.user));
        //                 localStorage.setItem('appUser', JSON.stringify(response.appUser));
        //                 localStorage.setItem('organizationID', response.user.organizationId);
        //                 localStorage.setItem('userID', response.user.userId);
        //                 localStorage.setItem('CDN_PATH', 'https://dxrq26z7a1rw3.cloudfront.net');
        //                 localStorage.setItem('CDN_THUMB', response.CDN_THUMB);
        //                 if (response.appUser) {
        //                     localStorage.setItem('appUser', JSON.stringify(response.appUser));
        //                 }
        //                 if (response.appUser && response.appUser.userphotoupload && response.appUser.userphotoupload[0]) {
        //                     localStorage.setItem('profileThumb', response.appUser.userphotoupload[0].mediaID);
        //                 } else {
        //                     localStorage.removeItem('profileThumb');
        //                 }
        //                 localStorage.setItem('tokenData', JSON.stringify(response.tokenData));
        //                 loginNativeCallWrappersignup14(response, '5ce2e616f9039e46f12edc4d');
        //                 return false;
        //             } else if (response.errorMessage) {
        //                 $('#display_loading').addClass('hideme');
        //                 $('#confirmpassword_error').html(response.errorMessage).show();
        //                 return false;
        //             } else {
        //                 $('#display_loading').addClass('hideme');
        //                 return false;
        //             }
        //         },
        //         error: function (xhr, status, error) { }
        //     });
        // }); // end of CreateNewThingin Session ID Process Before Call 
    });//end of Event Sign Up_is_click 
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('click', '#backbutton1', function () {
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = getParameterByName('queryMode');
        var recordID = getParameterByName('recordID');
        queryMode = 'add'
        window.location.href = 'login_cognito.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey
        return false;
    });//end of Event backbutton_is_click 
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('click', '#login5', function () {
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = getParameterByName('queryMode');
        var recordID = getParameterByName('recordID');
        queryMode = 'mylist'
        window.location.href = 'login_cognito.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey
        return false;
    });//end of Event Log In_is_click 
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};
    $(document).on('focusout', '#referralbycode12', function () {
        var objParams = {};
        $('#display_loading').removeClass('hideme');
        objParams.referralCode = $('#referralbycode12').val();
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());

        $.ajax({
            url: 'https://incorbeta.hokuapps.com/incorv56/verifyUserReferralCode5ce2e616f9039e46f12edc4d',
            data: objParams,
            type: 'POST',
            success: function (response) {
                $('#display_loading').addClass('hideme');
                if (response.status != undefined && response.status == 0) {
                    $('#display_loading').addClass('hideme');
                    $('#userreferralcode8_error').addClass('correct').removeClass('incorrect').removeClass('error_message');
                    $('#userreferralcode8_error').html(response.error).show();
                    return false;
                } else {
                    $('#display_loading').addClass('hideme');
                    $('#userreferralcode8_error').addClass('incorrect').addClass('error_message').removeClass('correct');
                    $('#userreferralcode8_error').html(response.error).show();
                    return false;
                }
            },
            error: function (xhr, status, error) {
                $('#display_loading').addClass('hideme');
                $('#userreferralcode8').removeProp('disabled');
            },
        });
        return false;
    });
    const locationPingJson = {
        country: "India",
        countryCode: "IN",
        state: "Maharashtra",
        name: "null Nande - Balewadi Road",
        subAdminArea: "Pune",
        postalCode: "411045",
        city: "Pune",
        subLocality: "Mahalunge",
        lat: "18.5745661",
        long: "73.7562774",
        response: {
            tokenKey: "null",
            secretKey: "null",
            queryMode: "mylist",
            action: "mylist",
            ajaXCallURL: "https://gateway-sg.hokuapps.com/62864e09ce661f57e6375105",
            callbackFunction: "setCurrentLocationOfOverlay",
            nextButtonCallback: "setCurrentLocationOfOverlay",
            appID: "62864e09ce661f57e6375105",
            sendAddress: true,
        },
    };

});//end of ready 
function createNewThingINProcessBeforeCallsignup14(objParams, callback) {
    callback();
}
function loginNativeCallWrappersignup14(response, appID) {
    try {
        var queryMode = $('#queryMode').val();
        var appJSON = {};
        appJSON.organizationID = response.user.organizationId;
        appJSON.userID = response.user.userId;
        appJSON.appID = $('#appID').val();
        appJSON.nextButtonCallback = 'setloginNativeCallBacksignup14';
        appJSON.action = queryMode;
        appJSON.colorCode = '#3c3c3c';
        appJSON.response = response;
        appJSON.launchNative = false;
        appJSON.authToken = response.appTokenDetails.authToken;
        appJSON.authSecretKey = response.appTokenDetails.authSecretKey;
        appJSON.roleName = response.appTokenDetails.roleName;
        appJSON.expiredTime = response.appTokenDetails.expiredTime;
        appJSON.launchNextpage = 'customerhome_5ce2e616f9039e46f12edc4d.html'

        var roleName = response.appTokenDetails.roleName;
        localStorage.setItem('roleName', roleName);
        var ISDEV_MODE = localStorage.getItem('ISDEV_MODE');
        var DEV_MODE = getParameterByName('devmode');
        if (ISDEV_MODE == 'true' || DEV_MODE) {
            var tokenKey = response.appTokenDetails.authToken;
            var secretKey = response.appTokenDetails.authSecretKey;
            var queryMode = 'mylist';
            window.location.href = 'customerhome_5ce2e616f9039e46f12edc4d.html?queryMode=add&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
            return false
        } else {
            var isAndroid = navigator.userAgent.toLowerCase().indexOf('android');
            if (isAndroid > -1) {
                window.Android.loginNativeCallV2(JSON.stringify(appJSON))
            } else {
                bridgeObj.callHandler('loginNativeCall', appJSON, function (response) { });
                bridgeObj.registerHandler('setloginNativeCallBacksignup14', function (responseData, responseCallback) {
                    setloginNativeCallBacksignup14(responseData)
                });
            }
        }
    } catch (err) {
        $('#display_loading').addClass('hideme');
    }
}
function setloginNativeCallBacksignup14(responseData) {
    try {
        if (responseData) {
            var userDeviceObj = responseData.userDeviceObj;
            if (responseData.data) {
                responseData = responseData.data;
            }
            var tokenKey = responseData.authToken;
            var secretKey = responseData.authSecretKey;
            var queryMode = 'mylist';
            var domainName = $('#domainName').val();
            var ajaXCallURL = 'https://gateway.' + domainName + '.com'
            var objParams = {};
            objParams.organizationID = responseData.organizationID;
            objParams.userID = responseData.userID;
            objParams.appID = responseData.appID;
            objParams.tokenKey = tokenKey;
            objParams.secretKey = secretKey;
            var ajaXCallURL = 'https://incorbeta.hokuapps.com';
            appJSON.apiName = ajaXCallURL + '/api/addUserDeviceForApp_5ce2e616f9039e46f12edc4d';
            appJSON.Authorization = IDENTITY_TOKEN;
            objParams.userDeviceObj = userDeviceObj;
            objParams.isLogin = true;
            if (responseData.roleName) {
                objParams.roleName = responseData.roleName;
            }
            $.ajax({
                url: ajaXCallURL + '/api/addUserDeviceForApp_5ce2e616f9039e46f12edc4d',
                data: objParams,
                type: 'POST',
                success: function (response) {
                    if (response.status == 0) {
                        var roleName = localStorage.getItem('roleName');
                        window.location.href = 'customerhome_5ce2e616f9039e46f12edc4d.html?queryMode=add&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                        return false
                    }
                },
                error: function (xhr, status, error) { },
            });
        };
    } catch (err) { };
}

function showPasswordStrength(password) {
    try {
        var isDigit = false;
        var isLowerChar = false;
        var isUpperChar = false;
        var isNonAlpha = false;
        var isLength = false;

        $('.strongpass').removeClass('valid')
        var charArray = password.split('');
        if (!password.trim().length) {
            return;
        }

        $.each(charArray, function (key, value) {
            if (value) {
                if (!isNaN(value)) {
                    isDigit = true;
                    $('.numberValid').addClass('valid')
                }

                if (value.toUpperCase() != value.toLowerCase()) {
                    isLetter = true;
                    if (value == value.toLowerCase()) {
                        isLowerChar = true;
                        $('.lowercaseValid').addClass('valid');
                    }
                    if (value == value.toUpperCase()) {
                        isUpperChar = true;
                        $('.uppercaseValid').addClass('valid');
                    }
                }
                if (/[^a-zA-Z0-9]/.test(value)) {
                    isNonAlpha = true;
                    $('.specialcharValid').addClass('valid');
                }
            }
        });

        if (password.length >= 8) {
            isLength = true;
            $('.lengthValid').addClass('valid');
        }

    } catch (err) {
        console.log(err, 'showPasswordStrength ');
    }
}



function getLocation(paramsType) {
    var selectOptionHtml = '<option disabled selected value="">Select</option>';
    regions_62864e09ce661f57e6375105.sort((a, b) => a.sequence - b.sequence);
    $.each(regions_62864e09ce661f57e6375105, function (keyList, objList) {
        if (objList.countryname == paramsType.country) {
            selectOptionHtml += '<option code="' + objList.countrycode + '" selected value="' + objList._id + '">' + objList.countryname + "</option>";
        } else {
            selectOptionHtml += '<option code="' + objList.countrycode + '" value="' + objList._id + '">' + objList.countryname + "</option>";
        }
    });
    $('#signuplocation').html(selectOptionHtml);
    $('#signuplocation').material_select();
}
function removeCls(el) {
    el.removeClass('success_msg');
    el.removeClass('error_msg');
    el.removeClass('warning_msg');
}
function showInvalidField(element) {
    element.parent().removeClass('input-style-active');
    element.siblings('.invalid').removeClass('disabled');
    element.siblings('.valid').addClass('disabled');
    element.siblings('em').addClass('disabled');
}
