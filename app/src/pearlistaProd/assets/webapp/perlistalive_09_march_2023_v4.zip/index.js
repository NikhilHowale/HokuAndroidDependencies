// function setupWebViewJavascriptBridge(callback) {
//     if (window.WebViewJavascriptBridge) {
//         return callback(WebViewJavascriptBridge);
//     }
//     if (window.WVJBCallbacks) {
//         return window.WVJBCallbacks.push(callback);
//     }
//     window.WVJBCallbacks = [callback];
//     var WVJBIframe = document.createElement('iframe');
//     WVJBIframe.style.display = 'none';
//     WVJBIframe.src = 'wvjbscheme://__BRIDGE_LOADED__';
//     document.documentElement.appendChild(WVJBIframe);
//     setTimeout(function () {
//         document.documentElement.removeChild(WVJBIframe)
//     }, 0)
// }

// setupWebViewJavascriptBridge(function (bridge) {
//     bridgeObj = bridge;
// });

$(document).ready(function () {

    // updateApp();

    var tokenKey = getParameterByName("tokenKey");
    var secretKey = getParameterByName("secretKey");

    // if no tokenkey or secretKey
    if (!tokenKey || !secretKey) {
        writeLog("weblog : tokenKey or secretKey missing from native tokenKey=" + tokenKey + "secretKey=" + secretKey + " -  index.js");
        tokenKey = localStorage.tokenKey;
        secretKey = localStorage.secretKey;
    }

    // if no tokenkey or secretKey
    if (!tokenKey || !secretKey) {
        writeLog("weblog : tokenKey or secretKey missing from localStorage + native tokenKey=" + tokenKey + "secretKey=" + secretKey + " -  index.js");
        window.location.href = "splash1_61f91155baf7700fc434e1af.html";
        return false;
    } else {
        // var roleName = localStorage.getItem("roleName");
        // writeLog("weblog : roleName=" + roleName + " -  index.js ");
        // // if rolename not found
        // if (!roleName) {
        //     writeLog("weblog : roleName = " + roleName + " missing -  index.js");
        //     window.location.href = "splash1_61f91155baf7700fc434e1af.html";
        //     return false;
        // } else {
        //     roleName = roleName.toLowerCase();
        //     if (roleName === "sales") {
        //         window.location.href = 'app_luxurybuyshome_5e457e5e882c9a26e4e0b327.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
        //         return false
        //     } else if (roleName === "executive") {
        //         window.location.href = 'splash1_61f91155baf7700fc434e1af.html?queryMode=executivelist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
        //         return false
        //     } else {
        //         writeLog("weblog : not an mobile role " + roleName + " -  index.js ");
        //         window.location.href = "splash1_61f91155baf7700fc434e1af.html";
        //         return false;
        //     }
        // }

        // START

        var roleRes = { roleName: localStorage.roleName };
        if (roleRes.roleName) {

            // if (roleRes.roleName.toLowerCase() == 'sales') {

            //     if (localStorage.getItem("upgrademembershipeffectiveuntildate")) {
            //         var upgrademembershipeffectiveuntildate = moment(new Date(localStorage.getItem("upgrademembershipeffectiveuntildate"))).format('YYYY-MM-DD');
            //         var currentdate = moment(new Date()).format('YYYY-MM-DD');

            //         if (upgrademembershipeffectiveuntildate < currentdate) {
            //             window.location.href = 'app_membershiplist_5e457e5e882c9a26e4e0b327.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
            //             return false
            //         } else {
            //             window.location.href = 'app_luxurybuyshome_5e457e5e882c9a26e4e0b327.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
            //             return false
            //         }

            //     } else {
            //         window.location.href = 'splash1_61f91155baf7700fc434e1af.html';
            //         return false;
            //     }
            // } else {
            //     window.location.href = 'splash1_61f91155baf7700fc434e1af.html';
            //     return false;
            // }

            if (roleRes.roleName == 'customer') {
                window.location.href = 'app_landingpage_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                return false
            }
            if (roleRes.roleName == 'admin') {
                window.location.href = 'app_landingpage_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                return false
            }
            if (roleRes.roleName == 'Logistics') {
                window.location.href = 'app_logistichome_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                return false
            }
            // if (roleRes.roleName == 'Guest') {
            //     window.location.href = 'app_userhome_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
            //     return false
            // }
            
            if (roleRes.roleName.toLowerCase() == 'student') {
                window.location.href = 'app_studentlist_608be3908424076b8c87f5bc.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                return false
            }
            if (roleRes.roleName.toLowerCase() == 'supervisor') {
                window.location.href = 'app_supervisorhome_608be3908424076b8c87f5bc.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                return false
            }
            if (roleRes.roleName.toLowerCase() == 'teacher') {
                window.location.href = 'app_teacherhome_608be3908424076b8c87f5bc.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                return false
            }
            if (roleRes.roleName.toLowerCase() == 'sales') {
                window.location.href = 'app_userhome_608be3908424076b8c87f5bc.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                return false
            }
            if (roleRes.roleName.toLowerCase() == 'executive') {
                window.location.href = 'login_608be3908424076b8c87f5bc.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                return false
            } else {
                window.location.href = 'splash1_61f91155baf7700fc434e1af.html';
                return false;
            }


        } else {
            window.location.href = 'splash1_61f91155baf7700fc434e1af.html';
            return false;
        }

    }

    // refreshAWSToken(function (response) {
    //     if (response) {
    //         proceesToLogin(response);
    //         var IDENTITY_TOKEN = localStorage.getItem('IDENTITY_TOKEN');
    //         if (IDENTITY_TOKEN) {
    //             var appJSON = {};
    //             appJSON.idToken = IDENTITY_TOKEN;
    //             var playload = JSON.parse(atob(IDENTITY_TOKEN.split('.')[1]));
    //             if (playload.exp) {
    //                 appJSON.ExpiryTime = playload.exp;
    //             }
    //             var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    //             if (isAndroid > -1) {
    //                 window.Android.updateToken(JSON.stringify(appJSON));
    //             } else {
    //                 setupWebViewJavascriptBridge(function (bridge) {
    //                     bridgeObj.callHandler('updateToken', appJSON, function (response) { });
    //                 });
    //             }
    //         }
    //     } else {
    //         proceesToLogin(true);
    //         // setTimeout(function () {
    //         //     window.location.href = 'splash1_61f91155baf7700fc434e1af.html';
    //         //     return false;
    //         // }, 2000);
    //     }
    // });
});

function updateApp() {
    var appJSON = {};
    // appJSON.userId = localStorage.userID;
    // appJSON.tokenKey = getParameterByName('tokenKey');
    // appJSON.secretKey = getParameterByName('secretKey');
    var ajaXCallURL = "https://enrichmentteamapp.hokuapps.com";
    appJSON.queryMode = "mylist";
    appJSON.ajaXCallURL = ajaXCallURL;
    appJSON.apiName = ajaXCallURL + "/team/GetAppVersionDetails_608be3908424076b8c87f5bc";
    appJSON.showNativeDialog = true;
    appJSON.organizationID = $('#organizationID').val();
    appJSON.userID = $('#userID').val();
    appJSON.appID = $('#appID').val();
    // appJSON.nextButtonCallback = 'loadcompleteCheckAppVersion';
    appJSON.action = appJSON.queryMode;
    // var IDENTITY_TOKEN = getParameterByName('IDENTITY_TOKEN');
    // IDENTITY_TOKEN = IDENTITY_TOKEN ? IDENTITY_TOKEN : localStorage.getItem('IDENTITY_TOKEN')
    // appJSON.Authorization = IDENTITY_TOKEN;

    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    if (isAndroid > -1) {
        window.Android.updateAppVersion(JSON.stringify(appJSON));
    } else {
        // setupWebViewJavascriptBridge(function(bridge) {
        //     bridgeObj = bridge;
        //     var appJSON = {};
        //     appJSON.nextButtonCallback = 'loadcompleteCheckAppVersion';
        //     bridgeObj.callHandler('updateAppVersion', appJSON, function(response) {});

        //     bridgeObj.registerHandler('updateAppVersion', function(responseData, responseCallback) {
        //         loadcompleteCheckAppVersion(responseData);
        //     });
        // });
    }
}

// function proceesToLogin(response) {
//     if (response != true) {
//         window.location.href = 'splash1_61f91155baf7700fc434e1af.html';
//         return false;
//     }
//     var tokenKey = getParameterByName('tokenKey');
//     var secretKey = getParameterByName('secretKey');

//     if (tokenKey != null && tokenKey != '') {
//         var tokenKey = getParameterByName('tokenKey');
//         var secretKey = getParameterByName('secretKey');
//         var roleRes = {roleName:localStorage.roleName};
//         if (roleRes.roleName) {
                
//             if (roleRes.roleName.toLowerCase() == 'customer') {
//                 window.location.href = 'app_studentlist_608be3908424076b8c87f5bc.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
//                 return false
//             }
//             if (roleRes.roleName.toLowerCase() == 'parent') {
//                 window.location.href = 'app_studentlist_608be3908424076b8c87f5bc.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
//                 return false
//             }
//             if (roleRes.roleName.toLowerCase() == 'student') {
//                 window.location.href = 'app_studentlist_608be3908424076b8c87f5bc.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
//                 return false
//             }
//             if (roleRes.roleName.toLowerCase() == 'supervisor') {
//                 window.location.href = 'app_supervisorhome_608be3908424076b8c87f5bc.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
//                 return false
//             }
//             if (roleRes.roleName.toLowerCase() == 'teacher') {
//                 window.location.href = 'app_teacherhome_608be3908424076b8c87f5bc.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
//                 return false
//             }
//             if (roleRes.roleName.toLowerCase() == 'sales') {
//                 window.location.href = 'app_userhome_608be3908424076b8c87f5bc.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
//                 return false
//             }
//             if (roleRes.roleName.toLowerCase() == 'executive') {
//                 window.location.href = 'login_608be3908424076b8c87f5bc.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
//                 return false
//             } else {
//                 window.location.href = 'splash1_61f91155baf7700fc434e1af.html';
//                 return false;
//             }

//         } else {
//             window.location.href = 'splash1_61f91155baf7700fc434e1af.html';
//             return false;
//         }
//     } else {
//         setTimeout(function () {
//             window.location.href = 'splash1_61f91155baf7700fc434e1af.html';
//             return false;
//         }, 2500);
//     }
// }
// function refreshGoogleToken() {
//     $('#display_loading').removeClass('hideme');
//     // localStorage.removeItem('objGetUserDetailsWithmenu');
//     var appJSON = {};
//     appJSON.nextButtonCallback = 'refreshGoogleTokenCallBack';
//     appJSON.colorCode = '#3c3c3c';
//     appJSON.launchNative = false;
//     appJSON.roleName = 'customer';
//     localStorage.setItem("activeMenu", "NewsFeed");
//     appJSON.launchNextpage = 'app_home_5cf798a8c3eff778ff9043e9.html';
//     // appJSON.isFromSocialMedia = true;
//     var ISDEV_MODE = localStorage.getItem("ISDEV_MODE");
//     if (ISDEV_MODE == "false" || ISDEV_MODE == false) {
//         var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
//         if (isAndroid > -1) {
//             window.Android.refreshGoogleToken(JSON.stringify(appJSON))
//         } else {
//             bridgeObj.callHandler('refreshGoogleToken', appJSON, function (response) { });
//             bridgeObj.registerHandler('refreshGoogleTokenCallBack', function (responseData, responseCallback) {
//                 refreshGoogleTokenCallBack(responseData);
//             }
//             );
//         }
//     }
// }
// function refreshGoogleTokenCallBack(responseData) {
//     $('#display_loading').addClass('hideme');
//     if (responseData && responseData.googleIdToken) {
//         localStorage.setItem('IS_IAMUSER', true);
//         localStorage.setItem('accessToken', responseData.googleIdToken);
//         var AWSCredentials = JSON.parse(localStorage.getItem('AWSCredentials'));
//         AWSCredentials.accessToken = responseData.googleIdToken;
//         AWSCredentials.identityProvider = 'google';
//         localStorage.setItem('AWSCredentials', JSON.stringify(AWSCredentials));
//         localStorage.setItem('identityProvider', 'google');
//         refreshAWSToken(function (response) {
//             proceesToLogin(response);
//         });
//     } else {
//         proceesToLogin(false);
//     }
// }
