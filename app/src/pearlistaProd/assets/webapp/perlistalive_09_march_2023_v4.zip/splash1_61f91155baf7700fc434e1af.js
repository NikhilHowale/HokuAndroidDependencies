
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
var totaldcard_topimage216560043190_collectioncontainer = 0;
var CDN_PATH ="https://d1hlq0tvec6h4x.cloudfront.net/61f91155baf7700fc434e1af/61f91155baf7700fc434e1af/";

$(document).ready(function () {
    if ($('.view_list_record').length) { $('.view_list_record').show(); }
    localStorage.removeItem('objParamsList');
    if ($('.js-candlestick').length) $("input[type='checkbox']").candlestick({ 'on': 'Yes', 'off': 'No', 'nc': 'NA', 'default': 'NA', 'swipe': false, 'allowManualDefault': true });
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    let objParamsList = {};
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    objParamsList.queryMode = queryMode;
    objParamsList.isMobile = isMobile;
    show_dcard_getsplashimagelist(objParamsList);
    


    $(document).on('click', '.dcard_categories_collectioncontainer', function () {
        var categoryid = $(this).attr('recordID');// get record ID;
        var nextPage = 'app_productslist';
        var queryParams = queryStringToJSON();
        if (categoryid) queryParams['categoryid'] = categoryid;
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        window.location.href = pageurl;
        return false;
    });
});//end of ready 2


function getDataProcessAfterCalldcard_topimage216560043190_collectioncontainerCategory62864e09ce661f57e6375105(response, callback) {
    callback();
}

function getdcard_topimage216560043190_collectioncontainerapp_programmecategorylistMobileView(response, tokenKey, queryMode) {
    var html = '';
    $('#display_loading').removeClass('hideme')
    if (response.data.length == 0 && !$('.dcard_categories_collectioncontainer').length) {
        html += '<div class="nodatafound">';
        html += '<img src="nodatafound.gif" width="100%">';
        html += '<br>';
        html += '<!-- span>No record found</span -->';
        html += '</div>';
        $('#categorycontainer').html(html);
    } else {
        html = '';
        var radioGroups = [];
        if (!response.showShimmer) {
            skip = skip + response.data.length;
        }
        $.each(response.data, function (keyList, objList) {
            var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (0) {  // need to fix with native gyes.. images not getting download
                var mediaID = '';
                var fileName = '';
                if (objList['imageupload'] && objList['imageupload'][0].mediaID) {
                    P
                    mediaID = objList['imageupload'][0].mediaID;
                    fileName = objList['imageupload'][0].mediaID + '.png';
                }
            } else {
                let msme = '';
                if (keyList % 2 == 0) {
                    msme = 'me-0';
                } else {
                    msme = 'ms-0';
                }
                html += '<a class="col-6">';
                html += '   <div recordID="' + objList._id + '" class="card card-style ' + msme + ' mb-3 text-center pt-2 dcard_categories_collectioncontainer" style="cursor:pointer;">';
                html += '       <i class="fa fa-bolt color-yellow-dark fa-3x mt-4"></i>';
                // objList['categoryname'] = objList['categoryname'] ? objList['categoryname'] : '';
                // let categoryname = objList['categoryname'];
                objList['productcategoryname'] = objList['productcategoryname'] ? objList['productcategoryname'] : '';
                let categoryname = objList['productcategoryname'];
                html += '       <h1 class="text-uppercase px-4 pt-4 font-20 text-truncate">' + categoryname + '</h1>';
                html += '       <p class="font-11 opacity-50 mt-n2 mb-4">Dont Miss Out </p>';
                html += '   </div>';
                html += '</a>';
            }
        });
        var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        $('#categorycontainer').append(html)
        $('#display_loading').addClass('hideme');
    };
};

function show_dcard_getsplashimagelist(objParamsList) {
    $('#display_loading').removeClass('hideme');
    $.ajax({
        // url: objParamsList.ajaXCallURL + '/api/getListDetails_Splashimages61f91155baf7700fc434e1af_splashimageweb_splashimagewebKendoList',
        url: CognitoConfig.APP_URL + '/api/getListDetails_Splashimages61f91155baf7700fc434e1af_splashimageweb_splashimagewebKendoList',
        data: objParamsList,
        type: 'POST',
        success: function (response) {
            if (response.status != undefined && response.status == 0) {
                // if (objParamsList.isMobile == 'true') {
                //     if (!objParamsList.isLazyLoading || objParamsList.fromSync) {
                //         $('.splide__list').html('');
                //     } else {
                //         scrollCached = 0;
                //     }
                // } else if (objParamsList.isiPad == 'true') {
                // } else {
                // }
                $('#display_loading').addClass('hideme');
                getdcard_bannerimagelistMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
            } else {
                $('#display_loading').addClass('hideme')
            }
        },
        error: function (xhr, status, error) {
            $('#display_loading').addClass('hideme');
            handleError(xhr, status, error);
        },
    });
}

function getDataAfterCallgetdcard_bannerimagelist(response, callback) {
    callback();
}

function getdcard_bannerimagelistMobileView(response) {
    let html = '';
    $.each(response.data, function (keyList, objList) {
             html += '<div class="splide__slide">';
        html += '<div data-card-height="cover" class="card text-center pb-5">';
        html += '    <div class="card-bottom">';
        html += '        <h1 class="font-700 font-32 mb-0">'+objList.info+'</h1>';
        html += '        <h6 class="font-400 font-15 mb-3 pb-1 color-highlight"></h6>';
        html += '        <p class="color-theme boxed-text-xl opacity-80 pb-5 mb-5"></p>';
        html += '        <p class="pb-4"></p>';
        html += '    </div>';
        let imgUrl = '';
        if (objList.bannerimage && objList.bannerimage[0] && objList.bannerimage[0].mediaID) {
            imgUrl = CDN_PATH + objList.bannerimage[0].mediaID + '_compressed.png';
        }
        html += '    <div class="card-overlay" style="height:70vh;background-image:url('+ imgUrl +')"></div>';
        html += '    <div class="card-overlay bg-gradient-fade"></div>';
        html += '</div>';
        html += '</div>';
        
    });

    $('.splide__list').html(html);
    $('#display_loading').addClass('hideme');

    // setTimeout(function () {
        var splide = document.getElementsByClassName('splide');
        if (splide.length) {
            var singleSlider = document.querySelectorAll('.single-slider');
            if (singleSlider.length) {
                singleSlider.forEach(function (e) {
                    var single = new Splide('#' + e.id, {
                        type: 'loop',
                        autoplay: true,
                        interval: 2000,
                        perPage: 1,
                    }).mount();
                    var sliderNext = document.querySelectorAll('.slider-next');
                    var sliderPrev = document.querySelectorAll('.slider-prev');
                    sliderNext.forEach(el => el.addEventListener('click', el => { single.go('>'); }));
                    sliderPrev.forEach(el => el.addEventListener('click', el => { single.go('<'); }));
                });
            }

            
        }

        const cards = document.getElementsByClassName('card');

        function card_extender1(){
            var headerHeight, footerHeight, headerOnPage;
            var headerOnPage = document.querySelectorAll('.header:not(.header-transparent)')[0];
            var footerOnPage = document.querySelectorAll('#footer-bar')[0];
        
            headerOnPage ? headerHeight = document.querySelectorAll('.header')[0].offsetHeight : headerHeight = 0
            footerOnPage ? footerHeight = document.querySelectorAll('#footer-bar')[0].offsetHeight : footerHeight = 0
        
            for (let i = 0; i < cards.length; i++) {
                if(cards[i].getAttribute('data-card-height') === "cover"){
                    if (window.matchMedia('(display-mode: fullscreen)').matches) {var windowHeight = window.outerHeight;}
                    if (!window.matchMedia('(display-mode: fullscreen)').matches) {var windowHeight = window.innerHeight;}
                    //Fix for iOS 15 pages with data-height="cover"
                    var coverHeight = windowHeight + 'px';
                    // - Remove this for iOS 14 issues - var coverHeight = windowHeight - headerHeight - footerHeight + 'px';
                }
                if(cards[i].hasAttribute('data-card-height')){
                    var getHeight = cards[i].getAttribute('data-card-height');
                    cards[i].style.height= getHeight +'px';
                    if(getHeight === "cover"){
                        var totalHeight = getHeight
                        cards[i].style.height =  coverHeight
                    }
                }
            }
        }

        if(cards.length){
            card_extender1();
            window.addEventListener("resize", card_extender1);
        }
    // }, 2000);

    
}

