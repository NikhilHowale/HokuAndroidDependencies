
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
$(document).ready(function () {
    // $('#display_loading').removeClass('hideme');
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    let objParamsList = {};
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.queryMode = queryMode;
    getnotification(objParamsList);
});//end of ready 2

function getnotification(objParamsList) {
    const url = objParamsList.ajaXCallURL + '/booksy/getList_Notifications61f91155baf7700fc434e1af';
    $('#display_loading').removeClass('hideme');
    $.ajax({
        url,
        type: 'POST',
        data: objParamsList,
        success: function (response) {
            let html = '';
            if (response.status == 0 && response.data) {
                $.each(response.data, function (keyLis, objList) {
                    let created = moment(objList.createdOn).format('MMM DD, YYYY hh:mm:ss A');
                    html += `<div class="card card-style mb-2">
                    <div class="d-flex px-3 pb-4 pt-3">
                        <div class="align-self-center">
                            <h5>${objList.title}</h5>
                            <p class="mb-0 opacity-50 font-11">${objList.description}</p>
                        </div>
                    </div>
                    <div class="position-absolute bottom-0 end-0 pe-3">${created}</div>
                </div>`;
                });
                $('#notificationcontainer').html(html);
                $('#display_loading').addClass('hideme');
            }
        },
        error: function (error) {
            console.log(error);
        }
    });
    // 
}
