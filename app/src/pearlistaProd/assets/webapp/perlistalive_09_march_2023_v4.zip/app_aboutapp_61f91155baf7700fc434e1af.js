
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
$(document).ready(function () {
    $('#display_loading').removeClass('hideme');
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    let objParamsList = {};
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.queryMode = queryMode;
    getaboutappinfo(objParamsList);
});//end of ready 2

function getaboutappinfo(objParamsList) {
    const url = objParamsList.ajaXCallURL + '/booksy/getListDetails_Aboutapp61f91155baf7700fc434e1af_adsmanagements_adsmanagementsKendoList';
    $.ajax({
        url,
        type: 'POST',
        data: objParamsList,
        success: function (response) {
            if (response.status == 0 && response.data && response.data.length > 0) {
                let html = '';
                $.each(response.data, function (keyList, objList) {
                    objList['description'] = objList['description'] ? objList['description'] : '';
                    let description = objList['description'];
                    objList['title'] = objList['title'] ? objList['title'] : '';
                    let title = objList['title'];
                    html += '<h2>' + title + '</h2>';
                    html += '<div class="divider"></div>';
                    html += '<p>' + description + '</p>';
                });
                $('#aboutappcontainer').html(html);
                $('#aboutappcontainer').removeClass('hideme');
                $('#display_loading').addClass('hideme');
            }
        },
        error: function (error) {
            console.log("error in getting privacy and policy : " + error);
            return;
        }
    })
}