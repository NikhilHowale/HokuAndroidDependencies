
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
let toastMsg = [];
const appUser = JSON.parse(localStorage.getItem('appUser')) || {};
$(document).ready(function () {
    $('#display_loading').removeClass('hideme');
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    $("#phone").intlTelInput({
        initialCountry: "sg",
        preferredCountries: ["sg", "my"],
        separateDialCode: true,
        utilsScript: "countrycodes/js/utils.js",
    });
    $('#dateofbirth').datepicker({
        format: 'yyyy-mm-dd',
        autoclose: true,
    });
    var mask1 = "0000 0000";
    $("#phone").attr("placeholder", mask1);
    $("#phone").mask(mask1);
    $("#phone").attr("dialCode", "65").attr("countryCode", "sg");

    $("#phone").on("countrychange", function (e, countryData) {
        $("#phone").val("");
        var dialCode = "+" + countryData.dialCode + " ";
        var iso2 = countryData.iso2;
        var sampleNumber = intlTelInputUtils.getExampleNumber(iso2, false, 1);
        var placeholder = sampleNumber.replace(dialCode, "");
        var mask1 = placeholder.replace(/[0-9]/g, 0);
        $("#phone")
            .attr("placeholder", mask1)
            .attr("dialCode", countryData.dialCode)
            .attr("countryCode", iso2);
        $("#phone").mask(mask1);
    });
    let objParamsList = {};
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    objParamsList.queryMode = queryMode;
    objParamsList.ajaXCallURL = ajaXCallURL;
    getUserDetails(objParamsList);

    $(document).on('click', '#userphoto', function () {
        var mediaMeta = {};
        var obj = $(this);
        mediaMeta.canDelete = obj.attr('canDelete');
        mediaMeta.targetID = obj.attr('targetID') ? obj.attr('targetID') : obj.attr('id');
        mediaMeta.displayType = obj.attr('displayType');
        mediaMeta.fieldMappingID = obj.attr('fieldMappingID');
        mediaMeta.name = obj.attr('name');
        var allowType = obj.attr('allowType');
        var multiple = obj.attr('multiple') ? obj.attr('multiple') : 0;
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = getParameterByName('queryMode');
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        loadNativeusermanagement_userphotouploadFileUpload(tokenKey, queryMode, secretKey, ajaXCallURL, mediaMeta, allowType, multiple);;
    });//end of Event usermanagement_userphotoupload_is_click 

    $(document).on('click', '#updateprofilebtn', function () {
        let objParams = {};
        let errorField = [];
        // fullname
        const fullname = $.trim($('#fullname').val());
        if (fullname == '') {
            errorField.push($('#fullname'));
        } else if (fullname != '' && $('#fullname').siblings('.valid').hasClass('disabled')) {
            errorField.push($('#fullname'));
        } else {
            objParams.name = fullname;
        }
        // email
        const email = $.trim($('#email').val());
        if (email == '') {
            errorField.push($('#email'));
        } else if (email != '' && $('#email').siblings('.valid').hasClass('disabled')) {
            errorField.push($('#email'));
        } else {
            objParams.email = email;
        }
        // address
        const address = $.trim($('#address').val());
        if (address == '') {
            errorField.push($('#address'));
        } else if (address != '' && $('#address').siblings('.valid').hasClass('disabled')) {
            errorField.push($('#address'));
        } else {
            objParams.custadds = address;
        }
        // dob
        const dateofbirth = $.trim($('#dateofbirth').val());
        if (dateofbirth == '') {
            errorField.push($('#dateofbirth'));
        } else {
            objParams.birthdate = dateofbirth;
        }

        // phone
        let phone = $.trim($('#phone').val());
        var placeholder = $('#phone').attr('placeholder');
        phone = phone.replace(/[^0-9]/gi, '');
        placeholder = placeholder.replace(/[^0-9]/gi, '');
        if (phone == '') {
            toastMsg.push({ type: "warning", msg: "Mobile Number is required" });
        } else if (phone && placeholder.length != phone.length) {
            toastMsg.push({ type: "warning", msg: "Valid Mobile Number is required" });
        } else {
            const countryData = $("#phone").intlTelInput("getSelectedCountryData");
            objParams.contactnumber_countrycode = countryData.iso2;
            objParams.contactnumber_dialcode = countryData.dialCode;
            objParams.contactnumber = phone;
        }

        if (errorField.length <= 0 && toastMsg.length <= 0) {
            $('#display_loading').removeClass('hideme');
            objParams.ajaXCallURL = ajaXCallURL;
            objParams.tokenKey = tokenKey;
            objParams.secretKey = secretKey;
            objParams.recordID = appUser._id;
            objParams.rolename = appUser.rolename;
            objParams.rolename_name = appUser.rolename_name;
            objParams.isDelete = 0;
            objParams.isActive = 1;
            objParams.status = 'Active';
            objParams.organizationID = $("#organizationID").val();
            objParams.status_name = 'Active';
            objParams.callUrl = ajaXCallURL + '/booksy/updateAjaxusermanagementusermanagementlistweb';
            localStorage.setItem('objParamsData', JSON.stringify(objParams));
            sendOfflineusermanagementplayerprofileD37D2D59EA994A4599B0DF4368FF5FDEcopyMediaDetails(tokenKey, queryMode, secretKey, ajaXCallURL, objParams, objParams.callUrl);
            // $.ajax({
            //     url: objParams.ajaXCallURL + objParams.callUrl,
            //     data: objParams,
            //     type: 'POST',
            //     success: function (response) {
            //         if (response.status == 0) {
            //             localStorage.setItem('appUser', JSON.stringify(response.data));
            //             var nextPage = 'app_logisticuserprofile';
            //             var queryParams = queryStringToJSON();
            //             var queryString = $.param(queryParams);
            //             queryString = queryString.replace(/\+/g, "%20");
            //             queryString = decodeURIComponent(queryString);
            //             var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
            //             window.location.href = pageurl;
            //             return false;
            //         }
            //     },
            //     error: function (error) {
            //         console.log('Error in order placing : ' + error);
            //     }
            // })

        } else {
            if (errorField.length > 0) {
                errorField.forEach((el) => {
                    showInvalidField(el);
                });
                return;
            }

            if (toastMsg.length > 0) {
                const type = toastMsg[0].type;
                const message = toastMsg[0].msg;
                showToast(type, message);
                toastMsg = [];
                return;
            }
            $('#display_loading').addClass('hideme')
            return;
        }

    });

    $(document).on('change', '#dateofbirth', function () {
        validateField($(this));
    })


});//end of ready 2

function getUserDetails(objParamsList) {
    if (appUser._id) objParamsList.recordID = appUser._id;
    const url = objParamsList.ajaXCallURL + '/booksy/get_data_by_record_Usermanagement61f91155baf7700fc434e1afusermanagementlistweb';
    $.ajax({
        url,
        type: 'POST',
        data: objParamsList,
        success: function (response) {
            if (response.status == 0 && response.recordDetails[0]) {
                const data = response.recordDetails[0];
                let imgUrl = '';
                if (data.userphotoupload && data.userphotoupload[0] && data.userphotoupload[0].mediaID) {
                    imgUrl = CDN_PATH + data.userphotoupload[0].mediaID + '_compressed.png';
                }
                $('#userphoto').attr('src', imgUrl);
                $('#userphoto').removeClass('opacity-0');

                data.name = data.name ? data.name : '';
                let name = data.name;
                if (name != '') {
                    $('#fullname').val(name);
                    validateField($('#fullname'));
                }


                data.email = data.email ? data.email : '';
                let email = data.email;
                if (email != '') {
                    $('#email').val(email);
                    validateField($('#email'));
                }
                if (data.contactnumber && data.contactnumber_dialcode && data.contactnumber_countrycode) {
                    data.contactnumber = data.contactnumber.toString();
                    data.contactnumber = data.contactnumber.replace('+' + data.contactnumber_dialcode, '');
                    $('#phone').intlTelInput('setCountry', data.contactnumber_countrycode);
                    var sampleNumber = intlTelInputUtils.getExampleNumber(data.contactnumber_countrycode, false, 1);
                    var placeholder = sampleNumber.replace('+' + data.contactnumber_dialcode + ' ', '');
                    var mask1 = placeholder.replace(/[0-9]/g, 0);
                    $('#phone').val(data.contactnumber);
                    $('#phone').mask(mask1);
                    $('#phone').val($('#phone').masked(data.contactnumber));
                    $('#phone').attr('dialCode', data.contactnumber_dialcode);
                    $('#phone').attr('countryCode', data.contactnumber_countrycode);
                }

                data.custadds = data.custadds ? data.custadds : '';
                let custadds = data.custadds;
                if (custadds != '') {
                    $('#address').val(custadds);
                    validateField($('#address'));
                }

                data.birthdate = data.birthdate ? moment(data.birthdate).format('YYYY-MM-DD') : '';
                let birthdate = data.birthdate;
                if (birthdate != '') {
                    $('#dateofbirth').val(birthdate);
                    validateField($('#dateofbirth'));
                }
                $('#display_loading').addClass('hideme');
            }
        },
        error: function (error) {
            console.log('Error in getting user profile details' + error);
        }
    })
}

function validateField(element) {
    element.parent().addClass('input-style-active');
    element.siblings('.valid').removeClass('disabled');
    element.siblings('.invalid').addClass('disabled');
    element.siblings('em').addClass('disabled');
}

function loadNativeusermanagement_userphotouploadFileUpload(tokenKey, queryMode, secretKey, ajaXCallURL, mediaMeta, allowType, multiple) {
    var appJSON = {};
    appJSON.tokenKey = tokenKey;
    appJSON.secretKey = secretKey;
    appJSON.queryMode = queryMode;
    appJSON.action = queryMode;
    appJSON.mediaMeta = mediaMeta;
    appJSON.isFileFormat = true;
    appJSON.fileMimeType = allowType;
    appJSON.step = count++;
    appJSON.multiple = multiple;
    appJSON.ajaXCallURL = ajaXCallURL;
    appJSON.organizationID = $("#organizationID").val();
    appJSON.userID = $("#userID").val();
    appJSON.appID = $("#appID").val();
    appJSON.callbackFunction = "setNativeusermanagement_userphotouploadUploadedFiles";
    appJSON.offlineDataID = offlineDataID;
    if (window.location.protocol == 'https:') {
        if (appJSON.isDocumentsOnly) { $('#tempupload').attr('accept', 'application/pdf,application/vnd.ms-excel'); } else { $('#tempupload').attr('accept', 'image/*'); }
        $('#tempupload').trigger('click');
        tempObject = {};
        $(document).on('change', '#tempupload', function () {
            var obj = $(this);
            var objFile = obj.get(0).files[0];
            var xmlhttp;
            if (window.XMLHttpRequest) { // code for IE7+, Firefox, Chrome, Opera, Safari                   
                xmlhttp = new XMLHttpRequest();
            } else { // code for IE6, IE5                                                                   
                xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');
            }
            xmlhttp.onreadystatechange = function () {
                if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                    $('#display_loading').addClass('hideme');
                    var response = xmlhttp.responseText;
                    if (typeof response != 'object') {
                        response = JSON.parse(response);
                    }

                    var fileName = objFile.name ? objFile.name.toLowerCase() : "";
                    fileName = fileName.replace(/\s/g, "");
                    var fileNameCleaned = fileName.replace(/[^a-z0-9s]/gi, "").replace(/[_s]/g, "-");
                    if (!tempObject[fileNameCleaned]) {
                        tempObject[fileNameCleaned] = true;
                        appJSON.mediaMeta.mediaID = response.mediaID;
                        appJSON.mediaMeta.S3FilePath = response.S3FilePath;
                        var responseData = {};
                        responseData.annotationCount = 0;
                        responseData.dataDictionary = appJSON;
                        responseData.fileName = fileName;
                        responseData.displayfileName = CDN_PATH + response.mediaID + '_compressed.png';;
                        responseData.imagePath = fileName;
                        responseData.offlineDataID = offlineDataID;
                        webUploadArray.push({
                            mediaID: appJSON.mediaMeta.mediaID,
                            S3FilePath: appJSON.mediaMeta.S3FilePath,
                            fileNm: fileName,
                            step: 0
                        })
                        setNativeusermanagement_userphotouploadUploadedFiles(responseData)
                    }
                }
            }
            if (localStorage.IDENTITY_TOKEN) {
                xmlhttp.open('POST', CognitoConfig.GATEWAY_URL + '/fs/upload', true);
                xmlhttp.setRequestHeader('Authorization', localStorage.IDENTITY_TOKEN);
            } else {
                xmlhttp.open('POST', $('#filePath').val() + '/upload', true);
            }
            xmlhttp.setRequestHeader('HTTP_X_REQUESTED_WITH', 'XMLHttpRequest');
            xmlhttp.setRequestHeader('authtoken', '');
            xmlhttp.setRequestHeader('token', getParameterByName('tokenKey'));
            xmlhttp.setRequestHeader('fromweb', 1);
            xmlhttp.setRequestHeader('cs', '64_64,124_124');
            xmlhttp.setRequestHeader('ar', '1');
            xmlhttp.setRequestHeader('ft', 'png');
            xmlhttp.send(objFile);
        })
    } else {
        if (DEVICE_TYPE == "ios") {
            bridgeObj.callHandler("LoadNativeFileUpload", appJSON, function (response) {
            });
            bridgeObj.registerHandler("setNativeusermanagement_userphotouploadUploadedFiles", function (responseData, responseCallback) {
                setNativeusermanagement_userphotouploadUploadedFiles(responseData);
            });
        } else {
            window.Android.LoadNativeFileUpload(JSON.stringify(appJSON));
        }
    }
}

function setNativeusermanagement_userphotouploadUploadedFiles(responseData) {
    try {
        imageCount['userphotoupload'] = imageCount['userphotoupload'] ? (imageCount['userphotoupload'] + 1) : 1;
        var fileName = responseData.fileName ? responseData.fileName : "";
        fileName = fileName.replace(/\s/g, "");
        var displayfileName = fileName;
        if (window.location.protocol == "https:") {
            displayfileName = responseData.displayfileName;
        }
        if (responseData.dataDictionary) {
            responseData = responseData.dataDictionary;
            responseData.fileName = fileName;
        }
        var mediaMeta = JSON.parse(JSON.stringify(responseData.mediaMeta));
        mediaMeta.fileName = fileName;
        mediaMeta.fileNm = fileName;
        mediaMeta.name = fileName;
        mediaMeta.multiple = responseData.multiple;
        var fileNameCleaned = responseData.fileName.replace(/[^a-z0-9s]/gi, "").replace(/[_s]/g, "-");
        arrAllMedia[fileNameCleaned] = mediaMeta;
        var parent = $('#playerprofileimage').parent()
        switch (mediaMeta.displayType) {
            case "src":
                if ($('input[targetid="' + mediaMeta.targetID + '"]').length) {
                    $('input[targetid="' + mediaMeta.targetID + '"]').attr('src', getuploadedfilepreview(displayfileName));
                } else {
                    $('#' + mediaMeta.targetID).attr('src', getuploadedfilepreview(displayfileName));
                };
                break;
            case "text":
                $("#" + mediaMeta.targetID).val(getuploadedfilepreview(displayfileName));
                break;
            case 'html':
                let uploadedFileName = mediaMeta.fileName ? mediaMeta.fileName : displayfileName;
                let uploadType = 'Doc';
                if (uploadedFileName && (uploadedFileName.indexOf('.gif') != -1 || uploadedFileName.indexOf('.jpeg') != -1 || uploadedFileName.indexOf('.png') != -1 || uploadedFileName.indexOf('.jpg') != -1)) { uploadType = 'Image'; } else { displayfileName = uploadedFileName; }
                $('#iconthumbuserphotoupload').append('<div targate="userphotoupload" mid="' + fileNameCleaned + '" class="editthumb"><img  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + getuploadedfilepreview(displayfileName) + '" /> <span targate="userphotoupload" mid="' + fileNameCleaned + '" class="removeItem"></span> <div class="imageThumbTitle">' + uploadType + ' ' + imageCount['userphotoupload'] + '</div> </div>');
                break;
            case 'audio':
                var html = '<audio controls><source src="' + responseData.filePath + '" type="audio/mpeg"></audio>';
                parent.append(html);
                break;
            default:
                break;

        }
    } catch (err) {
        console.log('Error in setNativeUploadedFiles', err);
    }
}
function showInvalidField(element) {
    element.parent().removeClass('input-style-active');
    element.siblings('.invalid').removeClass('disabled');
    element.siblings('.valid').addClass('disabled');
    element.siblings('em').addClass('disabled');
}

function showToast(type, msg) {
    if (type == 'success') {
        $('#messagetoast').addClass('success_msg');
        $('#toastBody').html('<i class="fa fa-check-circle me-2"></i>' + msg);
    } else if (type == 'error') {
        $('#messagetoast').addClass('error_msg');
        $('#toastBody').html('<i class="fa fa-xmark-circle me-2"></i>' + msg);
    } else if (type == 'warning') {
        $('#messagetoast').addClass('warning_msg');
        $('#toastBody').html('<i class="fa fa-circle-exclamation me-2"></i>' + msg);
    }
    $('#messagetoast').toast('show');
    toastMsg = [];
}


function sendOfflineusermanagementplayerprofileD37D2D59EA994A4599B0DF4368FF5FDEcopyMediaDetails(tokenKey, queryMode, secretKey, ajaXCallURL, objParams, callUrl) {
    try {
        var appJSON = {};
        appJSON.tokenKey = tokenKey;
        appJSON.secretKey = secretKey;
        appJSON.queryMode = queryMode;
        appJSON.ajaXCallURL = ajaXCallURL;
        appJSON.callUrl = callUrl;
        appJSON.pageTitle = '';
        appJSON.nextButtonTitle = '';
        appJSON.nextRedirectionURL = "";
        appJSON.nextButtonCallback = 'saveusermanagementplayerprofileD37D2D59EA994A4599B0DF4368FF5FDEcopy';
        appJSON.isReadOnly = false;
        appJSON.offlineDataID = offlineDataID;
        if (window.location.protocol == 'https:') {
            var responseData = {};
            responseData.dataDictionary = appJSON;
            responseData.appMediaArrayForUploadArray = webUploadArray;
            saveusermanagementplayerprofileD37D2D59EA994A4599B0DF4368FF5FDEcopy(responseData)
        } else {
            if (DEVICE_TYPE == 'ios') {
                bridgeObj.callHandler('sendOfflineMediaDetails', appJSON, function (response) { });
                bridgeObj.registerHandler('saveusermanagementplayerprofileD37D2D59EA994A4599B0DF4368FF5FDEcopy', function (responseData, responseCallback) {
                    saveusermanagementplayerprofileD37D2D59EA994A4599B0DF4368FF5FDEcopy(responseData);
                });
            } else {
                window.Android.sendOfflineMediaDetails(JSON.stringify(appJSON));
            }
        }
    } catch (err) {
        // console.log('Error in sendOffline', err) 
    }
}

function saveusermanagementplayerprofileD37D2D59EA994A4599B0DF4368FF5FDEcopy(responseData) {
    try {
        var objParams = JSON.parse(localStorage.getItem('objParamsData'));
        objParams.isValid = 1;
        if (responseData) {
            if (responseData.appMediaArrayForUploadArray) {
                for (var iFileCount = 0; iFileCount < responseData.appMediaArrayForUploadArray.length; iFileCount++) {
                    var objUploadedFile = responseData.appMediaArrayForUploadArray[iFileCount];
                    if (objUploadedFile) {
                        var fileNameCleaned = objUploadedFile.fileNm.replace(/[^a-z0-9s]/gi, "").replace(/[_s]/g, "-");
                        var mediaMeta = {};
                        if (fileNameCleaned && typeof (arrAllMedia[fileNameCleaned]) != 'undefined') {
                            mediaMeta = arrAllMedia[fileNameCleaned]
                        }
                        mediaMeta.mediaID = objUploadedFile.mediaID;
                        mediaMeta.fileNm = objUploadedFile.fileNm;
                        mediaMeta.S3FilePath = objUploadedFile.S3FilePath;
                        var name = mediaMeta.name;
                        var targetID = '';
                        if (mediaMeta && mediaMeta.fieldMappingID && mediaMeta.targetID) {
                            targetID = mediaMeta.fieldMappingID ? mediaMeta.fieldMappingID : mediaMeta.targetID.replace(/[0-9]/g, "");
                        }
                        if (arrEditMedia[targetID] && !objParams[targetID]) {
                            objParams[targetID] = [];
                            for (var key in arrEditMedia[targetID]) {
                                objParams[targetID].push(arrEditMedia[targetID][key]);
                            }
                        } else if (!objParams[targetID]) {
                            objParams[targetID] = [];
                        }
                        getFindings(targetID, objParams, mediaMeta, true)
                        objParams[targetID].push(mediaMeta);
                    }
                }
            }
            objParams.recordID = localStorage.getItem('userID');
            if (objParams['userphotoupload'] && !objParams['userphotoupload'].length) {
                delete objParams['userphotoupload'];
            }
            if (objParams.isValid) {
                $.ajax({
                    url: objParams.callUrl,
                    data: objParams,
                    type: 'POST',
                    success: function (response) {
                        if (response.status == 0) {
                            var queryParams = queryStringToJSON();
                            var nextPage = "app_logisticuserprofile";
                            var queryString = $.param(queryParams);
                            queryString = queryString.replace(/\+/g, "%20");
                            queryString = decodeURIComponent(queryString);
                            window.location.href = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
                        } else {
                            $('#display_loading').addClass('hideme');
                            $('#playerprofileD37D2D59EA994A4599B0DF4368FF5FDEcopy_error').html(response.error);
                            $('#playerprofileD37D2D59EA994A4599B0DF4368FF5FDEcopy_error').show();
                        }
                        $('#391757').removeProp('disabled');
                    },
                    error: function (xhr, status, error) {
                        $('#display_loading').addClass('hideme');
                        $('#playerprofileD37D2D59EA994A4599B0DF4368FF5FDEcopy').removeProp('disabled');
                    },
                });
            } else {
                $('#display_loading').addClass('hideme');
                $('#playerprofileD37D2D59EA994A4599B0DF4368FF5FDEcopy').removeProp('disabled');
            }
        } else {
            $('#display_loading').addClass('hideme');
            $('#playerprofileD37D2D59EA994A4599B0DF4368FF5FDEcopy').removeProp('disabled');
        }
    } catch (err) {
        // console.log("Error in native", err)  
    }
}
