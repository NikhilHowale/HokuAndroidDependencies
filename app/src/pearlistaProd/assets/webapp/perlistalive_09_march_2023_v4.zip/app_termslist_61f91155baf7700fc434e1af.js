
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
$(document).ready(function () {
    $('#display_loading').removeClass('hideme');
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    let objParamsList = {};
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.queryMode = queryMode;
    getTermsListinfo(objParamsList);
});//end of ready 2

function getTermsListinfo(objParamsList) {
    const url = objParamsList.ajaXCallURL + '/booksy/getListDetails_Terms61f91155baf7700fc434e1af_termsandconditionsweb_termsandconditionswebKendoList';
    $.ajax({
        url,
        type: 'POST',
        data: objParamsList,
        success: function (response) {
            if (response.status == 0 && response.data && response.data.length > 0) {
                let html = '';
                $.each(response.data,function(keyList,objList){
                    objList['description'] = objList['description'] ? objList['description'] : '';
                    let description = objList['description'];
                    html += '<p>'+description+'</p>';
                });
                $('#termslistwrapper').html(html);                
                $('#termscontainer').removeClass('hideme');
                $('#display_loading').addClass('hideme');
            }
        },
        error: function (error) {
            console.log("error in getting terms and conditions : " + error);
            return;
        }
    })
}