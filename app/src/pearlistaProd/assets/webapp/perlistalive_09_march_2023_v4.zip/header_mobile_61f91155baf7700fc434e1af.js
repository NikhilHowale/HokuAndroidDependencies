var isOffline = false;
var arrUniqueFindings = [];
var globalVar = {}
var DEVICE_TYPE = "";
var ORG_ID = (localStorage.organizationID && localStorage.organizationID != 'undefined') ? localStorage.organizationID : '61f91155baf7700fc434e1af';
var CDN_PATH = localStorage.getItem('CDN_PATH') + '/' + ORG_ID + '/61f91155baf7700fc434e1af/' // for HokuApps 
var CDN_THUMB = localStorage.getItem('CDN_THUMB') + '/' + ORG_ID + '/61f91155baf7700fc434e1af/'
if (localStorage.getItem('locationPingJson')) {
    var locationPingJson = JSON.parse(localStorage.getItem('locationPingJson'));
} else {
    var locationPingJson = {};
}

function setCurrentLocationOfUser(responseData, response) {
    try {
        var apiParams = {};
        if (responseData) {
            $('#display_loading').addClass('hideme');
            // Add Custome function Call here 
            localStorage.setItem('locationPingJson', JSON.stringify(responseData));
            var userDeviceObj = responseData.userDeviceObj;
            if (responseData.data) {
                responseData = responseData.data;
            }
            var tokenKey = response.appTokenDetails.authToken;
            var secretKey = response.appTokenDetails.authSecretKey;
            var queryMode = 'mylist';
            var roleName = localStorage.getItem('roleName');
            if (roleName == "customer") {
                window.location.href = 'app_newparenthome_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                return false
            }
            if (roleName == "parent") {
                window.location.href = 'app_newparenthome_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                return false
            }
            if (roleName == "student") {
                window.location.href = 'app_newparenthome_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                return false
            }
            if (roleName == "supervisor") {
                window.location.href = 'app_supervisorhome_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                return false
            }
            if (roleName == "teacher") {
                window.location.href = 'app_teacherhome_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                return false
            }
            if (roleName == "sales") {
                window.location.href = 'app_userhome_61f91155baf7700fc434e1af.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                return false
            }
            if (roleName == "executive") {
                window.location.href = 'login_cognito.html?queryMode=executivelist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                return false
            }
        }
    } catch (err) { }
}
$(document).ready(function () {

    // set header color
    setHeaderColor();

    var appJSON = {};
    appJSON.nextButtonCallback = "offlineMode";
    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    if (isAndroid === -1) {
        setupWebViewJavascriptBridge(function (bridge) {
            bridge.callHandler("getNetworkStatus", appJSON, function (response) { });
            bridge.registerHandler("offlineMode", function (responseData, responseCallback) {
                offlineMode(responseData);
            });
        });
    } else {
        window.Android.getNetworkStatus(JSON.stringify(appJSON));
    }

    // $('.tooltipped').tooltip();
    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    if (isAndroid > -1) {
        DEVICE_TYPE = 'andriod'
    } else {
        DEVICE_TYPE = 'ios'
    }
    setDynamicHeight();
    // $('.modal').modal();
    var isProduction = false;
    var ISDEV_MODE = false;
    var ISSTARGATE_MODE = false;
    localStorage.setItem("ISDEV_MODE", ISDEV_MODE);
    //Change your device type here ie. ios or andriod 
    if (isProduction) {
        $("#ajaXCallURL").val("https://apps.hokuapps.com");
        $("#s3BasePath").val("https://s3.amazonaws.com/hokuappsapps");
        $("#filePath").val("https://devfiles.hokuapps.com");
        $("#domainName").val("hokuapps");
    } else if (ISDEV_MODE) {
        $("#ajaXCallURL").val("https://team.hokuapps.com");
        $("#s3BasePath").val("https://s3.amazonaws.com/hokuappsapps");
        $("#filePath").val("https://devfiles.hokuapps.com");
        $("#domainName").val("mybeep");
    } else if (ISSTARGATE_MODE) {
        $("#ajaXCallURL").val('##appurl##');
        $("#s3BasePath").val("https://s3.amazonaws.com/hokuappsapps");
        $("#filePath").val("https://devfiles.##env##.com");
        $("#domainName").val("##env##");
    } else {
        $("#ajaXCallURL").val("https://team.hokuapps.com");
        $("#s3BasePath").val("https://s3.amazonaws.com/hokuappsapps");
        $("#filePath").val("https://devfiles.hokuapps.com");
        $("#domainName").val("hokuapps");
    }
    $("#ajaXCallURL").val("https://gateway-sg.hokuapps.com/61f91155baf7700fc434e1af");
    // $("#ajaXCallURL").val("http://pearlista.mybeeps.com:8080");
    var ajaxUrl = $("#ajaXCallURL").val();
    if (ajaxUrl.indexOf('gateway') != -1) {
        var IS_IAMUSER = localStorage.getItem('IS_IAMUSER');
        if (IS_IAMUSER) {
            $('#ajaXCallURL').val('https://gateway-sg.hokuapps.com/61f91155baf7700fc434e1af');
        } else {
            $('#ajaXCallURL').val('https://gateway-sg.hokuapps.com/61f91155baf7700fc434e1af');
        }
        var IDENTITY_TOKEN = localStorage.getItem('IDENTITY_TOKEN')
        var tokenData = JSON.parse(localStorage.getItem('tokenData'));
        if (!tokenData) tokenData = {};

        $.ajaxSetup({
            headers: {
                'Authorization': IDENTITY_TOKEN,
                'tokenKey': tokenData.authToken,
                'authSecretKey': tokenData.authSecretKey
            },
            beforeSend: function (request) {
                var IS_IAMUSER = localStorage.getItem('IS_IAMUSER');
                if (IS_IAMUSER && this.url.indexOf('undefined') === -1 && this.url.includes('.com')) {
                    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                    var callURL = this.url;
                    var objParams = {};
                    if (this.data != undefined) {
                        objParams = form2Json(this.data);
                    }
                    objParams.appID = '61f91155baf7700fc434e1af';
                    objParams.tokenKey = getParameterByName('tokenKey');
                    objParams.secretKey = getParameterByName('secretKey');
                    objParams.apiName = this.url.split('.com')[1];
                    var GATEWAY_URL = 'https://gateway-sg.hokuapps.com';
                    var apigClient = apigClientFactory.newClient(GATEWAY_URL + objParams.apiName);
                    var params = {
                        'Content-Type': 'application/json'
                    };
                    var additionalParams = {};
                    allRequests.push(this);
                    apigClient.rootPost(params, objParams, additionalParams).then(function (response) {
                        if (response.status == 200) {
                            $.each(allRequests, function (keyList, objList) {
                                if (objList.apiName == response.config.url) {
                                    objList.success(response.data)
                                }
                            });
                            return false;
                        }
                    });
                    return false;
                } else {
                    refreshAWSToken(function (response) {
                        writeLog("weblog : refreshAWSToken response " + response + " -  header_mobile.js");
                    });
                }
            }
        });
        // var tokenKey = getParameterByName('tokenKey');
        // var secretKey = getParameterByName('secretKey');
        // if (tokenKey && secretKey) {
        //     refreshAWSToken(function (response) {
        //         if (response) {
        //             //do nothing  
        //         } else {
        //             setTimeout(function () {
        //                 window.location.href = 'index.html';
        //                 return false;
        //             }, 2000);
        //         }
        //     });
        // }
    }
    if ($('#loadHeader').val() == undefined) { }
    $(document).on('click', '#continue56', function () {
        localStorage.setItem('IS_IAMUSER', '');
        window.location.href = 'login_cognito.html';
        return false;
    });
    $(document).on('click', '.cross-icon', function () {
        $('.button-collapse').sideNav('hide');
    });
    $(document).on('click', '.nav-profile', function () {
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = getParameterByName('queryMode');
        window.location.href = 'userprofile_5e32c406349f3418458e4e39.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
        return false;
    });
    $(document).on('click', '.showMoreDetails', function () {
        if ($('#' + $(this).attr('displayShowMoreMainID') + 'ParcialCompleteText').attr('isShowMore') == 0) {
            $('#' + $(this).attr('displayShowMoreMainID') + 'FirstPartialText').html('');
            $('#' + $(this).attr('displayShowMoreMainID') + 'showMoreDetailsText').html('');
            $('#' + $(this).attr('displayShowMoreMainID') + 'showMoreDetailsText').after("<div style='display:inline;'>" + $('#' + $(this).attr('displayShowMoreMainID') + 'CompleteText').html() + "</div>");
            $('#' + $(this).attr('displayShowMoreMainID') + 'showMoreDetailsText').next("div").slideDown();
            $('#' + $(this).attr('displayShowMoreMainID') + 'ParcialCompleteText').attr('isShowMore', 1);
        }
        return false;
    });
    var objGetUserDetailsWithmenu = localStorage.getItem('objGetUserDetailsWithmenu');
    if (objGetUserDetailsWithmenu && objGetUserDetailsWithmenu != '' && objGetUserDetailsWithmenu != 'undefined') {
        objGetUserDetailsWithmenu = JSON.parse(objGetUserDetailsWithmenu);
        if (objGetUserDetailsWithmenu.status && objGetUserDetailsWithmenu.status == 1) {
            objGetUserDetailsWithmenu = '';
            //getMenuList(); 
        } else {
            renderMenuList(objGetUserDetailsWithmenu);
        }
    } else {
        //getMenuList(); 
    }
    $(document).on('click', '.redirecttopage', function () {
        const appUser = JSON.parse(localStorage.getItem('appUser'));
        localStorage.setItem("headerPageName", $(this).attr("headerPageName"))
        var fileName = $(this).attr('fileName');
        if (appUser.rolename == 'Guest') {
            if (!$(this).hasClass('active-nav') || $(this).hasClass('isguest')) {
                $('#toastouter').remove();
                $('#page').append(`
                <div id="toastouter">
                    <div id="signuptoast" class="start-50 tostcenter position-fixed translate-middle-x toast align-items-center text-white border-0 bg-highlight" role="alert" aria-live="assertive" aria-atomic="true" data-bs-delay="1500" data-bs-autohide="true">
                        <div class="d-flex">
                            <div id="toastBody" class="toast-body d-flex align-items-center py-0">
                                <i class="fa fa-xmark-circle me-2"></i>Please create an account first !
                            </div>
                        </div>
                    </div>
                    <style>
                        #signuptoast {
                            white-space: nowrap !important;
                            overflow: hidden;

                            z-index: 10000;
                            border-radius: 8px !important;
                            top: 10px !important;
                            line-height: 50px !important;
                        }
                    </style>
                </div>
                `);
                $('#signuptoast').toast('show');
                return;
            }
        }
        var queryMode = $(this).attr('queryMode');
        if (fileName) {
            let arrFiles = fileName.split('_');
            if (arrFiles[1] && (arrFiles[1].endsWith('add') || arrFiles[1].endsWith('create'))) {
                queryMode = 'add';
            }
        }
        var nativeredirect = $(this).attr('nativeredirect');
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        $('.side-nav div').removeClass('active');
        $(this).addClass("active");
        localStorage.setItem("activeMenu", $(this).attr("id"))
        localStorage.removeItem('appbackpage')
        var menuID = $(this).attr("id");
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        if (typeof (menuID) != "undefined") {
            menuID = menuID.toLowerCase();
        };
        if (menuID == "chat" || menuID == "groupchat") {
            loadNativeChatControl(tokenKey, queryMode, secretKey, ajaXCallURL, menuID);
        } else if (nativeredirect) {
            var appJSON = {
                redirectToPage: fileName
            }
            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (isAndroid > -1) {
                window.Android.redirectPage(JSON.stringify(appJSON));
            } else {
                setupWebViewJavascriptBridge(function (bridgeObj) {
                    bridgeObj.callHandler('redirectPage', appJSON, function (response) { });
                });
            }
        } else {
            window.location.href = fileName + "?queryMode=" + queryMode + "&tokenKey=" + tokenKey + "&secretKey=" + secretKey;
            return false;
        }
    });

    $(document).on("click", "#nativeLogut", function () {
        var queryMode = "add";
        var ajaXCallURL = getParameterByName("ajaXCallURL");
        var tokenKey = getParameterByName("tokenKey");
        var secretKey = getParameterByName("secretKey");
        localStorage.setItem("IS_IAMUSER", "");
        writeLog('weblog : logoutNativeCall logout click event header_mobile.js');
        logoutNativeCall(tokenKey, queryMode, secretKey, ajaXCallURL);
    });

    // To update the app
    // if (
    //     localStorage.updateappmessage != true &&
    //     localStorage.updateappmessage != "true"
    // ) {
    //     updateApp();
    // }


}); //end of ready  



function refreshAWSTokenOnForeground() {
    writeLog("weblog : Inside refreshAWSTokenOnForeground -  header_mobile.js");

    var tokenKey = getParameterByName("tokenKey");
    var secretKey = getParameterByName("secretKey");

    writeLog("weblog : Inside refreshAWSTokenOnForeground - tokenKey " + tokenKey + " -  header_mobile.js");
    writeLog("weblog : Inside refreshAWSTokenOnForeground - secretKey " + secretKey + " -  header_mobile.js");
    writeLog("weblog : Inside refreshAWSTokenOnForeground - CognitoConfig " + CognitoConfig + " -  header_mobile.js");
    writeLog("weblog : Inside refreshAWSTokenOnForeground - CognitoConfig.USER_POOL_ID " + CognitoConfig.USER_POOL_ID + " -  header_mobile.js");

    if (tokenKey && secretKey && CognitoConfig && CognitoConfig.USER_POOL_ID != "") {
        //$("#display_loading").removeClass("hideme");
        var appJSON = {};
        appJSON.nextButtonCallback = "offlineModeWithRefreshToken";
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        writeLog("weblog : call getNetworkStatus bridge 1 -  header_mobile.js");
        if (isAndroid === -1) {
            setupWebViewJavascriptBridge(function (bridge) {
                writeLog("weblog : call getNetworkStatus bridge 2 -  header_mobile.js");
                bridge.callHandler("getNetworkStatus", appJSON, function (response) { });
                bridge.registerHandler("offlineModeWithRefreshToken", function (responseData, responseCallback) {
                    offlineModeWithRefreshToken(responseData);
                });
            });
        } else {
            window.Android.getNetworkStatus(JSON.stringify(appJSON));
        }
    } else {
        writeLog("weblog : Inside tokenKey || secretKey || CognitoConfig is missing -  header_mobile.js");
    }
}

function refreshAWSTokenFromNative() {
    refreshAWSTokenOnForeground();
}

$(document).on('click', '#nav-mobile-sort', function (e) {
    if ($('#displaysort').val() != undefined) {
        applyLocalSort($(this))
    }
});

function loadNativeChatControl(tokenKey, queryMode, secretKey, ajaXCallURL, menuID) {
    try {
        var appJSON = {};
        appJSON.tokenKey = tokenKey;
        appJSON.secretKey = secretKey;
        appJSON.queryMode = queryMode;
        appJSON.action = queryMode;
        appJSON.ajaXCallURL = ajaXCallURL;
        appJSON.organizationID = $('#organizationID').val();
        appJSON.appID = $('#appID').val();
        appJSON.chatTabType = 6;
        if (menuID == "groupchat") {
            if (DEVICE_TYPE == 'ios') {
                setupWebViewJavascriptBridge(function (bridgeObj) {
                    bridgeObj.callHandler('openChatWindow', appJSON, function (response) { });
                });
            } else {
                window.Android.openChatWindow(JSON.stringify(appJSON));
            }
        } else {
            if (DEVICE_TYPE == 'ios') {
                setupWebViewJavascriptBridge(function (bridgeObj) {
                    bridgeObj.callHandler('openChatWindow', appJSON, function (response) { });
                });
            } else {
                window.Android.openChatWindow(JSON.stringify(appJSON));
            }
        }
    } catch (err) {

    }
}

function applyLocalSort(thisObj) {
    var sortColumnName = $('#displaysort').val();
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var queryMode = getParameterByName('queryMode');
    if (gListData && gListData.data) {
        var sortType = thisObj.attr('sort');
        if (sortType == "0") {
            $('#btnSort').children().children().attr('src', 'a_z_up.svg');
            //do asc by alaphabet 
            gListData.data.sort(function (a, b) {
                //Turn your strings into dates, and then subtract them 
                //to get a value that is either negative, positive, or zero. 
                if (a[sortColumnName] && b[sortColumnName]) {
                    var textA = a[sortColumnName].toUpperCase();
                    var textB = b[sortColumnName].toUpperCase();
                    return (textA < textB) ? -1 : (textA > textB) ? 1 : 0;
                }
            });
            thisObj.attr('sort', "1");
        } else if (sortType == "1") {
            $('#btnSort').children().children().attr('src', 'a_z_down.svg');
            //do asc by alaphabet 
            gListData.data.sort(function (a, b) {
                //Turn your strings into dates, and then subtract them 
                //to get a value that is either negative, positive, or zero. 
                if (a[sortColumnName] && b[sortColumnName]) {
                    var textA = a[sortColumnName].toUpperCase();
                    var textB = b[sortColumnName].toUpperCase();
                    return (textB < textA) ? -1 : (textB > textA) ? 1 : 0;
                }
            });
            thisObj.attr('sort', "2");
        } else if (sortType == "2") {
            $('#btnSort').children().children().attr('src', 'a_z.svg');
            //do normal by updateOn 
            gListData.data.sort(function (a, b) {
                // Turn your strings into dates, and then subtract them 
                // to get a value that is either negative, positive, or zero. 
                if (a.updatedOn && b.updatedOn) {
                    return new Date(b.updatedOn) - new Date(a.updatedOn);
                }
            });
            thisObj.attr('sort', "0");
        }
        showMobileList(gListData, tokenKey, queryMode);
    }
}

function logoutNativeCall(tokenKey, queryMode, secretKey, ajaXCallURL) {
    var appJSON = {};
    appJSON.tokenKey = tokenKey;
    appJSON.secretKey = secretKey;
    appJSON.queryMode = queryMode;
    appJSON.ajaXCallURL = ajaXCallURL;
    appJSON.organizationID = $('#organizationID').val();
    appJSON.userID = $('#userID').val();
    appJSON.appID = $('#appID').val();
    appJSON.nextButtonCallback = 'logoutNativeCallBack';
    appJSON.action = queryMode;
    appJSON.step = 1;
    var objParams = {};
    objParams.organizationID = appJSON.organizationID;
    objParams.userID = appJSON.userID;
    objParams.appID = appJSON.appID;
    objParams.isLogout = true;
    var ajaXCallURL = (CognitoConfig && CognitoConfig.APP_URL) ? CognitoConfig.APP_URL : 'https://enrichmentteamapp.hokuapps.com';
    appJSON.apiName = ajaXCallURL + '/api/addUserDeviceForApp_61f91155baf7700fc434e1af';
    appJSON.addDeviceObject = objParams;
    try {
        //    localStorage.clear();

        var userforlogin = localStorage.getItem('userforlogin');

        localStorage.clear();

        localStorage.setItem('userforlogin', userforlogin);

        //removeLocalVariables61f91155baf7700fc434e1af();
    } catch (err) {
        // console.log('Error in removeLocalVariables', err);
    }
    localStorage.setItem('tokenKey', '');
    localStorage.setItem('secretKey', '');
    localStorage.setItem('objGetUserDetailsWithmenu', '');
    localStorage.setItem('perms', '');
    localStorage.setItem('user', '');
    localStorage.setItem('organizationID', '');
    localStorage.setItem('userID', '');
    localStorage.setItem('CDN_PATH', '');
    localStorage.setItem('CDN_THUMB', '');
    localStorage.setItem('profileThumb', '');
    localStorage.setItem('activeMenu', '');
    if (DEVICE_TYPE == 'ios') {
        setupWebViewJavascriptBridge(function (bridgeObj) {
            bridgeObj.callHandler('logoutNativeCall', appJSON, function (response) { });
        });
    } else {
        window.Android.logoutNativeCall(JSON.stringify(appJSON));
    }
    window.location.href = 'login_cognito.html';
    return false;
}

function nativeWebBackNav(response) {
    if (response) {
        var currentPageName = response.pageName;
        var navBackCntrl = $('div[id^="backbutton"]');
        if (currentPageName != 'login_cognito' && navBackCntrl.length > 0 && navBackCntrl.is(':visible')) {
            navBackCntrl.trigger('click');
        } else {
            var appJSON = {};
            appJSON.isFinishDelay = true;
            appJSON.isShowDialog = false;
            appJSON.finishDelayMsg = 'Press again to exit.';
            appJSON.dialogMessage = 'Application exit?';
            appJSON = JSON.stringify(appJSON);
            window.Android.handleNativeBack(appJSON);
        }
    }
}
var isfromweb = getParameterByName('isfromweb');
if (isfromweb == 1 || isfromweb == '1') {
    var objParamsToken = {};
    objParamsToken.appID = $('#hdnAppID').val();
    var ajaXCallURL = "https://enrichmentteamapp.hokuapps.com";
    objParamsToken.tokenKey = getParameterByName('tokenKey');
    objParamsToken.secretKey = getParameterByName('secretKey');
    objParamsToken.userID = getParameterByName('userID');
    objParamsToken.isFBSignup = true;
    $.ajax({
        url: ajaXCallURL + '/team/sendOTPToMobileNo61f91155baf7700fc434e1af',
        data: objParamsToken,
        type: 'POST',
        success: function (response) {
            localStorage.setItem('tokenKey', response.appTokenDetails.authToken);
            localStorage.setItem('secretKey', response.appTokenDetails.authSecretKey);
            localStorage.setItem('objGetUserDetailsWithmenu', JSON.stringify(response.objGetUserDetailsWithmenu));
            localStorage.setItem('perms', JSON.stringify(response.perms));
            localStorage.setItem('user', JSON.stringify(response.user));
            localStorage.setItem('appUser', JSON.stringify(response.appUser));
            localStorage.setItem('organizationID', response.user.organizationId);
            localStorage.setItem('userID', response.user.userId);
            localStorage.setItem('CDN_PATH', response.CDN_PATH);
            localStorage.setItem('CDN_THUMB', response.CDN_THUMB);
            if (response.appUser && response.appUser.userphotoupload && response.appUser.userphotoupload[0]) {
                localStorage.setItem('profileThumb', response.appUser.userphotoupload[0].mediaID);
            } else {
                localStorage.removeItem('profileThumb');
            }
            localStorage.setItem('tokenData', JSON.stringify(response.tokenData));
            localStorage.setItem('roleName', response.appTokenDetails.roleName);
            renderMenuList(response.objGetUserDetailsWithmenu);
        },
        error: function (xhr, status, error) {

        },
    });
}
//Start of renderMenuList 
function renderMenuList(response) {
    try {
        var fieldTags = {};
        if (typeof (response.fieldTags) != 'undefined') {
            $.each(response.fieldTags, function (keyList, objTag) {
                fieldTags[objTag.name] = objTag.value;
            });
        }
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        var html = ''
        if (response != undefined && response.status != undefined && response.data != undefined) {
            $('#userID').val(response.data.userID);
            localStorage.setItem("userRole", response.data.roleName);
            localStorage.setItem("userID", response.data.userID);
            $('#organizationID').val(response.data.organizationID);
            $('#appID').val(response.data.appID);
            var objList = {};
            objList.thumbImage = response.thumbImage;
            objList.userNameDetails = response.userNameDetails;
            objList.userEmailDetails = response.userEmailDetails;
            if (typeof (objList.thumbImage) == 'undefined') {
                var profileThumb = localStorage.getItem('profileThumb');
                objList.thumbImage = profileThumb ? (CDN_PATH + profileThumb + '') : 'nouserprofile.svg';
                localStorage.setItem('profileThumbURL', objList.thumbImage);
            } else {
                localStorage.setItem('profileThumbURL', objList.thumbImage);
            }
            html += '      <div class="row nav-profile" >';
            html += '           <div class="col s12">';
            html += '               <div id="thumbImage" class="profileSmallThumbnail" style="background-image: url(' + objList.thumbImage + ')"></div>'
            html += '           </div>';
            html += '           <div class="col s12">';
            html += '            <div id="userNameDetails">' + objList.userNameDetails + '</div>';
            html += '            <div id="userEmailDetails" >' + objList.userEmailDetails + '</div>';
            html += '            </div>';
            html += '     </div>';

            if (response.menuList != undefined) {
                var menuHtml = '';
                var indexCount = 0;
                $.each(response.menuList, function (keyList, objList) {
                    var menuName = objList.name;
                    if (typeof (currentLanguage) != 'undefined' && currentLanguage != '' && currentLanguage != 'en') {
                        objList.fn = objList.fn.replace('.html', '_' + currentLanguage + '.html');
                    }
                    objList.upName = objList.name;
                    menuName = menuName.toLowerCase();
                    menuName = menuName.replace(/ /g, '_');
                    var menuNameIcon = menuName + '_menu_list_icon'
                    if (objList.isMainHeader && objList.isMainHeader == 1) {
                        objList.menuLable = objList.name;
                        var headerID = objList.name.replace(/ /g, '_');
                        var regExpr = /[^a-zA-Z0-9-. ]/g;
                        headerID = headerID.replace(regExpr, "");
                        html += '      <div class="row menu-item redirecttopage" id="' + headerID + '" fileName="' + objList.fn + '" queryMode="' + objList.qm + '" >';
                        html += '           <div class="col s2 menu-icon">';
                        html += '               <img recordID="' + objList._id + '" class="menuicon"  src="icon_' + objList.name.toLowerCase() + '.svg">';
                        html += '           </div>';
                        html += '           <div class="col s10 menu-label">';
                        html += '            <div class="menuname languagetranslation" >' + objList.name + '</div>';
                        html += '            </div>';
                        html += '     </div>';
                    };
                });
                if (localStorage.getItem('roleName') && localStorage.getItem('roleName') == 'guest') {
                    html += '      <div class="row menu-item" id="continue56" style="cursor: pointer;">';
                    html += '           <div class="col s2 menu-icon" >';
                    html += '               <img   src="Logout.svg">';
                    html += '           </div>';
                    html += '           <div class="col s10 menu-label">';
                    html += '                <div>Login</div>';
                    html += '           </div>';
                    html += '      </div>';
                } else {
                    html += '      <div class="row menu-item" id="nativeLogut" >';
                    html += '           <div class="col s2 menu-icon" >';
                    html += '               <img   src="Logout.svg">';
                    html += '           </div>';
                    html += '           <div class="col s10 menu-label">';
                    html += '                <div>Logout</div>';
                    html += '           </div>';
                    html += '      </div>';
                }
                $("#slide-out").html(html);

            };

        }

        var tokenKey = getParameterByName('tokenKey');
        var url = 'nouserprofile.svg';
        var obj = findObjectByKey('_id', $('#userID').val());
        if (response.thumbImage) {
            url = response.thumbImage;
        } else if (obj && obj.userphotoupload && obj.userphotoupload[0] && obj.userphotoupload[0].mediaID) {
            url = $('#filePath').val() + '/download?f=' + obj.userphotoupload[0].mediaID + '.png&t=' + tokenKey
        }
        $('#thumbImage').attr('src', url);
        var activeMenu = localStorage.getItem("activeMenu");
        if (activeMenu != "") {
            $("#" + activeMenu + "").addClass("active");
        } else {
            $('.menu-item:first').addClass('active');
        }
        if ($('#displayBack').val() == undefined) {
            setTimeout(function () {
                // $('#slide-out').removeClass('hideme');
                // $('.button-collapse').sideNav({
                //     menuWidth: 240, // Default is 240 
                //     closeOnClick: true,
                //     draggable: true,
                //     edge: 'left', // Choose the horizontal origin 
                // })
            }, 1000);
        }


    } catch (err) {
        // console.log("Error in renderMenuList", err); 
    }
}
// End of  renderMenuList 

//$(document).on('focus', 'input', function(){ $(this).select(); })  

$(document).on('click', '#retrybutton', function () {
    window.location.reload();
});

function handleError(xhr, status, error) {
    try {
        //if(!ISDEV_MODE){ 
        if (XMLHttpRequest.readyState == 4) {
            //HTTP error (can be checked by XMLHttpRequest.status and XMLHttpRequest.statusText) 
            //$('#display_error').removeClass('hideme'); 
        } else if (XMLHttpRequest.readyState == 0) {
            //Network error (i.e. connection refused, access denied due to CORS, etc.) 
            //$('#display_error').removeClass('hideme'); 
        } else {
            //something weird is happening 
            //$('#display_error').removeClass('hideme'); 
        }
        // } 
    } catch (err) {
        // error 
    }
}

function getuploadedfilepreview(filename) {
    var pdfextension = ["pdf"];
    var docextension = ["doc", "docx"];
    var sheetextension = ["xls", "xlsx"];
    var result = filename;
    if (filename) {
        var extension = filename.split(".").pop();
        if (extension) {
            if (pdfextension.indexOf(extension) > -1) {
                result = "sg_pdficon.png";
            } else if (docextension.indexOf(extension) > -1) {
                result = "sg_docicon.png";
            } else if (sheetextension.indexOf(extension) > -1) {
                result = "sg_sheeticon.png";
            }
        }
    }
    return result;
}

function queryStringToJSON(url) {
    var pairs = location.search.slice(1).split('&');
    if (url) {
        pairs = url.split('&');
    }
    var result = {};
    pairs.forEach(function (pair) {
        pair = pair.split('=');
        result[pair[0]] = decodeURIComponent(pair[1] || '');
    });

    return JSON.parse(JSON.stringify(result));
}
setDateTimePicker();
setTimeout(function () {
    setDateTimePicker();
}, 200);
setTimeout(function () {
    setDateTimePicker();
}, 2000);

function setDateTimePicker() {
    if ($('.datepicker').length) {
        $('.datepicker').pickadate({
            selectMonths: true,
            selectYears: 150,
            dateFormat: 'd mmmm, yyyy',
            onSet: function (arg) {
                if ('select' in arg) {
                    this.close();
                }
            }
        });
        $('.datepicker').on('mousedown', function (event) {
            event.preventDefault();
        })
    }
    if ($('.datepickerpast').length) {
        $('.datepickerpast').pickadate({
            selectMonths: true,
            selectYears: 150,
            dateFormat: 'd mmmm, yyyy',
            max: new Date(),
            onSet: function (arg) {
                if ('select' in arg) {
                    this.close();
                }
            }
        });
        $('.datepickerpast').on('mousedown', function (event) {
            event.preventDefault();
        })
    }
    if ($('.datepickerfuture').length) {
        $('.datepickerfuture').pickadate({
            selectMonths: true,
            selectYears: 150,
            dateFormat: 'd mmmm, yyyy',
            min: new Date(),
            onSet: function (arg) {
                if ('select' in arg) {
                    this.close();
                }
            }
        });
        $('.datepickerfuture').on('mousedown', function (event) {
            event.preventDefault();
        })
    }
    if ($('.timepicker').length) {
        $('.timepicker').pickatime({
            default: 'now',
            fromnow: 0,
            twelvehour: true,
            donetext: 'OK',
            cleartext: 'Clear',
            canceltext: 'Cancel',
            autoclose: false
        });
        $('.timepicker').on('mousedown', function (event) {
            event.preventDefault();
        })
    }
}

function isEmail(email) {
    var regex = /^([a-zA-Z0-9_.+-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/;
    regex = EMAIL_REGEX ? EMAIL_REGEX : regex;
    return regex.test(email);
}
$(document).on('click', '.removeItem', function () {
    var mid = $(this).attr('mid');
    var targate = $(this).attr('targate');
    if (arrEditMedia[targate] && arrEditMedia[targate][mid]) {
        delete arrEditMedia[targate][mid];
        $('div[mid=' + mid + '][targate=' + targate + ']').remove();
        $('.findingrow' + mid).remove();
    } else if (arrAllMedia[mid]) {
        delete arrAllMedia[mid];
        $('div[mid=' + mid + ']').remove();
        $('.findingrow' + mid).remove();
    }
});
$(document).on('click', '.displaythumb img', function () {
    try {
        displayCloudPreview($(this), 'displaythumb')
    } catch (error) {
        console.log('Error in native carsole1', error);
    }
})

$(document).on('click', '.editthumb img', function () {
    try {
        displayCloudPreview($(this), 'editthumb')
    } catch (error) {
        console.log('Error in native carsole2', error);
    }
})

function displayCloudPreview(element, className) {
    try {
        var parentID = element.parent().parent().attr('id');
        var appJSON = {};
        var AWSCredentials = localStorage.getItem('AWSCredentials');
        if (localStorage.IDENTITY_TOKEN) {
            var token = localStorage.IDENTITY_TOKEN;
            var playload = JSON.parse(atob(token.split('.')[1]));
            appJSON.Authorization = token;
            appJSON.Expiration = playload.exp;
        } else if (AWSCredentials) {
            AWSCredentials = JSON.parse(AWSCredentials);
            appJSON.accessKeyId = AWSCredentials.accessKeyId;
            appJSON.secretAccessKey = AWSCredentials.secretAccessKey;
            appJSON.sessionToken = AWSCredentials.sessionToken;
            appJSON.Expiration = AWSCredentials.Expiration;
        }
        var arrUrls = [];
        var arrStartUrls = [];
        var imageFound = false;
        var clickedTargetUrl = element.attr('cloudpath');
        var fileName = element.attr('fname');
        if (clickedTargetUrl && (clickedTargetUrl.endsWith('.png') || clickedTargetUrl.endsWith('.jpg') || clickedTargetUrl.endsWith('.jpeg'))) {
            $('#' + parentID + ' .' + className + ' img').each(function () {
                var imagePath = element.attr('cloudpath');
                if (imagePath && (imagePath.endsWith('.png') || imagePath.endsWith('.jpg') || imagePath.endsWith('.jpeg'))) {
                    if (clickedTargetUrl == imagePath) {
                        imageFound = true;
                    }
                    if (!imageFound) {
                        if (imagePath.indexOf('https://') != -1) {
                            arrUrls.push({
                                's3FilePath': imagePath
                            });
                        } else {
                            arrUrls.push({
                                'fileName': imagePath
                            });
                        }
                    } else {
                        if (imagePath.indexOf('https://') != -1) {
                            arrStartUrls.push({
                                's3FilePath': imagePath
                            });
                        } else {
                            arrStartUrls.push({
                                'fileName': imagePath
                            });
                        }
                    }

                }
            })

            if (arrUrls && arrUrls.length) {
                for (var key in arrUrls) {
                    arrStartUrls.push(arrUrls[key]);
                }
            }

            if (arrStartUrls && arrStartUrls.length) {
                appJSON.imageList = arrStartUrls;
                appJSON.index = 0;
                appJSON.isFromPath = true;

                if (DEVICE_TYPE == 'ios') {
                    setupWebViewJavascriptBridge(function (bridgeObj) {
                        bridgeObj.callHandler('showNativeCarousel', appJSON, function (response) { });
                    });
                } else {
                    window.Android.showNativeCarousel(JSON.stringify(appJSON));
                }
            }
        } else if (clickedTargetUrl && (clickedTargetUrl.indexOf('.pdf') != -1)) {
            // handle pdf view  
            downloadFile(clickedTargetUrl, 'pdf', fileName);
        } else if (clickedTargetUrl && (clickedTargetUrl.endsWith('.xls'))) {
            // handle xls view TODO::need to handle 
            shareAppData(clickedTargetUrl, 'xls');
        } else if (clickedTargetUrl && (clickedTargetUrl.endsWith('.xlsx'))) {
            // handle xlsx view TODO::need to handle 
            shareAppData(clickedTargetUrl, 'xlsx');
        } else if (clickedTargetUrl && (clickedTargetUrl.endsWith('.doc'))) {
            // handle doc view TODO::need to handle 
            shareAppData(clickedTargetUrl, 'doc');
        }
    } catch (error) {
        console.log('Error in native carsole', error);
    }
}


setupWebViewJavascriptBridge(function (bridgeObj) {
    bridgeObj.registerHandler('nativeRedirectPageCallback', function (responseData, responseCallback) {
        nativeRedirectPageCallback(responseData);
    });
});

function nativeRedirectPageCallback(responseLocations) {
    try {
        if (responseLocations) {
            if (responseLocations.bridgeData) {
                var response = responseLocations.bridgeData;
            } else {
                var response = responseLocations;
            }
            response.recordID = response.recordID ? response.recordID : response._id;
            var recordID = response.recordID ? response.recordID : response._id;
            if (recordID) {
                var tokenKey = getParameterByName('tokenKey');
                var secretKey = getParameterByName('secretKey');
                var queryMode = getParameterByName('queryMode');
                var nextPage = getParameterByName('redirectPage');
                window.location.href = nextPage + '_61f91155baf7700fc434e1af.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&recordID=' + recordID + '&bazaarid=' + recordID + '&ordersid=' + recordID;
                return false;
            }
        }
    } catch (err) {
        // console.log(err);
    }
}

function redirectPageCallbackV2(responseLocations) {
    try {
        if (responseLocations) {
            if (responseLocations.bridgeData) {
                var response = responseLocations.bridgeData;
            } else {
                var response = responseLocations;
            }
            response.recordID = response.recordID ? response.recordID : response._id;
            var tokenKey = getParameterByName('tokenKey') ? getParameterByName('tokenKey') : response.tokenKey;
            var secretKey = getParameterByName('secretKey') ? getParameterByName('secretKey') : response.secretKey;
            var queryMode = getParameterByName('queryMode') ? getParameterByName('queryMode') : response.queryMode;
            var recordID = getParameterByName('recordID') ? getParameterByName('recordID') : response.recordID;
            queryMode = 'mylist';
            localStorage.setItem('isFilterFromMap', 1);
            window.location.href = response.redirectPage + '_61f91155baf7700fc434e1af.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&ordersid=' + response.ordersid + '&bazaarid=' + response.bazaarid + '&recordID=' + recordID + '&applyFilter=true'
            return false;
        }
    } catch (err) {
        // console.log(err);
    }
}

function activatePullToRefresh() {
    try {
        // Enable scrollz 
        $('#full-body-container').scrollz({
            pull: true,
            styleClass: 'activepull'
        });
        // Bind pulled event 
        $('#full-body-container').bind('pulled', function (event) {
            var objParamsList = localStorage.objParamsList ? JSON.parse(localStorage.objParamsList) : null;
            if (objParamsList && objParamsList.functionName) {
                $('#display_loading').removeClass('hideme');
                skip = 0;
                var func = new Function(
                    'return ' + objParamsList.functionName + '(' + JSON.stringify(objParamsList) + ');'
                )();
                $(document).ajaxStop(function () {
                    $('#display_loading').addClass('hideme');
                    // Hide pull header when done 
                    $('#full-body-container').scrollz('hidePullHeader');
                })
            } else {
                $('#display_loading').addClass('hideme');
                $('#full-body-container').scrollz('hidePullHeader');
            }
        });
    } catch (error) {
        console.log('Error in activatePullToRefresh', error);
    }
}
var fetchRecord = 15;
var skip = 0;
var lastscroll = 0;
var scrollCached = 0;

function fullBodyScrollEvent(element) {
    try {
        var scrollHeight = element.scrollHeight;
        var clientHeight = element.clientHeight;
        var scrollTop = element.scrollTop;
        var scrollPos = (clientHeight + scrollTop);
        //var tempScrollPos = scrollPos + 100;  
        if (scrollHeight <= scrollPos && lastscroll < scrollPos && !scrollCached) {
            var objParamsList = localStorage.objParamsList ? JSON.parse(localStorage.objParamsList) : null;
            if (objParamsList && objParamsList.functionName) {
                scrollCached = 1;
                $('#display_loading').removeClass('hideme');
                lastscroll = scrollPos;
                objParamsList.isLazyLoading = true;
                var func = new Function(
                    'return ' + objParamsList.functionName + '(' + JSON.stringify(objParamsList) + ');'
                )();
            }
        }
    } catch (error) {
        console.log('Error in fullBodyScrollEvent', error);
    }
}

function concatDateTime(tempDate, tempTime) {
    try {
        if (tempDate && tempTime) {
            tempTime = tempTime.toUpperCase();
            var newDate = new Date(tempDate + ' ' + tempTime.replace('PM', ' PM').replace('AM', ' AM'))
            newDate = moment(newDate).format('YYYY-MM-DDTHH:mm:ssZ');
            if (newDate) {
                return newDate;
            } else {
                console.log('Error in concatDateTime', 'date or time missing');
                return null;
            }
        } else {
            console.log('Error in concatDateTime', 'date or time missing');
            return null;
        }
    } catch (error) {
        console.log('Error in concatDateTime', error);
        return null;
    }
}

function onMarkerClick(responseData) {
    try {
        if (responseData && responseData._id) {
            if ($('.view_list_record').length) {
                $('.view_list_record').hide();
                $('[class*="view_list_record"][recordID="' + responseData._id + '"]').show()
            }
            return false;
        }
    } catch (err) {
        console.log("Error in onMarkerClick --", err)
    }
}



function offlineMode({
    mode
}) {
    try {
        if (mode) {
            isOffline = mode;
            $("#networkerror").remove();
            $("#full-body-container").prepend('<div id="networkerror"><h5>No Connection Found</h5><h6>Please check your network connection</h6></div>');
        } else {
            $("#networkerror").remove();
            isOffline = false;
        }
    } catch (error) {
        console.log("Error in offline mode", error);
    }
}

function offlineModeWithRefreshToken({
    mode
}) {
    $("#display_loading").addClass("hideme");
    writeLog("weblog : Inside offlineModeWithRefreshToken - " + mode + " -  header_mobile.js");
    try {
        if (mode) {
            writeLog("weblog : Inside offlineModeWithRefreshToken - Internet Offline  -  header_mobile.js");
            isOffline = mode;
            $("#networkerror").remove();
            $("#full-body-container").prepend('<div id="networkerror"><h5>No Connection Found</h5><h6>Please check your network connection</h6></div>');
        } else {
            writeLog("weblog : Inside offlineModeWithRefreshToken - Internet Online  -  header_mobile.js");
            $("#networkerror").remove();
            isOffline = false;
            writeLog("weblog : Inside offlineModeWithRefreshToken - call refreshAWSToken  -  header_mobile.js");
            refreshAWSToken(function (response) {
                writeLog("weblog : Inside offlineModeWithRefreshToken -  refreshAWSToken response " + response + "  -  header_mobile.js");

                if (response) {
                    writeLog("weblog : Inside offlineModeWithRefreshToken - token refreshed  -  header_mobile.js");
                    $("#display_loading").addClass("hideme");
                    var IDENTITY_TOKEN = localStorage.getItem("IDENTITY_TOKEN");
                    if (IDENTITY_TOKEN) {
                        var appJSON = {};
                        appJSON.idToken = IDENTITY_TOKEN;
                        var playload = JSON.parse(atob(IDENTITY_TOKEN.split(".")[1]));
                        if (playload.exp) {
                            appJSON.ExpiryTime = playload.exp;
                        }
                        if (DEVICE_TYPE == "ios") {
                            setupWebViewJavascriptBridge(function (bridge) {
                                bridgeObj.callHandler("updateToken", appJSON, function (response) { });
                            });
                        } else {
                            window.Android.updateToken(JSON.stringify(appJSON));
                        }
                    }
                }
            });
        }
    } catch (error) {
        writeLog("weblog : Inside offlineModeWithRefreshToken - error  -  header_mobile.js");
        console.log("Error in offline mode", error);
    }
}

function setHeaderColor() {
    var appJSON = {};
    appJSON.colourHexString = "#052c8a";
    appJSON.isWhiteColour = false;
    if (window.location.href.indexOf("app_inspectorhome") !== -1 || window.location.href.indexOf("login") !== -1) {
        appJSON.colourHexString = "#ffffff";
        appJSON.isWhiteColour = true;
    }
    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    if (isAndroid === -1) {
        setupWebViewJavascriptBridge(function (bridge) {
            bridge.callHandler("changeStatusBarColour", appJSON, function (response) { });
        });
    } else {
        // window.Android.changeStatusBarColour(JSON.stringify(appJSON));
    }
}

function updateApp() {
    var appJSON = {};
    appJSON.userId = localStorage.userID;
    appJSON.tokenKey = getParameterByName('tokenKey');
    appJSON.secretKey = getParameterByName('secretKey');
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    appJSON.queryMode = "mylist";
    appJSON.ajaXCallURL = ajaXCallURL;
    appJSON.apiName = ajaXCallURL + "/team/GetAppVersionDetails_61f91155baf7700fc434e1af";
    appJSON.showNativeDialog = true;
    appJSON.organizationID = $('#organizationID').val();
    appJSON.userID = $('#userID').val();
    appJSON.appID = $('#appID').val();
    // appJSON.nextButtonCallback = 'loadcompleteCheckAppVersion';
    appJSON.action = queryMode;
    var IDENTITY_TOKEN = getParameterByName('IDENTITY_TOKEN');
    IDENTITY_TOKEN = IDENTITY_TOKEN ? IDENTITY_TOKEN : localStorage.getItem('IDENTITY_TOKEN')
    appJSON.Authorization = IDENTITY_TOKEN;

    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    if (isAndroid > -1) {
        window.Android.updateAppVersion(JSON.stringify(appJSON));
    } else {
        setupWebViewJavascriptBridge(function (bridge) {
            bridgeObj = bridge;
            var appJSON = {};
            appJSON.nextButtonCallback = 'loadcompleteCheckAppVersion';
            bridgeObj.callHandler('updateAppVersion', appJSON, function (response) { });

            bridgeObj.registerHandler('updateAppVersion', function (responseData, responseCallback) {
                loadcompleteCheckAppVersion(responseData);
            });
        });
    }
}

function loadcompleteCheckAppVersion(responseData) {
    if (responseData) {
        if (responseData.newVersionFound == true) {
            var tokenKey = getParameterByName('tokenKey');
            var secretKey = getParameterByName('secretKey');
            var queryMode = getParameterByName('queryMode');
            var nextPage = 'updateappmessage';
            if (!nextPage) {
                return false;
            }
            localStorage.updateappmessage = "true";
            window.location.href = nextPage + '_61f91155baf7700fc434e1af.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
            return false;
        }
    } else { }
}
