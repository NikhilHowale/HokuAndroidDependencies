$(document).ready(function () {
  // function for refresh token
  refreshAWSToken(function (response) {
    writeLog("weblog : inside refreshAWSToken - indexstart.js");
    if (response) {
      writeLog("weblog : refreshAWSToken successful -  indexstart.js");
      // if refresh token success
      proceesToLogin(response);
    } else {
      writeLog("weblog : refresh token fail -  indexstart.js");
      let token_expired = true;
      proceesToLogin(response, token_expired);
      return false;
    }
  });
});

// proceedapp bridgecall for load index page
function proceesToLogin(response, token_expired = false) {
  writeLog("weblog : proceesToLogin  " + token_expired + " -  indexstart.js");
  var appJSON = {};
  appJSON.token_expired = token_expired;
  appJSON.response = response;
  var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
  if (isAndroid > -1) {
    window.Android.proceedToApp(JSON.stringify(appJSON));
  } else {
    setupWebViewJavascriptBridge(function (bridge) {
      writeLog("weblog : proceesToLogin - proceedToApp   -  indexstart.js");
      bridge.callHandler("proceedToApp", appJSON, function (response) {});
    });
  }

  // 90 day scenario
  if (token_expired) {
    writeLog("weblog : proceesToLogin  token_expired  90 day scenario -  indexstart.js");
    localStorage.clear();
    window.location.href = "login_cognito.html";
    return;
  }
}

function refreshGoogleToken() {
  $("#display_loading").removeClass("hideme");
  localStorage.removeItem("objGetUserDetailsWithmenu");
  var appJSON = {};
  appJSON.nextButtonCallback = "refreshGoogleTokenCallBack";
  appJSON.colorCode = "#3c3c3c";
  appJSON.launchNative = false;
  appJSON.roleName = "customer";
  localStorage.setItem("activeMenu", "NewsFeed");
  appJSON.launchNextpage = "app_home_5cf798a8c3eff778ff9043e9.html";
  // appJSON.isFromSocialMedia = true;
  var ISDEV_MODE = localStorage.getItem("ISDEV_MODE");
  if (ISDEV_MODE == "false" || ISDEV_MODE == false) {
    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    if (isAndroid > -1) {
      window.Android.refreshGoogleToken(JSON.stringify(appJSON));
    } else {
      bridgeObj.callHandler("refreshGoogleToken", appJSON, function (response) {});
      bridgeObj.registerHandler("refreshGoogleTokenCallBack", function (responseData, responseCallback) {
        refreshGoogleTokenCallBack(responseData);
      });
    }
  }
}

function refreshGoogleTokenCallBack(responseData) {
  localStorage.setItem("IS_IAMUSER", true);
  localStorage.setItem("accessToken", responseData.googleIdToken);
  var AWSCredentials = JSON.parse(localStorage.getItem("AWSCredentials"));
  AWSCredentials.accessToken = responseData.googleIdToken;
  localStorage.setItem("AWSCredentials", JSON.stringify(AWSCredentials));
  localStorage.setItem("identityProvider", "google");
  refreshAWSToken(function (response) {
    proceesToLogin(response);
  });
}

function offlineMode({ mode }) {
  writeLog("weblog : offlineMode mode " + mode + "-  indexstart.js");
  try {
    if (mode) {
      isOffline = true;
    } else {
      isOffline = false;
    }

    writeLog("weblog : before refresh token -  indexstart.js");
    // refresh cognito token
  } catch (error) {
    console.log("Error in offline mode", error);
    writeLog("weblog : error in offlineMode function -  indexstart.js");
  }
}
