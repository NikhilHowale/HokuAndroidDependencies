
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
var totaldcard_topimage216560043190_collectioncontainer = 0;
$(document).ready(function () {
    $('.page-content').css({
        'height': 'calc(100vh - 62px)',
        'overflow-y': 'scroll',
        'padding-bottom': '0px',
    });
    if ($('.view_list_record').length) { $('.view_list_record').show(); }
    localStorage.removeItem('objParamsList');
    if ($('.js-candlestick').length) $("input[type='checkbox']").candlestick({ 'on': 'Yes', 'off': 'No', 'nc': 'NA', 'default': 'NA', 'swipe': false, 'allowManualDefault': true });
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    let objParamsList = {};
    skip = 0;
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    objParamsList.queryMode = queryMode;
    objParamsList.isMobile = isMobile;
    objParamsList.functionName = 'show_dcard_getCategoryListDetails';
    localStorage.setItem('objParamsList', JSON.stringify(objParamsList));
    show_dcard_getCategoryListDetails(objParamsList);



    $(document).on('click', '.dcard_categories_collectioncontainer', function () {
        var orderid = $(this).attr('orderid');// get record ID;
        var nextPage = 'app_appointmentdetails';
        var queryParams = queryStringToJSON();
        queryParams['appointmentid'] = orderid;
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        window.location.href = pageurl;
        return false;
    });


    $(document).on('click', '#addbooking', function () {
        var categoryid = $(this).attr('recordID');// get record ID;
        var nextPage = 'app_addbooking';
        var queryParams = queryStringToJSON();
        if (queryMode) queryParams['queryMode'] = queryMode;
        if (categoryid) queryParams['categoryid'] = categoryid;
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);

        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = getParameterByName('queryMode');


        var pageurl = nextPage + "_61f91155baf7700fc434e1af.html?queryMode=" + queryMode + "&tokenKey=" + tokenKey + "&secretKey=" + secretKey;
        window.location.href = pageurl;
        return false;
    });


});//end of ready 2

function show_dcard_getCategoryListDetails(objParamsList) {
    $('#display_loading').removeClass('hideme');
    objParamsList.isParent = 1;
    objParamsList.isExternalBooking = 1;
    objParamsList.skip = skip;
    objParamsList.fetch = fetchRecord;
    objParamsList.loginuserid = localStorage.userID; // to not get all appoinment 
    objParamsList.isCancelledOrder = 1; //to not get cancelled appoinments
    $.ajax({
        url: objParamsList.ajaXCallURL + '/booksy/schedulerGetNewEvents_appointmentschedularweb_Appointment61f91155baf7700fc434e1af',
        data: objParamsList,
        type: 'POST',
        success: function (response) {
            getDataProcessAfterCalldcard_topimage216560043190_collectioncontainerCategory62864e09ce661f57e6375105(response, function () {
                if (response.status != undefined && response.status == 0) {
                    if (objParamsList.isMobile == 'true') {
                        if (!objParamsList.isLazyLoading || objParamsList.fromSync) {
                            $('#orderslistcontainer').html('');
                        } else {
                            scrollCached = 0;
                        }
                        getdcard_topimage216560043190_collectioncontainerapp_programmecategorylistMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    } else if (objParamsList.isiPad == 'true') {
                        //getdcard_topimage216560043190_collectioncontainerapp_programmecategorylistiPadView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    } else {
                        //getdcard_topimage216560043190_collectioncontainerapp_programmecategorylistWebView(response, objParamsList.tokenKey,objParamsList.queryMode);
                    }
                    $('#display_loading').addClass('hideme');
                } else {
                    $('#display_loading').addClass('hideme')
                }
            });
        },
        error: function (xhr, status, error) {
            $('#display_loading').addClass('hideme')
            handleError(xhr, status, error);
        },
    });
} // end of function     

function getDataProcessAfterCalldcard_topimage216560043190_collectioncontainerCategory62864e09ce661f57e6375105(response, callback) {
    callback();
}

function getdcard_topimage216560043190_collectioncontainerapp_programmecategorylistMobileView(response, tokenKey, queryMode) {
    var html = '';
    $('#display_loading').removeClass('hideme')
    if (response.data.length == 0 && !$('.dcard_categories_collectioncontainer').length) {
        html += '<div class="nodatafound">';
        html += '<img src="nodatafound.gif" width="100%">';
        html += '<br>';
        html += '<!-- span>No record found</span -->';
        html += '</div>';
        $('#orderslistcontainer').html(html);
    } else {
        html = '';
        var radioGroups = [];
        if (!response.showShimmer) {
            skip = skip + response.data.length;
        }
        $.each(response.data, function (keyList, objList) {
            var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (0) {  // need to fix with native gyes.. images not getting download
                var mediaID = '';
                var fileName = '';
                // if (objList['imageupload'] && objList['imageupload'][0].mediaID) {
                //     P
                //     mediaID = objList['imageupload'][0].mediaID;
                //     fileName = objList['imageupload'][0].mediaID + '.png';
                // }
            } else {
                objList['date'] = objList['date'] ? objList['date'] : '';
                let date = moment(objList['date']).format('DD MMM, YYYY');

                html += '<div orderid="' + objList._id + '" class="card card-style card-margin dcard_categories_collectioncontainer">'
                html += '    <div class="content mb-0 content-margin" id="">'
                html += '        <div class="row row-m-1">'
                html += '            <div class="col-12">'
                html += '                <div><span class="card-id">' + objList.appointmentnumber + '</span></div>'
                html += '                <div>Date : <span class="text-black">' + date + '</span></div>'
                html += '                <div>Duration : <span class="text-black">' + objList.duration + '</span></div>'
                // html += '                <div>Price : <span class="text-black">$' + objList.price + '</span></div>'
                html += '            </div>'
                html += '        </div>'
                html += '    </div>'
                html += '</div>'
            }
        });
        var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        $('#orderstrip').removeClass('hideme');
        $('#orderslistcontainer').html(html)
        $('#orderslistcontainer').removeClass('hideme');
        $('#display_loading').addClass('hideme');
    };
};

function show_dcard_getbannerimagelist(objParamsList) {
    $('#display_loading').removeClass('hideme');
    $.ajax({
        url: objParamsList.ajaXCallURL + '/booksy/getListDetails_Homebanner61f91155baf7700fc434e1af_promotionalbannerweb_promotionalbannerwebKendoList',
        data: objParamsList,
        type: 'POST',
        success: function (response) {
            if (response.status != undefined && response.status == 0) {
                if (objParamsList.isMobile == 'true') {
                    if (!objParamsList.isLazyLoading || objParamsList.fromSync) {
                        $('.splide__list').html('');
                    } else {
                        scrollCached = 0;
                    }
                } else if (objParamsList.isiPad == 'true') {
                } else {
                }
                $('#display_loading').addClass('hideme');
                getdcard_bannerimagelistMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
            } else {
                $('#display_loading').addClass('hideme')
            }
        },
        error: function (xhr, status, error) {
            $('#display_loading').addClass('hideme');
            handleError(xhr, status, error);
        },
    });
}

function getDataAfterCallgetdcard_bannerimagelist(response, callback) {
    callback();
}

function getdcard_bannerimagelistMobileView(response) {
    let html = '';
    $.each(response.data, function (keyList, objList) {
        html += '<div class="splide__slide">';
        html += '   <div class="card rounded-m shadow-l mx-3" style="height:200px;">';
        html += '       <div class="card-overlay bg-gradient"></div>';
        let imgUrl = '';
        if (objList.bannerimage && objList.bannerimage[0] && objList.bannerimage[0].mediaID) {
            imgUrl = CDN_PATH + objList.bannerimage[0].mediaID + '_compressed.png';
        }
        html += '       <img class="img-fluid" src="' + imgUrl + '">';
        html += '   </div>';
        html += '</div>';
    });
    $('.splide__list').html(html)
    $('#display_loading').addClass('hideme');
    var splide = document.getElementsByClassName('splide');
    if (splide.length) {
        var singleSlider = document.querySelectorAll('.single-slider');
        if (singleSlider.length) {
            singleSlider.forEach(function (e) {
                var single = new Splide('#' + e.id, {
                    type: 'loop',
                    autoplay: true,
                    interval: 4000,
                    perPage: 1,
                }).mount();
                var sliderNext = document.querySelectorAll('.slider-next');
                var sliderPrev = document.querySelectorAll('.slider-prev');
                sliderNext.forEach(el => el.addEventListener('click', el => { single.go('>'); }));
                sliderPrev.forEach(el => el.addEventListener('click', el => { single.go('<'); }));
            });
        }

        var doubleSlider = document.querySelectorAll('.double-slider');
        if (doubleSlider.length) {
            doubleSlider.forEach(function (e) {
                var double = new Splide('#' + e.id, {
                    type: 'loop',
                    autoplay: true,
                    interval: 4000,
                    arrows: false,
                    perPage: 2,
                }).mount();
            });
        }

        var trippleSlider = document.querySelectorAll('.tripple-slider');
        if (trippleSlider.length) {
            trippleSlider.forEach(function (e) {
                var tripple = new Splide('#' + e.id, {
                    type: 'loop',
                    autoplay: true,
                    padding: {
                        left: '0px',
                        right: '80px',
                    },
                    interval: 4000,
                    arrows: false,
                    perPage: 2,
                    perMove: 1,
                }).mount();
            });
        }
    }
}
