
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
$(document).ready(function () {
    $('#display_loading').removeClass('hideme');
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    let objParamsList = {};
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    getCheckoutProductList(objParamsList);

    $(document).on('click', '.orderstatus', function () {
        if ($(this).attr('completed') == 'true') { return; }
        const status = $(this).attr('status');
        const currentDate = moment(new Date()).utc().format('YYYY-MM-DDTHH:mm:ssZ');
        const orderid = getParameterByName('orderid');
        const updateType = $(this).prop('id');
        let objParams = {};
        objParams.tokenKey = tokenKey;
        objParams.secretKey = secretKey;
        objParams.ajaXCallURL = ajaXCallURL;
        objParams.recordID = orderid;
        objParams[updateType] = currentDate;
        objParams.status = status;
        const url = objParams.ajaXCallURL + '/booksy/updateProductCheckout61f91155baf7700fc434e1af';
        $('#display_loading').removeClass('hideme');
        $.ajax({
            url,
            type: 'POST',
            data: objParams,
            success: function (response) {
                if (response.status == 0) {
                    var nextPage = 'app_logisticorderdetails';
                    var queryParams = queryStringToJSON();
                    var queryString = $.param(queryParams);
                    queryString = queryString.replace(/\+/g, "%20");
                    queryString = decodeURIComponent(queryString);
                    var pageurl = nextPage + "_61f91155baf7700fc434e1af.html?" + queryString;
                    window.location.href = pageurl;
                    return false;
                }
            },
            error: function (error) {
                console.log("Error in updating order status : " + error);
                return;
            }
        })
    })
    // $(document).on('click', '#callbtncustomer', function () {
    //     var custphone = $(this).attr('customerphone');
    //     shareAppData(custphone, 'mailTo');
    //     return false;
    // })
    $(document).on('click', '#Chatbtncustomer', function () {
        var customerID = $(this).attr('customerID');
        var queryMode = getParameterByName('queryMode');
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var ajaXCallURL = $('#ajaXCallURL').val();
        var appJSON = {};
        appJSON.title = 'Discussion'
        appJSON.chatSegmentTitle = 'Recent';
        appJSON.groupSegmentTitle = 'Classes';
        appJSON.groupByTitle = 'People';
        appJSON.hideContactTab = true;
        appJSON.tokenKey = tokenKey;
        appJSON.secretKey = secretKey;
        appJSON.queryMode = queryMode;
        appJSON.action = queryMode;
        appJSON.ajaXCallURL = ajaXCallURL;
        appJSON.organizationID = $('#organizationID').val();
        appJSON.appID = $('#appID').val();
        appJSON.chatTabType = 6;
        appJSON.userID = customerID;
        appJSON.recordID = customerID;
        if (DEVICE_TYPE == 'ios') {
            setupWebViewJavascriptBridge(function (bridgeObj) {
                bridgeObj.callHandler('loadNativeChatIndivisualWindow', appJSON, function (response) { });
            });
        } else {
            window.Android.loadNativeChatIndivisualWindow(JSON.stringify(appJSON));
        }
    })
});//end of ready 2


function getCheckoutProductList(objParamsList) {
    objParamsList.parentproductid = getParameterByName('orderid');
    objParamsList.isExternalBooking = 1;
    objParamsList.skip = skip;
    objParamsList.fetch = fetchRecord;
    $.ajax({
        url: objParamsList.ajaXCallURL + '/booksy/getProductCheckoutListDetails_61f91155baf7700fc434e1afCustom',
        type: "POST",
        data: objParamsList,
        success: function (response) {
            if (response.status == 0) {
                getdcard_topimage216560043190_collectioncontainerapp_productlistMobileView(response);
            }
            $('#display_loading').addClass('hideme');
        },
        error: function (error) {
            console.log(error);
        }
    })

}

function getdcard_topimage216560043190_collectioncontainerapp_productlistMobileView(response) {
    var html = '';
    $('#display_loading').removeClass('hideme')
    if (response.data.length == 0 && !$('.product_dcard').length) {
        html += '<div class="nodatafound">';
        html += '<img src="nodatafound.gif" width="100%">';
        html += '<br>';
        html += '<!-- span>No record found</span -->';
        html += '</div>';
        // $('#productListwrapper').html(html);
    } else {
        html = '';
        var radioGroups = [];
        if (!response.showShimmer) {
            skip = skip + response.data.length;
        }
        $.each(response.data, function (keyList, objList) {
            if (objList.type == 'parent') {
                $('#orderstatus').html(objList.status);
                $('#customername').html(objList.customerid_name);
                $('#customeremail').html(objList.email);
            
                $('#customeraddress').html(objList.address);
                $('#customernotes').html(objList.notes);
             
                $('#customerphone').html("+" + objList.contactnumber_dialcode + " " + objList.contactnumber);
                // $('#callbtncustomer').attr('customerphone',"+" + objList.contactnumber_dialcode + " " + objList.contactnumber);
                $('#callbtncustomer').attr("href","tel:"+objList.contactnumber);
                $('#grandtotalamount').html("$" + objList.actualamount.toFixed(2));
                $('#Chatbtncustomer').attr("customerID",objList.customerid);
                if(objList.isorderguestuser == 1){
                    $('#Chatbtncustomer').addClass("hideme");
                }
                $('#orderinfowrapper').removeClass('hideme');
                $('.orderstatus').attr('completed', true);
                if (objList.orderconfirmdate) {
                    const date = moment(objList.orderconfirmdate).format('DD MMM YYYY hh:mm:ss');
                    $('.timeline-item').eq(0).removeClass('hideme');
                    $('.timeline-item').eq(0).find('.statusdate').html(date);
                    $('.orderstatus').removeClass('bg-green-dark');
                    $('.orderstatus').eq(0).addClass('bg-green-dark');
                    $('.orderstatus').eq(0).attr('completed', true);
                    $('.orderstatus').eq(0).next().removeAttr('completed');
                }
                if (objList.orderpreparingdate) {
                    const date = moment(objList.orderpreparingdate).format('DD MMM YYYY hh:mm:ss');
                    $('.timeline-item').eq(1).removeClass('hideme');
                    $('.timeline-item').eq(1).find('.statusdate').html(date);
                    $('.orderstatus').removeClass('bg-green-dark');
                    $('.orderstatus').eq(1).addClass('bg-green-dark');
                    $('.orderstatus').eq(1).attr('completed', true);
                    $('.orderstatus').eq(1).next().removeAttr('completed');
                }
                if (objList.handovercourierdate) {
                    const date = moment(objList.handovercourierdate).format('DD MMM YYYY hh:mm:ss');
                    $('.timeline-item').eq(2).removeClass('hideme');
                    $('.timeline-item').eq(2).find('.statusdate').html(date);
                    $('.orderstatus').removeClass('bg-green-dark');
                    $('.orderstatus').eq(2).addClass('bg-green-dark');
                    $('.orderstatus').eq(2).attr('completed', true);
                    $('.orderstatus').eq(2).next().removeAttr('completed');
                }
                if (objList.ordercompleteddate) {
                    const date = moment(objList.ordercompleteddate).format('DD MMM YYYY hh:mm:ss');
                    $('.timeline-item').eq(3).removeClass('hideme');
                    $('.timeline-item').eq(3).find('.statusdate').html(date);
                    $('.orderstatus').removeClass('bg-green-dark');
                    $('.orderstatus').eq(3).addClass('bg-green-dark');
                    $('.orderstatus').attr('completed', true);
                    $('#editbtn').addClass('hideme');
                }
            }

            var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (0) {  // need to fix with native gyes.. images not getting download
                var mediaID = '';
                var fileName = '';
                // if (objList['imageupload'] && objList['imageupload'][0].mediaID) {
                //     P
                //     mediaID = objList['imageupload'][0].mediaID;
                //     fileName = objList['imageupload'][0].mediaID + '.png';
                // }
            } else {
                objList['totalcost'] = objList['totalcost'] ? objList['totalcost'].toFixed(2) : '';
                let totalcost = objList['totalcost'];
                objList['productid_name'] = objList['productid_name'] ? objList['productid_name'] : '';
                let productid_name = objList['productid_name'];

                objList['quentity'] = objList['quentity'] ? objList['quentity'] : '';
                let quantity = objList['quentity'];
                let imgUrl = '';
                if (objList.productid.productimage && objList.productid.productimage[0] && objList.productid.productimage[0].mediaID) {
                    imgUrl = CDN_PATH + objList.productid.productimage[0].mediaID + '_compressed.png';
                }
                html += '<div class="d-flex mb-4 product_dcard">';
                html += '   <div>';
                html += '       <img onerror="this.src =\'https://appscdn-us.hokuapps.com/card.png\'" src="' + imgUrl + '" class="rounded-m shadow-xl" width="100" height="85" style="object-fit:cover;">';
                html += '   </div>';
                html += '   <div class="ms-3 overflow-hidden">';
                html += '       <h4 class="text-capitalize text-truncate">' + productid_name + '</h4>';
                html += '       <h4 class="pt-1 color-highlight">$' + totalcost + '</h4>';
                html += '       <span class="color-theme font-12 text-capitalize">Quantity : ' + quantity + '</span>';
                html += '   </div>';
                html += '</div>';
            }
        });
        var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        $('#productListwrapper').html(html);
        $('#productListwrapper').removeClass('hideme');
        $('#timeline').removeClass('hideme');
        $('#display_loading').addClass('hideme');
    };
};
