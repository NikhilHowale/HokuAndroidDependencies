
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
$(document).ready(function () {
    $('#display_loading').removeClass('hideme');
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    let objParamsList = {};
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    getCheckoutProductList(objParamsList);
    // $(document).on('click', '#callbtnlogistic', function () {
    //     var logiphone = $(this).attr('logisticphone');
    //     // shareAppData(logiphone, 'mailTo');
    //     return false;  
        
    // })
    $(document).on('click', '#Chatbtnlogistic', function () {
        var logistciID = $(this).attr('logistciID');
        var queryMode = getParameterByName('queryMode');
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var ajaXCallURL = $('#ajaXCallURL').val();
        var appJSON = {};
        appJSON.title = 'Discussion'
        appJSON.chatSegmentTitle = 'Recent';
        appJSON.groupSegmentTitle = 'Classes';
        appJSON.groupByTitle = 'People';
        appJSON.hideContactTab = true;
        appJSON.tokenKey = tokenKey;
        appJSON.secretKey = secretKey;
        appJSON.queryMode = queryMode;
        appJSON.action = queryMode;
        appJSON.ajaXCallURL = ajaXCallURL;
        appJSON.organizationID = $('#organizationID').val();
        appJSON.appID = $('#appID').val();
        appJSON.chatTabType = 6;
        appJSON.userID = logistciID;
        appJSON.recordID = logistciID;
        if (DEVICE_TYPE == 'ios') {
            setupWebViewJavascriptBridge(function (bridgeObj) {
                bridgeObj.callHandler('loadNativeChatIndivisualWindow', appJSON, function (response) { });
            });
        } else {
            window.Android.loadNativeChatIndivisualWindow(JSON.stringify(appJSON));
        }
    })
});//end of ready 2 
function getCheckoutProductList(objParamsList) {
    objParamsList.parentproductid = getParameterByName('orderid');
    objParamsList.isExternalBooking = 1;
    objParamsList.skip = skip;
    objParamsList.fetch = fetchRecord;
    $.ajax({
        url: objParamsList.ajaXCallURL + '/booksy/getProductCheckoutListDetails_61f91155baf7700fc434e1afCustom',
        type: "POST",
        data: objParamsList,
        success: function (response) {
            if (response.status == 0) {
                getdcard_topimage216560043190_collectioncontainerapp_productlistMobileView(response);
            }
            $('#display_loading').addClass('hideme');
        },
        error: function (error) {
            console.log(error);
        }
    })

}

function getdcard_topimage216560043190_collectioncontainerapp_productlistMobileView(response) {
    var html = '';
    $('#display_loading').removeClass('hideme')
    if (response.data.length == 0 && !$('.product_dcard').length) {
        html += '<div class="nodatafound">';
        html += '<img src="nodatafound.gif" width="100%">';
        html += '<br>';
        html += '<!-- span>No record found</span -->';
        html += '</div>';
        // $('#productListwrapper').html(html);
    } else {
        html = '';
        var radioGroups = [];
        if (!response.showShimmer) {
            skip = skip + response.data.length;
        }
        $.each(response.data, function (keyList, objList) {
            if (objList.type == 'parent') {
                $('#orderstatus').html(objList.status);
                $('#customername').html(objList.customerid_name);
                $('#customeremail').html(objList.email);
                $('#customerphone').html("+"+objList.contactnumber_dialcode + " " + objList.contactnumber);
                $('#callbtnlogistic').attr("href","tel:"+objList.logisticcontactnumber);
                $('#Chatbtnlogistic').attr("logistciID",objList.logisticid);
                $('#grandtotalamount').html("$" + objList.actualamount.toFixed(2));
                $('#orderinfowrapper').removeClass('hideme');
                if (objList.orderconfirmdate) {
                    const date = moment(objList.orderconfirmdate).format('DD MMM YYYY hh:mm:ss');
                    $('.timeline-item').eq(0).removeClass('hideme');
                    $('.timeline-item').eq(0).find('.statusdate').html(date);
                }
                if (objList.orderpreparingdate) {
                    const date = moment(objList.orderpreparingdate).format('DD MMM YYYY hh:mm:ss');
                    $('.timeline-item').eq(1).removeClass('hideme');
                    $('.timeline-item').eq(1).find('.statusdate').html(date);
                }
                if (objList.handovercourierdate) {
                    const date = moment(objList.handovercourierdate).format('DD MMM YYYY hh:mm:ss');
                    $('.timeline-item').eq(2).removeClass('hideme');
                    $('.timeline-item').eq(2).find('.statusdate').html(date);
                }
                if (objList.ordercompleteddate) {
                    const date = moment(objList.ordercompleteddate).format('DD MMM YYYY hh:mm:ss');
                    $('.timeline-item').eq(3).removeClass('hideme');
                    $('.timeline-item').eq(3).find('.statusdate').html(date);
                }

            }
            var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (0) {  // need to fix with native gyes.. images not getting download
                var mediaID = '';
                var fileName = '';
                // if (objList['imageupload'] && objList['imageupload'][0].mediaID) {
                //     P
                //     mediaID = objList['imageupload'][0].mediaID;
                //     fileName = objList['imageupload'][0].mediaID + '.png';
                // }
            } else {
                objList['totalcost'] = objList['totalcost'] ? objList['totalcost'].toFixed(2) : '';
                let totalcost = objList['totalcost'];
                objList['productid_name'] = objList['productid_name'] ? objList['productid_name'] : '';
                let productid_name = objList['productid_name'];

                objList['quentity'] = objList['quentity'] ? objList['quentity'] : '';
                let quantity = objList['quentity'];
                let imgUrl = '';
                if (objList.productid.productimage && objList.productid.productimage[0] && objList.productid.productimage[0].mediaID) {
                    imgUrl = CDN_PATH + objList.productid.productimage[0].mediaID + '_compressed.png';
                }
                html += '<div class="d-flex mb-4 product_dcard">';
                html += '   <div>';
                html += '       <img onerror="this.src =\'https://appscdn-us.hokuapps.com/card.png\'" src="' + imgUrl + '" class="rounded-m shadow-xl" width="100" height="85" style="object-fit:cover;">';
                html += '   </div>';
                html += '   <div class="ms-3 overflow-hidden">';
                html += '       <h4 class="text-capitalize text-truncate">' + productid_name + '</h4>';
                html += '       <h4 class="pt-1 color-highlight">$' + totalcost + '</h4>';
                html += '       <span class="color-theme font-12 text-capitalize">Quantity : ' + quantity + '</span>';
                html += '   </div>';
                html += '</div>';
            }
        });
        var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        $('#productListwrapper').html(html);
        $('#productListwrapper').removeClass('hideme');
        $('#timeline').removeClass('hideme');
        $('#display_loading').addClass('hideme');
    };
};
