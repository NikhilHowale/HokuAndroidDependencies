var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
let myDayChart = '';
var totaldcard_topimage216560043190_collectioncontainer = 0;
$(document).ready(function() {
    $('.page-content').css({
        'height': 'calc(100vh - 62px)',
        'overflow-y': 'scroll',
        'padding-bottom': '0px',
    });
    if ($('.view_list_record').length) {
        $('.view_list_record').show();
    }
    localStorage.removeItem('objParamsList');

    getGraphDataCall('today');
    $(document).on('click', '.filtergraphdata', function() {
        $('#display_loading').removeClass('hideme');
        let filterType = $(this).attr('data-type');
        getGraphDataCall(filterType);
    });
}); //end of ready 2


function getGraphDataCall(filterType) {
    let graphParams = {};
    graphParams.graphfiltertype = filterType;
    graphParams.queryMode = getParameterByName('queryMode');
    graphParams.tokenKey = getParameterByName('tokenKey');
    graphParams.secretKey = getParameterByName('secretKey');
    graphParams.rolename = localStorage.roleName;
    if (filterType == "today") {
        graphParams.fromdate = moment(new Date()).startOf("day").utc().format("YYYY-MM-DDTHH:mm:ssZ");
        graphParams.todate = moment(new Date()).endOf("day").utc().format("YYYY-MM-DDTHH:mm:ssZ");
    } else if (filterType == "yesterday") {
        graphParams.fromdate = moment(new Date()).startOf("day").subtract(1, "days").utc().format("YYYY-MM-DDTHH:mm:ssZ");
        graphParams.todate = moment(new Date()).endOf("day").subtract(1, "days").utc().format("YYYY-MM-DDTHH:mm:ssZ");
    } else if (filterType == "week") {
        graphParams.fromdate = moment(new Date()).startOf("week").utc().format("YYYY-MM-DDTHH:mm:ssZ");
        graphParams.todate = moment(new Date()).endOf("week").utc().format("YYYY-MM-DDTHH:mm:ssZ");
    } else if (filterType == "month") {
        graphParams.fromdate = moment(new Date()).startOf("month").utc().format("YYYY-MM-DDTHH:mm:ssZ");
        graphParams.todate = moment(new Date()).endOf("month").utc().format("YYYY-MM-DDTHH:mm:ssZ");
    }
    graphParams.ajaXCallURL = $.trim($('#ajaXCallURL').val());
    $.ajax({
        url: graphParams.ajaXCallURL + '/booksy/getAdminGraphData_ProductCheckoutList',
        data: graphParams,
        type: 'POST',
        success: function(response) {
            if (response.status != undefined && response.status == 0) {
                if (filterType == "today" || filterType == "yesterday") {
                    if(response.data.totalSum){
                        $('#totalrevenue').html("SGD $" + parseFloat(response.data.totalSum).toFixed(2));
                    }else{
                    $('#totalrevenue').html("SGD $" + parseFloat(response.data.totalSum).toFixed(2));
                    }
                    $('#numberoforders').html(response.data.count + " Orders");
                    drawDayChart(response.data);
                } else if (filterType == "week" || filterType == "month") {
                    if(response.totalWeekSum){
                        $('#totalrevenue').html("SGD $" + parseFloat(response.totalWeekSum).toFixed(2));
                    }else{
                        $('#totalrevenue').html("SGD $" + parseFloat(response.totalWeekSum).toFixed(2));
                    }
                    $('#numberoforders').html(response.totalWeekCount + " Orders");
                    drawWeekChart(response);
                }


                $('#display_loading').addClass('hideme');
            } else {
                $('#display_loading').addClass('hideme')
            }
        },
        error: function(xhr, status, error) {
            $('#display_loading').addClass('hideme')
            handleError(xhr, status, error);
        },
    });
}

function drawDayChart(data) {
    if (myDayChart) myDayChart.destroy();
    myDayChart = new Chart('chart', {
        type: 'bar',
        data: {
            labels: [data.filterType],
            datasets: [{
                data: [data.totalSum],
                backgroundColor: '#92a68a' //data.randomColor,
            }]
        },
        options: {
            plugins: {
                legend: {
                    display: false,
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            if (context.parsed.y !== null) {
                                label = 'S$ ' + (context.parsed.y);
                            }
                            return label;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                },
                x: {
                    grid: {
                        drawOnChartArea: false,
                    },
                    ticks: {
                        color: '#009E60',
                    }
                }
            }
        }
    })
}

function drawWeekChart(response) {
    if (myDayChart) myDayChart.destroy();
    myDayChart = new Chart('chart', {
        type: 'bar',
        data: {
            labels: response.weekLableData,
            datasets: [{
                data: response.data,
                backgroundColor: '#92a68a' //response.randomColor,
            }]
        },
        options: {
            plugins: {
                legend: {
                    display: false,
                },
                tooltip: {
                    callbacks: {
                        label: function(context) {
                            if (context.parsed.y !== null) {
                                label = 'S$ ' + (context.parsed.y);
                            }
                            return label;
                        }
                    }
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                },
                x: {
                    grid: {
                        drawOnChartArea: false,
                    },
                    ticks: {
                        color: '#009E60',
                    }
                }
            }
        }
    })
}
