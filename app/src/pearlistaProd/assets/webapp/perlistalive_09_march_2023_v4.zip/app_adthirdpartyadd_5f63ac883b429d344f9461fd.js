
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
var cpcCalculationRate = 16.67;
var impressionsCalculationRate = 666.67;

$(document).ready(function () {
    $('#full-body-container').css({ 'overflow-y': 'auto' })
    if ($('.view_list_record').length) { $('.view_list_record').show(); }
    localStorage.removeItem('objParamsList');
    if ($('.js-candlestick').length) $("input[type='checkbox']").candlestick({ 'on': 'Yes', 'off': 'No', 'nc': 'NA', 'default': 'NA', 'swipe': false, 'allowManualDefault': true });
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"))
    }

    // budget calculation
    $(document).on('change', '#budget14', function (e) {
        const budget = $.trim($('#budget14').val()); //$.trim($('#budget14').maskMoney('unmasked')[0]); 
        let impressions = parseInt(impressionsCalculationRate * budget);
        let cpc = parseInt(cpcCalculationRate * budget);
        $('#totalamount8').html('$' + parseFloat(budget).toFixed(2));
        // $('#impressionslabel').html(impressions + ' Impressions');
        $('#impressions14').attr('impressions', impressions);
        // $('#cpclabel').html(cpc + ' CPC');
        $('#cpc14').attr('cpc', cpc);
        $('#sgrow1566').html(`<span>${cpc}</span> CPC (Cost Per Clicks) OR <span>${impressions}</span> Impressions`);
    });

    // $(document).on('change', 'input[name="impressiontype"]', function (e) {
    //     if ($(this).val() === 'impressions') {
    //         $('#sgrowgroup116017237134_row').addClass('hide');
    //     } else if ($(this).val() === 'cpc') {
    //         $('#sgrowgroup116017237134_row').removeClass('hide');
    //     }
    // });

    // upload add photo
    $(document).on('click', '#thirdpartyadE0E2B93FA8014FC7AD9CA5E511E8E04Ccopy', function () {
        var mediaMeta = {};
        var obj = $(this);
        mediaMeta.canDelete = obj.attr('canDelete');
        mediaMeta.targetID = obj.attr('targetID') ? obj.attr('targetID') : obj.attr('id');
        mediaMeta.displayType = obj.attr('displayType');
        mediaMeta.fieldMappingID = obj.attr('fieldMappingID');
        mediaMeta.name = obj.attr('name');
        var allowType = obj.attr('allowType');
        var multiple = obj.attr('multiple') ? obj.attr('multiple') : 0;
        var tokenKey = getParameterByName('tokenKey');;
        var secretKey = getParameterByName('secretKey');;
        var queryMode = getParameterByName('queryMode');;
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());;
        arrEditMedia['imageupload'] = {};
        loadNativeimageFileUpload(tokenKey, queryMode, secretKey, ajaXCallURL, mediaMeta, allowType, multiple);;
    });//end of Event Image_is_click 

    // buy advertisement activity
    $(document).on('click', '#buyadvertisement14', function (e) {
        try {
            const objParams = {};
            const recordID = $(this).attr("recordID");
            const ajaXCallURL = $.trim($('#ajaXCallURL').val());
            objParams.isDelete = 0;
            objParams.tokenKey = getParameterByName('tokenKey');
            objParams.secretKey = getParameterByName('secretKey');
            objParams.offlineDataID = localStorage.getItem("offlineDataID");
            objParams.callUrl = ajaXCallURL + '/tangboewenv101/saveAjaxAdvertiseAdd5f63ac933b429d344f946b64storeapp_advertiseadd';

            objParams.status = "Pending";
            objParams.type = "advertisement";
            objParams.advertisementtype = "third party";

            
            if ($('#sampleimage11').attr('src') === 'ad_sample.svg') {
                $('#imageupload14_error').show();
                return false;
            } else {
                $('#imageupload14_error').hide();
            }

            const tags = $('#tagsselect12').val();
            if (tags) {
                objParams.tagsid = tags;
            }

            const genres = $('#generessselect12').val();
            if (genres) {
                objParams.genresid = genres;
            }

            const budget = $.trim($('#budget14').val()); //$.trim($('#budget14').maskMoney('unmasked')[0]);
            if (!budget) {
                $('#budget14_error').show();
                return false;
            } else {
                objParams.budgetcost = budget;
                objParams.totalamount = budget;
                $('#budget14_error').hide();
            }

            const budgettype = $.trim($('input[name=impressiontype]:checked').val());
            if (!budgettype) {
                $('#impressiontype12_error').show();
                return false;
            } else if (budgettype == 'impressions') {
                objParams.impressions = $('input[name=impressiontype]:checked').attr('impressions');
                objParams.remainingimpressions = objParams.impressions;
                $('#impressiontype12_error').hide();
            } else if (budgettype == 'cpc') {
                objParams.cpc = $('input[name=impressiontype]:checked').attr('cpc');
                objParams.remainingcpc = objParams.cpc;
                $('#impressiontype12_error').hide();
            }

            objParams.budgettype = budgettype;

            const adurl = $('#advertisementurl14').val();
            if ($('#advertisementurl14_div').is(':visible')) {
                if (adurl == '' && budgettype == 'cpc') {
                    $('#advertisementurl14_error').html('Ad URL is required').show();
                    return false;
                } else {
                    let validUrl = checkValidUrl(adurl);
                    if (validUrl) {
                        objParams.adurl = adurl;
                        $('#advertisementurl14_error').hide();
                    } else if (budgettype == 'cpc') {
                        $('#advertisementurl14_error').html('Please enter valid Ad URL').show();
                        return false;
                    }
                }
            }

            $('#display_loading').removeClass('hideme');
            $('#buyadvertisement14').prop('disabled', true);
            objParams.ajaXCallURL = $("#ajaXCallURL").val();
            // objParams.organizationID = $("#organizationID").val();
            processBeforeCallForSaveappnewrelease2details5f63ac933b429d344f946b64bazaarlikescomments(objParams, {}, function (processBeforeRes) {
                localStorage.setItem('objParamsData', JSON.stringify(objParams));
                sendOfflineusermanagementthirdpartyadD37D2D59EA994A4599B0DF4368FF5FDEcopyMediaDetails(objParams.tokenKey, queryMode, objParams.secretKey, ajaXCallURL, objParams, objParams.callUrl);

                // $.ajax({
                //     url: objParams.callUrl,
                //     data: objParams,
                //     type: 'POST',
                //     success: function (response) {
                //         if (response.status == 0) {  //22
                //             $('#display_loading').addClass('hideme');
                //             const nextPage = 'app_advertisementlisting';
                //             const queryParams = queryStringToJSON();
                //             queryParams.queryMode = "mylist";
                //             localStorage.removeItem("appbackpage");
                //             if (document.referrer && document.referrer.split('_')[1]) { localStorage.setItem('applastbackpage', 'app_' + document.referrer.split('_')[1]); }
                //             let queryString = $.param(queryParams);
                //             queryString = queryString.replace(/\+/g, "%20");
                //             queryString = decodeURIComponent(queryString);
                //             localStorage.setItem("appbackpage", "app_book2edit");
                //             window.location.href = nextPage + '_5f63ac883b429d344f9461fd.html?' + queryString;
                //             return false;
                //         } else {
                //             $('#display_loading').addClass('hideme');
                //         }
                //         $('#buyadvertisement14').removeProp('disabled');
                //     },
                //     error: function (xhr, status, error) {
                //         $('#display_loading').addClass('hideme');
                //         $('#buyadvertisement14').removeProp('disabled');
                //     },
                // });
                return false;
            }); // End of Before Process
        } catch (error) {
            console.log("Error in pageredirect workflow - add advertisement", error);
        }
    }); // end buy advertisement event

    $(document).on('click', '#backbutton1', function (e) {
        try {
            const element = $(this);
            element.addClass('csspointer');
            const nextPage = 'app_storedetails';
            const queryParams = queryStringToJSON();
            queryParams.queryMode = "mylist";
            localStorage.removeItem("appbackpage");
            if (document.referrer && document.referrer.split('_')[1]) { localStorage.setItem('applastbackpage', 'app_' + document.referrer.split('_')[1]); }
            let queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            localStorage.setItem("appbackpage", "app_book2edit");
            window.location.href = nextPage + '_5f63ac883b429d344f9461fd.html?' + queryString;
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - backbutton1", error)
        }
    });

    var paramsType = {};
    getTags(paramsType);

    var paramsType = {};
    getGenres(paramsType);
});//end of ready
function getParams(url) {
    var urlParams = {};
    url.replace(
        new RegExp("([^?=&]+)(=([^&]*))?", "g"),
        function ($0, $1, $2, $3) {
            if ($3 && $3 != 'undefined') urlParams[$1] = $3;
        }
    );
    return urlParams;
}

function processBeforeCallForSaveappnewrelease2details5f63ac933b429d344f946b64bazaarlikescomments(objParams, response, callback) {
    callback();
}

/**
 * get tags
 * @param {object} paramsType 
 */
function getTags(paramsType) {
    const ajaXCallURL = $.trim($('#ajaXCallURL').val());
    paramsType.tokenKey = getParameterByName('tokenKey');
    paramsType.secretKey = getParameterByName('secretKey');
    $.ajax({
        url: ajaXCallURL + '/tangboewenv101/getfromothertable_app_book2edit_tags_5f63ac883b429d344f9461fd_Tags',
        data: paramsType,
        type: 'POST',
        success: function (response) {
            if (response.status == 0) {
                let selectOptionHtml = '<option disabled value="">Select</option>';
                $.each(response.data, function (keyList, objList) {
                    selectOptionHtml += '<option  value="' + objList._id + '">' + objList.tagname + '</option>';
                });
                $('#tagsselect12').html(selectOptionHtml);
                $('#tagsselect12').material_select();
            }
        },
        error: function (xhr, status, error) {

        },
    });
}

/**
 * get genres
 * @param {object} paramsType 
 */
function getGenres(paramsType) {
    const ajaXCallURL = $.trim($('#ajaXCallURL').val());
    paramsType.tokenKey = getParameterByName('tokenKey');
    paramsType.secretKey = getParameterByName('secretKey');
    $.ajax({
        url: ajaXCallURL + '/tangboewenv101/getfromothertable_app_book2edit_genres_5f63ac883b429d344f9461fd_Genres',
        data: paramsType,
        type: 'POST',
        success: function (response) {
            if (response.status == 0) {
                let selectOptionHtml = '<option disabled value="">Select</option>';
                $.each(response.data, function (keyList, objList) {
                    selectOptionHtml += '<option  value="' + objList._id + '">' + objList.genresname + '</option>';
                });
                $('#generessselect12').html(selectOptionHtml);
                $('#generessselect12').material_select();
            }
        },
        error: function (xhr, status, error) {

        },
    });
}


function loadNativeimageFileUpload(tokenKey, queryMode, secretKey, ajaXCallURL, mediaMeta, allowType, multiple) {
    var appJSON = {};
    appJSON.tokenKey = tokenKey;
    appJSON.secretKey = secretKey;
    appJSON.queryMode = queryMode;
    appJSON.action = queryMode;
    appJSON.mediaMeta = mediaMeta;
    appJSON.isFileFormat = true;
    appJSON.fileMimeType = allowType;
    appJSON.step = count++;
    appJSON.multiple = multiple;
    appJSON.ajaXCallURL = ajaXCallURL;
    appJSON.organizationID = $("#organizationID").val();
    appJSON.userID = $("#userID").val();
    appJSON.appID = $("#appID").val();
    appJSON.callbackFunction = "setNativeimageUploadedFiles";
    appJSON.offlineDataID = offlineDataID;
    if (DEVICE_TYPE == "ios") {
        bridgeObj.callHandler("LoadNativeFileUpload", appJSON, function (response) {
        });
        bridgeObj.registerHandler("setNativeimageUploadedFiles", function (responseData, responseCallback) {
            setNativeimageUploadedFiles(responseData);
        });
    } else {
        window.Android.LoadNativeFileUpload(JSON.stringify(appJSON));
    }
}

function setNativeimageUploadedFiles(responseData) {
    try {
        var fileName = responseData.fileName;
        if (responseData.dataDictionary) {
            responseData = responseData.dataDictionary;
            responseData.fileName = fileName;
        }
        var mediaMeta = responseData.mediaMeta;
        mediaMeta.fileName = responseData.fileName;
        mediaMeta.multiple = responseData.multiple;
        var fileNameCleaned = responseData.fileName.replace(/[^a-z0-9s]/gi, "").replace(/[_s]/g, "-");
        arrAllMedia[fileNameCleaned] = mediaMeta;

        // var parent = $('#thirdpartyadE0E2B93FA8014FC7AD9CA5E511E8E04Ccopy');
        // var html = '<img class="uploadthumb" src="' + getuploadedfilepreview(responseData.fileName) + '" />';
        // parent.html(html);

        $('#sampleimage11').attr('src', getuploadedfilepreview(responseData.fileName));

        const adWidth = $('#sgcol3035').width();
        const adHeight = 0.4 * adWidth;
        $('#sgcol3035').find('img').css('height', adHeight);
    } catch (err) {
        // console.log('Error in setNativeUploadedFiles', err); 
    }
}

function sendOfflineusermanagementthirdpartyadD37D2D59EA994A4599B0DF4368FF5FDEcopyMediaDetails(tokenKey, queryMode, secretKey, ajaXCallURL, objParams, callUrl) {
    try {
        var appJSON = {};
        appJSON.tokenKey = tokenKey;
        appJSON.secretKey = secretKey;
        appJSON.queryMode = queryMode;
        appJSON.ajaXCallURL = ajaXCallURL;
        appJSON.callUrl = callUrl;
        appJSON.pageTitle = '';
        appJSON.nextButtonTitle = '';
        appJSON.nextRedirectionURL = "";
        appJSON.nextButtonCallback = 'saveusermanagementthirdpartyadD37D2D59EA994A4599B0DF4368FF5FDEcopy';
        appJSON.isReadOnly = false;
        appJSON.offlineDataID = offlineDataID;
        if (window.location.protocol == 'https:') {
            var responseData = {};
            responseData.dataDictionary = appJSON;
            responseData.appMediaArrayForUploadArray = webUploadArray;
            saveusermanagementthirdpartyadD37D2D59EA994A4599B0DF4368FF5FDEcopy(responseData)
        } else {
            if (DEVICE_TYPE == 'ios') {
                bridgeObj.callHandler('sendOfflineMediaDetails', appJSON, function (response) {
                });
                bridgeObj.registerHandler('saveusermanagementthirdpartyadD37D2D59EA994A4599B0DF4368FF5FDEcopy', function (responseData, responseCallback) {
                    saveusermanagementthirdpartyadD37D2D59EA994A4599B0DF4368FF5FDEcopy(responseData);
                });
            } else {
                window.Android.sendOfflineMediaDetails(JSON.stringify(appJSON));
            }
        }
    } catch (err) {
        // console.log('Error in sendOffline', err) 
    }
}
function saveusermanagementthirdpartyadD37D2D59EA994A4599B0DF4368FF5FDEcopy(responseData) {
    try {
        var objParams = JSON.parse(localStorage.getItem('objParamsData'));
        objParams.isValid = 1;
        if (responseData) {
            if (responseData.appMediaArrayForUploadArray) {
                for (var iFileCount = 0; iFileCount < responseData.appMediaArrayForUploadArray.length; iFileCount++) {
                    var objUploadedFile = responseData.appMediaArrayForUploadArray[iFileCount];
                    if (objUploadedFile) {
                        var fileNameCleaned = objUploadedFile.fileNm.replace(/[^a-z0-9s]/gi, "").replace(/[_s]/g, "-");
                        var mediaMeta = {};
                        if (fileNameCleaned && typeof (arrAllMedia[fileNameCleaned]) != 'undefined') {
                            mediaMeta = arrAllMedia[fileNameCleaned]
                        }
                        mediaMeta.mediaID = objUploadedFile.mediaID;
                        mediaMeta.fileNm = objUploadedFile.fileNm;
                        mediaMeta.S3FilePath = objUploadedFile.S3FilePath;
                        var name = mediaMeta.name;
                        var targetID = '';
                        if (mediaMeta && mediaMeta.fieldMappingID && mediaMeta.targetID) {
                            targetID = mediaMeta.fieldMappingID ? mediaMeta.fieldMappingID : mediaMeta.targetID.replace(/[0-9]/g, "");
                        }
                        if (arrEditMedia[targetID] && !objParams[targetID]) {
                            objParams[targetID] = [];
                            for (var key in arrEditMedia[targetID]) {
                                objParams[targetID].push(arrEditMedia[targetID][key]);
                            }
                        } else if (!objParams[targetID]) {
                            objParams[targetID] = [];
                        }
                        getFindings(targetID, objParams, mediaMeta, true)
                        objParams[targetID].push(mediaMeta);
                    }
                }
            }
            if (objParams['imageupload'] && !objParams['imageupload'].length) {
                delete objParams['imageupload'];
            }
            if (objParams.isValid) {
                $.ajax({
                    url: objParams.callUrl,
                    data: objParams,
                    type: 'POST',
                    success: function (response) {
                        if (response.status == 0) {
                            $('#display_loading').addClass('hideme');
                            var tokenKey = getParameterByName('tokenKey');
                            var secretKey = getParameterByName('secretKey');
                            var queryMode = getParameterByName('queryMode');
                            response.nextPage = 'app_adpaymentdetails'
                            var tokenKey = getParameterByName('tokenKey');
                            var secretKey = getParameterByName('secretKey');
                            localStorage.setItem("headerPageName", 'app_adpaymentdetails');
                            var queryString = window.location.search.slice(1);
                            var newQuery = queryString + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&queryMode=add' + '&ordersid=' + response.data._id + '&recordID=' + response.data._id + '&paymentMethod=Paypal'
                            var queryParams = queryStringToJSON(newQuery);
                            queryString = $.param(queryParams);
                            queryString = queryString.replace(/\+/g, "%20");
                            queryString = decodeURIComponent(queryString);
                            if (response.data && response.data['imageupload']) {
                                var profilethumb = response.data['imageupload'][0];
                                var mediaID = profilethumb.mediaID;
                                var targateuserid = response.data._id;
                                var name = '';

                                // var xmlhttp;
                                // if (window.XMLHttpRequest) { // code for IE7+, Firefox, Chrome, Opera, Safari     
                                //     xmlhttp = new XMLHttpRequest();
                                // } else { // code for IE6, IE5        
                                //     xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');
                                // }
                                // xmlhttp.onreadystatechange = function () {
                                //     if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                                $('#display_loading').addClass('hideme');
                                makePaymentTransaction(response.data._id);
                                // window.location.href = response.nextPage + '_5f63ac883b429d344f9461fd.html?' + queryString;
                                return false;
                                //     }
                                // }
                                // xmlhttp.open('POST', 'https://devfiles.' + $('#domainName').val() + '.com/upthumb', true);
                                // xmlhttp.setRequestHeader('HTTP_X_REQUESTED_WITH', 'XMLHttpRequest');
                                // xmlhttp.setRequestHeader('apptoken', tokenKey);
                                // xmlhttp.setRequestHeader('mediaid', mediaID);
                                // xmlhttp.setRequestHeader('targateuserid', targateuserid);
                                // xmlhttp.setRequestHeader('name', name);
                                // xmlhttp.send();
                            } else {
                                // window.location.href = response.nextPage + '_5f63ac883b429d344f9461fd.html?' + queryString;
                                makePaymentTransaction(response.data._id);
                            }
                            return false;
                        } else {
                            $('#display_loading').addClass('hideme');
                            $('#buyadvertisement14').show();
                        }
                    },
                    error: function (xhr, status, error) {
                        $('#display_loading').addClass('hideme');
                        $('#buyadvertisement14').removeProp('disabled');
                    },
                });

            } else {
                $('#display_loading').addClass('hideme');
                $('#buyadvertisement14').removeProp('disabled');
            }
        } else {
            $('#display_loading').addClass('hideme');
            $('#buyadvertisement14').removeProp('disabled');
        }
    } catch (err) {
        $('#buyadvertisement14').removeProp('disabled');
    }
}

function makePaymentTransaction(recordID) {
    $('#display_loading').removeClass('hideme'); //111333
    var objParams = {};
    var browserUrl = window.location.href;
    if (browserUrl.endsWith('#!')) { browserUrl = browserUrl.slice(0, -2); }
    if (browserUrl.endsWith('#')) { browserUrl = browserUrl.slice(0, -1); }
    var tempobjParams = getParams(browserUrl);
    objParams = extend(objParams, tempobjParams);
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParams.tokenKey = getParameterByName('tokenKey');
    objParams.secretKey = getParameterByName('secretKey');
    objParams.offlineDataID = localStorage.getItem("offlineDataID");
    objParams.recordID = recordID;
    objParams.paymentmethod = 'paypal';
    objParams.callUrl = ajaXCallURL + '/tangboewenv101/updateAjaxordersstorepurchase5f63ac933b429d344f946b64orderstorepurchase';

    $('#newrelease2detailsFAD5B160D85A49259E33C5C96E8F01DBcopy').prop('disabled', true);
    $('#display_loading').removeClass('hideme');
    objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    // objParams.organizationID = $("#organizationID").val();;
    processBeforeCallForSavestorepurchase5f63ac933b429d344f946b64order(objParams, function (processBeforeRes) {
        $.ajax({
            url: objParams.callUrl,
            data: objParams,
            type: 'POST',
            success: function (response) {
                if (response.status == 0) {
                    var paymentMethod = "paypal"; //getParameterByName('paymentMethod');
                    if (paymentMethod != "" && paymentMethod != null) {
                        switch (paymentMethod.toLowerCase()) {
                            case "credit or debit card":
                                var appJSON = {};
                                appJSON.successPage = 'app_paymentsuccessthankyou_5f63ac883b429d344f9461fd.html';
                                appJSON.failurePage = 'failpayment_5f63ac883b429d344f9461fd.html';
                                appJSON.extraparams = 'recordID=' + response.data._id;
                                var ios = navigator.userAgent.toLowerCase().indexOf("ios");
                                var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
                                if (DEVICE_TYPE == 'ios') {
                                    bridgeObj.callHandler('setRedirectPagesforExternal', appJSON, function (response) {
                                    });
                                } else {
                                    window.Android.setRedirectPagesforExternal(JSON.stringify(appJSON));
                                }
                                var ajaXCallURL = $('#ajaXCallURL').val();
                                var appurl = "https://astroireapp.hokuapps.com/";
                                window.location.href = appurl + '/payment/5f63ac883b429d344f9461fd/ocbc.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&recordIDSession=' + getParameterByName("recordID") + '&secretKey=' + secretKey + '&totalamount=' + response.data.totalamount + '&queryMode=mylist' + '&ordersid=' + response.data._id + '&recordID=' + response.data._id + '&transactionID=' + response.data._id
                                break;
                            case "paypal":
                                var appJSON = {};
                                appJSON.successPage = 'app_paymentsuccessthankyou_5f63ac883b429d344f9461fd.html';
                                appJSON.failurePage = 'failpayment_5f63ac883b429d344f9461fd.html';
                                appJSON.extraparams = 'recordID=' + response.data._id;
                                var AWSCredentials = localStorage.getItem("AWSCredentials");
                                if (localStorage.IDENTITY_TOKEN) {
                                    var token = localStorage.IDENTITY_TOKEN;
                                    var playload = JSON.parse(atob(token.split(".")[1]));
                                    appJSON.Authorization = token;
                                    appJSON.Expiration = playload.exp;
                                } else if (AWSCredentials) {
                                    AWSCredentials = JSON.parse(AWSCredentials);
                                    appJSON.accessKeyId = AWSCredentials.accessKeyId;
                                    appJSON.secretAccessKey = AWSCredentials.secretAccessKey;
                                    appJSON.sessionToken = AWSCredentials.sessionToken;
                                    appJSON.Expiration = AWSCredentials.Expiration;
                                }
                                var tokenKey = getParameterByName('tokenKey');
                                var secretKey = getParameterByName('secretKey');
                                var queryMode = getParameterByName('queryMode');
                                var recordID = getParameterByName('recordID');
                                var ios = navigator.userAgent.toLowerCase().indexOf("ios");
                                var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
                                if (DEVICE_TYPE == 'ios') {
                                    bridgeObj.callHandler('setRedirectPagesforExternal', appJSON, function (response) {
                                    });
                                } else {
                                    window.Android.setRedirectPagesforExternal(JSON.stringify(appJSON));
                                }
                                var ajaXCallURL = $('#ajaXCallURL').val();
                                var appurl = "https://astroireapp.hokuapps.com/";
                                IDENTITY_TOKEN = localStorage.IDENTITY_TOKEN;
                                window.location.href = appurl + '/payment/5f63ac883b429d344f9461fd/payment.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&totalamount=' + response.data.totalamount + '&queryMode=mylist' + '&ordersid=' + response.data._id + '&recordID=' + response.data._id + '&transactionID=' + response.data._id + '&authorization=' + IDENTITY_TOKEN;
                                break;
                            case "senangpay":
                                var appJSON = {};
                                appJSON.successPage = 'app_paymentsuccessthankyou_5f63ac883b429d344f9461fd.html';
                                appJSON.failurePage = 'failpayment_5f63ac883b429d344f9461fd.html';
                                appJSON.extraparams = 'recordID=' + response.data._id;
                                var ios = navigator.userAgent.toLowerCase().indexOf("ios");
                                var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
                                if (DEVICE_TYPE == 'ios') {
                                    bridgeObj.callHandler('setRedirectPagesforExternal', appJSON, function (response) {
                                    });
                                } else {
                                    window.Android.setRedirectPagesforExternal(JSON.stringify(appJSON));
                                }
                                var ajaXCallURL = $('#ajaXCallURL').val();
                                var appurl = "https://astroireapp.hokuapps.com/";
                                var paymentUrl = appurl + '/payment/5f63ac883b429d344f9461fd/senangpay.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&totalamount=' + response.data.totalamount + '&queryMode=mylist' + '&ordersid=' + response.data._id + '&recordID=' + response.data._id
                                paymentUrl += '&transactionID=' + response.data._id
                                paymentUrl += '&paymentMethod=senangpay'
                                var appUser = localStorage.getItem('appUser');
                                if (appUser) {
                                    appUser = JSON.parse(appUser);
                                    if (appUser.name) {
                                        paymentUrl += '&name=' + appUser.name
                                    }
                                    if (appUser.contactnumber) {
                                        paymentUrl += '&phone=' + appUser.contactnumber
                                    }
                                    if (appUser.email) {
                                        paymentUrl += '&email=' + appUser.email
                                    }
                                }
                                window.location.href = paymentUrl
                                break;
                            case "stripe":
                                break;
                        }
                    } else {
                        var objParams = {};
                        objParams.transactionID = response.data._id;
                        objParams.recordID = response.data._id;
                        objParams.paymentdate = new Date();
                        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                        objParams.tokenKey = getParameterByName('tokenKey');
                        objParams.secretKey = getParameterByName('secretKey');
                        var recordID = objParams.transactionID;// get record ID;
                        var ordersid = recordID;// get record ID;
                        var tokenKey = getParameterByName('tokenKey');
                        var secretKey = getParameterByName('secretKey');
                        var queryMode = 'details';
                        var callUrl = ajaXCallURL + '/vohnkohnapp4/save_payment_Payments5f63ac883b429d344f9461fd';
                        IDENTITY_TOKEN = getParameterByName('authorization');
                        $.ajax({
                            url: callUrl,
                            data: objParams,
                            type: 'POST',
                            beforeSend: function (request) {
                                request.setRequestHeader("Authorization", IDENTITY_TOKEN);
                            },
                            success: function (response) {
                                if (response.status == 0) {
                                    var nextPage = 'app_paymentsuccessthankyou';
                                    var pageurl = nextPage + '_5f63ac883b429d344f9461fd.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&ordersid=' + ordersid + '&recordID=' + recordID + '&applyFilter=true';
                                    window.location.href = pageurl;
                                    return false;
                                } else {
                                    var nextPage = 'paypalfailure.html';
                                    var pageurl = nextPage + '_5f63ac883b429d344f9461fd.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&ordersid=' + ordersid + '&recordID=' + recordID + '&applyFilter=true';
                                    window.location.href = pageurl;
                                    return false;
                                }
                            },
                            error: function (xhr, status, error) {
                                var nextPage = 'paypalfailure.html';
                                var pageurl = nextPage + '_5f63ac883b429d344f9461fd.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&ordersid=' + ordersid + '&recordID=' + recordID + '&applyFilter=true';
                                window.location.href = pageurl;
                                return false;
                            },
                        });
                    }
                } else {
                }
            },
            error: function (xhr, status, error) {
                $('#display_loading').addClass('hideme');
            },
        });
        return false;
    }); // End of Before Process
}

function processBeforeCallForSavestorepurchase5f63ac933b429d344f946b64order(objParams, callback) {
    callback();
}

function extend(obj, src) {
    for (var key in src) {
        if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
    }
    return obj;
}