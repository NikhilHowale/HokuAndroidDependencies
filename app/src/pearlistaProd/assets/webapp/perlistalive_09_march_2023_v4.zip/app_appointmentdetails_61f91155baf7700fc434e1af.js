
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
let serviceTotalAmount = 0;
let gstAmount = 0;
let discountAmount = 0;
let grandtotal = 0;
let paidAmount = 0;
let balanceAmount = 0;
$(document).ready(function () {
    $('.page-content').css({
        'height': 'calc(100vh - 62px)',
        'overflow-y': 'scroll',
        'padding-bottom': '0px',
    });
    $('#display_loading').removeClass('hideme');
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    let objParamsList = {};
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    getAppointmentsDetails(objParamsList);
    getCheckoutProductList(objParamsList);
    let paramsType = {};
    paramsType.tokenKey = tokenKey;
    paramsType.secretKey = secretKey;
    paramsType.ajaXCallURL = ajaXCallURL;
    getProductcheckoutList(paramsType);
    getPaymentDetails(paramsType);



    // start sg 

    $(document).on('click', '#deleteappoinmentbtn', function () {
        var recordID = getParameterByName('appointmentid');
        $('#deleteappoinment').val(recordID);
        $('#DialogIconDeleteUser').modal('open');
        return false;
    }); // to add New record

    $(document).on('click', '#deleteappoinment', function () {
        $('#display_loading').removeClass('hideme');
        var recordID = $('#deleteappoinment').val();
        var paramsDelete = {};
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        paramsDelete.recordID = recordID;
        // paramsDelete.isDelete = 1;
        paramsDelete.status = "Cancelled";
        var currTime = moment(new Date()).format('h:mm A');
        paramsDelete.time = currTime;
        paramsDelete.tokenKey = getParameterByName('tokenKey')
        paramsDelete.secretKey = getParameterByName('secretKey')
        // paramsDelete.queryMode = 'adminlist';
        var callUrl = ajaXCallURL + '/booksy/updateAjaxappointmentappointmentschedularweb';

        $.ajax({
            url: callUrl,
            data: paramsDelete,
            type: 'POST',
            success: function (response) {
                if (response.status == 0) {
                    var tokenKey = $('#tokenKey').val();
                    var objParamsList = {};
                    objParamsList.queryMode = queryMode;
                    objParamsList.tokenKey = tokenKey;
                    objParamsList.isMobile = isMobile;
                    $('#display_loading').addClass('hideme');
                    $('#deleteappoinment').val('');
                    // $('#DialogIconDeleteUser').modal('close');
                    var nextPage = 'app_appointmentorders';
                    var queryParams = queryStringToJSON();
                    if (queryMode) queryParams['queryMode'] = queryMode;
                    var queryString = $.param(queryParams);
                    queryString = queryString.replace(/\+/g, "%20");
                    queryString = decodeURIComponent(queryString);
                    var tokenKey = getParameterByName('tokenKey');
                    var secretKey = getParameterByName('secretKey');
                    var queryMode = getParameterByName('queryMode');
                    var pageurl = nextPage + "_61f91155baf7700fc434e1af.html?queryMode=" + queryMode + "&tokenKey=" + tokenKey + "&secretKey=" + secretKey;
                    window.location.href = pageurl;
                } else {
                }
            },
            
            error: function (xhr, status, error) {

            },
        });


        return false;
    }); // to add New record

    // end sg









});//end of ready 2

function getCheckoutProductList(objParamsList) {
    objParamsList.recordID = getParameterByName('appointmentid');
    objParamsList.isExternalBooking = 1;
    objParamsList.skip = skip;
    objParamsList.fetch = fetchRecord;
    $('#display_loading').removeClass('hideme');
    $.ajax({
        url: objParamsList.ajaXCallURL + '/booksy/get_data_by_record_Appointment61f91155baf7700fc434e1afappointmentsearchlistweb',
        type: "POST",
        data: objParamsList,
        success: function (response) {
            if (response.status == 0) {
                getdcard_topimage216560043190_collectioncontainerapp_productlistMobileView(response);
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

function getdcard_topimage216560043190_collectioncontainerapp_productlistMobileView(response) {
    var html = '';
    $('#display_loading').removeClass('hideme');
    if (response.recordDetails.length == 0) {
        // html += '<div class="nodatafound">';
        // html += '<img src="nodatafound.gif" width="100%">';
        // html += '<br>';
        // // html += '<!-- span>No record found</span -->';
        // html += '</div>';
        // $('#').html(html);
    } else {
        html = '';
        var radioGroups = [];
        if (!response.showShimmer) {
            skip = skip + response.recordDetails.length;
        }
        $.each(response.recordDetails, function (keyList, objList) {
            $('#customername').html(objList.clientid_name);
            $('#appointmentstatus').html(objList.status);
            $('#customerstaff').html(objList.staffid_name);
            $('#customerdate').html(moment(objList.date).format('DD MMM, YYYY'));
            $('#customerduration').html(objList.duration);
            $('#grandtotalamount').html("$" + objList.price.toFixed(2));
            $('#appointmentdetailscard').removeClass('hideme');
            $('#display_loading').addClass('hideme');
            var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (0) {  // need to fix with native gyes.. images not getting download
                var mediaID = '';
                var fileName = '';
                // if (objList['imageupload'] && objList['imageupload'][0].mediaID) {
                //     P
                //     mediaID = objList['imageupload'][0].mediaID;
                //     fileName = objList['imageupload'][0].mediaID + '.png';
                // }
            } else {
                objList['totalcost'] = objList['totalcost'] ? objList['totalcost'] : '';
                let totalcost = objList['totalcost'];
                objList['productid_name'] = objList['productid_name'] ? objList['productid_name'] : '';
                let productid_name = objList['productid_name'];
                html += '<div class="row">';
                html += '   <div class="col-5 pe-0">';
                html += '       <div class="card m-0 card-style" style="height: 100px;" data-card-height="100">';
                html += '            <div class="card-bottom px-2">';
                html += '            </div>';
                html += '            <div class="card-overlay bg-gradient opacity-80"></div>';
                html += '        </div>';
                html += '    </div>';
                html += '    <div class="col-7">';
                html += '        <h1 class="line-height-l font-20">' + productid_name + '</h1>';
                html += '<h1 class="color-highlight font-20">$' + totalcost + '</h1>';
                html += '        <p class="line-height-s mt-2"></p>';
                html += '   </div >';
                html += '</div >';
            }
        });
        var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        $('#productListwrapper').html(html)
        $('#display_loading').addClass('hideme');
    };
};

function getdcard_services_collectioncontainerapp_servicesList(response) {
    var html = '';
    $('#display_loading').removeClass('hideme');
    if (response.data.length == 0 && !$('.service_dcard').length) {
        // html += '<div class="card card-style bg-secondary animated swing">';
        // html += '    <div class="content">';
        // // html += '        <h2 class="text-center color-white my-4">No record Found!</h2>';
        // html += '    </div>';
        // html += '</div>';
        $('#servicestrip').removeClass('hideme');
        $('#appointmentservicesdiv').html(html);
        $('#display_loading').addClass('hideme');
    } else {
        html = '';
        var radioGroups = [];
        if (!response.showShimmer) {
            skip = skip + response.data.length;
        }
        $.each(response.data, function (keyList, objList) {
            serviceTotalAmount += objList['totalcost'];
            gstAmount += objList['gst'];
            discountAmount += objList['discount'];
            var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (0) {  // need to fix with native gyes.. images not getting download
                var mediaID = '';
                var fileName = '';
                // if (objList['imageupload'] && objList['imageupload'][0].mediaID) {
                //     P
                //     mediaID = objList['imageupload'][0].mediaID;
                //     fileName = objList['imageupload'][0].mediaID + '.png';
                // }
            } else {

                objList['ordercost'] = objList['ordercost'] ? objList['ordercost'] : 0;
                let ordercost = objList['ordercost'].toFixed(2);

                objList['serviceid_name'] = objList['serviceid_name'] ? objList['serviceid_name'] : '';
                let serviceid_name = objList['serviceid_name'];

                objList['qty'] = objList['qty'] ? objList['qty'] : '0';
                let qty = objList['qty'];

                objList['gst'] = objList['gst'] ? objList['gst'] : 0;
                let gst = objList['gst'].toFixed(2);

                objList['discount'] = objList['discount'] ? objList['discount'] : 0;
                let discount = objList['discount'].toFixed(2);

                objList['actualcost'] = objList['actualcost'] ? objList['actualcost'] : '0';
                let actualcost = objList['actualcost'];

                html += '<div class="card card-style service_dcard mb-3">'
                html += '    <div class="content" id="">'
                html += '        <div class="row mb-0">'
                html += '            <div class="col-12">'
                html += '                <h2 class="line-height-l text-capitalize"> ' + serviceid_name + '</h2>'
                html += '                <div>Amount : <span class="text-black">$' + actualcost + '</span></div>'
                html += '                <div>Quantity : <span class="text-black">' + qty + '</span></div>'
                html += '                <div>GST : <span class="text-black">$' + gst + '</span></div>'
                html += '                <div>Discount : <span class="text-black">$' + discount + '</span></div>'
                html += '                <div>Total Amount : <span class="text-black">$' + ordercost + '</span></div>'
                html += '            </div>'
                html += '        </div>'
                html += '    </div>'
                html += '</div>'
            }
        });

        var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        $('#appointmentservicesdiv').html(html);
        $('#servicestrip').removeClass('hideme');
        $('#display_loading').addClass('hideme');
    };
}

function getProductcheckoutList(objParamsList) {
    // objParamsList.userId = localStorage.userID;
    objParamsList.appointmentnumber = getParameterByName('appointmentid');
    const url = objParamsList.ajaXCallURL + '/booksy/getProductCheckoutListDetails_61f91155baf7700fc434e1afCustom';
    $.ajax({
        url,
        type: 'POST',
        data: objParamsList,
        success: function (response) {
            if (response.status == 0) {
                show_productlistdcardMobileView(response);
            }
        },
        error: function (error) {

        }
    });
}


function show_productlistdcardMobileView(response) {
    $('#display_loading').removeClass('hideme');
    var html = '';
    if (response.data.length == 0 && !$('.product_dcard').length) {
        // html += '<div class="card card-style bg-secondary animated swing">';
        // html += '    <div class="content">';
        // // html += '        <h2 class="text-center color-white my-4">No record Found!</h2>';
        // html += '    </div>';
        // html += '</div>';
        $('#productsstrip').removeClass('hideme');
        $('#productlistcontainer').html(html);
        $('#display_loading').addClass('hideme');
    } else {
        html = '';
        var radioGroups = [];
        if (!response.showShimmer) {
            skip = skip + response.data.length;
        }
        $.each(response.data, function (keyList, objList) {
            serviceTotalAmount += objList['totalcost'];
            gstAmount += objList['gst'];
            discountAmount += objList['discount'];
            objList['totalcost'] = objList['totalcost'] ? objList['totalcost'].toFixed(2) : '';
            let totalcost = objList['totalcost'];
            objList['productid_name'] = objList['productid_name'] ? objList['productid_name'] : '';
            let productid_name = objList['productid_name'];

            objList['quentity'] = objList['quentity'] ? objList['quentity'] : '';
            let quantity = objList['quentity'];
            let imgUrl = '';
            if (objList.productid.productimage && objList.productid.productimage[0] && objList.productid.productimage[0].mediaID) {
                imgUrl = CDN_PATH + objList.productid.productimage[0].mediaID + '_compressed.png';
            }
            html += '<div class="card card-style mb-3 product_dcard">';
            html += '   <div class="content">';
            html += '       <div class="d-flex">';
            html += '           <div>';
            html += '               <img onerror="this.src =\'https://appscdn-us.hokuapps.com/card.png\'" src="' + imgUrl + '" class="rounded-m shadow-xl" width="100" height="85" style="object-fit:cover;">';
            html += '           </div>';
            html += '           <div class="ms-3 overflow-hidden">';
            html += '               <h4 class="text-capitalize text-truncate">' + productid_name + '</h4>';
            html += '               <h4 class="pt-1 color-highlight">$' + totalcost + '</h4>';
            html += '               <span class="color-theme font-12 text-capitalize">Quantity : ' + quantity + '</span>';
            html += '           </div>';
            html += '       </div>';
            html += '   </div>';
            html += '</div>';
        });
        $('#productlistcontainer').html(html);
        $('#productsstrip').removeClass('hideme');
        $('#display_loading').addClass('hideme');
    }
}

function getAppointmentsDetails(objParamsList) {
    objParamsList.recordID = getParameterByName('appointmentid');
    objParamsList.skip = skip;
    objParamsList.fetch = fetchRecord;
    objParamsList.customerId = getParameterByName('appointmentid');
    $.ajax({
        url: objParamsList.ajaXCallURL + '/booksy/getAjaxappointmentappointmentcheckoutweb',
        type: "POST",
        data: objParamsList,
        success: function (response) {
            if (response.status == 0) {
                getdcard_services_collectioncontainerapp_servicesList(response);
            }
        },
        error: function (error) {
            console.log(error);
        }
    });
}

$(document).ajaxStop(function () {
    grandtotal = (serviceTotalAmount + gstAmount) - discountAmount;
    balanceAmount = grandtotal - paidAmount;
    $('#servicetotal').html('$' + serviceTotalAmount.toFixed(2));
    $('#gstamount').html('$' + gstAmount.toFixed(2));
    $('#discountamount').html('$' + discountAmount.toFixed(2));
    $('#grandtotal').html('$' + grandtotal.toFixed(2));
    $('#paidamount').html('$' + paidAmount.toFixed(2));
    $('#balanceamount').html('$' + balanceAmount.toFixed(2));

    $('#checkoutstrip,#checkoutdetails').removeClass('hideme');
});


function getPaymentDetails(objParamsList) {
    if (objParamsList.recordID) { delete objParamsList.recordID; }
    objParamsList.appointmentnumber = getParameterByName('appointmentid');
    const url = objParamsList.ajaXCallURL + '/booksy/getPaymentListDetails_ServicePayments61f91155baf7700fc434e1af';
    $.ajax({
        url,
        type: 'POST',
        data: objParamsList,
        success: function (response) {
            if (response.status == 0) {
                paidAmount = response.totalPaid ? response.totalPaid : 0;
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}
