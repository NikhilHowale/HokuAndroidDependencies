
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
var totaldcard_topimage216560043190_collectioncontainer = 0;
let totalproductquantity = 0;
var imgUrl = '';
$(document).ready(function () {
    $('.page-content').css({
        'overflow-y': 'scroll',
        'padding-bottom': '0px',
    });
    if ($('.view_list_record').length) { $('.view_list_record').show(); }
    localStorage.removeItem('objParamsList');
    if ($('.js-candlestick').length) $("input[type='checkbox']").candlestick({ 'on': 'Yes', 'off': 'No', 'nc': 'NA', 'default': 'NA', 'swipe': false, 'allowManualDefault': true });
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    let objParamsList = {};
    skip = 0;
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    objParamsList.queryMode = queryMode;
    objParamsList.isMobile = isMobile;
    objParamsList.functionName = 'show_dcard_getCategoryListDetails';
    if (queryMode != '') {
        localStorage.setItem('objParamsList', JSON.stringify(objParamsList));
        show_dcard_getCategoryListDetails(objParamsList);
    }
    // show_dcard_getbannerimagelist(objParamsList);
    $(document).on('click', '.addcartbtn', function () {
        var toastData = '';
        const id = getParameterByName('productid');
        // const id = $('#currentQuantity').val();
        const productname = $(this).attr('productname');
        const productQty = $('#currentQuantity').val();
        const imgUrl = $(this).attr('imgUrl');
        const price = $(this).attr('price');
        const gst = $(this).attr('gst');
        if (Number(productQty) > 0) {
            toastData = 'snackbar-1'
            const product = {};
            product.id = id;
            product.name = productname;
            // product.description = productdesc;
            product.url = imgUrl;
            product.price = price;
            product.quantity = productQty;
            product.gst = gst;
            const cart = JSON.parse(localStorage.getItem('cart')) || [];
            let _cart = [...cart];
            const index = _cart.findIndex(item => item.id == id);
            if (index >= 0) {
                _cart[index].quantity = productQty;
            } else {
                _cart.push(product);
            }
            localStorage.setItem('cart', JSON.stringify(_cart));
        }
        else {
            toastData = 'snackbar-2'
        }
        var notificationToast = document.getElementById(toastData);
        var notificationToast = new bootstrap.Toast(notificationToast);
        notificationToast.show();
    });

    $(document).on('click', '#cartbtn', function () {
        var nextPage = 'app_productcheckout';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        var pageurl = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        window.location.href = pageurl;
        return false;
    })
    $(document).on('keyup', '#searchproducts', function () {
        var globalsearchtext = $('#searchproducts').val();
        if (globalsearchtext == '') {
            skip = 0;
            fetchRecord = 0;
            if (globalsearchtext) {
                $('#globalsearchcloseicon_img').show();
            } else {
                $('#globalsearchcloseicon_img').hide();
            }
            var objParamsList = {};
            objParamsList.queryMode = 'mylist';
            var ajaXCallURL = $.trim($('#ajaXCallURL').val());
            objParamsList.tokenKey = getParameterByName('tokenKey');
            objParamsList.secretKey = getParameterByName('secretKey');
            objParamsList.ajaXCallURL = ajaXCallURL;
            objParamsList.isMobile = 'true';
            objParamsList.isiPad = false;
            $('#display_loading').addClass('hideme');
            objParamsList.globalsearchvalue = globalsearchtext;
            $('#totaldcard_topimage216560043190_collectioncontainer').html('');
            $('#totaldcard_topimage216560043190_collectioncontainer').find('.view_list_record').removeClass('shimmer');
            show_dcard_getCategoryListDetails(objParamsList)
        }

    });
    $(document).on('click', '.stepper-minus', function () {
        const currentValue = parseInt($(this).siblings('input').val());
        if (currentValue > 0) {
            $(this).siblings('input').val(currentValue - 1);
        }
    });

    $(document).on('click', '.stepper-plus', function () {
        const currentValue = parseInt($(this).siblings('input').val());
        if (currentValue < totalproductquantity) {
            $(this).siblings('input').val(currentValue + 1);
        }
    });



});//end of ready 2



function show_dcard_getCategoryListDetails(objParamsList) {
    $('#display_loading').removeClass('hideme');
    objParamsList.categoryid = getParameterByName('categoryid');
    objParamsList.skip = skip;
    objParamsList.fetch = fetchRecord;
    objParamsList.recordID = getParameterByName('productid');


    $.ajax({
        url: objParamsList.ajaXCallURL + '/booksy/get_data_by_record_Products61f91155baf7700fc434e1afproductlistweb',
        data: objParamsList,
        type: 'POST',
        success: function (response) {
            if (response.status != undefined && response.status == 0) {
                const data = response.recordDetails[0];
                totalproductquantity = data.totalproductquentity;
                let url = CDN_PATH + data.productimage[0].mediaID + '_compressed.png';
                $(".addcartbtn").attr("gst",data.gst).attr("productname",data.productname).attr("imgUrl",url).attr("price",data.cost);
                if(totalproductquantity <= 0){
                    $("#soldout").removeClass("hideme")
                    $('#addtocartcontainer').addClass('hidecontainer');     
                }else{
                    $("#soldout").addClass("hideme");
                    $('#addtocartcontainer').removeClass('hidecontainer');
                }
                let imgHtml = '';
                if (data.productimage && data.productimage.length) {
                    $.each(data.productimage, function (key, value) {
                        imgUrl = CDN_PATH + value.mediaID + '_compressed.png';
                        imgHtml += '<div class="splide__slide">';
                        imgHtml += '<div class="card rounded-m shadow-l mx-3" style="height:200px;">';
                        imgHtml += '<img class="productslideimg img-fluid" src="' + imgUrl + '">';
                        imgHtml += '</div>';
                        imgHtml += '</div>';
                    });
                    $('#slideContainer').html(imgHtml);
                    var splide = document.getElementsByClassName('splide');
                    if (splide.length) {
                        var singleSlider = document.querySelectorAll('.single-slider');
                        if (singleSlider.length) {
                            singleSlider.forEach(function (e) {
                                var single = new Splide('#' + e.id, {
                                    type: 'loop',
                                    autoplay: true,
                                    interval: 4000,
                                    perPage: 1,
                                }).mount();
                                var sliderNext = document.querySelectorAll('.slider-next');
                                var sliderPrev = document.querySelectorAll('.slider-prev');
                                sliderNext.forEach(el => el.addEventListener('click', el => { single.go('>'); }));
                                sliderPrev.forEach(el => el.addEventListener('click', el => { single.go('<'); }));
                            });
                        }
                    }
                }
                
                if (!isNaN(data.cost)) {
                    $("#productprice").html(formatCurrency(data.cost));
                }
                if (data.productname) {
                    $("#productname").html(data.productname);
                }
                if (data.info) {
                    $("#productshortdecription").html(data.info);
                }
                if (data.heading) {
                    $("#productdecription").html(data.heading);
                }
                $('#mainContainer').removeClass('hideme');
                $('#display_loading').addClass('hideme');
            } else {
                $('#display_loading').addClass('hideme')
            }
        },
        error: function (xhr, status, error) {
            $('#display_loading').addClass('hideme')
            handleError(xhr, status, error);
        },
    });
} // end of function     

function formatCurrency(amount) {
    return Intl.NumberFormat('en-US', { style: 'currency', currency: 'USD' }).format(amount);
}


