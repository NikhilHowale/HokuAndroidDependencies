
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
$(document).ready(function () {
    // $('#display_loading').removeClass('hideme');
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    let objParamsList = {};
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    // objParamsList.ispaymentpaid = 1;
    objParamsList.ispaymentfailed = 0;
    objParamsList.recordID = getParameterByName('recordID');
    getCheckoutProductList(objParamsList);
});

$(document).on('click', '#shopnowbtn', function () {
    let nextPage = 'app_userhome';
    var queryParams = queryStringToJSON();
    if (queryParams['recordID']) delete queryParams['recordID'];
    if (queryParams['categoryid']) delete queryParams['categoryid'];
    if (queryParams['orderid']) delete queryParams['orderid'];
    var queryString = $.param(queryParams);
    queryString = queryString.replace(/\+/g, "%20");
    queryString = decodeURIComponent(queryString);
    var pageurl = nextPage + "_61f91155baf7700fc434e1af.html?" + queryString;
    window.location.href = pageurl;
    return false;
});



//end of ready 2


function getCheckoutProductList(objParamsList) {
    objParamsList.isExternalBooking = 1;
    objParamsList.skip = skip;
    objParamsList.fetch = fetchRecord;
    $.ajax({
        url: objParamsList.ajaXCallURL + '/booksy/getDataByRecordIdProductCheckout61f91155baf7700fc434e1af',
        type: "POST",
        data: objParamsList,
        success: function (response) {            
        },
        error: function (error) {
            console.log(error);
        }
    })

}