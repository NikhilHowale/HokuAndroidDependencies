
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var imageCount = {};
var webUploadArray = [];
var tempObject = {};
let arrPastTimes = [];
var totaldcard_topimage216560043190_collectioncontainer = 0;
$(document).ready(function () {

    let objParamsLocal = localStorage.getItem('objParams');
    if(objParamsLocal){
        objParamsLocal = JSON.parse(objParamsLocal);
        $('.confirmdate').html(localStorage.getItem('confirmeddatetime'));
        $('.confirmduration').html(objParamsLocal.starttimeid_name + ' - ' + localStorage.getItem('latestEndTimeDisplay') + ' ('+ objParamsLocal.totalduration +')');
        $('.salonlocationname').html(localStorage.getItem('salonlocationname'))
    }
    const appUser = JSON.parse(localStorage.getItem('appUser'));
    $('#servicetotalprice').html('$'+ localStorage.getItem('total-price'));
    $('#servicetotaltime').html(localStorage.getItem('total-hours') + 'h ' + localStorage.getItem('total-minutes') + 'min');

    $('#servicedate').val(moment(new Date()).format('YYYY-MM-DD'));
    if ($('.view_list_record').length) { $('.view_list_record').show(); }
    localStorage.removeItem('objParamsList');
    if ($('.js-candlestick').length) $("input[type='checkbox']").candlestick({ 'on': 'Yes', 'off': 'No', 'nc': 'NA', 'default': 'NA', 'swipe': false, 'allowManualDefault': true });
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    var queryMode = getParameterByName('queryMode');
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var isMobile = $.trim($('#isMobile').val());
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    let objParamsList = {};
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.tokenKey = tokenKey;
    objParamsList.secretKey = secretKey;
    objParamsList.isMobile = isMobile;
    // getservicetimeslotlistdetails(objParamsList);
    const custaddedservices = JSON.parse(localStorage.getItem('custaddedservices')) || [];
    // if (custaddedservices && custaddedservices.length) {
    //     makeServicesList(custaddedservices);
    // }
    $(document).on('click', '#backbutton1', function (e) {
        var queryParams = queryStringToJSON();
        var nextPage = 'app_servicepickdateandtime';
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        return false;
    });

    $(document).on('click', '.stafferList', function () {
        let nextPage = 'app_stylishlist';
        let serviceid = $(this).attr('id');
        var queryParams = queryStringToJSON();
        if (serviceid) queryParams['serviceid'] = serviceid;
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        return false;
    });

    $(document).on('click', '#addService', function () {
        let nextPage = 'app_serviceslist';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        return false;
    });

    $(document).on('click', '.removeService', function () {
        const id = $(this).attr('id');
        const currentService = JSON.parse(localStorage.getItem('custaddedservices')) || [];
        const _serviceArr = currentService.filter((item) => {
            return item.serviceid != id;
        });
        localStorage.setItem('custaddedservices', JSON.stringify(_serviceArr));

        let strHr = parseInt($(this).attr('data-hr').replace("h", ""));
        let strMin = parseInt($(this).attr('data-min').replace("min", ""));
        let strPrice = parseFloat($(this).attr('data-price'));

        let totalHours = parseInt(localStorage.getItem('total-hours')) - strHr;
        let totalMinutes = parseInt(localStorage.getItem('total-minutes')) - strMin;
        let totalPrice = parseFloat(localStorage.getItem('total-price')) - strPrice;

        var hours = Math.floor(totalMinutes / 60) + totalHours;          
        var minutes = totalMinutes % 60;

        localStorage.setItem('total-hours',hours);
        localStorage.setItem('total-minutes',minutes);
        localStorage.setItem('total-price',totalPrice);

        $('#servicetotalprice').html('$' + totalPrice.toFixed(2));
        $('#servicetotaltime').html(hours + 'h ' + minutes + 'min');

        // makeServicesList(_serviceArr);
    });
    $(document).on('change', '#servicedate', function (e) {
        let objParamsList = {};
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.tokenKey = tokenKey;
        objParamsList.secretKey = secretKey;
        objParamsList.isMobile = isMobile;
        // getservicetimeslotlistdetails(objParamsList);
        // console.log($(this).val());
        // const checkslotdatestart = moment(new Date($.trim($(this).val()))).startOf('day').utc().format('YYYY-MM-DDTHH:mm:ssZ');
        // const checkslotdateend = moment(new Date($.trim($(this).val()))).endOf('day').utc().format('YYYY-MM-DDTHH:mm:ssZ');
        // console.log(checkslotdatestart);
        // console.log(checkslotdateend);
    })

    $(document).on('click', '#confirmservice87', async function() {

        var objParams = localStorage.getItem('objParams');
        if(objParams){
            objParams = JSON.parse(objParams);
        } else {
            objParams = {};
        }
        
        var starttimeid = $.trim($('#servicetime').val());
        if ($('#servicetime_div').is(':visible')) {
            if (starttimeid == '') {
                $('#servicetime_error').show();
                if (!Object.keys(errorFields).length) errorFields['servicetime'] = 'dropdown';
                validAll = false;
            } else {
                $('#servicetime_error').hide();
            }
        }
        var material_pattern = /^Select/;
        if ($("#servicetime option:selected").text() && $("#servicetime option:selected").text().match(material_pattern)) {
            var tmpvalsanitized = $("#servicetime option:selected").map(function () {
                return $(this).text();
            }).get().join(',').replace("Select Start Time,", "");
            tmpvalsanitized = tmpvalsanitized ? tmpvalsanitized.replace('Select,', '') : tmpvalsanitized;
            $('[id^=starttimeid_name]').val(tmpvalsanitized);
        } else {
            objParams.starttimeid_name = $("#servicetime option:selected").map(function () {
                return $(this).text();
            }).get().join(',');
            $('[id^=starttimeid_name]').val(objParams.starttimeid_name);
        }
        if (starttimeid) objParams.starttimeid = starttimeid;

        var hoursselected = localStorage.getItem('data-hours'); 
        var minutesselected = localStorage.getItem('data-minutes'); 

        console.log(hoursselected);
        console.log(minutesselected);

        var appointmentdate = $("#servicedate").val();
        var appointmentstarttime = $("#starttimeid43 option:selected").text().replace("AM", " AM").replace("PM", " PM");
        var computeddate = moment(new Date(appointmentdate + ", " + appointmentstarttime)).format("DD-MMM-YYYY, hh:mm A");
        var computeddatenextdate = moment(new Date(computeddate)).add(hoursselected, 'hours').add(minutesselected, 'minutes').format("hh:mmA");

        let endTimeParams = {};
        endTimeParams.starttimeappointment = computeddatenextdate;
        // objParams.endtimeid_name = computeddatenextdate;
        // await calculateEndTime(endTimeParams);

        var endtimeid = $.trim($('#endtime44').val());
        if ($('#endtime44_div').is(':visible')) {
            if (endtimeid == '') {
                $('#endtime44_error').show();
                if (!Object.keys(errorFields).length) errorFields['endtime44'] = 'dropdown';
                validAll = false;
            } else {
                $('#endtime44_error').hide();
            }
        }
        // var material_pattern = /^Select/;
        // if ($("#endtime44 option:selected").text() && $("#endtime44 option:selected").text().match(material_pattern)) {
        //     var tmpvalsanitized = $("#endtime44 option:selected").map(function () {
        //         return $(this).text();
        //     }).get().join(',').replace("Select End Time,", "");
        //     tmpvalsanitized = tmpvalsanitized ? tmpvalsanitized.replace('Select,', '') : tmpvalsanitized;
        //     $('[id^=endtimeid_name]').val(tmpvalsanitized);
        // } else {
        //     objParams.endtimeid_name = $("#endtime44 option:selected").map(function () {
        //         return $(this).text();
        //     }).get().join(',');
        //     $('[id^=endtimeid_name]').val(objParams.endtimeid_name);
        // }
        if (endtimeid) {
            objParams.endtimeid = endtimeid;
        }

        
        var pax43 = $("#form5").val();
        objParams.pax = pax43;
        
        var date = $.trim($('#servicedate').val());
        if ($('#servicedate_div').is(':visible')) {
            if (date == '') {
                $('#servicedate_error').show();
                if (!Object.keys(errorFields).length) errorFields['servicedate'] = 'datecontrol';
                validAll = false;
            } else {
                $('#servicedate_error').hide();
            }
        }
        if (date) {
            objParams.date = date;
            objParams.datedisplaystring = date;
        }

        if (errorFields && Object.keys(errorFields).length) {
            $('#display_loading').addClass('hideme');
            for (var firstErrorField in errorFields) {
                var controlType = errorFields[firstErrorField];
                errorFields = []
                var errField = $('#' + firstErrorField);
                if (controlType == 'dropdown') {
                    errField.prev().prev().focus();
                } else {
                    errField.focus()
                }
                validAll = true;
                return false;
            }
        }
        if (!validAll) {
            validAll = true;
            return false;
        }
        var totalduration = $('#servicetotaltime').text();
        if (totalduration) objParams.totalduration = totalduration;

        objParams.mailsalonlocationid = localStorage.getItem('salonlocationid');
        objParams.salonlocationid_name = localStorage.getItem('salonlocationname');

        $('.confirmdate').html(date);
        $('.confirmduration').attr('totalduration',totalduration);
        $('.salonlocationname').html(localStorage.getItem('salonlocationname'));
        

        var custaddedservices = localStorage.getItem('custaddedservices');
        if(custaddedservices){
            custaddedservices = JSON.parse(custaddedservices);
            let latestEndTime = '';
            custaddedservices.forEach((service,key) => {
                
                if(key == 0){
                    service.starttime = objParams.starttimeid_name;
                    service.endtime = serviceEndTime(objParams.starttimeid_name,service);
                    latestEndTime = service.endtime;
                    latestEndTimeDisplay = service.endtime;

                    

                } else {
                    service.starttime = latestEndTime;
                    service.endtime = serviceEndTime(latestEndTime,service);
                    latestEndTime = service.endtime;
                    latestEndTimeDisplay = service.endtime;

                    // objParams.endtimeid_name = service.endtime;

                }
                
                
            });
            localStorage.setItem('custaddedservices',JSON.stringify(custaddedservices))
        }

        $('.confirmduration').html(objParams.starttimeid_name + ' - ' + latestEndTimeDisplay + ' ('+ totalduration +')');
        

        localStorage.setItem('objParams',JSON.stringify(objParams));
        // check salon end date based on services
        // for Saturday and Sunday calculation
        var dayofweeknumber = moment(new Date($("#date42").val())).weekday();
        if(dayofweeknumber == 0 || dayofweeknumber == 6){
            var starttimeslotecheck = moment().format('DD MMMM, YYYY') + " 05:00 PM";
        } else {
            var starttimeslotecheck = moment().format('DD MMMM, YYYY') + " " + salonendtime;
        }
        var endtimeslotecheck = moment().format('DD MMMM, YYYY') + " " + latestEndTimeDisplay.replace('AM',' AM').replace('PM',' PM');

        console.log(starttimeslotecheck);
        console.log(endtimeslotecheck);

        var momstarttimeslotecheck = moment(starttimeslotecheck);
        var momendtimeslotecheck = moment(endtimeslotecheck);

        var slotemindiffcheck = momendtimeslotecheck.diff(momstarttimeslotecheck, 'minutes');

        console.log(slotemindiffcheck);

        if(slotemindiffcheck > 0){
            if(dayofweeknumber == 0 || dayofweeknumber == 6){
                Materialize.toast('Salon is closed at 05:00 PM and your end time of service is '+latestEndTimeDisplay.replace('AM',' AM').replace('PM',' PM')+', Please select different time slot.', 2000);
            } else {
                Materialize.toast('Salon is closed at '+salonendtime+' and your end time of service is '+latestEndTimeDisplay.replace('AM',' AM').replace('PM',' PM')+', Please select different time slot.', 2000);
            }
        } else {

            // check slot available details
            var paramsServicesSlotCheck = {};
            paramsServicesSlotCheck.salonlocationid = $('#recordID').val();
            if($('#date42').val()){
                paramsServicesSlotCheck.checkslotdatestart = moment(new Date($.trim($('#date42').val()))).startOf('day').utc().format('YYYY-MM-DDTHH:mm:ssZ');
                paramsServicesSlotCheck.checkslotdateend = moment(new Date($.trim($('#date42').val()))).endOf('day').utc().format('YYYY-MM-DDTHH:mm:ssZ');
            }
            var servicesarrslot = localStorage.getItem('custaddedservices');
            if(servicesarrslot){
               paramsServicesSlotCheck.servicesarr = JSON.parse(servicesarrslot);
            }

            var arrPax = [];
            var pax43 = $("#pax43").val();
            pax43 = parseInt(pax43);

            for(var i = 1;i <= pax43; i++){
                arrPax.push(i);
            }
            paramsServicesSlotCheck.checkpax = arrPax;
            var ajaXCallURL = $.trim($('#ajaXCallURL').val());
            if(paramsServicesSlotCheck.servicesarr){
                $('#display_loading').removeClass('hideme');
                $.ajax({
                    url: ajaXCallURL + '/booksy/checkoutappointmentschedularweb',
                    data: paramsServicesSlotCheck,
                    type: 'POST',
                    success: function (response) {
                        $('#display_loading').addClass('hideme');
                        if (response.status == 0) {

                            if(response.isfounderror == 0){
                                // let newCustAddServices = [];
                                // arrPax.forEach((pax) => {
                                //     response.data.forEach((record) => {
                                    
                                //     // for(const pax of arrPax){
                                //         if(pax == 2){
                                //             record["pax"+pax] = pax.toString();
                                //         }
                                //         newCustAddServices.push({ ...record });    //push(record);
                                //         // console.log('######333333333 myloop pax : ',pax,record.pax);
                                //     });
                                //     console.log('######333333333 newCustAddServices : ',newCustAddServices);
                                // });
                                
                                localStorage.setItem('custaddedservices',JSON.stringify(response.data));
                                addConfirmServiceCard();
                                $('#confimdetailsmodal').modal({dismissible:false});
                                $('#confimdetailsmodal').modal('open');
                            } else {
                                Materialize.toast('Services that are selected by you have slots available to others, Please select different slots.', 2000);
                                var paramsType = {};
                                paramsType.salonlocationid = $('#recordID').val();
                                getStartTime(paramsType);
                            }
                        } else {
                            Materialize.toast('No services are selected, Please select atleast one service.', 2000);
                        }
                    },
                    error: function (xhr, status, error) {
                        $('#display_loading').addClass('hideme');
                        Materialize.toast('No services are selected, Please select atleast one service.', 2000);
                    },
                });

            } else {
                Materialize.toast('No services are selected, Please select atleast one service.', 2000);
            }



            // addConfirmServiceCard();
            // $('#confimdetailsmodal').modal({dismissible:false});
            // $('#confimdetailsmodal').modal('open');
        }

        

    });

    $(document).on('click', '#confirmandbook87', function() {

        var objParams = localStorage.getItem('objParams');
        if(objParams){
            objParams = JSON.parse(objParams);

            var internalnote = $.trim($('#additionalnote89').val());
            if (internalnote) objParams.internalnote = internalnote;

            localStorage.setItem('objParams',JSON.stringify(objParams));
        }
        
        $('#confimandbookmodal').modal({ dismissible: false });
        $('#confimandbookmodal').modal('open');
        
        

    });
    
    $(document).on('click', '#backtohome', function() {
        // $('#display_loading').addClass('hideme');
        $('#display_loading').removeClass('hideme');
        if (appUser && appUser.rolename !== 'Guest') {
        let nextPage = 'app_appointmentorders';
        var queryParams = queryStringToJSON();
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        }else{
            $('#display_loading').removeClass('hideme');
            let nextPage = 'app_userhome';
            var queryParams = queryStringToJSON();
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_61f91155baf7700fc434e1af.html?' + queryString;
        }
    });
    

});//end of ready 2

function serviceEndTime(starttime,service){
    // let starttime = objParams.starttimeid_name;
    let [hours, allmin] = starttime.split(':');
    let allminarr = allmin.match(/.{1,2}/g);
    let minutes = allminarr[0]
    let ampm = allminarr[1];
    hours = parseInt(hours)
    minutes = parseInt(minutes)
    if(ampm == "PM" && hours<12) hours = hours+12;
    if(ampm == "AM" && hours==12) hours = hours-12;
    if(hours<10) hours = "0" + hours;
    if(minutes<10) minutes = "0" + minutes;
    
    let durationHours = parseInt(service.servicehours.replace('h',''));
    let durationMinutes = parseInt(service.serviceminuts.replace('min',''));
    hours = hours + durationHours
    minutes = minutes + durationMinutes
    if(hours >= 24) hours = hours - 24
    
    hours = Math.floor((minutes) / 60) + hours;          
    minutes = (minutes) % 60;
    if(hours<10) hours = "0" + hours;
    if(minutes<10) minutes = "0" + minutes;
    
    
    var suffix = hours >= 12 ? "PM":"AM";
    hours = (hours + 11) % 12 + 1;
    if(hours<10) hours = "0" + hours;
    // if(minutes<10) minutes = "0" + minutes;
    finalTime = hours + ':' + minutes + suffix

    console.log(finalTime);

    return finalTime;
}


function getservicetimeslotlistdetails(paramsType) {
    paramsType.salonlocationid = getParameterByName('salonlocationid');
    paramsType.checkslotdatestart = moment(new Date($.trim($('#servicedate').val()))).startOf('day').utc().format('YYYY-MM-DDTHH:mm:ssZ');
    paramsType.checkslotdateend = moment(new Date($.trim($('#servicedate').val()))).endOf('day').utc().format('YYYY-MM-DDTHH:mm:ssZ');
    const url = paramsType.ajaXCallURL + '/booksy/getfromothertable_appointmentschedularweb_timeslot_61f91155baf7700fc434e1af_StartTime';
    $('#display_loading').removeClass('hideme');
    $.ajax({
        url,
        type: 'POST',
        data: paramsType,
        success: function (response) {
            if (response.status == 0 && response.data) {
                var arrSalonLocationHours = [];

                if (paramsType.salonlocationid) {
                    var slonestartcount = 0;
                    $.each(response.data, function (keyList, objList) {
                        arrSalonLocationHours.push(objList.starttime);
                        slonestartcount++;
                        if (slonestartcount == 1) {
                            salonstarttime = objList.starttime.replace('AM', ' AM').replace('PM', ' PM');
                        }
                        if (response.data.length == slonestartcount) {
                            salonendtime = objList.starttime.replace('AM', ' AM').replace('PM', ' PM');
                        }
                    });
                }
                if (response.slotserviceslist) {
                    $.each(response.data, function (keySalonSlotList, objSalonSlotList) {
                        var totalCount = 0;
                        $.each(response.slotserviceslist, function (keySloteList, objSloteList) {
                            var arrSelectedservicesSlotsStylist = [];
                            $.each(objSloteList, function (keySloteServiceList, objSloteServiceList) {
                                if (objSloteServiceList.starttimeid_name && objSloteServiceList.endtimeid_name) {
                                    var starttimeslote = moment().format('DD MMMM, YYYY') + " " + objSloteServiceList.starttimeid_name.replace('AM', ' AM').replace('PM', ' PM');
                                    var endtimeslote = moment().format('DD MMMM, YYYY') + " " + objSloteServiceList.endtimeid_name.replace('AM', ' AM').replace('PM', ' PM');
                                    var momstarttimeslote = moment(starttimeslote);
                                    var momendtimeslote = moment(endtimeslote);
                                    var slotemindiff = momendtimeslote.diff(momstarttimeslote, 'minutes');
                                    if (slotemindiff > 0) {
                                        var slotemindiffinter = Math.ceil(slotemindiff / 15);
                                        var cuculatedtimemoment = moment(new Date(starttimeslote)).format('hh:mmA');
                                        arrSelectedservicesSlotsStylist.push(cuculatedtimemoment);
                                        for (var i = 1; i < slotemindiffinter; i++) {
                                            var cuculatedtimemoment = moment(new Date(starttimeslote)).add(i * 15, 'minutes').format('hh:mmA');
                                            arrSelectedservicesSlotsStylist.push(cuculatedtimemoment);
                                        }
                                    }
                                }
                            });
                            if (arrSelectedservicesSlotsStylist.indexOf(objSalonSlotList.starttime) >= 0) {
                                totalCount++;
                            }
                        });
                        if (totalCount == response.locationstylistcount) {
                            arrPastTimes.push(objSalonSlotList.starttime);
                        }
                    });
                }

                var selectOptionHtml = '<option disabled selected value="">Select Start Time</option>';
                let datalength = response.data.length;
                $.each(response.data, function (keyList, objList) {
                    if (keyList < (datalength - 3)) {
                        // for Saturday and Sunday calculation
                        var dayofweeknumber = moment(new Date($("#date42").val())).weekday();
                        if (dayofweeknumber == 0 || dayofweeknumber == 6) {
                            var starttimesloteone = moment(new Date($("#date42").val())).format('DD MMMM, YYYY') + " 05:00 PM";
                            var endtimesloteone = moment(new Date($("#date42").val())).format('DD MMMM, YYYY') + " " + objList.starttime.replace('AM', ' AM').replace('PM', ' PM');
                            var momstarttimesloteone = moment(starttimesloteone);
                            var momendtimesloteone = moment(endtimesloteone);
                            var slotemindiff = momendtimesloteone.diff(momstarttimesloteone, 'minutes');
                            if (slotemindiff >= 0 || slotemindiff == -30 || slotemindiff == -15) {
                                arrPastTimes.push(objList.starttime);
                            }
                            if (slotemindiff >= 0 || slotemindiff == -30 || slotemindiff == -15) {
                            } else {
                                // check pass values
                                if (arrPastTimes.indexOf(objList.starttime) >= 0) {
                                    selectOptionHtml += '<option  sequence="' + objList.sequence + '" value="' + objList._id + '" disabled>' + objList.starttime + '</option>';
                                } else {
                                    selectOptionHtml += '<option  sequence="' + objList.sequence + '" value="' + objList._id + '">' + objList.starttime + '</option>';
                                }
                            }
                        } else {
                            // check pass values
                            if (arrPastTimes.indexOf(objList.starttime) >= 0) {
                                selectOptionHtml += '<option  sequence="' + objList.sequence + '" value="' + objList._id + '" disabled>' + objList.starttime + '</option>';
                            } else {
                                selectOptionHtml += '<option  sequence="' + objList.sequence + '" value="' + objList._id + '">' + objList.starttime + '</option>';
                            }
                        }
                    }
                });
                $('#servicetime').html(selectOptionHtml); //2
                $('#display_loading').addClass('hideme');








                // let selectHtml = ' <option value="default" disabled selected="">Start Time</option>';
                // $.each(response.data, function (keyList, objList) {
                //     selectHtml += '<option value="' + objList._id + '">' + objList.starttime + '</option>';
                // });
                // $('#servicetime').html(selectHtml);
            }
        },
        error: function (error) {
            console.log(error);
        }
    })
}

function makeServicesList(response) {
    let html = '';
    $.each(response, function (index, data) {
        let servicename = data['servicename'] ? data['servicename'] : '';
        let servicedescription = data['servicedescription'] ? data['servicedescription'] : '';
        let serviceprice = data['serviceprice'] ? data['serviceprice'] : '0';
        let serviceduration = data['serviceduration'] ? data['serviceduration'] : '';
        let stylistid_name = data['stylistid_name'] ? data['stylistid_name'] : '';
        let serviceid = data['serviceid'] ? data['serviceid'] : '';
        let mediaId = data['mediaid'] ? data['mediaid'] : '';
        let imgUrl = '';
        if (mediaId != '') {
            imgUrl = CDN_PATH + mediaId + '_compressed.png';
        }
        html += '<div class="card card-style mb-3 mx-0 overflow-visible">';
        html += '    <div class="content overflow-hidden">';
        html += '        <div class="d-flex gap-2 justify-content-between">';
        html += '            <div>';
        html += '                <h3 class="text-capitalize">' + servicename + '</h3>';
        html += '                <p class="lh-base">' + stylistid_name + '</p>';
        html += '            </div>';
        html += '            <div class="text-nowrap text-end">';
        html += '                <strong class="color-black">$' + serviceprice + '</strong>';
        html += '                <div class="">' + serviceduration + '</div>';
        html += '            </div>';
        html += '        </div>';
        // html += '       <div class="divider my-2"></div>';
        // html += '       <div class="d-flex justify-content-between align-items-center">';
        // html += '           <div class="d-flex align-items-center justify-content-start">';
        // html += '               <img onerror="this.src =\'https://appscdn-us.hokuapps.com/card.png\'" src="' + imgUrl + '" style="object-fit: cover;min-width:40px;min-height:40px;width:40px;height:40px;" class="rounded-circle">';
        // html += '               <h6 class="ps-2">' + stylistid_name + '</h6>';
        // html += '           </div>';
        // // html += '           <div>';
        // html += '               <a id="' + serviceid + '" class="stafferList btn bg-green-dark py-1 px-2 font-12 rounded-xl">Change</a>';
        // // html += '           </div>';
        // html += '       </div>';
        html += '    </div>';
        if (response.length > 1) {
            html += '    <div id="' + serviceid + '" data-hr="'+ data.servicehours +'" data-min="'+ data.serviceminuts +'" data-price="'+ data.serviceprice +'" class="position-fixed removeService" style="top: -5px;right:-5px;"><i class="fa fa-circle-xmark color-highlight font-22"></i></div>';
        }

        html += '</div>';
    });
    $('#selectedservices').html(html);
}
