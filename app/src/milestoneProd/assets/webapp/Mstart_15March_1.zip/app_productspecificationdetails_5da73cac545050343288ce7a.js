
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
  $('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
    $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

  var objParamsToken = {};
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  objParamsToken.tokenKey = getParameterByName('tokenKey');
  objParamsToken.secretKey = getParameterByName('secretKey');

  var userRole = $('#userRole').val();
  var userID = $('#userID').val();
  var createrOfRecord = $('#createrOfRecord').val();
  var queryMode = getParameterByName('queryMode');
  var recordID = $.trim($('#recordID').val());
  var addSessionComments = [];
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
                  
                 
                  $(document).on('click', '#locationbutton', function (e) {
                                 
                                 });
  $(document).on('click', '#backbutton1', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_productadditionaldetails';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "update";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error)
    }
  })
  $(document).on('click', '#icongetdirection9', function () {
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var queryMode = getParameterByName('queryMode');
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());;
    loadNativeicon_getdirectionControl(tokenKey, queryMode, secretKey, ajaXCallURL);
  });
  var paramsEdit = {};
  paramsEdit.tokenKey = getParameterByName('tokenKey');
  paramsEdit.secretKey = getParameterByName('secretKey')
  getRecordByIDProcessBeforeCall395660(paramsEdit, function (processBeforeRes) {
    $.ajax({
      url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_productspecificationdetails_Bazaar5da73cac545050343288ce7a',
      data: paramsEdit,
      type: 'POST',
      jsonpCallback: 'callback',
      success: function (response) {
        getRecordByIDProcessAfterCall395660(response, function (processBeforeRes) {
          if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
            var objParamsList = {};
            var queryMode = $('#queryMode').val();
            objParamsList.queryMode = queryMode;;
            var tokenKey = $('#tokenKey').val();;
            objParamsList.tokenKey = tokenKey;;
            if (!$('#8').html()) {
              $('#8').append(response.recordDetails.undefined);
            }
            if (!$('#about26').html()) {
              $('#about26').append(response.recordDetails.undefined);
            }
            if (!$('#backbutton1').html()) {
              $('#backbutton1').append(response.recordDetails.undefined);
            }
            if (!$('#contactphonenumber18').html()) {
              $('#contactphonenumber18').append('<a id="contactphonenumberImg" class="tellink" href="tel:' + response.recordDetails.contactphonenumber + '">' + response.recordDetails.contactphonenumber + '</a>');
            }
            if (!$('#contactperson9').html()) {
              $('#contactperson9').append(response.recordDetails.contactperson);
            }
            if (!$('#contactperson15').html()) {
              $('#contactperson15').append(response.recordDetails.contactperson);
            }
            if (!$('#description28').html()) {
              $('#description28').append(response.recordDetails.description);
            }
            if (!$('#eventcategory_name7').html()) {
              $('#eventcategory_name7').append(response.recordDetails.eventcategory_name);
            }
                                            if (response.recordDetails.venue) {
                                            localStorage.setItem("venue_name",response.recordDetails.venue_name)
                                             localStorage.setItem('pickuplocationLongitute',response.recordDetails.venue.coordinates[0]);
                                            localStorage.setItem('pickuplocationLatitude',response.recordDetails.venue.coordinates[1]);
                                          //  $('#eventcategory_name7').append(response.recordDetails.venue);
                                            }
            response.recordDetails['eventdate_preserved'] = response.recordDetails['eventdate'];
            response.recordDetails['eventdate'] = response.recordDetails['eventdate'] ? moment(new Date(response.recordDetails['eventdate'])).format('DD MMM YYYY') : '';
            if (!$('#eventdate12').html()) {
              $('#eventdate12').append(response.recordDetails.eventdate);
            }
            response.recordDetails['eventdate'] = response.recordDetails['eventdate_preserved'];
            response.recordDetails['eventdate_preserved'] = response.recordDetails['eventdate'];
            response.recordDetails['eventdate'] = response.recordDetails['eventdate'] ? moment(new Date(response.recordDetails['eventdate'])).format('DD MMM YYYY') : '';
            if (!$('#eventdate21').html()) {
              $('#eventdate21').append(response.recordDetails.eventdate);
            }
            response.recordDetails['eventdate'] = response.recordDetails['eventdate_preserved'];
            if (!$('#eventname11').html()) {
              $('#eventname11').append(response.recordDetails.eventname);
            }
            //  response.recordDetails['fromtime_preserved'] = response.recordDetails['fromtime'] ;
            //  response.recordDetails['fromtime'] = response.recordDetails['fromtime']  ? moment(new Date(response.recordDetails['fromtime'])).format('DD MMM YYYY') : '';
            if (!$('#fromtime24').html()) {
              $('#fromtime24').append(response.recordDetails.fromtime);
            }
            response.recordDetails['fromtime'] = response.recordDetails['fromtime_preserved'];
            if (!$('#status10').html()) {
              $('#status10').append(response.recordDetails.status);
            }
            if (!$('#contactperson14').html()) {
              $('#contactperson14').append(response.recordDetails.undefined);
            }
            if (!$('#date20').html()) {
              $('#date20').append(response.recordDetails.undefined);
            }
            if (!$('#eventdetails2').html()) {
              $('#eventdetails2').append(response.recordDetails.undefined);
            }
            if (!$('#phonenumber17').html()) {
              $('#phonenumber17').append(response.recordDetails.undefined);
            }
            if (!$('#time23').html()) {
              $('#time23').append(response.recordDetails.undefined);
            }

            Materialize.updateTextFields();
            $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

          }
        }); // end of getRecord By ID
      },
      error: function (xhr, status, error) {
        handleError(xhr, status, error);
      },
    });
  }); // end of getRecord By ID

});//end of ready 
function loadNativeicon_getdirectionControl(tokenKey, queryMode, secretKey, ajaXCallURL) {
  try {
    var appJSON = {};
    appJSON.tokenKey = tokenKey;
    appJSON.secretKey = secretKey;
    appJSON.queryMode = queryMode;
    appJSON.action = queryMode;
    appJSON.ajaXCallURL = ajaXCallURL;
    var AWSCredentials = localStorage.getItem("AWSCredentials");
    if (localStorage.IDENTITY_TOKEN) {
      var token = localStorage.IDENTITY_TOKEN;
      var playload = JSON.parse(atob(token.split(".")[1]));
      appJSON.Authorization = token;
      appJSON.Expiration = playload.exp;
    } else if (AWSCredentials) {
      AWSCredentials = JSON.parse(AWSCredentials);
      appJSON.accessKeyId = AWSCredentials.accessKeyId;
      appJSON.secretAccessKey = AWSCredentials.secretAccessKey;
      appJSON.sessionToken = AWSCredentials.sessionToken;
      appJSON.Expiration = AWSCredentials.Expiration;
    }
    appJSON.organizationID = $('#organizationID').val();
    appJSON.userID = $('#userID').val();
    appJSON.callbackFunction = 'setNativeicon_getdirectionControl';
    appJSON.nextButtonCallback = 'setNativeicon_getdirectionControl';
    appJSON.appID = $('#appID').val();
    clientbeforeNativeicon_getdirection(appJSON, function (pbcRes) {
      if (DEVICE_TYPE == 'ios') {
        setupWebViewJavascriptBridge(function (bridgeObj) {
          bridgeObj.callHandler('LoadMapView', appJSON, function (response) {
          });
          bridgeObj.registerHandler('setNativeicon_getdirectionControl', function (responseData, responseCallback) {
            setNativeicon_getdirectionControl(responseData);
          });
        });
      } else {
        window.Android.loadMapViewByConfig(JSON.stringify(appJSON));
      }
    }); // end of process before call 
  } catch (err) {

  }
}
function clientbeforeNativeicon_getdirection(appJSON, callback) {
  var response = appJSON;
  appJSON.openMapApp = true;
  appJSON.isShowDirections = true;
  appJSON.isPlotAddressLocation = true;
  appJSON.sourceAddressString = localStorage.getItem('venue_name');
 // appJSON.DestAddress = $('input[name="droplocation_name"]').val();
  appJSON.isReadOnly = true;
  appJSON.isShowBottomButton = 0;
  appJSON.isSelectLocation = 0;
  appJSON.mapZoomLevel = 16;
  appJSON.isNavigation = 1;
  appJSON.isOtherNearbyLocation =true;
//  appJSON.DestLongitude = localStorage.getItem('droplocationLongitute');
//  appJSON.DestLatitude = localStorage.getItem('droplocationLatitude');
  appJSON.Longitude = localStorage.getItem('pickuplocationLongitute');
  appJSON.Latitude = localStorage.getItem('pickuplocationLatitude');
  callback();
}
function setNativeicon_getdirectionControl(responseData) {
  try {
    if (responseData) {
      // Add Custome function Call here                 
      clientafterNativeicon_getdirection(responseData, function (pbcRes) {
        // handle client after call 
      })
    }
  } catch (err) {

  }
}
function clientafterNativeicon_getdirection(response, callback) {
  callback();
}
function getRecordByIDProcessBeforeCall395660(paramsType, callback) {
  var response = paramsType;

  if (getParameterByName('bazaarid') && getParameterByName('bazaarid') != 'undefined') { paramsType.recordID = getParameterByName('bazaarid') } else if (getParameterByName('recordID') && getParameterByName('recordID') != 'undefined') { paramsType.recordID = getParameterByName('recordID') }; callback();
}
function getRecordByIDProcessAfterCall395660(response, callback) {
  callback();
}
