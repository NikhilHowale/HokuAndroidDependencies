
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
     var totalmenuslider = 0;
     var totalallservices = 0;
     var totaltrendingslider = 0;
     var totalbrandsslider = 0;
     var totalhotbazaarslider = 0;
     var totalrecentlyslider = 0;
     var totalhomebanner = 0;
     var totalprodcutbanner = 0;
     var totalofferbanner = 0;
     var totalbottombanner = 0;
  function makeSlidesbannerphotoupload14(data){
        var slide='';
        var htmlString='';
        if(data && data.length == 1 ){ data = data[0].bannerphotoupload ? data[0].bannerphotoupload  : [] ;};
        if(data && data.length > 0){
             for (let index = 0; index < data.length; index++) { 
                 const element = data[index];
                 var mediaID;
                 if(element && element.bannerphotoupload && element.bannerphotoupload[0]){
                     mediaID = element.bannerphotoupload[0].mediaID;
                 } else if(element && element.mediaID){
                      mediaID = element.mediaID;
                 }
        slide += ' <div class="swiper-slide" href="#one!" >'
        slide += '    <div class="row  col s12" style="padding: 0px" !important;>'
        slide += '       <div id="image6_div" style="text-align: center;">'
        slide += '          <img  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+CDN_PATH+mediaID+'_compressed.png" style="width:100%; height:300px">'
        slide += '       </div>'
        slide += '    </div>'
        slide += '        </div>'
                        }
        if(slide){
                   $("#bannerphotoupload14").html(slide)
                 }
        var swiper = new Swiper('.swiper-container', {
             autoplay: {
             delay: 2500,
              disableOnInteraction: false,
             },
             watchOverflow: true,
             pagination: {
                  el: '.swiper-pagination'
                 },
              });
              $('.dynamic-slider-view').removeClass('shimmer');
           }
        }
  function makeSlidesbannerphotoupload21(data){
        var slide='';
        var htmlString='';
        if(data && data.length == 1 ){ data = data[0].bannerphotoupload ? data[0].bannerphotoupload  : [] ;};
        if(data && data.length > 0){
             for (let index = 0; index < data.length; index++) { 
                 const element = data[index];
                 var mediaID;
                 if(element && element.bannerphotoupload && element.bannerphotoupload[0]){
                     mediaID = element.bannerphotoupload[0].mediaID;
                 } else if(element && element.mediaID){
                      mediaID = element.mediaID;
                 }
        slide += ' <div class="swiper-slide" href="#one!" >'
        slide += '    <div class="row  col s12" style="padding: 0px" !important;>'
        slide += '       <div id="image6_div" style="text-align: center;">'
        slide += '          <img  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+CDN_PATH+mediaID+'_compressed.png" style="width:100%; height:300px">'
        slide += '       </div>'
        slide += '    </div>'
        slide += '        </div>'
                        }
        if(slide){
                   $("#bannerphotoupload21").html(slide)
                 }
        var swiper = new Swiper('.swiper-container', {
             autoplay: {
             delay: 2500,
              disableOnInteraction: false,
             },
             watchOverflow: true,
             pagination: {
                  el: '.swiper-pagination'
                 },
              });
              $('.dynamic-slider-view').removeClass('shimmer');
           }
        }
  function makeSlidesbannerphotoupload33(data){
        var slide='';
        var htmlString='';
        if(data && data.length == 1 ){ data = data[0].bannerphotoupload ? data[0].bannerphotoupload  : [] ;};
        if(data && data.length > 0){
             for (let index = 0; index < data.length; index++) { 
                 const element = data[index];
                 var mediaID;
                 if(element && element.bannerphotoupload && element.bannerphotoupload[0]){
                     mediaID = element.bannerphotoupload[0].mediaID;
                 } else if(element && element.mediaID){
                      mediaID = element.mediaID;
                 }
        slide += ' <div class="swiper-slide" href="#one!" >'
        slide += '    <div class="row  col s12" style="padding: 0px" !important;>'
        slide += '       <div id="image6_div" style="text-align: center;">'
        slide += '          <img  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+CDN_PATH+mediaID+'_compressed.png" style="width:100%; height:300px">'
        slide += '       </div>'
        slide += '    </div>'
        slide += '        </div>'
                        }
        if(slide){
                   $("#bannerphotoupload33").html(slide)
                 }
        var swiper = new Swiper('.swiper-container', {
             autoplay: {
             delay: 2500,
              disableOnInteraction: false,
             },
             watchOverflow: true,
             pagination: {
                  el: '.swiper-pagination'
                 },
              });
              $('.dynamic-slider-view').removeClass('shimmer');
           }
        }
  function makeSlidesbannerphotoupload39(data){
        var slide='';
        var htmlString='';
        if(data && data.length == 1 ){ data = data[0].bannerphotoupload ? data[0].bannerphotoupload  : [] ;};
        if(data && data.length > 0){
             for (let index = 0; index < data.length; index++) { 
                 const element = data[index];
                 var mediaID;
                 if(element && element.bannerphotoupload && element.bannerphotoupload[0]){
                     mediaID = element.bannerphotoupload[0].mediaID;
                 } else if(element && element.mediaID){
                      mediaID = element.mediaID;
                 }
        slide += ' <div class="swiper-slide" href="#one!" >'
        slide += '    <div class="row  col s12" style="padding: 0px" !important;>'
        slide += '       <div id="image6_div" style="text-align: center;">'
        slide += '          <img  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+CDN_PATH+mediaID+'_compressed.png" style="width:100%; height:300px">'
        slide += '       </div>'
        slide += '    </div>'
        slide += '        </div>'
                        }
        if(slide){
                   $("#bannerphotoupload39").html(slide)
                 }
        var swiper = new Swiper('.swiper-container', {
             autoplay: {
             delay: 2500,
              disableOnInteraction: false,
             },
             watchOverflow: true,
             pagination: {
                  el: '.swiper-pagination'
                 },
              });
              $('.dynamic-slider-view').removeClass('shimmer');
           }
        }
  function distance(lat2, lon2, unit) {
      if (locationJson.coordinates != undefined) {
          var myLong = 0;
          var myLat = 0;
          if (locationJson.coordinates[0] != undefined && locationJson.coordinates[1] != undefined) {
              var myLat = parseFloat(locationJson.coordinates[1]);
              var myLong = parseFloat(locationJson.coordinates[0]);
          }
      }
      if (myLat && myLong) {
          var lat1 = myLat;
          var lon1 = myLong;
          var radlat1 = Math.PI * lat1 / 180
          var radlat2 = Math.PI * lat2 / 180
          var theta = lon1 - lon2
          var radtheta = Math.PI * theta / 180
          var dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
          dist = Math.acos(dist)
          dist = dist * 180 / Math.PI
          dist = dist * 60 * 1.1515
          if (unit == "K") { dist = dist * 1.609344 }
          if (unit == "N") { dist = dist * 0.8684 }
          return dist
      }else {
          return 0;
      }
  }
  function loadGoogleMap() {

 var inputlocation2 = document.getElementById("location2");
 var searchBoxlocation2 = new google.maps.places.SearchBox(inputlocation2);
 searchBoxlocation2.addListener('places_changed', function () {
     var places = searchBoxlocation2.getPlaces();
     if (places && places.length > 0) {
              var locationJson = {};
              var place = places[0];
              locationJson.coordinates = [place.geometry.location.lng(), place.geometry.location.lat()]; 
              locationJson.type = 'Point';
             localStorage.setItem('location',JSON.stringify(locationJson))
             var locName = place.name ? place.formatted_address : place.formatted_address;
             localStorage.setItem('location_name', locName)
     }
 });
              var currentLocation = localStorage.getItem('locationPingJson');
              if(currentLocation && currentLocation != '' && currentLocation != null ){
               currentLocation = JSON.parse(currentLocation);
               var locationString = '';
               if(currentLocation.subLocality){
                 locationString += currentLocation.subLocality;
               }
               if(currentLocation.city){
                 locationString += ", "+currentLocation.city;
               }
               if(currentLocation.city && currentLocation.subAdminArea && currentLocation.subAdminArea != currentLocation.city ){
                 locationString += ", "+currentLocation.subAdminArea;
               }
               if(currentLocation.state){
                 locationString += ", "+currentLocation.state
               }
              if(currentLocation.country){
                 locationString += ", "+currentLocation.country;
              }
              if(currentLocation.postalCode){
                 locationString += ", "+currentLocation.postalCode;
              }
              if(locationString && locationString.charAt(0) == ',' ){
                 locationString = locationString.substring(1, locationString.length);
              }     
              var location_name = localStorage.getItem('location_name');     
              if(location_name && location_name != '' && location_name != null){
                 locationString = location_name;
              }     
              $("#location2").val(locationString);
              if(currentLocation && currentLocation.long && currentLocation.long ){
                 var locationJson = {}; 
                 locationJson.coordinates = [currentLocation.long, currentLocation.lat]; 
                 locationJson.type = 'Point';
                 localStorage.setItem('location',JSON.stringify(locationJson));
              }
             }
 }
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
	$(document).on('click', '.addtocartbutton1', function(e) {
		try {
			e.preventDefault();
			var objParams = {};
			var element = $(this);
			objParams.recordID = getParameterByName('recordID');
			if ($(this).attr('recordID')) {
				objParams.recordID = $(this).attr('recordID');
			}
		
			objParams.quantity = 1;
			if ($(this).val()) {
				objParams.quantity = $(this).val();
			} else if($('input[name=quantity]').val()){
				objParams.quantity = $('input[name=quantity]').val();
			}
				objParams.quantity = $('#'+'undefined'+$(this).attr('recordID')).val();
			addtocartv2Cartitems5da73cac545050343288ce7aadd32(objParams, element);
			return false;
		} catch (error) {
			console.log('Error in addtocart click', error);
		}
	});
	$(document).on('click', '.addtocartbutton', function(e) {
		try {
			e.preventDefault();
			var objParams = {};
			var element = $(this);
			objParams.recordID = getParameterByName('recordID');
			if ($(this).attr('recordID')) {
				objParams.recordID = $(this).attr('recordID');
			}
		
			objParams.quantity = 1;
			if ($(this).val()) {
				objParams.quantity = $(this).val();
			} else if($('input[name=quantity]').val()){
				objParams.quantity = $('input[name=quantity]').val();
			}
				objParams.quantity = $('#'+'undefined'+$(this).attr('recordID')).val();
			addtocartv2Cartitems5da73cac545050343288ce7aaddproduct50(objParams, element);
			return false;
		} catch (error) {
			console.log('Error in addtocart click', error);
		}
	});
	$(document).on('click', '.addtocartbutton2', function(e) {
		try {
			e.preventDefault();
			var objParams = {};
			var element = $(this);
			objParams.recordID = getParameterByName('recordID');
			if ($(this).attr('recordID')) {
				objParams.recordID = $(this).attr('recordID');
			}
		
			objParams.quantity = 1;
			if ($(this).val()) {
				objParams.quantity = $(this).val();
			} else if($('input[name=quantity]').val()){
				objParams.quantity = $('input[name=quantity]').val();
			}
				objParams.quantity = $('#'+'undefined'+$(this).attr('recordID')).val();
			addtocartv2Cartitems5da73cac545050343288ce7aadditem59(objParams, element);
			return false;
		} catch (error) {
			console.log('Error in addtocart click', error);
		}
	});
			var objParams = {};
			getcartcountCartitems5da73cac545050343288ce7a(objParams);
			var objParams = {};
			objParams.recordID = getParameterByName('recordID');
			getreferancedatahiddenField(objParams, null);
		//start roleaccess
		var localRole = localStorage.getItem('roleName');
		if(localRole == 'customer'){
		} // end roleaccess if

 $(document).on('click', '.clearSearch', function () {
     $('#search9').val('').trigger('keyup');
     return false;
 }); // to add New record

 $(document).on('keyup', '#search9', function (e) {
     e.preventDefault();
     var objList = $("div[id^=collectioncontainer] .search");
     globalSearch($(this), objList, 'search');
     return false;
 }); // to add New record
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#imageupload26', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'pattern0details'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - imageupload26", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#imageupload44', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'pattern0details'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - imageupload44", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#imageupload55', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'pattern0details'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - imageupload55", error) 
		} 
	})
  var paramsType = {};
  paramsType.tokenKey = getParameterByName('tokenKey');
  paramsType.secretKey = getParameterByName('secretKey'); 
                     	getCountProcessBeforeCallbannerphotoupload14(paramsType, function (processBeforeRes) {
  							var ajaXCallURL = $.trim($('#ajaXCallURL').val());
 								$.ajax({
 									url: ajaXCallURL+'/milestone003/showslider_userhome_Banner5da73cac545050343288ce7ahomebanner',
 									data: paramsType,
 									type: 'POST',
 									success: function (response) {
 										if (response.status == 0) {
 											makeSlidesbannerphotoupload14(response.data)
 										} else {
 											makeSlidesbannerphotoupload14([])
 										}
 									},
 									error: function (xhr, status, error) {
 									},
 								});
 							}); 
                 function getCountProcessBeforeCallbannerphotoupload14(paramsType,callback) {
 callback(); 
                 }
  var paramsType = {};
  paramsType.tokenKey = getParameterByName('tokenKey');
  paramsType.secretKey = getParameterByName('secretKey'); 
                     	getCountProcessBeforeCallbannerphotoupload39(paramsType, function (processBeforeRes) {
  							var ajaXCallURL = $.trim($('#ajaXCallURL').val());
 								$.ajax({
 									url: ajaXCallURL+'/milestone003/showslider_userhome_Bottombanner5da73cac545050343288ce7abottombanner',
 									data: paramsType,
 									type: 'POST',
 									success: function (response) {
 										if (response.status == 0) {
 											makeSlidesbannerphotoupload39(response.data)
 										} else {
 											makeSlidesbannerphotoupload39([])
 										}
 									},
 									error: function (xhr, status, error) {
 									},
 								});
 							}); 
                 function getCountProcessBeforeCallbannerphotoupload39(paramsType,callback) {
 callback(); 
                 }
  var paramsType = {};
  paramsType.tokenKey = getParameterByName('tokenKey');
  paramsType.secretKey = getParameterByName('secretKey'); 
                     	getCountProcessBeforeCallbannerphotoupload33(paramsType, function (processBeforeRes) {
  							var ajaXCallURL = $.trim($('#ajaXCallURL').val());
 								$.ajax({
 									url: ajaXCallURL+'/milestone003/showslider_userhome_Offerbanner5da73cac545050343288ce7aofferbanner',
 									data: paramsType,
 									type: 'POST',
 									success: function (response) {
 										if (response.status == 0) {
 											makeSlidesbannerphotoupload33(response.data)
 										} else {
 											makeSlidesbannerphotoupload33([])
 										}
 									},
 									error: function (xhr, status, error) {
 									},
 								});
 							}); 
                 function getCountProcessBeforeCallbannerphotoupload33(paramsType,callback) {
 callback(); 
                 }
  var paramsType = {};
  paramsType.tokenKey = getParameterByName('tokenKey');
  paramsType.secretKey = getParameterByName('secretKey'); 
                     	getCountProcessBeforeCallbannerphotoupload21(paramsType, function (processBeforeRes) {
  							var ajaXCallURL = $.trim($('#ajaXCallURL').val());
 								$.ajax({
 									url: ajaXCallURL+'/milestone003/showslider_userhome_Productbanner5da73cac545050343288ce7aprodcutbanner',
 									data: paramsType,
 									type: 'POST',
 									success: function (response) {
 										if (response.status == 0) {
 											makeSlidesbannerphotoupload21(response.data)
 										} else {
 											makeSlidesbannerphotoupload21([])
 										}
 									},
 									error: function (xhr, status, error) {
 									},
 								});
 							}); 
                 function getCountProcessBeforeCallbannerphotoupload21(paramsType,callback) {
 callback(); 
                 }
});//end of ready
	function addtocartv2Cartitems5da73cac545050343288ce7aadd32(objParams, element) {
		try {
			objParams.userId = localStorage.getItem('userID');
			var ajaXCallURL = $.trim($('#ajaXCallURL').val());
			objParams.tokenKey = getParameterByName('tokenKey');
			objParams.secretKey = getParameterByName('secretKey');
		objParams.updatequantity = true;
		objParams.addquantity = true;
			var callUrl = ajaXCallURL + '/milestone003/addtocartv2_Cartitems5da73cac545050343288ce7a_userhome';
			$('#display_loading').removeClass('hideme');
 			addToCartV2ProcessBeforeCallCartitems5da73cac545050343288ce7aAdd(element, objParams, function(){
			$.ajax({
				url: callUrl,
				data: objParams,
				type: 'POST',
				success: function (response) {
					$('#display_loading').addClass('hideme');
 					addToCartV2ProcessAfterCallCartitems5da73cac545050343288ce7aAdd(response, function(){
					if (response.status == 0) {
						if(response.carttotal){
						    response.carttotal = Math.round(response.carttotal * 100) / 100
						}
					    if(objParams.quantity == 0){ // remove div no record found
					        $('[recordID="'+ objParams.recordID +'"]').closest('.plain-card').remove()
					    }
					    if(response.cartcount && $('#cartcountid').length){ 
					    	$('#cartcountid').html(response.cartcount); 
					    } else if(response.cartcount && $('.clsshowcartcount').length){ 
						    var cls = 'clscartcount1';
						    if(response.cartcount > 9 ) { cls = 'clscartcount2';}
						    $('.clsshowcartcount').append('<span id="cartcountid" class="'+ cls +'">'+ response.cartcount +'</span>');
						    $('#cartcountid').on('click', function(){ $('#cartcountid').parent().find('img').trigger('click'); })
					    }
			            $('#'+'cartcount5').text(response.cartcount) ;
	
	
						shareAppData('Item added to the cart successfully.', 'toast');
						return;
					} else {
 	var quantityTotal = $('#'+objParams.recordID+'_quantity').val();
 	if(quantityTotal){
		quantityTotal =  parseInt(quantityTotal)-1;
		$('#'+objParams.recordID+'_quantity').val(quantityTotal);
 	}else {
		$('#'+objParams.recordID+'_quantity').val(1);
 	}
						var errorMessage = '';
						errorMessage = 'Item is Out-of-Stock';
						if( response.error &&  response.error.trim() != ''){
							errorMessage = response.error;
						}
						if(errorMessage){
							shareAppData(errorMessage, 'toast');
						}
						return;
					 }
					}); //close client after call
				},
				error: function (xhr, status, error) {
					$('#display_loading').addClass('hideme');
				},
			});
			}); // close precessbeforecall
		} catch (error) {
			$('#display_loading').addClass('hideme');
			console.log('Error in addtocartv2_fieldname', error);
		}
	} 
 function addToCartV2ProcessBeforeCallCartitems5da73cac545050343288ce7aAdd(element, objParams, callback) { 	var response = objParams;
 callback(); 
 } 
 function addToCartV2ProcessAfterCallCartitems5da73cac545050343288ce7aAdd(response, callback) {
 callback(); 
 }
	function addtocartv2Cartitems5da73cac545050343288ce7aaddproduct50(objParams, element) {
		try {
			objParams.userId = localStorage.getItem('userID');
			var ajaXCallURL = $.trim($('#ajaXCallURL').val());
			objParams.tokenKey = getParameterByName('tokenKey');
			objParams.secretKey = getParameterByName('secretKey');
		objParams.updatequantity = true;
		objParams.addquantity = true;
			var callUrl = ajaXCallURL + '/milestone003/addtocartv2_Cartitems5da73cac545050343288ce7a_userhome';
			$('#display_loading').removeClass('hideme');
 			addToCartV2ProcessBeforeCallCartitems5da73cac545050343288ce7aAddProduct(element, objParams, function(){
			$.ajax({
				url: callUrl,
				data: objParams,
				type: 'POST',
				success: function (response) {
					$('#display_loading').addClass('hideme');
 					addToCartV2ProcessAfterCallCartitems5da73cac545050343288ce7aAddProduct(response, function(){
					if (response.status == 0) {
						if(response.carttotal){
						    response.carttotal = Math.round(response.carttotal * 100) / 100
						}
					    if(objParams.quantity == 0){ // remove div no record found
					        $('[recordID="'+ objParams.recordID +'"]').closest('.plain-card').remove()
					    }
					    if(response.cartcount && $('#cartcountid').length){ 
					    	$('#cartcountid').html(response.cartcount); 
					    } else if(response.cartcount && $('.clsshowcartcount').length){ 
						    var cls = 'clscartcount1';
						    if(response.cartcount > 9 ) { cls = 'clscartcount2';}
						    $('.clsshowcartcount').append('<span id="cartcountid" class="'+ cls +'">'+ response.cartcount +'</span>');
						    $('#cartcountid').on('click', function(){ $('#cartcountid').parent().find('img').trigger('click'); })
					    }
			            $('#'+'cartcount5').text(response.cartcount) ;
	
	
						shareAppData('Item added to the cart successfully.', 'toast');
						return;
					} else {
 	var quantityTotal = $('#'+objParams.recordID+'_quantity').val();
 	if(quantityTotal){
		quantityTotal =  parseInt(quantityTotal)-1;
		$('#'+objParams.recordID+'_quantity').val(quantityTotal);
 	}else {
		$('#'+objParams.recordID+'_quantity').val(1);
 	}
						var errorMessage = '';
						errorMessage = 'Item is Out-of-Stock';
						if( response.error &&  response.error.trim() != ''){
							errorMessage = response.error;
						}
						if(errorMessage){
							shareAppData(errorMessage, 'toast');
						}
						return;
					 }
					}); //close client after call
				},
				error: function (xhr, status, error) {
					$('#display_loading').addClass('hideme');
				},
			});
			}); // close precessbeforecall
		} catch (error) {
			$('#display_loading').addClass('hideme');
			console.log('Error in addtocartv2_fieldname', error);
		}
	} 
 function addToCartV2ProcessBeforeCallCartitems5da73cac545050343288ce7aAddProduct(element, objParams, callback) { 	var response = objParams;
 callback(); 
 } 
 function addToCartV2ProcessAfterCallCartitems5da73cac545050343288ce7aAddProduct(response, callback) {
 callback(); 
 }
	function addtocartv2Cartitems5da73cac545050343288ce7aadditem59(objParams, element) {
		try {
			objParams.userId = localStorage.getItem('userID');
			var ajaXCallURL = $.trim($('#ajaXCallURL').val());
			objParams.tokenKey = getParameterByName('tokenKey');
			objParams.secretKey = getParameterByName('secretKey');
		objParams.updatequantity = true;
		objParams.addquantity = true;
			var callUrl = ajaXCallURL + '/milestone003/addtocartv2_Cartitems5da73cac545050343288ce7a_userhome';
			$('#display_loading').removeClass('hideme');
 			addToCartV2ProcessBeforeCallCartitems5da73cac545050343288ce7aAddItem(element, objParams, function(){
			$.ajax({
				url: callUrl,
				data: objParams,
				type: 'POST',
				success: function (response) {
					$('#display_loading').addClass('hideme');
 					addToCartV2ProcessAfterCallCartitems5da73cac545050343288ce7aAddItem(response, function(){
					if (response.status == 0) {
						if(response.carttotal){
						    response.carttotal = Math.round(response.carttotal * 100) / 100
						}
					    if(objParams.quantity == 0){ // remove div no record found
					        $('[recordID="'+ objParams.recordID +'"]').closest('.plain-card').remove()
					    }
					    if(response.cartcount && $('#cartcountid').length){ 
					    	$('#cartcountid').html(response.cartcount); 
					    } else if(response.cartcount && $('.clsshowcartcount').length){ 
						    var cls = 'clscartcount1';
						    if(response.cartcount > 9 ) { cls = 'clscartcount2';}
						    $('.clsshowcartcount').append('<span id="cartcountid" class="'+ cls +'">'+ response.cartcount +'</span>');
						    $('#cartcountid').on('click', function(){ $('#cartcountid').parent().find('img').trigger('click'); })
					    }
			            $('#'+'cartcount5').text(response.cartcount) ;
	
	
						shareAppData('Item added to the cart successfully.', 'toast');
						return;
					} else {
 	var quantityTotal = $('#'+objParams.recordID+'_quantity').val();
 	if(quantityTotal){
		quantityTotal =  parseInt(quantityTotal)-1;
		$('#'+objParams.recordID+'_quantity').val(quantityTotal);
 	}else {
		$('#'+objParams.recordID+'_quantity').val(1);
 	}
						var errorMessage = '';
						errorMessage = 'Item is Out-of-Stock';
						if( response.error &&  response.error.trim() != ''){
							errorMessage = response.error;
						}
						if(errorMessage){
							shareAppData(errorMessage, 'toast');
						}
						return;
					 }
					}); //close client after call
				},
				error: function (xhr, status, error) {
					$('#display_loading').addClass('hideme');
				},
			});
			}); // close precessbeforecall
		} catch (error) {
			$('#display_loading').addClass('hideme');
			console.log('Error in addtocartv2_fieldname', error);
		}
	} 
 function addToCartV2ProcessBeforeCallCartitems5da73cac545050343288ce7aAddItem(element, objParams, callback) { 	var response = objParams;
 callback(); 
 } 
 function addToCartV2ProcessAfterCallCartitems5da73cac545050343288ce7aAddItem(response, callback) {
 callback(); 
 }
	function getcartcountCartitems5da73cac545050343288ce7a(objParams) {
		try {
			objParams.userId = localStorage.getItem('userID');
			var ajaXCallURL = $.trim($('#ajaXCallURL').val());
			objParams.tokenKey = getParameterByName('tokenKey');
			objParams.secretKey = getParameterByName('secretKey');
	
			var callUrl = ajaXCallURL + '/milestone003/getcartcount_Cartitems5da73cac545050343288ce7a';
			$('#display_loading').removeClass('hideme');
			$.ajax({
				url: callUrl,
				data: objParams,
				type: 'POST',
				success: function (response) {
                getcartcountProcessAfterCartitems5da73cac545050343288ce7a(response, function(){
					$('#display_loading').addClass('hideme');
					if (response.status == 0) {
						if(response.carttotal){
						    response.carttotal = Math.round(response.carttotal * 100) / 100
						}
						if(response.cartcount && $('.clsshowcartcount').length){
						    var cls = 'clscartcount1';
						    if(response.cartcount > 9 ) { cls = 'clscartcount2';}
						    $('.clsshowcartcount').append('<span id="cartcountid" class="'+ cls +'">'+ response.cartcount +'</span>');
						    $('#cartcountid').on('click', function(){ $('#cartcountid').parent().find('img').trigger('click'); })
						} else if(response.cartcount){
						    $('.clscartcount').html(response.cartcount).removeClass('hide');
						}
						response.cartcount = response.cartcount ? response.cartcount : '0';
						$('#cartcount5').html(' '+ response.cartcount+' ');
						return;
					} else {
						return;
					}
				  })
				},
				error: function (xhr, status, error) {
					$('#display_loading').addClass('hideme');
				},
			});
		} catch (error) {
			$('#display_loading').addClass('hideme');
			console.log('Error in getcartcount_fieldname', error);
		}
	} 
 function getcartcountProcessAfterCartitems5da73cac545050343288ce7a(response,callback) {
 callback(); 
 }
	function getreferancedatahiddenField(objParams, element) {
		try {
			objParams.userId = localStorage.getItem('userID');
			var ajaXCallURL = $.trim($('#ajaXCallURL').val());
			objParams.tokenKey = getParameterByName('tokenKey');
			objParams.secretKey = getParameterByName('secretKey');
			var callUrl = ajaXCallURL + '/milestone003/getreferancedata_userhome_hiddenField';
			$('#display_loading').removeClass('hideme');
          getreferancedataProcessBeforeCallhiddenField(objParams, function(){
			    $.ajax({
			    	url: callUrl,
			    	data: objParams,
			    	type: 'POST',
			    	success: function (response) {
			    		$('#display_loading').addClass('hideme');
                      var tokenKey = getParameterByName('tokenKey');
                      var secretKey = getParameterByName('secretKey');
                      var recordID = getParameterByName('recordID');
                      var queryMode = getParameterByName('queryMode');
                      queryMode = queryMode.replace('edit', '');
                      getreferancedataProcessAfterCallhiddenField(response, function(){
                      
	   var locationicon = $('#locationicon3');
	   var okbutton = $('#ok62');
	   var locationtext = $('#location2');
	   var modalmessage = $('#modalmessage61');
 var location = localStorage.getItem("location");
var location_name = localStorage.getItem("location_name");

if (response && response.settingdata) {
    var data = response.settingdata;
    location = location ? JSON.parse(location) : {};
    if (location && location.coordinates && location_name) {
        $('input[id^="location"]').val(location_name);
        //getdelivery location
        if (location && location.coordinates && location.coordinates[1]) {
            var lon1 = location.coordinates[0]
            var lat1 = location.coordinates[1]
        }

        //get storelocation
        var storelocation = data.address;
        var scoperadius = data.daescoscoperadius;
        scoperadius = scoperadius ? parseFloat(scoperadius) : 0;
        storelocation = storelocation ? storelocation : {};

        if (storelocation && storelocation.coordinates && storelocation.coordinates[1]) {
            localStorage.setItem('warningdisplayed', 1);
            var lon2 = storelocation.coordinates[0]
            var lat2 = storelocation.coordinates[1]
            var km = getDistanceByLatLong(lat1, lon1, lat2, lon2, 'K');
            if (scoperadius && scoperadius < km) {
                // trigger warning popup
                modalmessage.html("Sorry! we are not delivering our products in your locality. Please change your location");
                $('#confirmationmodal').modal('open');
            } else {
                //trigger info popup				
            }
        } else {
            locationicon.trigger('click');
        }
    } else {
        locationicon.trigger('click');
    }
} else if (location_name) {
    $('input[id^="location"]').val(location_name);
}
		                });
			    	},
		    		error: function (xhr, status, error) {
		    			$('#display_loading').addClass('hideme');
                          handleError(xhr, status, error); 
		    		},
		    	});
		    });
		} catch (error) {
			$('#display_loading').addClass('hideme');
			console.log('Error in getreferancedata_fieldname', error);
		}
	} 
 function getreferancedataProcessBeforeCallhiddenField(objParams,callback) {
 callback(); 
 } 
 function getreferancedataProcessAfterCallhiddenField(response,callback) {
 callback(); 
 }