
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_financialcalculateadd'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "add"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#ok16', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_financialcalculateadd'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "add"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - ok16", error) 
		} 
	})
      $('#display_loading1').removeClass('hideme');
      var paramsEdit = {};
      paramsEdit.tokenKey = getParameterByName('tokenKey');
      paramsEdit.secretKey = getParameterByName('secretKey') 
                       getRecordByIDProcessBeforeCall977060(paramsEdit, function (processBeforeRes) {
      $.ajax({
          url: ajaXCallURL+'/milestone003/getRecordByCustomeQuery_app_financialgoaldetails_Usermanagement5da73cac545050343288ce7a',
          data: paramsEdit,
          type: 'POST',
          jsonpCallback: 'callback',
          success: function (response) { 
                       getRecordByIDProcessAfterCall977060(response, function (processBeforeRes) {
                        $('#display_loading1').addClass('hideme');
                        $('#sg9253').removeClass('hideme');
              if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                  var objParamsList = {};
                  var queryMode = $('#queryMode').val(); 
                  objParamsList.queryMode = queryMode;;
                  var tokenKey = $('#tokenKey').val();;
                  objParamsList.tokenKey = tokenKey;;
             if(response.recordDetails.shortfall != undefined) $('#shortfall15').val(response.recordDetails.shortfall);
  if(!$('#backbutton1').html()){
            $('#backbutton1').append(response.recordDetails.undefined);
 }
  if(!$('#financialgoalsdetails2').html()){
            $('#financialgoalsdetails2').append(response.recordDetails.undefined);
 }
 response.recordDetails['savings_preserved'] = response.recordDetails['savings'] ;
 response.recordDetails['savings'] = response.recordDetails['savings']  ? moment(new Date(response.recordDetails['savings'])).format('DD MMM YYYY') : '';
  if(!$('#savings8').html()){
            $('#savings8').append(response.recordDetails.savings);
 }
 response.recordDetails['savings'] =  response.recordDetails['savings_preserved'];
  if(!$('#years9').html()){
            $('#years9').append(response.recordDetails.years);
 }
             if(response.recordDetails.inflationrate != undefined) $('#inflationrate14').val(response.recordDetails.inflationrate);
  if(!$('#currentsaving10').html()){
            $('#currentsaving10').append(response.recordDetails.currentsaving);
 }
  if(!$('#resultmessage12').html()){
            $('#resultmessage12').append(response.recordDetails.resultmessage);
 }
             if(response.recordDetails.investmentrequipredpermonth != undefined) $('#investmentrequipredpermonth13').val(response.recordDetails.investmentrequipredpermonth);
  if(!$('#results7').html()){
            $('#results7').append(response.recordDetails.undefined);
 }

              Materialize.updateTextFields();
                $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);
  
              } 
              }); // end of getRecord By ID
          },
          error: function (xhr, status, error) {
              handleError(xhr, status, error); 
          },
      }); 
              }); // end of getRecord By ID
   
});//end of ready 
                 function getRecordByIDProcessBeforeCall977060(paramsType,callback) { 
                 var response = paramsType;
 
paramsType.recordID = localStorage.userID;
callback(); 
                 } 
                 function getRecordByIDProcessAfterCall977060(response,callback) {
                     if(response.recordDetails.investmentrequipredpermonth == null)
                     {
                         response.recordDetails.investmentrequipredpermonth = 0;
                     }
                    var resultmessage = 'Something went wrong, please try again later.';
                    if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                        resultmessage = "Based on your targeted savings, you will need to set aside  <b>$ " + formatNumber(response.recordDetails.savings) + "</b> to plan towards your financial goals.<br/><br/>";
                        resultmessage += "You still have a shortfall of <b>$" + formatNumber(response.recordDetails.shortfall) + "</b>.Based on average inflation rate of <b>" + response.recordDetails.inflationrate + " % </b>, you need to save <b>$" + formatNumber(response.recordDetails.investmentrequipredpermonth.toFixed(2)) + " / month </b>in order to achieve this goal by <b>" + response.recordDetails.years + "</b>.<br/><br/>";
                        resultmessage += "To find out how you can save up for your financial goals efficiently, you might want to seek advice from a professional financial consultant.<br/><br/>";
                    //    resultmessage += "If you are planning for wedding, refer to our merchant list for wedding planners.";
                    }
                    $('div[id^="resultmessage"]').html(resultmessage);
                    callback(); 
                 }
                 function formatNumber(num) {
                    return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
                  }