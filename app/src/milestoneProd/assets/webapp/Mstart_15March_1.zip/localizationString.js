

$(function() {

  // var t = {
  //   "Toggle navigation": {
  //     pt: "Mostrar/esconder navegação"
  //   },
  //   "Trending": {
  //     ch: "Início"
  //   },
  //   "See All": {
  //     pt: "Início"
  //   },
  //   About: {
  //     pt: "Acerca"
  //   },
  //   "Language": {
  //     pt: "Idioma"
  //   },
  //   "Step": {
  //     pt: "Passo"
  //   },
  //   subtitle_key: {
  //     en: "translate.js is a jQuery plugin to translate text in the client side.",
  //     pt: "translate.js é um plugin JQuery para traduzir texto client side."
  //   },
  //   "Usage: translate entire page": {
  //     pt: "Uso: traduzir uma página inteira"
  //   },
  //   "Usage: translate a string": {
  //     pt: "Uso: traduzir uma string"
  //   },
  //   step1: {
  //     en: "include JQuery and translate.js in your page",
  //     pt: "incluir JQuery e translate.js na página"
  //   },
  //   step2: {
  //     en: "every text you want translated include the <code>trn</code> class",
  //     pt: "incluir a classe <code>trn</code> no texto a traduzir"
  //   },
  //   step3: {
  //     en: "create your dictionary",
  //     pt: "criar o dicionário"
  //   },
  //   step4: {
  //     en: "initialize the plugin and translate the entire page body",
  //     pt: "iniciar o plugin e traduzir o body da página"
  //   },
  //   step5: {
  //     en: "change to another language",
  //     pt: "mudar para outro idioma"
  //   },
  //   step6: {
  //     en: "try it",
  //     pt: "experimentar"
  //   },
  //   "translate to English": {
  //     pt: "traduzir para Inglês"
  //   },
  //   "translate to Portuguese": {
  //     pt: "traduzir para Português"
  //   },
  //   string_translate_key: {
  //     en: "After you initialize the component you can translate a string",
  //     pt: "Depois do componente iniciado, pode-se traduzir uma string"
  //   },
  //   "Download translate.js": {
  //     pt: "Descarregar translate.js"
  //   }
  // };




  var t = dataJson;

  var language = localStorage.getItem('lan');

  var _t = $('body').translate({lang: language, t: t});
  var str = _t.g("translate");
  //console.log(str);

  $(".lang_selector").click(function(ev) {
    var lang = $(this).attr("data-value");
    if(lang=="en"){
      localStorage.setItem('lan','en');
      $('#chaina').css('display','block');
      $('#usa').css('display','none');
    }else{
      localStorage.setItem('lan','ch');
      $('#chaina').css('display','none');
      $('#usa').css('display','block');
    }
    _t.lang(lang);

    console.log(lang);
    ev.preventDefault();
  });



});



    
    

