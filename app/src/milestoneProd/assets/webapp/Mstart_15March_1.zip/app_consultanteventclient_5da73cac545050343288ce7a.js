
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
     var totaldcard_leftimage_collectioncontainer = 0;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }
//   showFilterBox(); 
 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];


  var queryMode = getParameterByName('queryMode');
      var isMobile = $('#isMobile').val();
      var isiPad = $('#isiPad').val();
      if(queryMode != ''){
          var tokenKey = $('#tokenKey').val();
          var objParamsList = {};
          objParamsList.queryMode = queryMode;
          var ajaXCallURL = $.trim($('#ajaXCallURL').val());
          objParamsList.tokenKey = getParameterByName('tokenKey');
          objParamsList.secretKey = getParameterByName('secretKey');
          objParamsList.ajaXCallURL = ajaXCallURL;
          objParamsList.isMobile = isMobile;
          objParamsList.isiPad = isiPad;
          objParamsList.applyFilter = false;
          getDataProcessBeforeCalldcard_leftimage_collectioncontainerUsermanagement5da73cac545050343288ce7a(objParamsList,function(processBeforeRes){
 if(getParameterByName('consultantid') && getParameterByName('consultantid') != '' && getParameterByName('consultantid') != null  && getParameterByName('consultantid') != 'undefined' ){
 objParamsList.consultantid =  getParameterByName('consultantid');
 }
          var dcard_leftimage_collectioncontainerapp_consultantclientlisting = localStorage.getItem('dcard_leftimage_collectioncontainerapp_consultantclientlisting');
          var  applyFilter = getParameterByName('applyFilter');
          $('#display_loading').removeClass('hideme');
          if (dcard_leftimage_collectioncontainerapp_consultantclientlisting && applyFilter != 'true' ) {
              response = JSON.parse(dcard_leftimage_collectioncontainerapp_consultantclientlisting);
              $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html('');
              getdcard_leftimage_collectioncontainerapp_consultantclientlistingMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
              dcard_leftimage_collectioncontainerapp_consultantclientlistingSync(response.timestamp);   
          } else {
         show_dcard_leftimage_collectioncontainerapp_consultantclientlisting_Details(objParamsList)
          }
          });//End of get data process before call.
  }
 $(document).on('click', '.dcard_leftimage_collectioncontainers', function () {
   if(dcardLoaded && !dcardLoaded['dcard_leftimage_collectioncontainer']) { return false;}; // added for use should not able to click until data loaded
   localStorage.setItem("headerPageName", 'app_consultantclientdetails') ;
   var recordID =  $(this).attr('recordID');// get record ID;
   var usermanagementid =  $(this).attr('recordID');// get record ID;
   var tokenKey = getParameterByName('tokenKey');
   var secretKey = getParameterByName('secretKey');
   var queryMode = 'update';
   var nextPage = 'app_consultantclientdetails';
   if(!nextPage){
      return false;
   }
   var pageurl =  nextPage + '_5da73cac545050343288ce7a.html?queryMode='+ queryMode+'&tokenKey='+tokenKey+ '&secretKey=' + secretKey+ '&usermanagementid=' + usermanagementid+ '&recordID=' + recordID+'&applyFilter=true';
   window.location.href = pageurl;
   return false;
 }); // to add New record

		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_productadditionaldetails'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "update"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
  showBottomMenu(); 
});//end of ready
 function getDataProcessBeforeCalldcard_leftimage_collectioncontainerUsermanagement5da73cac545050343288ce7a(objParamsList,callback){
      var response = objParamsList
objParamsList.consultantid = localStorage.getItem("userID");
callback();
 }
 function dcard_leftimage_collectioncontainerapp_consultantclientlistingSync(timestamp) {
     try {
         var objParamsList = {};
         objParamsList.queryMode = 'mylist';
         var ajaXCallURL = $.trim($('#ajaXCallURL').val());
         objParamsList.tokenKey = getParameterByName('tokenKey');
         objParamsList.secretKey = getParameterByName('secretKey');
         objParamsList.ajaXCallURL = ajaXCallURL;
         objParamsList.isMobile = true;
         objParamsList.timestamp = timestamp;
         $.ajax({
             url: objParamsList.ajaXCallURL + '/milestone003/syncListDetails_Usermanagement5da73cac545050343288ce7a_app_consultantclientlisting',
             data: objParamsList,
             type: 'POST',
             success: function (response) {
              $('#display_loading').addClass('hideme');
                 if (response.status != undefined && response.status == 1) {
                     localStorage.removeItem('dcard_leftimage_collectioncontainerapp_consultantclientlisting');
                     var objParamsList = {};
                     objParamsList.queryMode = 'mylist';
                     var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                     objParamsList.bazaarid = getParameterByName('recordID');
                     objParamsList.tokenKey = getParameterByName('tokenKey');
                     objParamsList.secretKey = getParameterByName('secretKey');
                     objParamsList.ajaXCallURL = ajaXCallURL;
                     objParamsList.isMobile = 'true';
                     objParamsList.isiPad = false;
                     objParamsList.timestamp = timestamp; 
 if(getParameterByName('consultantid') && getParameterByName('consultantid') != '' && getParameterByName('consultantid') != null  && getParameterByName('consultantid') != 'undefined' ){
    objParamsList.consultantid =  getParameterByName('consultantid');
 }
         show_dcard_leftimage_collectioncontainerapp_consultantclientlisting_Details(objParamsList)
                 }
             },
             error: function (xhr, status, error) { 
                 handleError(xhr, status, error); 
             } 
         });
     } catch (err) {
        // console.log('Error in workingtoolsSync', err);
     }
 }
         function show_dcard_leftimage_collectioncontainerapp_consultantclientlisting_Details(objParamsList){ 
 //if(getParameterByName('consultantid') && getParameterByName('consultantid') != '' && getParameterByName('consultantid') != null  && getParameterByName('consultantid') != 'undefined' ){
 
 
 var appUserID =  localStorage.getItem("userID");
 objParamsList.bazaarid = getParameterByName('recordID');
 objParamsList.consultantid = appUserID//getParameterByName('consultantid');
// }
         localStorage.setItem('appconsultantclientlistingFilterBox','');
 
          $.ajax({
              url: objParamsList.ajaXCallURL+'/milestone003/getListDetails_Usermanagement5da73cac545050343288ce7a_app_consultanteventclient_dcard_leftimage_collectioncontainer',
              data: objParamsList,
              type: 'POST',
              success: function (response) {
                      getDataProcessAfterCalldcard_leftimage_collectioncontainerUsermanagement5da73cac545050343288ce7a(response, function(){
                      if (response.status != undefined && response.status == 0) {
                     if (objParamsList.isMobile == 'true') {    
                             $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html('');
                            //localStorage.removeItem('dcard_leftimage_collectioncontainerapp_consultantclientlisting');
                            localStorage.setItem('dcard_leftimage_collectioncontainerapp_consultantclientlisting',JSON.stringify(response));
                              getdcard_leftimage_collectioncontainerapp_consultantclientlistingMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
                          } else if (objParamsList.isiPad == 'true') {    
                              getdcard_leftimage_collectioncontainerapp_consultantclientlistingiPadView(response, objParamsList.tokenKey, objParamsList.queryMode);
                          } else {
                              getdcard_leftimage_collectioncontainerapp_consultantclientlistingWebView(response, objParamsList.tokenKey,objParamsList.queryMode);
                          }
                          $('#display_loading').addClass('hideme');
                     } else {   
                          $('#display_loading').addClass('hideme')
                     }   
                   });   
                  },        
                  error: function (xhr, status, error) {        
                          $('#display_loading').addClass('hideme')
                          handleError(xhr, status, error); 
                  },        
              });  
        } // end of function     
                  
 function getDataProcessAfterCalldcard_leftimage_collectioncontainerUsermanagement5da73cac545050343288ce7a(response,callback){

      callback();
 }

        function getdcard_leftimage_collectioncontainerapp_consultantclientlistingMobileView(response, tokenKey, queryMode) {
              var html = '';
              if (response.data.length == 0) {
                  html += '<div class="nodatafound">';
                  html +=     '<img src="nodatafound.gif" width="100%">';
                  html +=         '<br>';
                  html +=     '<!-- span>No record found</span -->';
                  html += '</div>';
                  $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html); ;
             } else {
              html =       '';
              var radioGroups =       [];
              $.each(response.data, function (keyList, objList) {
                  
                  var ios = navigator.userAgent.toLowerCase().indexOf("iphone os"); 
                  var isAndroid = navigator.userAgent.toLowerCase().indexOf("android"); 
                  if(isAndroid > -1 || ios > -1){  // need to fix with native gyes.. images not getting download
                      var mediaID = '';
                      var fileName = '';
                      if(objList['userphotoupload'] && objList['userphotoupload'][0].mediaID){
                          mediaID = objList['userphotoupload'][0].mediaID;
                          fileName = objList['userphotoupload'][0].mediaID + '.png';
                      }
                      getLocalImagedcard_leftimage_collectioncontainer(objList, mediaID, fileName); 
                  }else {
               
 html += '      <div class="row plain-card search" search="'+ removeSpecialChars(  objList.imageupload  + objList.clientname_name  + objList.clientcontact  + objList.createdon  + objList.address_name) +'">';
 html += '      		<div class="col s12 m12">';
 html += '               <div class="card-content">';
 html += '                  <div     status="'+ objList.status+ '"  recordID="'+objList._id+'" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
 html += '      <div class="row  element" style="cursor: none;"  >';
 html += '      <div class="col s3 cls_sg6599" style="">';
  var localFilePath = '';
  if(response && response.localFilePath){
     localFilePath = response.localFilePath;
  }
 html += '           <div class="col s12 clssg0699" style="">';
 var filetodisplay = ''; 
 if(objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID){
    filetodisplay = getuploadedfilepreview(objList.userphotoupload[0].fileNm);
 }
 if ( localFilePath && localFilePath != '' ) {
     html += '               <img recordID="'+objList._id+'"  id="userphotoupload11"   class=" clssg0699image userphotoupload11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/default-user.png\'" src="'+ localFilePath+'" mediaid="'+ objList.mediaID +'" filenm="'+ objList.filenm +'" >';
 } else if(objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID){
    if(filetodisplay && filetodisplay != objList.userphotoupload[0].fileNm){
        html += '               <img recordID="'+objList._id+'"    id="userphotoupload11"   class=" clssg0699image userphotoupload11" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/default-user.png\'" src="'+ filetodisplay + '">';
    } else {
        html += '               <img recordID="'+objList._id+'"    id="userphotoupload11"   class=" clssg0699image userphotoupload11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/default-user.png\'" src="'+ CDN_PATH+objList.userphotoupload[0].mediaID+'_compressed.png">';
    }
 } else{
    // stage 6666666666666666
     html += '               <img recordID="'+objList._id+'"   id="userphotoupload11"   class=" clssg0699image userphotoupload11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/default-user.png\'" src="default-user.png">';
 }
 html += '           </div>';
 html += '     </div>';
 html += '      <div class="col s9 cls_sg8599 addshimmer" style="">';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg2699  '+adddbclass+' " style=" cursor: pointer;">';
 objList['name'] = objList['name'] ? objList['name'] : '';
 if(response.showShimmer){
    objList['name'] = '';
 }
 var name = objList['name'];
 html += '           <div recordID="' + objList._id +'"   id="name12" class="languagetranslation " style="" >'+ name+'</div>';
 html += '     </div>';
//  var adddbclass = ''
//  html += '           <div recordID="'+objList._id+'" class="col s12 clssg4699  '+adddbclass+' " style=" cursor: pointer;">';
//  objList['contactnumber'] = objList['contactnumber'] ? objList['contactnumber'] : '';
//  if(response.showShimmer){
//     objList['contactnumber'] = '';
//  }
//  var contactnumber = objList['contactnumber'];
//  html += '           <div recordID="' + objList._id +'"   id="contactnumber13" class="languagetranslation " style="" >'+ contactnumber+'</div>';
//  html += '     </div>';
//  var adddbclass = ''
//  html += '           <div recordID="'+objList._id+'" class="col s12 clssg6699  '+adddbclass+' " style=" cursor: pointer;">';
//  objList['createdOn'] = objList['createdOn'] ? moment(new Date(objList['createdOn'])).format('DD MMMM YYYY hh:mm A') : '';
//  var createdOn = objList['createdOn'];
//  html += '           <div recordID="' + objList._id +'"   id="createdOn14" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Added on</span>'+ createdOn+ '</div>';
//  html += '     </div>';
//Show silver/ gold customer
var adddbclass = ''
html += '           <div recordID="'+objList._id+'" class="col s12 clssg4699  '+adddbclass+' " style=" cursor: none;">';
objList['referedby'] = objList['referedby'] ? objList['referedby'] : '';
if(response.referedby){
   objList['referedby'] = '';

var referedby = objList['referedby'];
html += '           <div recordID="' + objList._id +'"   id="customertype" class="languagetranslation " style="" >Referred by: '+ referedby+'</div>';
}
html += '     </div>';

var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg6699  '+adddbclass+' " style=" cursor: none;">';

 objList['createdOn'] = objList['createdOn'] ? moment(new Date(objList['createdOn'])).format('DD MMM YYYY') : '';
                var createdOn = objList['createdOn'];
 html += '           <div recordID="' + objList._id +'"   id="createdOn14" class="languagetranslation " style="" >Registration date: '+ createdOn+ '</div>';
 html += '     </div>';

 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg8699  '+adddbclass+' " style=" cursor: none;">';
 objList['address_name'] = objList['address_name'] ? objList['address_name'] : '';
 if(response.showShimmer){
    objList['address_name'] = '';
 }
 var address_name = objList['address_name'];
 html += '           <div recordID="' + objList._id +'"   id="address_name15" class="languagetranslation " style="" >'+ address_name+'</div>';
 html += '     </div>';
 html += '     </div>';
 html += '     </div>';
 html += '      				</div>';
 html += '          </div>';
 html += '        </div>';
 html += '     </div>';
 html += '   </div>';
                  }
             });
                  var ios = navigator.userAgent.toLowerCase().indexOf("iphone os"); 
                  var isAndroid = navigator.userAgent.toLowerCase().indexOf("android"); 
                  if(1){ 
                          $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html)
                   $('#full-body-container').addClass('fadeInUp');
                  };
                  if(!response.showShimmer){
                      dcardLoaded['dcard_leftimage_collectioncontainer'] = true;
                      $('#collectioncontainerDivdcard_leftimage_collectioncontainer').find('.view_list_record').removeClass('shimmer');
                  }
                  $('.carddropdown').material_select();
                  $('<input>').attr({type: 'hidden',class: 'cardtoggleswitch',id: 'togleswitchvalue'}).appendTo('body')
                  if($('.js-candlestick').length) $('.js-candlestick').candlestick({afterSetting: function(input, wrapper, value) {$('#togleswitchvalue').val(value).attr('recordID', input.attr('id')).trigger('click');}});
                  if(radioGroups && radioGroups.length){
                      for(var key in radioGroups){
                          var groupName = radioGroups[key];
                          $('input:radio[name='+ groupName +']:first').prop('checked', true);
                          $('input:radio[name='+ groupName +']:first').trigger('change');
                      }
                  }
              };
            };
            function getLocalImagedcard_leftimage_collectioncontainer(objList, mediaID, fileName) {
                try {
                    var appJSON = {};
                    appJSON.nextButtonCallback = 'handleLocalImagedcard_leftimage_collectioncontainer';
                    appJSON.url = CDN_PATH + mediaID+ '_compressed.png';
                    appJSON.fileMimeType = 'image/png';
                    appJSON.fileName = fileName;
                    appJSON.objList = objList;
                    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
                    if (isAndroid > -1) {
                        window.Android.getLocalImage(JSON.stringify(appJSON))
                    } else {
                        setupWebViewJavascriptBridge(function (bridge) {
                            bridgeObj = bridge;
                            bridgeObj.callHandler('getLocalImage', appJSON, function (response) { });
                            bridgeObj.registerHandler('handleLocalImagedcard_leftimage_collectioncontainer', function (responseData, responseCallback) {
                                handleLocalImagedcard_leftimage_collectioncontainer(responseData)
                            });
                        });
                    }
                } catch (err) {
            
                }
            }
            function handleLocalImagedcard_leftimage_collectioncontainer(response) {
               var objList = response.dataDictionay.objList;
               var html = '';
               
 html += '      <div class="row plain-card search" search="'+ removeSpecialChars(  objList.imageupload  + objList.clientname_name  + objList.clientcontact  + objList.createdon  + objList.address_name) +'">';
 html += '      		<div class="col s12 m12">';
 html += '               <div class="card-content">';
 html += '                  <div     status="'+ objList.status+ '"  recordID="'+objList._id+'" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
 html += '      <div class="row  element" style=""  >';
 html += '      <div class="col s3 cls_sg6599" style="">';
  var localFilePath = '';
  if(response && response.localFilePath){
     localFilePath = response.localFilePath;
  }
 html += '           <div class="col s12 clssg0699" style="">';
 var filetodisplay = ''; 
 if(objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID){
    filetodisplay = getuploadedfilepreview(objList.userphotoupload[0].fileNm);
 }
 if ( localFilePath && localFilePath != '' ) {
     html += '               <img recordID="'+objList._id+'"  id="userphotoupload11"   class=" clssg0699image userphotoupload11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ localFilePath+'" mediaid="'+ objList.mediaID +'" filenm="'+ objList.filenm +'" >';
 } else if(objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID){
    if(filetodisplay && filetodisplay != objList.userphotoupload[0].fileNm){
        html += '               <img recordID="'+objList._id+'"    id="userphotoupload11"   class=" clssg0699image userphotoupload11" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ filetodisplay + '">';
    } else {
        html += '               <img recordID="'+objList._id+'"    id="userphotoupload11"   class=" clssg0699image userphotoupload11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ CDN_PATH+objList.userphotoupload[0].mediaID+'_compressed.png">';
    }
 } else{
    // stage 6666666666666666
     html += '               <img recordID="'+objList._id+'"   id="userphotoupload11"   class=" clssg0699image userphotoupload11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
 }
 html += '           </div>';
 html += '     </div>';
 html += '      <div class="col s9 cls_sg8599 addshimmer" style="">';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg2699  '+adddbclass+' " style=" cursor: pointer;">';
 objList['name'] = objList['name'] ? objList['name'] : '';
 if(response.showShimmer){
    objList['name'] = '';
 }
 var name = objList['name'];
 html += '           <div recordID="' + objList._id +'"   id="name12" class="languagetranslation " style="" >'+ name+'</div>';
 html += '     </div>';
//  var adddbclass = ''
//  html += '           <div recordID="'+objList._id+'" class="col s12 clssg4699  '+adddbclass+' " style=" cursor: pointer;">';
//  objList['contactnumber'] = objList['contactnumber'] ? objList['contactnumber'] : '';
//  if(response.showShimmer){
//     objList['contactnumber'] = '';
//  }
//  var contactnumber = objList['contactnumber'];
//  html += '           <div recordID="' + objList._id +'"   id="contactnumber13" class="languagetranslation " style="" >'+ contactnumber+'</div>';
//  html += '     </div>';
//  var adddbclass = ''
//  html += '           <div recordID="'+objList._id+'" class="col s12 clssg6699  '+adddbclass+' " style=" cursor: pointer;">';
//  objList['createdOn'] = objList['createdOn'] ? moment(new Date(objList['createdOn'])).format('DD MMMM YYYY hh:mm A') : '';
//  var createdOn = objList['createdOn'];
//  html += '           <div recordID="' + objList._id +'"   id="createdOn14" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Added on</span>'+ createdOn+ '</div>';
//  html += '     </div>';
//New 
var adddbclass = ''
html += '           <div recordID="'+objList._id+'" class="col s12 clssg4699  '+adddbclass+' " style=" cursor: pointer;">';
objList['customertype'] = objList['customertype'] ? objList['customertype'] : '';
if(response.showShimmer){
   objList['customertype'] = '';
}
var customertype = objList['customertype'];
html += '           <div recordID="' + objList._id +'"   id="customertype" class="languagetranslation " style="" >'+ customertype+'</div>';
html += '     </div>';

var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg6699  '+adddbclass+' " style=" cursor: pointer;">';
 objList['membership'] = objList['membership'] ?  objList['membership']: '';
 var membership = objList['membership'];
 html += '           <div recordID="' + objList._id +'"   id="createdOn14" class="languagetranslation " style="" >'+ membership+ ' Customer</div>';
 html += '     </div>';

//New End


 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg8699  '+adddbclass+' " style=" cursor: pointer;">';
 objList['address_name'] = objList['address_name'] ? objList['address_name'] : '';
 if(response.showShimmer){
    objList['address_name'] = '';
 }
 var address_name = objList['address_name'];
 html += '           <div recordID="' + objList._id +'"   id="address_name15" class="languagetranslation " style="" >'+ address_name+'</div>';
 html += '     </div>';
 html += '     </div>';
 html += '     </div>';
 html += '      				</div>';
 html += '          </div>';
 html += '        </div>';
 html += '     </div>';
 html += '   </div>';
               $('#collectioncontainerDivdcard_leftimage_collectioncontainer').append(html)
              $('#full-body-container').addClass('fadeInUp');
        dcardLoaded['dcard_leftimage_collectioncontainer'] = true;
        $('#collectioncontainerDivdcard_leftimage_collectioncontainer').find('.view_list_record').removeClass('shimmer');
        // after html bining code
        };

        function getdcard_leftimage_collectioncontainerapp_consultantclientlistingPadView(response, tokenKey, queryMode) {
              var html = '';
              if (response.data.length == 0) {
                              html += '<tr>';
                              html +=     '<td colspan="1" class="text_center first_row_table_td">';
                              html +=         'No record found';
                              html +=     '</td>';
                              html += '</tr>';
             } else {
              html =       '';
              $.each(response.data, function (keyList, objList) {
               
 html += '      <div class="row plain-card search" search="'+ removeSpecialChars(  objList.imageupload  + objList.clientname_name  + objList.clientcontact  + objList.createdon  + objList.address_name) +'">';
 html += '      		<div class="col s12 m12">';
 html += '               <div class="card-content">';
 html += '                  <div     status="'+ objList.status+ '"  recordID="'+objList._id+'" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
 html += '      <div class="row  element" style=""  >';
 html += '      <div class="col s3 cls_sg6599" style="">';
  var localFilePath = '';
  if(response && response.localFilePath){
     localFilePath = response.localFilePath;
  }
 html += '           <div class="col s12 clssg0699" style="">';
 var filetodisplay = ''; 
 if(objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID){
    filetodisplay = getuploadedfilepreview(objList.userphotoupload[0].fileNm);
 }
 if ( localFilePath && localFilePath != '' ) {
     html += '               <img recordID="'+objList._id+'"  id="userphotoupload11"   class=" clssg0699image userphotoupload11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ localFilePath+'" mediaid="'+ objList.mediaID +'" filenm="'+ objList.filenm +'" >';
 } else if(objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID){
    if(filetodisplay && filetodisplay != objList.userphotoupload[0].fileNm){
        html += '               <img recordID="'+objList._id+'"    id="userphotoupload11"   class=" clssg0699image userphotoupload11" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ filetodisplay + '">';
    } else {
        html += '               <img recordID="'+objList._id+'"    id="userphotoupload11"   class=" clssg0699image userphotoupload11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ CDN_PATH+objList.userphotoupload[0].mediaID+'_compressed.png">';
    }
 } else{
    // stage 6666666666666666
     html += '               <img recordID="'+objList._id+'"   id="userphotoupload11"   class=" clssg0699image userphotoupload11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
 }
 html += '           </div>';
 html += '     </div>';
 html += '      <div class="col s9 cls_sg8599 addshimmer" style="">';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg2699  '+adddbclass+' " style=" cursor: pointer;">';
 objList['name'] = objList['name'] ? objList['name'] : '';
 if(response.showShimmer){
    objList['name'] = '';
 }
 var name = objList['name'];
 html += '           <div recordID="' + objList._id +'"   id="name12" class="languagetranslation " style="" >'+ name+'</div>';
 html += '     </div>';
//  var adddbclass = ''
//  html += '           <div recordID="'+objList._id+'" class="col s12 clssg4699  '+adddbclass+' " style=" cursor: pointer;">';
//  objList['contactnumber'] = objList['contactnumber'] ? objList['contactnumber'] : '';
//  if(response.showShimmer){
//     objList['contactnumber'] = '';
//  }
//  var contactnumber = objList['contactnumber'];
//  html += '           <div recordID="' + objList._id +'"   id="contactnumber13" class="languagetranslation " style="" >'+ contactnumber+'</div>';
//  html += '     </div>';
//  var adddbclass = ''
//  html += '           <div recordID="'+objList._id+'" class="col s12 clssg6699  '+adddbclass+' " style=" cursor: pointer;">';
//  objList['createdOn'] = objList['createdOn'] ? moment(new Date(objList['createdOn'])).format('DD MMMM YYYY hh:mm A') : '';
//  var createdOn = objList['createdOn'];
//  html += '           <div recordID="' + objList._id +'"   id="createdOn14" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Added on</span>'+ createdOn+ '</div>';
//  html += '     </div>';
//New 
var adddbclass = ''
html += '           <div recordID="'+objList._id+'" class="col s12 clssg4699  '+adddbclass+' " style=" cursor: pointer;">';
objList['customertype'] = objList['customertype'] ? objList['customertype'] : '';
if(response.showShimmer){
   objList['customertype'] = '';
}
var customertype = objList['customertype'];
html += '           <div recordID="' + objList._id +'"   id="customertype" class="languagetranslation " style="" >'+ customertype+'</div>';
html += '     </div>';

var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg6699  '+adddbclass+' " style=" cursor: pointer;">';
 objList['membership'] = objList['membership'] ?  objList['membership']: '';
 var membership = objList['membership'];
 html += '           <div recordID="' + objList._id +'"   id="createdOn14" class="languagetranslation " style="" >'+ membership+ ' Customer</div>';
 html += '     </div>';

//New End
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg8699  '+adddbclass+' " style=" cursor: pointer;">';
 objList['address_name'] = objList['address_name'] ? objList['address_name'] : '';
 if(response.showShimmer){
    objList['address_name'] = '';
 }
 var address_name = objList['address_name'];
 html += '           <div recordID="' + objList._id +'"   id="address_name15" class="languagetranslation " style="" >'+ address_name+'</div>';
 html += '     </div>';
 html += '     </div>';
 html += '     </div>';
 html += '      				</div>';
 html += '          </div>';
 html += '        </div>';
 html += '     </div>';
 html += '   </div>';
              }); // end of each loop
            };
              $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html)
        };

        function getdcard_leftimage_collectioncontainerapp_consultantclientlistingWebView(response, tokenKey, queryMode) {
              var html = '';
              if (response.data.length == 0) {
                              html += '<tr>';
                              html +=     '<td colspan="1" class="text_center first_row_table_td">';
                              html +=         'No record found';
                              html +=     '</td>';
                              html += '</tr>';
             } else {
              html =       '';
              $.each(response.data, function (keyList, objList) {
               
 html += '      <div class="row plain-card search" search="'+ removeSpecialChars(  objList.imageupload  + objList.clientname_name  + objList.clientcontact  + objList.createdon  + objList.address_name) +'">';
 html += '      		<div class="col s12 m12">';
 html += '               <div class="card-content">';
 html += '                  <div     status="'+ objList.status+ '"  recordID="'+objList._id+'" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
 html += '      <div class="row  element" style=""  >';
 html += '      <div class="col s3 cls_sg6599" style="">';
  var localFilePath = '';
  if(response && response.localFilePath){
     localFilePath = response.localFilePath;
  }
 html += '           <div class="col s12 clssg0699" style="">';
 var filetodisplay = ''; 
 if(objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID){
    filetodisplay = getuploadedfilepreview(objList.userphotoupload[0].fileNm);
 }
 if ( localFilePath && localFilePath != '' ) {
     html += '               <img recordID="'+objList._id+'"  id="userphotoupload11"   class=" clssg0699image userphotoupload11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ localFilePath+'" mediaid="'+ objList.mediaID +'" filenm="'+ objList.filenm +'" >';
 } else if(objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID){
    if(filetodisplay && filetodisplay != objList.userphotoupload[0].fileNm){
        html += '               <img recordID="'+objList._id+'"    id="userphotoupload11"   class=" clssg0699image userphotoupload11" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ filetodisplay + '">';
    } else {
        html += '               <img recordID="'+objList._id+'"    id="userphotoupload11"   class=" clssg0699image userphotoupload11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ CDN_PATH+objList.userphotoupload[0].mediaID+'_compressed.png">';
    }
 } else{
    // stage 6666666666666666
     html += '               <img recordID="'+objList._id+'"   id="userphotoupload11"   class=" clssg0699image userphotoupload11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
 }
 html += '           </div>';
 html += '     </div>';
 html += '      <div class="col s9 cls_sg8599 addshimmer" style="">';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg2699  '+adddbclass+' " style=" cursor: pointer;">';
 objList['name'] = objList['name'] ? objList['name'] : '';
 if(response.showShimmer){
    objList['name'] = '';
 }
 var name = objList['name'];
 html += '           <div recordID="' + objList._id +'"   id="name12" class="languagetranslation " style="" >'+ name+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg4699  '+adddbclass+' " style=" cursor: pointer;">';
 objList['contactnumber'] = objList['contactnumber'] ? objList['contactnumber'] : '';
 if(response.showShimmer){
    objList['contactnumber'] = '';
 }
 var contactnumber = objList['contactnumber'];
 html += '           <div recordID="' + objList._id +'"   id="contactnumber13" class="languagetranslation " style="" >'+ contactnumber+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg6699  '+adddbclass+' " style=" cursor: pointer;">';
 objList['createdOn'] = objList['createdOn'] ? moment(new Date(objList['createdOn'])).format('DD MMMM YYYY hh:mm A') : '';
 var createdOn = objList['createdOn'];
 html += '           <div recordID="' + objList._id +'"   id="createdOn14" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Added on</span>'+ createdOn+ '</div>';
 html += '     </div>';



 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg8699  '+adddbclass+' " style=" cursor: pointer;">';
 objList['address_name'] = objList['address_name'] ? objList['address_name'] : '';
 if(response.showShimmer){
    objList['address_name'] = '';
 }
 var address_name = objList['address_name'];
 html += '           <div recordID="' + objList._id +'"   id="address_name15" class="languagetranslation " style="" >'+ address_name+'</div>';
 html += '     </div>';
 html += '     </div>';
 html += '     </div>';
 html += '      				</div>';
 html += '          </div>';
 html += '        </div>';
 html += '     </div>';
 html += '   </div>';
             }); // end of each loop 1
            };
              $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html)
        };
 function showBottomMenu(){ 
   var menuObj = localStorage.getItem('objGetUserDetailsWithmenu');
   if(menuObj){
     menuObj = JSON.parse(menuObj);
     if( menuObj.data && menuObj.data.roleName ) {
          var roleName = menuObj.data.roleName;
     }
   }
   try {
       var roleName = localStorage.getItem('roleName');
        var clientIcon = "icon_clientactive.svg"
       var notificationicon = "icon_notification.svg"
       if (roleName == "consultant") {
           notificationicon = "icon_calendar.svg"
           clientIcon = "icon_teamactive.png";
       } 
       var  appUser = JSON.parse(localStorage.getItem("appUser"));
       var notificationCount = 0
       if(appUser.notificationunreadcount)
       {
           notificationCount = appUser.notificationunreadcount
       }
       $("#notificationcount5").html(notificationCount)
       var appointmentunreadcount = 0
       if(appUser.appointmentunreadcount)
       {
           appointmentunreadcount = appUser.appointmentunreadcount
       }
       var roleName = localStorage.getItem('roleName');
       var clientIcon = "icon_client.svg"
       var notificationicon = "icon_notification.svg"

       if (roleName == "consultant") {
           clientIcon = "icon_teamactive.png";
           notificationicon = "icon_calendar.svg"

       }
       
     
  } catch(err){
     // console.log('Error in showBottomMenu', err);
  }
}
function showFilterBox(){ 
    try { 
       var filterboxmenu = ''; 
         filterboxmenu += '    <div id="allfilterbox" class="filterboxeach" status="All">All</div>'
         filterboxmenu += '    <div id="assignedcustomerfilterbox" class="filterboxeach" status="AssignedCustomer">Assigned Customer</div>'
         filterboxmenu += '    <div id="referredcustomerfilterbox" class="filterboxeach" status="ReferredCustomer">Referred Customer</div>'
         filterboxmenu += '    <div id="mycustomerfilterbox" class="filterboxeach" status="MyCustomer">My Customer</div>'
         filterboxmenu += '    <div id="goldcustomersfilterbox" class="filterboxeach" status="GoldCustomers">Gold Customer</div>'
         filterboxmenu += '    <div id="silvercustomersfilterbox" class="filterboxeach" status="SilverCustomers">Silver Customer</div>'
       $('#chipfilter8').html(filterboxmenu)
  $(document).on('click', '.filterboxeach', function () {
      skip = 0;
      lastscroll = 0;
      var status = $(this).attr('status');
      if($('.view_list_record').length) { $('.view_list_record').show(); }
      localStorage.removeItem('app_foodlistingfilters');
      if($(this).hasClass('active')){
          $(this).removeClass('active');
          $('#allfilterbox').addClass('active');
          if(localStorage.getItem('appClientlistingFilterBox')){
              var arrFilterBox = localStorage.getItem('appClientlistingFilterBox').split(',');
          } else {
              var arrFilterBox = [];
          }
          var arrFilterBox = arrFilterBox.filter(function(elem){
              return elem != status; 
          });
          localStorage.setItem('appClientlistingFilterBox',arrFilterBox.toString());
      } else {
       $('.filterboxeach').removeClass('active');
       $('#filtersfilterbox').removeClass('active');
       $('#filtersfilterbox').css('background-image', 'url(chipfilter.svg)');
          $(this).addClass('active');
          if(localStorage.getItem('appClientlistingFilterBox')){
              var arrFilterBox = [];
          } else {
              var arrFilterBox = [];
          }
           arrFilterBox.push(status);
          localStorage.setItem('appClientlistingFilterBox',arrFilterBox.toString());
      }
       if(localStorage.getItem('appClientlistingFilterBox')){
           var arrFilterBox = localStorage.getItem('appClientlistingFilterBox').split(',');
           if(arrFilterBox.length > 0){
               for(count=0;count<arrFilterBox.length;count++){
                   var filterName = arrFilterBox[count] ? arrFilterBox[count].replace(/ /g,'') : '';
                   $('#'+filterName.toLowerCase() +'filterbox').addClass('active');
               }
           } else {
               $('#allfilterbox').addClass('active');
           }
      } else if(!localStorage.app_foodlistingfilters){
          $('#allfilterbox').addClass('active');
      }
  var queryMode = getParameterByName('queryMode');
  var isMobile = $('#isMobile').val();
  var isiPad = $('#isiPad').val();
  if(queryMode != ''){
     var tokenKey = $('#tokenKey').val();
     var objParamsList = {};
     objParamsList.queryMode = queryMode;
     var ajaXCallURL = $.trim($('#ajaXCallURL').val());
     objParamsList.tokenKey = getParameterByName('tokenKey');
     objParamsList.secretKey = getParameterByName('secretKey');
     objParamsList.ajaXCallURL = ajaXCallURL;
     objParamsList.isMobile = isMobile;
     objParamsList.isiPad = isiPad;
     objParamsList.applyFilter = false;
     objParamsList.applyFilterStatus = false;
       if(localStorage.getItem('appClientlistingFilterBox') == 'AssignedCustomer'){
        objParamsList.customertype = arrFilterBox.toString() == 'AssignedCustomer' ? 'Assigned Customer' : arrFilterBox.toString();
       }
       if(localStorage.getItem('appClientlistingFilterBox') == 'ReferredCustomer'){
        objParamsList.customertype = arrFilterBox.toString() == 'ReferredCustomer' ? 'Referred Customer' : arrFilterBox.toString();
       }
       if(localStorage.getItem('appClientlistingFilterBox') == 'MyCustomer'){
        objParamsList.customertype = arrFilterBox.toString() == 'MyCustomer' ? 'My Customer' : arrFilterBox.toString();
       }
       if(localStorage.getItem('appClientlistingFilterBox') == 'GoldCustomers'){
        objParamsList.membership = arrFilterBox.toString() == 'GoldCustomers' ? 'Gold' : arrFilterBox.toString();
       }
       if(localStorage.getItem('appClientlistingFilterBox') == 'SilverCustomers'){
       objParamsList.membership = arrFilterBox.toString() == 'SilverCustomers' ? 'Silver' : arrFilterBox.toString();
       }
       objParamsList.consultantid = localStorage.getItem("userID");
                       $('#collectioncontainerDivdcard_collectioncontainer').html('');
                       $('#collectioncontainerDivdcard_collectioncontainer').find('.view_list_record').removeClass('shimmer');
                       
                       show_dcard_leftimage_collectioncontainerapp_consultantclientlisting_Details(objParamsList);
                       
  }
  });
  if(localStorage.getItem('appClientlistingFilterBox')){
      var arrFilterBox = localStorage.getItem('appClientlistingFilterBox').split(',');
      if(arrFilterBox.length > 0){
          for(count=0;count<arrFilterBox.length;count++){
                   var filterName = arrFilterBox[count] ? arrFilterBox[count].replace(/ /g,'') : '';
                   $('#'+filterName.toLowerCase() +'filterbox').addClass('active');
          }
      } else {
         $('#allfilterbox').addClass('active');
      }
  } else if(!localStorage.app_foodlistingfilters){
     $('#allfilterbox').addClass('active');
  }
  if($('.filterboxeach.active').length && $('.filterboxeach.active').position().left > 300) $('.filterboxmaindiv').animate({'scrollLeft': $('.filterboxeach.active').position().left}, 500);
   } catch(err){
      // console.log('Error in showFilterBox', err);
   }
 }
