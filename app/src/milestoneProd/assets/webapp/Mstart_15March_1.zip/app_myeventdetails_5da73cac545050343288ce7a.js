
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
  $('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
    $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

  var objParamsToken = {};
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  objParamsToken.tokenKey = getParameterByName('tokenKey');
  objParamsToken.secretKey = getParameterByName('secretKey');

  var userRole = $('#userRole').val();
  var userID = $('#userID').val();
  var createrOfRecord = $('#createrOfRecord').val();
  var queryMode = getParameterByName('queryMode');
  var recordID = $.trim($('#recordID').val());
  var addSessionComments = [];
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on('click', '#scan30', function () {
    var objParams = {};
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var contactperson = $.trim($('#contactperson10').val());
    var obj = {}
    if ($('#contactperson10_div').is(':visible')) {
      if (contactperson == '') {
        $('#contactperson10_error').show();
        if (!Object.keys(errorFields).length) errorFields['contactperson10'] = 'divtag';
        validAll = false;
      } else {
        $('#contactperson10_error').hide();
      }
    }
    if ($('#contactperson10_div').is(':visible')) {
      objParams.contactperson = contactperson;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var eventname = $.trim($('#eventname12').val());
    var obj = {}
    if ($('#eventname12_div').is(':visible')) {
      if (eventname == '') {
        $('#eventname12_error').show();
        if (!Object.keys(errorFields).length) errorFields['eventname12'] = 'divtag';
        validAll = false;
      } else {
        $('#eventname12_error').hide();
      }
    }
    if ($('#eventname12_div').is(':visible')) {
      objParams.eventname = eventname;
    }
    var eventdate = $.trim($('#eventdate13').val());
    var obj = {}
    if ($('#eventdate13_div').is(':visible')) {
      if (eventdate == '') {
        $('#eventdate13_error').show();
        if (!Object.keys(errorFields).length) errorFields['eventdate13'] = 'divtag';
        validAll = false;
      } else {
        $('#eventdate13_error').hide();
      }
    }
    if ($('#eventdate13_div').is(':visible')) {
      objParams.eventdate = eventdate;
    }
    var contactperson = $.trim($('#contactperson10').val());
    var obj = {}
    if ($('#contactperson10_div').is(':visible')) {
      if (contactperson == '') {
        $('#contactperson10_error').show();
        if (!Object.keys(errorFields).length) errorFields['contactperson10'] = 'divtag';
        validAll = false;
      } else {
        $('#contactperson10_error').hide();
      }
    }
    if ($('#contactperson10_div').is(':visible')) {
      objParams.contactperson = contactperson;
    }
    var eventdate = $.trim($('#eventdate13').val());
    var obj = {}
    if ($('#eventdate13_div').is(':visible')) {
      if (eventdate == '') {
        $('#eventdate13_error').show();
        if (!Object.keys(errorFields).length) errorFields['eventdate13'] = 'divtag';
        validAll = false;
      } else {
        $('#eventdate13_error').hide();
      }
    }
    if ($('#eventdate13_div').is(':visible')) {
      objParams.eventdate = eventdate;
    }
    var description = $.trim($('#description15').val());
    var obj = {}
    if ($('#description15_div').is(':visible')) {
      if (description == '') {
        $('#description15_error').show();
        if (!Object.keys(errorFields).length) errorFields['description15'] = 'divtag';
        validAll = false;
      } else {
        $('#description15_error').hide();
      }
    }
    if ($('#description15_div').is(':visible')) {
      objParams.description = description;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var ordersnumber = $.trim($('#ordersnumber35').val());
    if ($('#ordersnumber35_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber35').val());
    if ($('#ordersnumber35_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber35').val());
    if ($('#ordersnumber35_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var ordersnumber = $.trim($('#ordersnumber35').val());
    if ($('#ordersnumber35_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber35').val());
    if ($('#ordersnumber35_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var description = $.trim($('#description15').val());
    var obj = {}
    if ($('#description15_div').is(':visible')) {
      if (description == '') {
        $('#description15_error').show();
        if (!Object.keys(errorFields).length) errorFields['description15'] = 'divtag';
        validAll = false;
      } else {
        $('#description15_error').hide();
      }
    }
    if ($('#description15_div').is(':visible')) {
      objParams.description = description;
    }
    var ordersnumber = $.trim($('#ordersnumber35').val());
    if ($('#ordersnumber35_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber35').val());
    if ($('#ordersnumber35_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var ordersnumber = $.trim($('#ordersnumber35').val());
    if ($('#ordersnumber35_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var eventname = $.trim($('#eventname12').val());
    var obj = {}
    if ($('#eventname12_div').is(':visible')) {
      if (eventname == '') {
        $('#eventname12_error').show();
        if (!Object.keys(errorFields).length) errorFields['eventname12'] = 'divtag';
        validAll = false;
      } else {
        $('#eventname12_error').hide();
      }
    }
    if ($('#eventname12_div').is(':visible')) {
      objParams.eventname = eventname;
    }
    var eventdate = $.trim($('#eventdate13').val());
    var obj = {}
    if ($('#eventdate13_div').is(':visible')) {
      if (eventdate == '') {
        $('#eventdate13_error').show();
        if (!Object.keys(errorFields).length) errorFields['eventdate13'] = 'divtag';
        validAll = false;
      } else {
        $('#eventdate13_error').hide();
      }
    }
    if ($('#eventdate13_div').is(':visible')) {
      objParams.eventdate = eventdate;
    }
    var ordersnumber = $.trim($('#ordersnumber35').val());
    if ($('#ordersnumber35_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var eventimage = $.trim($('#eventimage6').val());
    var obj = {}
    if ($('#eventimage6_div').is(':visible')) {
      if (eventimage == '') {
        $('#eventimage6_error').show();
        if (!Object.keys(errorFields).length) errorFields['eventimage6'] = 'image';
        validAll = false;
      } else {
        $('#eventimage6_error').hide();
      }
    }
    if ($('#eventimage6_div').is(':visible') && eventimage) {
      objParams.eventimage = eventimage;
    }
    var eventcategory_name = $.trim($('#eventcategory_name8').val());
    var obj = {}
    if ($('#eventcategory_name8_div').is(':visible')) {
      if (eventcategory_name == '') {
        $('#eventcategory_name8_error').show();
        if (!Object.keys(errorFields).length) errorFields['eventcategory_name8'] = 'divtag';
        validAll = false;
      } else {
        $('#eventcategory_name8_error').hide();
      }
    }
    if ($('#eventcategory_name8_div').is(':visible')) {
      objParams.eventcategory_name = eventcategory_name;
    }
    var contactperson = $.trim($('#contactperson10').val());
    var obj = {}
    if ($('#contactperson10_div').is(':visible')) {
      if (contactperson == '') {
        $('#contactperson10_error').show();
        if (!Object.keys(errorFields).length) errorFields['contactperson10'] = 'divtag';
        validAll = false;
      } else {
        $('#contactperson10_error').hide();
      }
    }
    if ($('#contactperson10_div').is(':visible')) {
      objParams.contactperson = contactperson;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var eventname = $.trim($('#eventname12').val());
    var obj = {}
    if ($('#eventname12_div').is(':visible')) {
      if (eventname == '') {
        $('#eventname12_error').show();
        if (!Object.keys(errorFields).length) errorFields['eventname12'] = 'divtag';
        validAll = false;
      } else {
        $('#eventname12_error').hide();
      }
    }
    if ($('#eventname12_div').is(':visible')) {
      objParams.eventname = eventname;
    }
    var eventdate = $.trim($('#eventdate13').val());
    var obj = {}
    if ($('#eventdate13_div').is(':visible')) {
      if (eventdate == '') {
        $('#eventdate13_error').show();
        if (!Object.keys(errorFields).length) errorFields['eventdate13'] = 'divtag';
        validAll = false;
      } else {
        $('#eventdate13_error').hide();
      }
    }
    if ($('#eventdate13_div').is(':visible')) {
      objParams.eventdate = eventdate;
    }
    var description = $.trim($('#description15').val());
    var obj = {}
    if ($('#description15_div').is(':visible')) {
      if (description == '') {
        $('#description15_error').show();
        if (!Object.keys(errorFields).length) errorFields['description15'] = 'divtag';
        validAll = false;
      } else {
        $('#description15_error').hide();
      }
    }
    if ($('#description15_div').is(':visible')) {
      objParams.description = description;
    }
    var description = $.trim($('#description15').val());
    var obj = {}
    if ($('#description15_div').is(':visible')) {
      if (description == '') {
        $('#description15_error').show();
        if (!Object.keys(errorFields).length) errorFields['description15'] = 'divtag';
        validAll = false;
      } else {
        $('#description15_error').hide();
      }
    }
    if ($('#description15_div').is(':visible')) {
      objParams.description = description;
    }
    var pickuplocation = $.trim($('#pickuplocation31').val());
    if ($('#pickuplocation31_div').is(':visible')) {
      objParams.pickuplocation = pickuplocation;
    }
    var droplocation = $.trim($('#droplocation32').val());
    if ($('#droplocation32_div').is(':visible')) {
      objParams.droplocation = droplocation;
    }
    var pickuplocation_name = $.trim($('#pickuplocation_name33').val());
    if ($('#pickuplocation_name33_div').is(':visible')) {
      objParams.pickuplocation_name = pickuplocation_name;
    }
    var droplocation_name = $.trim($('#droplocation_name34').val());
    if ($('#droplocation_name34_div').is(':visible')) {
      objParams.droplocation_name = droplocation_name;
    }
    var ordersnumber = $.trim($('#ordersnumber35').val());
    if ($('#ordersnumber35_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber35').val());
    if ($('#ordersnumber35_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var tempobjParams = getParams(window.location.href)
    function extend(obj, src) {
      for (var key in src) {
        if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
      }
      return obj;
    }
    objParams = extend(objParams, tempobjParams);
    var recordID = $('#recordID').val();
    objParams.isDelete = 0;
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParams.tokenKey = getParameterByName('tokenKey');
    objParams.secretKey = getParameterByName('secretKey');
    objParams.offlineDataID = localStorage.getItem("offlineDataID");
    var queryMode = getParameterByName('queryMode')
    if (queryMode == 'add') {
      objParams.callUrl = ajaXCallURL + '/milestone003/saveAjaxorders2765scanapp_myeventdetails';
    } else {
      objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxorders2765scanapp_myeventdetails';
      objParams.recordID = recordID;
    }
    if (errorFields && Object.keys(errorFields).length) {
      $('#display_loading1').addClass('hideme');
      for (var firstErrorField in errorFields) {
        var controlType = errorFields[firstErrorField];
        errorFields = []
        var errField = $('#' + firstErrorField);
        if (controlType == 'dropdown') {
          errField.prev().prev().focus();
        } else {
          errField.focus()
        }
        validAll = true;
        return false;
      }
    }
    if (!validAll) {
      validAll = true;
      return false;
    }
    $('#scan30').prop('disabled', true);
    $('#display_loading1').removeClass('hideme');
    if (addSessionComments.length > 0) {
      objParams.addSessionComments = addSessionComments;
    } else {
      objParams.addSessionComments = [];
    }
    var parentID = $('#parentID').val();
    var parentName = $('#parentName').val();
    if (parentID != '') {
      objParams.parentID = parentID;
      objParams.parentName = parentName
    }
    if (typeof (addedFiles) != "undefined" && addedFiles && addedFiles.length > 0) {
      objParams.addedFiles = addedFiles;
    }
    objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    objParams.organizationID = $("#organizationID").val();;
    objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    objParams.organizationID = $("#organizationID").val();;
    processBeforeCallForSave2765scan(objParams, {}, function (processBeforeRes) {
      $.ajax({
        url: objParams.callUrl,
        data: objParams,
        type: 'POST',
        success: function (response) {
          if (response.status == 0) {
            $('#display_loading1').addClass('hideme');
            response.nextPage = 'app_eventscansuccess'
            processAfterCallForSave2765scan(response, function (processAfterRes) {
              var tokenKey = getParameterByName('tokenKey');
              var secretKey = getParameterByName('secretKey');
              var queryMode = getParameterByName('queryMode');
              queryMode = queryMode.replace('edit', '');
              localStorage.setItem("headerPageName", 'app_eventscansuccess');
              var queryString = window.location.search.slice(1);
              var newQuery = queryString + '&queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&queryMode=mylist' + '&ordersid=' + response.data._id + '&recordID=' + response.data._id
              var queryParams = queryStringToJSON(newQuery);
              queryString = $.param(queryParams);
              queryString = queryString.replace(/\+/g, "%20");
              queryString = decodeURIComponent(queryString);
              if (recordID == '') {
                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
              } else {
                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
              }
              return false;
            }); // End of After Process
          } else {
            $('#display_loading1').addClass('hideme');
            $('#2656d_error').html(response.error);
            $('#2656d_error').show();
          }
          $('#scan30').removeProp('disabled');
        },
        error: function (xhr, status, error) {
          $('#display_loading1').addClass('hideme');
          $('#scan30').removeProp('disabled');
        },
      });
      return false;
    }); // End of Before Process
  });//end of Event Scan_is_click 
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#backbutton1', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_myupcomingeventslist';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error)
    }
  })
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#icongetdirection14', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_eventoverlaymap';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - icongetdirection14", error)
    }
  })
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#aditionaldetails22', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_myeventadditionaldetails';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "update";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - aditionaldetails22", error)
    }
  })
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#iconnext423', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_myeventadditionaldetails';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "update";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - iconnext423", error)
    }
  })
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#photos25', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_photoslisting';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - photos25", error)
    }
  })
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#iconnext126', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_photoslisting';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - iconnext126", error)
    }
  })
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#documents28', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_documentslisting';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - documents28", error)
    }
  })
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#iconnext629', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_documentslisting';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - iconnext629", error)
    }
  })
  var paramsEdit = {};
  paramsEdit.tokenKey = getParameterByName('tokenKey');
  paramsEdit.secretKey = getParameterByName('secretKey')
  getRecordByIDProcessBeforeCall537425(paramsEdit, function (processBeforeRes) {
    $.ajax({
      url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_myeventdetails_Orderdetails5da73cac545050343288ce7a',
      data: paramsEdit,
      type: 'POST',
      jsonpCallback: 'callback',
      success: function (response) {
        getRecordByIDProcessAfterCall537425(response, function (processBeforeRes) {
          if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
            var objParamsList = {};
            var queryMode = $('#queryMode').val();
            objParamsList.queryMode = queryMode;;
            var tokenKey = $('#tokenKey').val();;
            objParamsList.tokenKey = tokenKey;;
            if (!$('#9').html()) {
              $('#9').append(response.recordDetails.undefined);
            }
            if (!$('#aditionaldetails22').html()) {
              $('#aditionaldetails22').append(response.recordDetails.undefined);
            }
            $('#ordersnumber35_value').html(response.recordDetails.ordersnumber);
            if (!$('#backbutton1').html()) {
              $('#backbutton1').append(response.recordDetails.undefined);
            }
            if (!$('#description17').html()) {
              $('#description17').append(response.recordDetails.undefined);
            }
            if (!$('#documents28').html()) {
              $('#documents28').append(response.recordDetails.undefined);
            }
            if (!$('#eventdetails2').html()) {
              $('#eventdetails2').append(response.recordDetails.undefined);
            }
            if (!$('#eventoverview20').html()) {
              $('#eventoverview20').append(response.recordDetails.undefined);
            }
            if (response.recordDetails.droplocation != undefined) $('#droplocation32').val(response.recordDetails.droplocation);
            if (response.recordDetails.droplocation && response.recordDetails.droplocation['coordinates']) {
              var coordinates = response.recordDetails.droplocation['coordinates'];
              if (coordinates && coordinates.length) {
                localStorage.setItem('droplocationLatitude', coordinates[1]);
                localStorage.setItem('droplocationLongitute', coordinates[0]);
              }
            }
            if (response.recordDetails.droplocation_name != undefined) $('#droplocation_name34').val(response.recordDetails.droplocation_name);
            if (response.recordDetails.pickuplocation != undefined) $('#pickuplocation31').val(response.recordDetails.pickuplocation);
            if (response.recordDetails.pickuplocation && response.recordDetails.pickuplocation['coordinates']) {
              var coordinates = response.recordDetails.pickuplocation['coordinates'];
              if (coordinates && coordinates.length) {
                localStorage.setItem('pickuplocationLatitude', coordinates[1]);
                localStorage.setItem('pickuplocationLongitute', coordinates[0]);
              }
            }
            if (response.recordDetails.pickuplocation_name != undefined) $('#pickuplocation_name33').val(response.recordDetails.pickuplocation_name);
            var url = 'icon_location.png'
            $('#icongetdirection14').attr("src", url);
            var url = 'icon_next1.png'
            $('#iconnext126').attr("src", url);
            var url = 'icon_next4.png'
            $('#iconnext423').attr("src", url);
            var url = 'icon_next6.png'
            $('#iconnext629').attr("src", url);
            // getrecordbycustomquery - Stage - 111111111111
            if (response.recordDetails['eventimage'] && response.recordDetails['eventimage'].length > 0) {
              if (response.recordDetails['eventimage'][0].displayType = 'html') {
                var eleParent = $('#eventimage6').parent();
                for (var key in response.recordDetails['eventimage']) {
                  var objImage = response.recordDetails['eventimage'][key];
                  if (response.recordDetails['eventimage'][key].name == 'Audio') {
                    var token = $('#tokenKey').val();
                    if (token && token != '') {
                      token = $('#tokenKey').val();
                    } else {
                      token = getParameterByName('tokenKey');
                    }
                    var mediaIDa = response.recordDetails['eventimage'][0].mediaID
                    var filenamea = response.recordDetails['eventimage'][0].fileName
                    var CDN_PATH2 = 'https://devfiles.hokuapps.com/downloadOriginal?f=' + mediaIDa + '&fn=' + filenamea + '&t=' + token
                    var url = CDN_PATH2
                  } else {
                    var filetodisplay = getuploadedfilepreview(objImage.fileNm);
                    if (filetodisplay && filetodisplay != objImage.fileNm) {
                      var url = filetodisplay;
                    } else {
                      var url = CDN_PATH + objImage.mediaID + '_compressed.png';
                    }
                  }
                  if (response.recordDetails['eventimage'][key].name == 'Audio') {
                    var html = '';
                    html += '<div class="col s12" style="float: right;">'
                    html += '<audio class="" src="' + url + '" controls></audio>'
                    html += '</div>'
                  } else {
                    var html = '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + url + '" />';
                  }
                  if (!key || key == '0') {
                    eleParent.html(html);
                  } else {
                    eleParent.append(html);
                  }
                }
              } else {
                if (response.recordDetails['eventimage'][key].name == 'Audio') {
                  var url = CDN_PATH + response.recordDetails['eventimage'][0].mediaID;
                } else {
                  var url = CDN_PATH + response.recordDetails['eventimage'][0].mediaID + '_compressed.png';
                }
                $('#eventimage6').attr("src", url);
              }
            }
            if (!$('#contactperson10').html()) {
              $('#contactperson10').append(response.recordDetails.contactperson);
            }
            if (!$('#description18').html()) {
              $('#description18').append(response.recordDetails.description);
            }
            if (!$('#description15').html()) {
              $('#description15').append(response.recordDetails.description);
            }
            if (!$('#eventcategory_name8').html()) {
              $('#eventcategory_name8').append(response.recordDetails.eventcategory_name);
            }
            response.recordDetails['eventdate_preserved'] = response.recordDetails['eventdate'];
            response.recordDetails['eventdate'] = response.recordDetails['eventdate'] ? moment(new Date(response.recordDetails['eventdate'])).format('DD MMM YYYY') : '';
            if (!$('#eventdate13').html()) {
              $('#eventdate13').append(response.recordDetails.eventdate);
            }
            response.recordDetails['eventdate'] = response.recordDetails['eventdate_preserved'];
            if (!$('#eventname12').html()) {
              $('#eventname12').append(response.recordDetails.eventname);
            }
            if (!$('#status11').html()) {
              $('#status11').append(response.recordDetails.status);
            }
            if (!$('#photos25').html()) {
              $('#photos25').append(response.recordDetails.undefined);
            }

            Materialize.updateTextFields();
            $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

          }
        }); // end of getRecord By ID
      },
      error: function (xhr, status, error) {
        handleError(xhr, status, error);
      },
    });
  }); // end of getRecord By ID

});//end of ready
function getParams(url) {
  var urlParams = {};
  url.replace(
    new RegExp("([^?=&]+)(=([^&]*))?", "g"),
    function ($0, $1, $2, $3) {
      if ($3 && $3 != 'undefined') urlParams[$1] = $3;
    }
  );
  return urlParams;
}
function processBeforeCallForSave2765scan(objParams, response, callback) {


  objParams.type = 'events'; callback();
}
function processAfterCallForSave2765scan(response, callback) {

  callback();
}
function getRecordByIDProcessBeforeCall537425(paramsType, callback) {
  var response = paramsType;

  if (getParameterByName('orderdetailsid') && getParameterByName('orderdetailsid') != 'undefined') { paramsType.recordID = getParameterByName('orderdetailsid') } else if (getParameterByName('recordID') && getParameterByName('recordID') != 'undefined') { paramsType.recordID = getParameterByName('recordID') }; callback();
}
function getRecordByIDProcessAfterCall537425(response, callback) {
  callback();
}
