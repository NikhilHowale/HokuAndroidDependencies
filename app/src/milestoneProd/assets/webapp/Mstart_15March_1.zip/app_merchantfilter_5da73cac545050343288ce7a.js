
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;

$(document).ready(function () {
  $('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
    $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

  var objParamsToken = {};
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  objParamsToken.tokenKey = getParameterByName('tokenKey');
  objParamsToken.secretKey = getParameterByName('secretKey');

  var userRole = $('#userRole').val();
  var userID = $('#userID').val();
  var createrOfRecord = $('#createrOfRecord').val();
  var queryMode = getParameterByName('queryMode');
  var recordID = $.trim($('#recordID').val());
  var addSessionComments = [];
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;

  dcard_collectioncontainerapp_merchantlistingSync();


  function dcard_collectioncontainerapp_merchantlistingSync() {
    try {
      var objParamsList = {};
      objParamsList.queryMode = 'mylist';
      var ajaXCallURL = $.trim($('#ajaXCallURL').val());
      objParamsList.tokenKey = getParameterByName('tokenKey');
      objParamsList.secretKey = getParameterByName('secretKey');
      objParamsList.ajaXCallURL = ajaXCallURL;
      objParamsList.isMobile = true;
      objParamsList.queryMode = "adminlist";
      $.ajax({
        url: objParamsList.ajaXCallURL + '/milestone003/getListDetails_Category5da73cac545050343288ce7a_eventcategoryweb_eventcategorywebKendoList',
        data: objParamsList,
        type: 'POST',
        success: function (response) {
          $('#display_loading').addClass('hideme');
          if (response.status != undefined && response.status == 0) {
            let filterboxmenu = '';
            let categoryids = null;
            categoryids = localStorage.getItem('filterCategoryId');
            $.each(response.data, function (keyList, objList) {
              let checkorNot = '';
              if (categoryids && categoryids !== undefined && categoryids !== "" && categoryids !== "null" && categoryids !== " ") {
                checkorNot = $.inArray(objList._id, categoryids.split(','));
              }

              let checkBoxcheck = '';
              if (checkorNot !== undefined && checkorNot !== "" && checkorNot >= 0) {
                checkBoxcheck = 'checked=checked';
              }
              if (objList.categorytype === "Merchant") {
                filterboxmenu += '<div style="" id="retirementage14_div" class="input-field margin_bottom_5px ">';
                filterboxmenu += ' <input autocomplete="off" style="" id="retirementage' + objList._id + '" type="checkbox" class="element checkedCheck" name="myintendedretirementage" maxlength=""   value="' + objList._id + '" ' + checkBoxcheck + '>'
                filterboxmenu += '<label class="" for="retirementage' + objList._id + '">' + objList.categoryname + '</label>';
                filterboxmenu += '</div>';
              }

            })
            $('.categorycls').html(filterboxmenu)
          }
        },
        error: function (xhr, status, error) {
          handleError(xhr, status, error);
        }
      });
    } catch (err) {
      // console.log('Error in workingtoolsSync', err);
    }
  }

  $(document).on('click', '#result18', function () {
    try {
      localStorage.removeItem('filterCategoryId');
      let finalCategoryIdArray = [];
      $('input[type=checkbox]').each(function () {
        if ($(this).prop("checked") == true) {
          let element = $(this).val();
          finalCategoryIdArray.push(element);
        }
      })
      if (finalCategoryIdArray !== undefined) {
        localStorage.setItem('filterCategoryId', finalCategoryIdArray);
      } else {
        localStorage.removeItem('filterCategoryId');
        localStorage.removeItem('filterCategoryIdSingle');
      }
      var element = $(this);
      var nextPage = 'app_merchantlisting';
      if (localStorage.getItem('isFromStampCard') == 'true') {
        nextPage = 'app_allofferlisting';
      }
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error)
    }

  });//end of Event Result_is_click 
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#backbutton1', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_merchantlisting';
      if (localStorage.getItem('isFromStampCard') == 'true') {
        nextPage = 'app_allofferlisting';
      }
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error)
    }
  })
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#financialgoals8', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_financialcalculateadd';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "add";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - financialgoals8", error)
    }
  })
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#childuniversityfund9', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_childcalculateadd';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "add";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - childuniversityfund9", error)
    }
  })
});//end of ready
function getParams(url) {
  var urlParams = {};
  url.replace(
    new RegExp("([^?=&]+)(=([^&]*))?", "g"),
    function ($0, $1, $2, $3) {
      if ($3 && $3 != 'undefined') urlParams[$1] = $3;
    }
  );
  return urlParams;
}
function processBeforeCallForSave4524result(objParams, response, callback) {


  objParams.recordID = localStorage.userID;

  var currentage13 = $("#currentage13").val();
  var retirementage14 = $("#retirementage14").val();
  if (retirementage14 < currentage13) {
    $('#retirementage15_error').show();
    $('#result18').removeProp('disabled');
    $('#display_loading1').addClass('hideme');


    return false;

  }
  {
    $('#retirementage15_error').hide();

  }
  var monthlyincome15 = $("#monthlyincome15").val();
  var incomeyearsrequired16 = parseInt($("#incomeyearsrequired16").val());
  var inflationrate17 = $("#inflationrate17").val();
  inflationrate17 = inflationrate17 / 100;
  var yeartoachive = retirementage14 - currentage13;

  var inflationrate17value = (1 + inflationrate17);
  var inflationrate17value1 = inflationrate17value;
  for (var i = 1; i < yeartoachive; i++) {
    inflationrate17value1 = inflationrate17value1 * inflationrate17value
  }
  var firstlevelvalue0 = monthlyincome15 * 12 * incomeyearsrequired16;
  firstlevelvalue = firstlevelvalue0 * inflationrate17value1



  objParams.result1 = firstlevelvalue //monthlyincome15 * 12 * incomeyearsrequired16;
  objParams.result2 = firstlevelvalue / yeartoachive;
  objParams.result2 = objParams.result2 / 12
  callback();
}
function processAfterCallForSave4524result(response, callback) {

  callback();
}
