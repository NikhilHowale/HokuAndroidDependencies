
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
 var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on('click', '#result17', function () {
  var objParams = {};
  var inflationrate = $.trim($('#inflationrate16').val());
 var  obj  =  {}
 if($('#inflationrate16_div').is(':visible')){
  if(inflationrate == ''){
    $('#inflationrate16_error').show();
    if(!Object.keys(errorFields).length) errorFields['inflationrate16'] = 'textbox';
     validAll = false;
  } else {
    $('#inflationrate16_error').hide();
  }
  }
 if($('#inflationrate16_div').is(':visible')){
  objParams.inflationrate = inflationrate;
 }
  var savings = $.trim($('#savings13').val());
 var  obj  =  {}
 if($('#savings13_div').is(':visible')){
  if(savings == ''){
    $('#savings13_error').show();
    if(!Object.keys(errorFields).length) errorFields['savings13'] = 'textbox';
     validAll = false;
  } else {
    $('#savings13_error').hide();
  }
  }
 if($('#savings13_div').is(':visible')){
  objParams.savings = savings;
 }
  var years = $.trim($('#years14').val());
 var  obj  =  {}
 if($('#years14_div').is(':visible')){
  if(years == ''){
    $('#years14_error').show();
    if(!Object.keys(errorFields).length) errorFields['years14'] = 'textbox';
     validAll = false;
  } else {
    $('#years14_error').hide();
  }
  }
                 var d = new Date();
                 var currentyear = d.getFullYear();

                 if(currentyear >= years)
                 {
                    $('#years15_error').show();
                 
               //  alert('Year cannot be less than current year')
                 return false;
                 }
                 else
                 {
                  $('#years15_error').hide();
                 
                 }
 if($('#years14_div').is(':visible')){
  objParams.years = years;
 }
  var currentsaving = $.trim($('#currentsaving15').val());
 var  obj  =  {}
 if($('#currentsaving15_div').is(':visible')){
  if(currentsaving == ''){
    $('#currentsaving15_error').show();
    if(!Object.keys(errorFields).length) errorFields['currentsaving15'] = 'textbox';
     validAll = false;
  } else {
    $('#currentsaving15_error').hide();
  }
  }
 if($('#currentsaving15_div').is(':visible')){
  objParams.currentsaving = currentsaving;
 }
  var inflationrate = $.trim($('#inflationrate16').val());
 var  obj  =  {}
 if($('#inflationrate16_div').is(':visible')){
  if(inflationrate == ''){
    $('#inflationrate16_error').show();
    if(!Object.keys(errorFields).length) errorFields['inflationrate16'] = 'textbox';
     validAll = false;
  } else {
    $('#inflationrate16_error').hide();
  }
  }
 if($('#inflationrate16_div').is(':visible')){
  objParams.inflationrate = inflationrate;
 }
  var investmentrequipredpermonth = $.trim($('#investmentrequipredpermonth20').val());
 if($('#investmentrequipredpermonth20_div').is(':visible')){
  objParams.investmentrequipredpermonth = investmentrequipredpermonth;
 }
  var investmentrequipredpermonth = $.trim($('#investmentrequipredpermonth20').val());
 if($('#investmentrequipredpermonth20_div').is(':visible')){
  objParams.investmentrequipredpermonth = investmentrequipredpermonth;
 }
  var investmentrequipredpermonth = $.trim($('#investmentrequipredpermonth20').val());
 if($('#investmentrequipredpermonth20_div').is(':visible')){
  objParams.investmentrequipredpermonth = investmentrequipredpermonth;
 }
  var investmentrequipredpermonth = $.trim($('#investmentrequipredpermonth20').val());
 if($('#investmentrequipredpermonth20_div').is(':visible')){
  objParams.investmentrequipredpermonth = investmentrequipredpermonth;
 }
   var tempobjParams  =  getParams(window.location.href)
   function extend(obj, src) {
          for (var key in src) {
              if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
          }
          return obj;
    }
    objParams = extend(objParams, tempobjParams);
   var recordID = $('#recordID').val();
   objParams.isDelete = 0;
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParams.tokenKey = getParameterByName('tokenKey');
   objParams.secretKey = getParameterByName('secretKey');
   objParams.offlineDataID =  localStorage.getItem("offlineDataID");
   var queryMode = getParameterByName('queryMode')
 if (queryMode == 'mylist') {
  objParams.callUrl = ajaXCallURL + '/milestone003/saveAjaxusermanagement7257resultapp_financialcalculateadd';
  } else {
  objParams.callUrl = ajaXCallURL +'/milestone003/updateAjaxusermanagement7257resultapp_financialcalculateadd';
  objParams.recordID = recordID;
 }
  if(errorFields && Object.keys(errorFields).length){
      $('#display_loading1').addClass('hideme');
      for(var firstErrorField in errorFields){
          var controlType = errorFields[firstErrorField];
          errorFields = []
          var errField = $('#'+ firstErrorField);
          if(controlType == 'dropdown'){
              errField.prev().prev().focus();
          } else {
              errField.focus()
          }
          validAll = true;
          return false;
      }
  }
  if(!validAll){
      validAll = true;
      return false;
  }
  $('#result17').prop('disabled', true);
  $('#display_loading1').removeClass('hideme');
  if (addSessionComments.length > 0) {
      objParams.addSessionComments = addSessionComments;
  } else {
      objParams.addSessionComments = [];
  }
   var parentID = $('#parentID').val();
   var parentName = $('#parentName').val();
   if(parentID != ''){
      objParams.parentID = parentID;
      objParams.parentName = parentName
   }
   if (typeof(addedFiles) != "undefined" && addedFiles && addedFiles.length > 0 ) {
       objParams.addedFiles = addedFiles;
   }
   objParams.ajaXCallURL = $("#ajaXCallURL").val();;
   objParams.organizationID = $("#organizationID").val();;
   objParams.ajaXCallURL = $("#ajaXCallURL").val();;
   objParams.organizationID = $("#organizationID").val();;
  processBeforeCallForSave7257result(objParams,{},function(processBeforeRes){
  $.ajax({
      url: objParams.callUrl,
      data: objParams,
      type: 'POST',
      success: function (response) {
          if(response.status == 0){
              $('#display_loading1').addClass('hideme');
              response.nextPage = 'app_financialgoaldetails'
  processAfterCallForSave7257result(response,function(processAfterRes){
             var tokenKey = getParameterByName('tokenKey');
             var secretKey = getParameterByName('secretKey');
            var queryMode = getParameterByName('queryMode');
            queryMode = queryMode.replace('edit', '');
  localStorage.setItem("headerPageName", 'app_financialgoaldetails'); 
    		var queryString = window.location.search.slice(1); 
    		var newQuery = queryString +'&queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey+'&queryMode=mylist'+'&financialid=' + response.data._id+'&recordID=' + response.data._id 
    		var queryParams = queryStringToJSON(newQuery); 
    		queryString = $.param(queryParams); 
         queryString = queryString.replace(/\+/g, "%20"); 
    		queryString = decodeURIComponent(queryString);
              if (recordID == '') { 
                  window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?'+ queryString
              }else{
                  window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?'+ queryString
              }
              return false;
 }); // End of After Process
          } else {
              $('#display_loading1').addClass('hideme');
              $('#2656d_error').html(response.error);
              $('#2656d_error').show();
          }
          $('#result17').removeProp('disabled');
      },
      error: function (xhr, status, error) {
          $('#display_loading1').addClass('hideme');
          $('#result17').removeProp('disabled');
      },
  });
 return false;
  }); // End of Before Process
  });//end of Event Result_is_click 
 var forwardChekbox = [];
 var isOpenForwardPopup = 0;
 var objParams = {};
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 


        ///
				var element = $(this);
			  var rolename = localStorage.getItem("roleName");
        // var nextPage = 'app_custmoreinfodetails';
        var nextPage = 'app_allfinancialservicesstepfinallist';
            if (rolename == "consultant") {
              nextPage = "app_consultantcustmoreinfodetails";
            } 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "update"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#retirementfund7', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_retirementcalculateadd'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "add"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - retirementfund7", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#childuniversityfund9', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_childcalculateadd'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "add"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - childuniversityfund9", error) 
		} 
	})
});//end of ready
 function getParams(url) {
      var urlParams = {};
      url.replace(
                  new RegExp("([^?=&]+)(=([^&]*))?", "g"),
                  function($0, $1, $2, $3) {
                     if($3 && $3 != 'undefined') urlParams[$1] = $3;
                  }
                 );
                return urlParams;
     }
 function processBeforeCallForSave7257result(objParams,response,callback){ 

 
var savings13 = $("#savings13").val();
var years = $("#years14").val();
var currentsaving15 = $("#currentsaving15").val(); 
var inflationrate16 = $("#inflationrate16").val();

var d = new Date();
var currentyear = d.getFullYear();

var yeartoachive = years-currentyear;

var shortfall = parseFloat(savings13) - parseFloat($("#currentsaving15").val()); 
if(shortfall < 0)
{
    shortfall = 0;
}
inflationrate16 = inflationrate16/100;

var inflationrate16value = (1+inflationrate16);
var inflationrate16value1 = inflationrate16value;
for (var i = 1; i < yeartoachive; i++) {
	inflationrate16value1 =  inflationrate16value1*inflationrate16value
}
 
firstlevelvalue = shortfall*inflationrate16value1
firstlevelvalue1 = firstlevelvalue/yeartoachive;
 

objParams.shortfall = shortfall;
objParams.investmentrequipredpermonth = firstlevelvalue1/12;
 objParams.recordID = localStorage.userID;
callback();
 }
 function processAfterCallForSave7257result(response,callback){ 

 callback();
 }
