
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
 var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on('click', '#done124', function () {
  var tokenKey = getParameterByName('tokenKey');
 var secretKey = getParameterByName('secretKey');
 var queryMode = getParameterByName('queryMode');
 var recordID = getParameterByName('recordID');
 queryMode = 'mylist'
  window.location.href = 'app_userhome_5da73cac545050343288ce7a.html?queryMode='+ queryMode+'&tokenKey='+tokenKey+ '&secretKey=' + secretKey
  return false;
  });//end of Event Done_is_click 
 var forwardChekbox = [];
 var isOpenForwardPopup = 0;
 var objParams = {};
});//end of ready