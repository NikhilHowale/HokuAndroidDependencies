
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var totaldcard_collectioncontainer = 0;
$(document).ready(function () {
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"))
    }
    updatenotificationunreadcount()
    var objParamsToken = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsToken.tokenKey = getParameterByName('tokenKey');
    objParamsToken.secretKey = getParameterByName('secretKey');

    var userRole = $('#userRole').val();
    var userID = $('#userID').val();
    var createrOfRecord = $('#createrOfRecord').val();
    var queryMode = getParameterByName('queryMode');
    var recordID = $.trim($('#recordID').val());
    var addSessionComments = [];


    var queryMode = getParameterByName('queryMode');
    var isMobile = $('#isMobile').val();
    var isiPad = $('#isiPad').val();
    if (queryMode != '') {
        var tokenKey = $('#tokenKey').val();
        var objParamsList = {};
        objParamsList.queryMode = queryMode;
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParamsList.tokenKey = getParameterByName('tokenKey');
        objParamsList.secretKey = getParameterByName('secretKey');
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = isMobile;
        objParamsList.isiPad = isiPad;
        objParamsList.applyFilter = false;
        getDataProcessBeforeCalldcard_collectioncontainerOrders5da73cac545050343288ce7a(objParamsList, function (processBeforeRes) {
            if (getParameterByName('clientid') && getParameterByName('clientid') != '' && getParameterByName('clientid') != null && getParameterByName('clientid') != 'undefined') {
                objParamsList.clientid = getParameterByName('clientid');
            }
            var applyFilter = getParameterByName('applyFilter');
            if (applyFilter == null && objParamsList.applyFilter == false) {
                objParamsList.type = 'appointments';
                objParamsList.applystaticfilter = true;
            }
            var applyFilter = getParameterByName('applyFilter');
            if (applyFilter == null && objParamsList.applyFilter == false) {
                objParamsList.status = 'Requested,Approved,Rejected,Handed Over,Accepted';
                objParamsList.applystaticfilter = true;
            }
            var dcard_collectioncontainerapp_appointmentslisting = localStorage.getItem('dcard_collectioncontainerapp_appointmentslisting');
            var applyFilter = getParameterByName('applyFilter');
            $('#display_loading').removeClass('hideme');
            if (dcard_collectioncontainerapp_appointmentslisting && applyFilter != 'true') {
                response = JSON.parse(dcard_collectioncontainerapp_appointmentslisting);
                $('#collectioncontainerDivdcard_collectioncontainer').html('');
                getdcard_collectioncontainerapp_appointmentslistingMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
                dcard_collectioncontainerapp_appointmentslistingSync(response.timestamp);
            } else {
                show_dcard_collectioncontainerapp_appointmentslisting_Details(objParamsList)
            }
        });//End of get data process before call.
    }
    $(document).on('click', '.dcard_collectioncontainer', function () {
        if (dcardLoaded && !dcardLoaded['dcard_collectioncontainer']) { return false; }; // added for use should not able to click until data loaded
        localStorage.setItem("headerPageName", 'app_appointments2details');
        var recordID = $(this).attr('recordID');// get record ID;
        var ordersid = $(this).attr('recordID');// get record ID;
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = 'update';
        var nextPage = 'app_appointments2details';
        if (!nextPage) {
            return false;
        }
        var pageurl = nextPage + '_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&ordersid=' + ordersid + '&recordID=' + recordID + '&applyFilter=true';
        window.location.href = pageurl;
        return false;
    }); // to add New record

    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#backbutton1', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_custmoreinfodetails';
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "update";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - backbutton1", error)
        }
    })
    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#headeraddnew3', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_appointmentsadd';
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "add";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            if(queryParams["reschedule"])
	            queryParams.delete["reschedule"];
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - headeraddnew3", error)
        }
    })
    // showBottomMenu();
});//end of ready
function getDataProcessBeforeCalldcard_collectioncontainerOrders5da73cac545050343288ce7a(objParamsList, callback) {
    var response = objParamsList

    var data = {
    };
    functf1aa4d70f0ce11e9b8cc058871cb4a77(response, function (responsefunctf1aa4d70f0ce11e9b8cc058871cb4a77) {
        if (responsefunctf1aa4d70f0ce11e9b8cc058871cb4a77.inValid) {
            callback();
        } else {
            callback();
        }
    });

    function functf1aa4d70f0ce11e9b8cc058871cb4a77(response, callback) {
        objParamsList.clientid = localStorage.userID;
        objParamsList.type = 'appointments';
        callback({ 'inValid': 1 });
    }
}
function dcard_collectioncontainerapp_appointmentslistingSync(timestamp) {
    try {
        var objParamsList = {};
        objParamsList.queryMode = 'mylist';
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParamsList.tokenKey = getParameterByName('tokenKey');
        objParamsList.secretKey = getParameterByName('secretKey');
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = true;
        objParamsList.timestamp = timestamp;
        $.ajax({
            url: objParamsList.ajaXCallURL + '/milestone003/syncListDetails_Orders5da73cac545050343288ce7a_app_appointmentslisting',
            data: objParamsList,
            type: 'POST',
            success: function (response) {
                $('#display_loading').addClass('hideme');
                if (response.status != undefined && response.status == 1) {
                    localStorage.removeItem('dcard_collectioncontainerapp_appointmentslisting');
                    var objParamsList = {};
                    objParamsList.queryMode = 'mylist';
                    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                    objParamsList.tokenKey = getParameterByName('tokenKey');
                    objParamsList.secretKey = getParameterByName('secretKey');
                    objParamsList.ajaXCallURL = ajaXCallURL;
                    objParamsList.isMobile = 'true';
                    objParamsList.isiPad = false;
                    objParamsList.timestamp = timestamp;
                    if (getParameterByName('clientid') && getParameterByName('clientid') != '' && getParameterByName('clientid') != null && getParameterByName('clientid') != 'undefined') {
                        objParamsList.clientid = getParameterByName('clientid');
                    }
                    var applyFilter = getParameterByName('applyFilter');
                    if (applyFilter == null && objParamsList.applyFilter == false) {
                        objParamsList.type = 'appointments';
                        objParamsList.applystaticfilter = true;
                    }
                    var applyFilter = getParameterByName('applyFilter');
                    if (applyFilter == null && objParamsList.applyFilter == false) {
                        objParamsList.status = 'Requested,Approved,Rejected,Handed Over,Accepted';
                        objParamsList.applystaticfilter = true;
                    }
                    show_dcard_collectioncontainerapp_appointmentslisting_Details(objParamsList)
                }
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            }
        });
    } catch (err) {
        // console.log('Error in workingtoolsSync', err);
    }
}
function show_dcard_collectioncontainerapp_appointmentslisting_Details(objParamsList) {
    if (getParameterByName('clientid') && getParameterByName('clientid') != '' && getParameterByName('clientid') != null && getParameterByName('clientid') != 'undefined') {
        objParamsList.clientid = getParameterByName('clientid');
    }
    var applyFilter = getParameterByName('applyFilter');
    if (applyFilter == null && objParamsList.applyFilter == false) {
        objParamsList.type = 'appointments';
        objParamsList.applystaticfilter = true;
    }
    var applyFilter = getParameterByName('applyFilter');
    if (applyFilter == null && objParamsList.applyFilter == false) {
        objParamsList.status = 'Requested,Approved,Rejected,Handed Over,Accepted,Cancelled';
        objParamsList.applystaticfilter = true;
    }
    localStorage.setItem('appappointmentslistingFilterBox', '');

    $.ajax({
        url: objParamsList.ajaXCallURL + '/milestone003/getListDetails_Orders5da73cac545050343288ce7a_app_appointmentslisting_dcard_collectioncontainer',
        // url: objParamsList.ajaXCallURL + '/milestone003/app_get_refreralpointhistorylisting',
        data: objParamsList,
        type: 'POST',
        success: function (response) {
            getDataProcessAfterCalldcard_collectioncontainerOrders5da73cac545050343288ce7a(response, function () {
                if (response.status != undefined && response.status == 0) {
                    if (objParamsList.isMobile == 'true') {
                        $('#collectioncontainerDivdcard_collectioncontainer').html('');
                        localStorage.removeItem('dcard_collectioncontainerapp_appointmentslisting');
                        getdcard_collectioncontainerapp_appointmentslistingMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    } else if (objParamsList.isiPad == 'true') {
                        getdcard_collectioncontainerapp_appointmentslistingiPadView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    } else {
                        getdcard_collectioncontainerapp_appointmentslistingWebView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    }
                    $('#display_loading').addClass('hideme');
                } else {
                    $('#display_loading').addClass('hideme')
                }
            });
        },
        error: function (xhr, status, error) {
            $('#display_loading').addClass('hideme')
            handleError(xhr, status, error);
        },
    });
} // end of function     

function getDataProcessAfterCalldcard_collectioncontainerOrders5da73cac545050343288ce7a(response, callback) {

    callback();
}

function getdcard_collectioncontainerapp_appointmentslistingMobileView(response, tokenKey, queryMode) {
    var html = '';
    if (response.data.length == 0) {
        html += '<div class="nodatafound">';
        html += '<img src="nodatafound.gif" width="100%">';
        html += '<br>';
        html += '<!-- span>No record found</span -->';
        html += '</div>';
        $('#collectioncontainerDivdcard_collectioncontainer').html(html);;
    } else {
        html = '';
        var radioGroups = [];
        var url = 'card.png';
        if(localStorage.getItem('consultantphoto')){
            let consultantphoto = JSON.parse(localStorage.getItem('consultantphoto'));
            if (consultantphoto && consultantphoto[0].mediaID) {
              url = CDN_PATH + consultantphoto[0].mediaID + '_compressed.png';
            }
        }
        $.each(response.data, function (keyList, objList) {


            html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.clientname + objList.status + objList.note + objList.createdon) + '">';
            html += '      		<div class="col s12 m12">';
            html += '               <div class="card-content">';
            html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_collectioncontainer" style="" >';
            html += '      <div class="row  element" style=""  >';
            var adddbclass = ''


            html += ' <div class="row">' +
                '<div class="col s3 leftcard">' + //left div
                '<img class="leftcard-image" src="'+url+'">' +
                '</div>' +  // left div closed
                '<div class="col s9 rightcard">' + //right div
                '<div recordID="' + objList._id + '" class="col s8 clssg3418  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['note'] = objList['note'] ? objList['note'] : '';
            if (response.showShimmer) {
                objList['note'] = '';
            }
            var note = objList['note'];
            html += '           <div recordID="' + objList._id + '"   id="note12" class="languagetranslation " style="font-weight: bold;" >' + note + '</div>';
            html += '     </div>';
            var adddbclass = ''
            var statusclass = "clssg5418";
            if (objList['status'] == "Accepted") {
                statusclass = "clssg5418Approved";
            }

            html += '           <div recordID="' + objList._id + '" class="col s4 ' + statusclass + ' ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['status'] = objList['status'] ? objList['status'] : '';
            if (response.showShimmer) {
                objList['status'] = '';
            }
            var status = objList['status'];
            html += '           <div recordID="' + objList._id + '"   id="status11" class="languagetranslation " style="" >' + status + '</div>';
            html += '     </div>';
            var adddbclass = ''
        
            html += '           <div recordID="' + objList._id + '" class="col s9 clssg9418  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['slotdate'] = objList['slotdate'] ? moment(new Date(objList['slotdate'])).format('DD/MM/YYYY') : '';
            var slotdate = objList['slotdate'];
            html += '           <div recordID="' + objList._id + '"   id="slotdate13" class="languagetranslation " style="" >' + slotdate + '<br> ' + objList.starttime + ' to ' + objList.endtime + '</div>';
            html += '     </div>';
            html += '<div class="col s3 right-align">' +
                '<img src="./Event-Calendar-Gold.svg">';
            html += '     </div>';
            html += '</div>'; // right div closed
            html += '</div>'; //row closed
            html += '      				</div>';
            html += '          </div>';
            html += '        </div>';
            html += '     </div>';
            html += '   </div>';
            html += '   </div>';
        }); //end of each loop
        $('#collectioncontainerDivdcard_collectioncontainer').html(html)
        $('#full-body-container').addClass('fadeInUp');
        if (!response.showShimmer) {
            dcardLoaded['dcard_collectioncontainer'] = true;
            $('#collectioncontainerDivdcard_collectioncontainer').find('.view_list_record').removeClass('shimmer');
        }
        $('.carddropdown').material_select();
        $('<input>').attr({ type: 'hidden', class: 'cardtoggleswitch', id: 'togleswitchvalue' }).appendTo('body')
        if ($('.js-candlestick').length) $('.js-candlestick').candlestick({ afterSetting: function (input, wrapper, value) { $('#togleswitchvalue').val(value).attr('recordID', input.attr('id')).trigger('click'); } });
        if (radioGroups && radioGroups.length) {
            for (var key in radioGroups) {
                var groupName = radioGroups[key];
                $('input:radio[name=' + groupName + ']:first').prop('checked', true);
                $('input:radio[name=' + groupName + ']:first').trigger('change');
            }
        }
    };
};
function getLocalImagedcard_collectioncontainer(objList, mediaID, fileName) {
    try {
        var appJSON = {};
        appJSON.nextButtonCallback = 'handleLocalImagedcard_collectioncontainer';
        appJSON.url = CDN_PATH + mediaID + '_compressed.png';
        appJSON.fileMimeType = 'image/png';
        appJSON.fileName = fileName;
        appJSON.objList = objList;
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        if (isAndroid > -1) {
            window.Android.getLocalImage(JSON.stringify(appJSON))
        } else {
            setupWebViewJavascriptBridge(function (bridge) {
                bridgeObj = bridge;
                bridgeObj.callHandler('getLocalImage', appJSON, function (response) { });
                bridgeObj.registerHandler('handleLocalImagedcard_collectioncontainer', function (responseData, responseCallback) {
                    handleLocalImagedcard_collectioncontainer(responseData)
                });
            });
        }
    } catch (err) {

    }
}
function handleLocalImagedcard_collectioncontainer(response) {
    var objList = response.dataDictionay.objList;
    var html = '';

    html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.clientname + objList.status + objList.note + objList.createdon) + '">';
    html += '      		<div class="col s12 m12">';
    html += '               <div class="card-content">';
    html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_collectioncontainer" style="" >';
    html += '      <div class="row  element" style=""  >';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s8 clssg3418  ' + adddbclass + ' " style=" cursor: pointer;">';
       objList['note'] = objList['note'] ? objList['note'] : '';
    if (response.showShimmer) {
        objList['note'] = '';
    }
    var note = objList['note'];
    html += '           <div recordID="' + objList._id + '"   id="note12" class="languagetranslation " style="" >' + note + '</div>';
    html += '     </div>';
    var adddbclass = ''
    var statusclass = "clssg5418";
    if (objList['status'] == "Accepted") {
        statusclass = "clssg5418Approved";
    }
    html += '           <div recordID="' + objList._id + '" class="col s4 clssg5418  ' + statusclass + ' ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['status'] = objList['status'] ? objList['status'] : '';
    if (response.showShimmer) {
        objList['status'] = '';
    }
    var status = objList['status'];
    html += '           <div recordID="' + objList._id + '"   id="status11" class="languagetranslation " style="" >' + status + '</div>';
    html += '     </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s12 clssg9418  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['slotdate'] = objList['slotdate'] ? moment(new Date(objList['slotdate'])).format('DD/MM/YYYY') : '';
    var slotdate = objList['slotdate'];
    html += '           <div recordID="' + objList._id + '"   id="slotdate13" class="languagetranslation " style="" >' + slotdate + '</div>';
    html += '     </div>';
    html += '     </div>';
    html += '      				</div>';
    html += '          </div>';
    html += '        </div>';
    html += '     </div>';
    html += '   </div>';
    $('#collectioncontainerDivdcard_collectioncontainer').append(html)
    $('#full-body-container').addClass('fadeInUp');
    dcardLoaded['dcard_collectioncontainer'] = true;
    $('#collectioncontainerDivdcard_collectioncontainer').find('.view_list_record').removeClass('shimmer');
    // after html bining code
};

function getdcard_collectioncontainerapp_appointmentslistingPadView(response, tokenKey, queryMode) {
    var html = '';
    if (response.data.length == 0) {
        html += '<tr>';
        html += '<td colspan="1" class="text_center first_row_table_td">';
        html += 'No record found';
        html += '</td>';
        html += '</tr>';
    } else {
        html = '';
        $.each(response.data, function (keyList, objList) {

            html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.clientname + objList.status + objList.note + objList.createdon) + '">';
            html += '      		<div class="col s12 m12">';
            html += '               <div class="card-content">';
            html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_collectioncontainer" style="" >';
            html += '      <div class="row  element" style=""  >';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s8 clssg3418  ' + adddbclass + ' " style=" cursor: pointer;">';
                 objList['note'] = objList['note'] ? objList['note'] : '';
            if (response.showShimmer) {
                objList['note'] = '';
            }
            var note = objList['note'];
            html += '           <div recordID="' + objList._id + '"   id="note12" class="languagetranslation " style="" >' + note + '</div>';
            html += '     </div>';
            var adddbclass = ''
            var statusclass = "clssg5418";
            if (objList['status'] == "Accepted") {
                statusclass = "clssg5418Approved";
            }
            html += '           <div recordID="' + objList._id + '" class="col s4 clssg5418  ' + statusclass + ' ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['status'] = objList['status'] ? objList['status'] : '';
            if (response.showShimmer) {
                objList['status'] = '';
            }
            var status = objList['status'];
            html += '           <div recordID="' + objList._id + '"   id="status11" class="languagetranslation " style="" >' + status + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg9418  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['slotdate'] = objList['slotdate'] ? moment(new Date(objList['slotdate'])).format('DD/MM/YYYY') : '';
            var slotdate = objList['slotdate'];
            html += '           <div recordID="' + objList._id + '"   id="slotdate13" class="languagetranslation " style="" >' + slotdate + '</div>';
            html += '     </div>';
            html += '     </div>';
            html += '      				</div>';
            html += '          </div>';
            html += '        </div>';
            html += '     </div>';
            html += '   </div>';
        }); // end of each loop
    };
    $('#collectioncontainerDivdcard_collectioncontainer').html(html)
};

function getdcard_collectioncontainerapp_appointmentslistingWebView(response, tokenKey, queryMode) {
    var html = '';
    if (response.data.length == 0) {
        html += '<tr>';
        html += '<td colspan="1" class="text_center first_row_table_td">';
        html += 'No record found';
        html += '</td>';
        html += '</tr>';
    } else {
        html = '';
        $.each(response.data, function (keyList, objList) {

            html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.clientname + objList.status + objList.note + objList.createdon) + '">';
            html += '      		<div class="col s12 m12">';
            html += '               <div class="card-content">';
            html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_collectioncontainer" style="" >';
            html += '      <div class="row  element" style=""  >';
            var adddbclass = ''
            html += ' <div class="row">' +
                '<div class="col s3 ">' + //left div
                '<img class="leftcard-image" src="./nouserprofile.svg">' +
                '</div>' +  // left div closed
                '<div class="col s9 rightcard">' + //right div         
                '<div recordID="' + objList._id + '" class="col s8 clssg3418  ' + adddbclass + ' " style=" cursor: pointer;">';
           objList['note'] = objList['note'] ? objList['note'] : '';
            if (response.showShimmer) {
                objList['note'] = '';
            }
            var note = objList['note'];
            html += '           <div recordID="' + objList._id + '"   id="note12" class="languagetranslation " style="font-weight: bold;" >' + note + '</div>';
            html += '     </div>';
            var adddbclass = ''
            var statusclass = "clssg5418";
            if (objList['status'] == "Accepted") {
                statusclass = "clssg5418Approved";
            }

            html += '           <div recordID="' + objList._id + '" class="col s4 clssg5418  ' + statusclass + ' ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['status'] = objList['status'] ? objList['status'] : '';
            if (response.showShimmer) {
                objList['status'] = '';
            }
            var status = objList['status'];
            html += '           <div recordID="' + objList._id + '"   id="status11" class="languagetranslation " style="" >' + status + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s9 clssg9418  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['slotdate'] = objList['slotdate'] ? moment(new Date(objList['slotdate'])).format('DD/MM/YYYY') : '';
            var slotdate = objList['slotdate'];
            html += '           <div recordID="' + objList._id + '"   id="slotdate13" class="languagetranslation " style="" >' + slotdate + '</div>';
            html += '     </div>';
            html += '<div class="col s3 right-align">' +
                '<img src="./Event-Calendar-Gold.svg">';
            html += '</div>';

            html += '     </div>'; //right div closed
            html += '      </div>'; //row closed
            html += '     </div>';
            html += '      				</div>';
            html += '          </div>';
            html += '        </div>';
            html += '     </div>';
            html += '   </div>';
        }); // end of each loop 1
    };
    $('#collectioncontainerDivdcard_collectioncontainer').html(html)
};
//  function showBottomMenu(){ 
//    var menuObj = localStorage.getItem('objGetUserDetailsWithmenu');
//    if(menuObj){
//      menuObj = JSON.parse(menuObj);
//      if( menuObj.data && menuObj.data.roleName ) {
//           var roleName = menuObj.data.roleName;
//      }
//    }
//    try { 
//       var bottommenu = ''; 
// 	    bottommenu += '<div class="mobilebottommenu">'
// 	    bottommenu += '    <div class="row">'
// 	    bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Home" fileName="app_userhome_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_home.svg"><span>Home</span></a></div>'
// 	    bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Appointment" fileName="app_alleventpromotionslist_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_calendaractive.svg"><span style ="color :#af935d !important;">Discover</span></a></div>'
// 	    bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Scan" fileName="app_sacaner_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_barcode.svg" class="scannerbottommenu"><span>Scan</span></a></div>'
//        bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Chat" fileName="undefined_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_chat.svg"><span>Chat</span></a><div style="display:none !important" class="chatunreadcount"></div></div>'
// 	    bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="More" fileName="app_custmoreinfodetails_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_more.svg"><span>More</span></a></div>'
// 	    bottommenu += '    </div>'
// 	    bottommenu += '</div>'
//       $('#bottommenu14').html(bottommenu)
//   } catch(err){
//      // console.log('Error in showBottomMenu', err);
//   }
// }
function updatenotificationunreadcount() {
    var userID = JSON.parse(localStorage.getItem("appUser"))._id
    var objParams = {}
    var recordID = $('#recordID').val();
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParams.tokenKey = getParameterByName('tokenKey');
    objParams.secretKey = getParameterByName('secretKey');
    objParams.offlineDataID = localStorage.getItem("offlineDataID");
    var queryMode = getParameterByName('queryMode')

    objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxusermanagement7555updateapp_clientprofile';
    objParams.recordID = userID;
    objParams.appointmentunreadcount = 0;
    $.ajax({
        url: objParams.callUrl,
        data: objParams,
        type: 'POST',
        success: function (response) {



        },
        error: function (xhr, status, error) {
            // $('#display_loading').addClass('hideme')
            // handleError(xhr, status, error);
        },
    });

}
