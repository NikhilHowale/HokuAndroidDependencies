
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
 var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on('click', '#createone10', function () {
  var tokenKey = getParameterByName('tokenKey');
 var secretKey = getParameterByName('secretKey');
 var queryMode = getParameterByName('queryMode');
 var recordID = getParameterByName('recordID');
 queryMode = 'add'
  window.location.href = 'usersignup_5da73cac545050343288ce7a.html?queryMode='+ queryMode+'&tokenKey='+tokenKey+ '&secretKey=' + secretKey
  return false;
  });//end of Event Create One_is_click 
 var forwardChekbox = [];
 var isOpenForwardPopup = 0;
 var objParams = {};
     Materialize.updateTextFields();
     var gBrnach = [];
     $(document).on('click', '#login7', function (e) {
         e.preventDefault();
         $('#display_loading').removeClass('hideme');
         $('#forgotPass_status').hide();
         $('#invalid_details_error').hide();
         var objParams = {};
         var email = $.trim($('#contactnumber4').val());
         if ($('#contactnumber4_div').is(':visible')) {
             if (email == '') {
                 $('#display_loading').addClass('hideme');
                 $('#contactnumber4_error').show();
                 $('#contactnumber4').focus();
                 return false;
             } else {
                 $('#contactnumber4_error').hide();
             }
         }
         var email = $.trim($('#email5').val());
         if ($('#email5_div').is(':visible')) {
             if (email == '') {
                 $('#display_loading').addClass('hideme');
                 $('#email5_error').show();
                 $('#email5').focus();
                 return false;
             } else {
                 $('#email5_error').hide();
             }
         }
         var password = $.trim($('#password6').val());
 
         if ($('#password6_div').is(':visible')) {
             if (password == '') {
                 $('#display_loading').addClass('hideme');
                 $('#password6_error').show();
                 $('#password6').focus();
                 return false;
             } else {
                 $('#password6_error').hide();
             }
         }
          
 localStorage.clear();
 getAppLogin(email, password);
     }); //end of Event
});//end of ready
 (function (global) {
    try {
     if (typeof (global) === "undefined") {
         throw new Error("window is undefined");
     }
     var _hash = "!";
     var noBackPlease = function () {
         global.location.href += "#";
         // making sure we have the fruit available for juice (^__^)
         global.setTimeout(function () {
             global.location.href += "!";
         }, 50);
     };
 
     global.onhashchange = function () {
         if (global.location.hash !== _hash) {
             global.location.hash = _hash;
         }
     };
 
     global.onload = function () {
         noBackPlease();
         // disables backspace on page except on input fields and textarea..
         document.body.onkeydown = function (e) {
             var elm = e.target.nodeName.toLowerCase();
             if (e.which === 8 && (elm !== 'input' && elm !== 'textarea')) {
                 e.preventDefault();
             }
             // stopping event bubbling up the DOM tree..
             e.stopPropagation();
         };
     }
     } catch(err) {
       // console.log('Error in global call', err);
     } 
 
 })(window);
 		function getAppLogin(username, password, callback) {
 			try {
 		        var ajaXCallURL = $('#ajaXCallURL').val();
 				var objParams = {};
 				objParams.username = username;
 				objParams.password = password;
 				objParams.subdomain = 'milestoneorg';
 				objParams.appID = '5da73cac545050343288ce7a';
 				$.ajax({
 					url: ajaXCallURL + '/milestone003/hokuexternallogin5da73cac545050343288ce7a',
 					data: objParams,
 					type: 'POST',
 					success: function(response) {
 						if (response.status != undefined && response.status == 0) {
                            response = response.responseParams || response
 							localStorage.setItem('userID', response.user.userId);
 			                if (response.isUpdatePassword) {
 									  var tokenKey = response.appTokenDetails.authToken;
 									  var secretKey = response.appTokenDetails.authSecretKey;
           					window.location.href = 'updatepassword_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey+ '&userID=' + response.user.userId;
                  			return false
 			                } else {
 							localStorage.setItem('objGetUserDetailsWithmenu', JSON.stringify(response.objGetUserDetailsWithmenu));
 							localStorage.setItem('perms', JSON.stringify(response.perms));
 							localStorage.setItem('user', JSON.stringify(response.user));
 							localStorage.setItem('appUser', JSON.stringify(response.appUser));
 							localStorage.setItem('organizationID', response.user.organizationId);
 							localStorage.setItem('CDN_PATH', response.CDN_PATH);
 							localStorage.setItem('CDN_THUMB', response.CDN_THUMB);
 							if(response.appUser && response.appUser.userphotoupload && response.appUser.userphotoupload[0]){
 								localStorage.setItem('profileThumb', response.appUser.userphotoupload[0].mediaID+'_compressed.png');
 							} else {
 								localStorage.removeItem('profileThumb');
 							} 
 			                localStorage.setItem('tokenData', JSON.stringify(response.tokenData));
 							loginNativeCallWrapper(response, '5da73cac545050343288ce7a');
 							return false;
 							}
 						} else {
                 $('#display_loading').addClass('hideme');
                 $('#contactnumber4_error').html("Please enter correct details.");
                 $('#contactnumber4_error').show();
                 $('#contactnumber4').focus();
                 return false;
                 $('#display_loading').addClass('hideme');
                 $('#email5_error').html("Please enter correct details.");
                 $('#email5_error').show();
                 $('#email5').focus();
                 return false;
 						}
 					},
 					error: function(xhr, status, error) {
                 $('#display_loading').addClass('hideme');
                 $('#contactnumber4_error').html("Please enter correct details.");
                 $('#contactnumber4_error').show();
                 $('#contactnumber4').focus();
                 return false;
                 $('#display_loading').addClass('hideme');
                 $('#email5_error').html("Please enter correct details.");
                 $('#email5_error').show();
                 $('#email5').focus();
                 return false;
 					},
 				});
 			} catch (err) {
 				console.log('Error in getAppLogin', err);
                 $('#display_loading').addClass('hideme');
                 $('#contactnumber4_error').html("Please enter correct details.");
                 $('#contactnumber4_error').show();
                 $('#contactnumber4').focus();
                 return false;
                 $('#display_loading').addClass('hideme');
                 $('#email5_error').html("Please enter correct details.");
                 $('#email5_error').show();
                 $('#email5').focus();
                 return false;
 			}
 	    }
 function loginNativeCallWrapper(response, appID) {
     try { 
		  var queryMode = $('#queryMode').val();
                         var appJSON = {};
                         appJSON.organizationID = response.user.organizationId;
                         appJSON.userID = response.user._id;
                         appJSON.appID = $('#appID').val();
                         appJSON.nextButtonCallback = 'setloginNativeCallBack';
                         appJSON.action = queryMode;
                         appJSON.colorCode = '#3c3c3c';
                         appJSON.response = response;
                         appJSON.launchNative = false;
                         appJSON.authToken = response.appTokenDetails.authToken;
                         appJSON.authSecretKey = response.appTokenDetails.authSecretKey;
                         appJSON.roleName = response.appTokenDetails.roleName;
 						   appJSON.expiredTime = response.appTokenDetails.expiredTime;
                         appJSON.launchNextpage = 'userhome5da73cac545050343288ce7a.html'
  
                     var AWSCredentials = localStorage.getItem("AWSCredentials");  
                     if (localStorage.IDENTITY_TOKEN) {  
                     	var token = localStorage.IDENTITY_TOKEN;  
                     	var playload = JSON.parse(atob(token.split(".")[1]));  
                     	appJSON.Authorization = token;  
                     	appJSON.Expiration = playload.exp;  
                     } else if (AWSCredentials) {  
                     	AWSCredentials = JSON.parse(AWSCredentials);  
                     	appJSON.accessKeyId = AWSCredentials.accessKeyId;  
                     	appJSON.secretAccessKey = AWSCredentials.secretAccessKey;  
                     	appJSON.sessionToken = AWSCredentials.sessionToken;  
                     	appJSON.Expiration = AWSCredentials.Expiration;  
                     } 
                         var roleName = response.appTokenDetails.roleName;
                         localStorage.setItem('roleName',roleName);
 						   var tokenKey = response.appTokenDetails.authToken;
 					   	   var secretKey = response.appTokenDetails.authSecretKey; 
           			var ISDEV_MODE = 	localStorage.getItem("ISDEV_MODE"); 
           			var DEV_MODE  = getParameterByName('devmode');
 						if(ISDEV_MODE == "true" || DEV_MODE){
 									  var queryMode = 'mylist';
if(roleName == "consultant"){
 	window.location.href = 'app_consultantuserhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
 	return false
}
if(roleName == "customer"){
 	window.location.href = 'app_userhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
 	return false
}
                                     return false;
 						 }else{
                                          var objParams = {};
                                          objParams.organizationID = appJSON.organizationID;
                                          objParams.userID = appJSON.userID;
                                          objParams.appID = appJSON.appID;
                                          objParams.roleName = roleName;
                                          objParams.isLogin = true;
                              			  var ajaXCallURL =  CognitoConfig.GATEWAY_URL;
                             appJSON.Authorization =  localStorage.getItem('IDENTITY_TOKEN');

                                           appJSON.apiName =  ajaXCallURL + '/api/addUserDeviceForApp_5da73cac545050343288ce7a';
                                          appJSON.addDeviceObject = objParams; 
           						var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
 									if( isAndroid > -1 ){
                         				window.Android.loginNativeCallV2(JSON.stringify(appJSON))
                         			} else {
                         			  	bridgeObj.callHandler('loginNativeCall', appJSON, function(response) {});
                         			  	bridgeObj.registerHandler('setloginNativeCallBack', function(responseData, responseCallback) {
                            			setloginNativeCallBack(responseData)
                         			 	});
                         			}
                         }
     } catch (err) {
         $('#display_loading').addClass('hideme');
     }
 }
 
function setCurrentLocationOfUser(responseData,response) {
    try {
        var apiParams = {};
        if (responseData) {
            $('#display_loading').addClass('hideme');
            // Add Custome function Call here
            localStorage.setItem('locationPingJson',JSON.stringify(responseData));
            var userDeviceObj = responseData.userDeviceObj;
           if(responseData.data){
            responseData = responseData.data;
           }
          var tokenKey = response.appTokenDetails.authToken;
          var secretKey = response.appTokenDetails.authSecretKey;
           var queryMode = 'mylist';
           var roleName = localStorage.getItem('roleName');
if(roleName == "consultant"){
 	window.location.href = 'app_consultantuserhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
 	return false
}
if(roleName == "customer"){
 	window.location.href = 'app_userhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
 	return false
}
      }
    } catch (err) {
    }
}
 
 
 function apiCall(params, callback) {
     try {
         var https = new XMLHttpRequest();
         var URL = params.URL;
         https.open("POST", URL, true);
         https.setRequestHeader('content-type', 'application/json');
         https.setRequestHeader("token", params.token);
         if (params.token) delete params.token;
 
         https.onreadystatechange = function () {
             if (https.readyState == 4 && https.status == 200) {
                 var response = https.responseText;
                 if (typeof response != 'object') {
                     response = JSON.parse(response);
                 }
                 callback(response);
             }
         }
         params = JSON.stringify(params);
         https.send(params);
     } catch (err) {
 
     }
 }
 
 function setloginNativeCallBack(responseData){
   try {
       if (responseData) {
           var userDeviceObj = responseData.userDeviceObj;
           if(responseData.data){
           	responseData = responseData.data;
           }
           var tokenKey = responseData.authToken;
           var secretKey = responseData.authSecretKey;
           var queryMode = 'mylist';
           var roleName = localStorage.getItem('roleName');
if(roleName == "consultant"){
 	window.location.href = 'app_consultantuserhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
 	return false
}
if(roleName == "customer"){
 	window.location.href = 'app_userhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
 	return false
}
       };
   } catch (err) {};
 }
