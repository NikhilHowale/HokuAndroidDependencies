
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
     var totaldcard_leftimage3_collectioncontainer = 0;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorderdetails'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "update"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '.dcard_leftimage3_collectioncontainer', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorderdetailsaddupdatemembers'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "update"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
      		var objResponse = {};
      		objResponse.recordID = recordID;
      		pageredirectProcessBeforeCallOrders5da73cac545050343288ce7adcard_leftimage3_collectioncontainer(element, queryParams,objResponse, function(updatedNextPage){
     		 	if(objResponse.nextPage){
     		 		nextPage = objResponse.nextPage
     		 	}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
    		}) 
		} catch(error){ 
			console.log("Error in pageredirect workflow - dcard_leftimage3_collectioncontainer", error) 
		} 
	})
	$(document).on('click', '#selectall3', function(e) {
		try {
			var element = $(this);
			var objParams = {};
			objParams.recordID = getParameterByName('recordID');
			if ($(this).attr('recordID')) {
				objParams.recordID = $(this).attr('recordID');
			}
		
			customcodeOrders5da73cac545050343288ce7aSelectAll(objParams, element,{}, function (processCustomcode) {
			    return false;
			});
		} catch (error) {
			console.log('Error in customcode click', error);
		}
	});
});//end of ready
function pageredirectProcessBeforeCallOrders5da73cac545050343288ce7adcard_leftimage3_collectioncontainer(element, objParams,response,callback) {
	try{
 

	selectedStaffJobs(response, function (responseselectedStaffJobs) {
	if(responseselectedStaffJobs.inValid) {
	setStaffJobs(response, function (responsesetStaffJobs) {
	if(responsesetStaffJobs.inValid) {
			Materialize.updateTextFields();
			return false;
 		} else {
			Materialize.updateTextFields();
			return false;
 		}
 });
 		} else {
			Materialize.updateTextFields();
			return false;
 		}
 });

 function selectedStaffJobs(response, callback) {
 $('.iconcheck16[recordid='+response.recordID+']').toggleClass('hide');
     if($('.iconcheck16[recordid='+response.recordID+']').hasClass('hide')){
         if(localStorage.getItem('participants')){
             var arrFilterSelectedBox = localStorage.getItem('participants').split(',');
         } else {
             var arrFilterSelectedBox = [];
         }
 		var arrFilterSelectedBoxSplite = []
 		arrFilterSelectedBoxSplite.push(response.recordID)
 		for(count = 0;count < arrFilterSelectedBoxSplite.length;count++){
         		arrFilterSelectedBox = arrFilterSelectedBox.filter(function(elem){
             		return elem != arrFilterSelectedBoxSplite[count]; 
         		});
 		}
         localStorage.setItem('participants',arrFilterSelectedBox.toString());
     } else {
         if(localStorage.getItem('participants')){
             var arrFilterSelectedBox = localStorage.getItem('participants').split(',');
         } else {
             var arrFilterSelectedBox = [];
         }
 		var arrFilterSelectedBoxSplite = []
 		arrFilterSelectedBoxSplite.push(response.recordID)
 		for(count = 0;count < arrFilterSelectedBoxSplite.length;count++){
 			if (arrFilterSelectedBox.indexOf(arrFilterSelectedBoxSplite[count]) == -1){
					arrFilterSelectedBox.push(arrFilterSelectedBoxSplite[count]);
 			}
 		}
         localStorage.setItem('participants',arrFilterSelectedBox.toString());
     }
	callback({'inValid': 1});
 }
 function setStaffJobs(response, callback) {
 var localget = localStorage.getItem('participants')
 if(localget){
 	var localcount = localget.split(',')
 } else {
 	var localcount = []
 }
 $('#selectedmembers02').html('Selected Members ('+localcount.length+')');
	callback({'inValid': 1});
 }
	} catch(error) { 
		console.log('Error in pageredirectProcessBeforeCallOrders5da73cac545050343288ce7adcard_leftimage3_collectioncontainer', error);
		callback();
	}
}
 $(document).on('keyup', '#globalsearch8', function () {
      var globalsearchtext = $('#globalsearch8').val();
      if(globalsearchtext){
          $('#globalsearchcloseicon_img').show();
      } else {
          $('#globalsearchcloseicon_img').hide();
      }
      var objParamsList = {};
      objParamsList.queryMode = 'mylist';
      var ajaXCallURL = $.trim($('#ajaXCallURL').val());
      objParamsList.tokenKey = getParameterByName('tokenKey');
      objParamsList.secretKey = getParameterByName('secretKey');
      objParamsList.ajaXCallURL = ajaXCallURL;
      objParamsList.isMobile = 'true';
      objParamsList.isiPad = false;
      $('#display_loading').addClass('hideme');
      objParamsList.globalsearchvalue = globalsearchtext;
      $('#collectioncontainerDivdcard_leftimage3_collectioncontainer').html('');
      $('#collectioncontainerDivdcard_leftimage3_collectioncontainer').find('.view_list_record').removeClass('shimmer');
      show_dcard_leftimage3_collectioncontainerapp_myorderdetailsaddupdatemembers_Details(objParamsList)
 });
 $(document).on('click', '#globalsearchcloseicon_img', function () {
      var objParamsList = {};
      objParamsList.queryMode = 'mylist';
      var ajaXCallURL = $.trim($('#ajaXCallURL').val());
      objParamsList.tokenKey = getParameterByName('tokenKey');
      objParamsList.secretKey = getParameterByName('secretKey');
      objParamsList.ajaXCallURL = ajaXCallURL;
      objParamsList.isMobile = 'true';
      objParamsList.isiPad = false;
      $('#display_loading').addClass('hideme');
      $('#globalsearch8').val('');
      $('#collectioncontainerDivdcard_leftimage3_collectioncontainer').html('');
      $('#collectioncontainerDivdcard_leftimage3_collectioncontainer').find('.view_list_record').removeClass('shimmer');
      show_dcard_leftimage3_collectioncontainerapp_myorderdetailsaddupdatemembers_Details(objParamsList)
 });
   function customcodeOrders5da73cac545050343288ce7aSelectAll(objParams, element,response,callback){
      try{ 	    var response = objParams; 	    response.element = element;

 var data = {
 text: {},
 memberids: {},
 };
	funct3c8016309b3511e9908dfdd6c1fe1c8d(response, function (responsefunct3c8016309b3511e9908dfdd6c1fe1c8d) {
	if(responsefunct3c8016309b3511e9908dfdd6c1fe1c8d.inValid) {
	funct3c8016319b3511e9908dfdd6c1fe1c8d(response, function (responsefunct3c8016319b3511e9908dfdd6c1fe1c8d) {
	if(responsefunct3c8016319b3511e9908dfdd6c1fe1c8d.inValid) {
	funct3c803d409b3511e9908dfdd6c1fe1c8d(response, function (responsefunct3c803d409b3511e9908dfdd6c1fe1c8d) {
	if(responsefunct3c803d409b3511e9908dfdd6c1fe1c8d.inValid) {
			callback();
 		} else {
			callback();
 		}
 });
 		} else {
			callback();
 		}
 });
 		} else {
			callback();
 		}
 });

 function funct3c8016309b3511e9908dfdd6c1fe1c8d(response, callback) {
 data.text = $('#selectall3').html();
	callback({'inValid': 1});
 }
 function funct3c8016319b3511e9908dfdd6c1fe1c8d(response, callback) {
				if (data.text =='Select All') {
data.memberids=localStorage.getItem('allmembers');
localStorage.setItem('participants',data.memberids);;
if(localStorage.getItem('participants')){ 
     var arrFilterSelectedBoxSplite = localStorage.getItem('participants').split(',');
     for(count = 0;count < arrFilterSelectedBoxSplite.length;count++){
         $('.iconcheck16[recordid='+arrFilterSelectedBoxSplite[count]+']').removeClass('hide');
     }
     var counttext ='Selected Members ('+arrFilterSelectedBoxSplite.length+')';
     $('#selectedmembers02').html(counttext);
}
 $('#selectall3').html('Unselect All');
 }
	callback({'inValid': 1});
 }
 function funct3c803d409b3511e9908dfdd6c1fe1c8d(response, callback) {
				if (data.text =='Unselect All') {
data.memberids='';
localStorage.setItem('participants',data.memberids);;
$('.iconcheck16').addClass('hide');
var counttext ='Selected Members (0)';
$('#selectedmembers02').html(counttext);
 $('#selectall3').html('Select All');
 }
	callback({'inValid': 1});
 }
     } catch(err){
          callback();
          // console.log('Error in customcode', err);
     }
 }