//get data in group"
function formatDataInGroup (groupIn,data,startDate,filterDateColumn) { 
  var result = [];
  switch(groupIn){
    case 'Monthly':
    result = getDataInMonths(data,startDate,filterDateColumn)
    break;
    case 'Quarterly':
    result = getDataInQuarter(data,startDate,filterDateColumn);
    break;
    case 'Yearly':
    result = getDataInYears(data,filterDateColumn)
    break;
    case "Weekly":
    result = getDataInWeek(data,startDate,filterDateColumn);
    break;
    default:
    result = getDataForDay(data,startDate,filterDateColumn);
    break;
  }
  return result;
}
function getstartDate (groupIn) { 
  switch(groupIn){
    case 'Monthly':
    return moment().startOf("month").format("DD MMMM YYYY")
    break;
    case 'Quarterly':
    return moment().startOf("quarter").format("DD MMMM YYYY")
    break;
    case 'Yearly':
    return moment().startOf("year").format("DD MMMM YYYY")
    break;
    case 'Weekly':
    return moment().startOf("week").format("DD MMMM YYYY")
    break;
    default:
    return moment().startOf("day").format("DD MMMM YYYY")
    break;
  }
}

//data is response received from api"
function getDataInYears(data,filterDateColumn){
  var Jan = [],Feb = [],Mar = [],Apr = [],May = [],June = [],July = [],Aug = [],Sept = [],Oct = [],Nov = [],Dec = [];
  $.each(data, function(keyList, objList) {
   var month = moment(objList[filterDateColumn]).format('M');
   switch(month){
     case '1':
     Jan.push(objList);
     break;
     case '2':
     Feb.push(objList);
     break;
     case '3':
     Mar.push(objList);
     break;
     case '4':
     Apr.push(objList);
     break;
     case '5':
     May.push(objList);
     break;
     case '6':
     June.push(objList);
     break;
     case '7':
     July.push(objList);
     break;
     case '8':
     Aug.push(objList);
     break;
     case '9':
     Sept.push(objList);
     break;
     case '10':
     Oct.push(objList);
     break;
     case '11':
     Nov.push(objList);
     break;
     case '12':
     Dec.push(objList);
     break;
   }
 });
  data = [Jan,Feb,Mar,Apr,May,June,July,Aug,Sept,Oct,Nov,Dec];
  return data;
}

//data is response received from api"
//startDate is date that user wnats to get data from"
function getDataInWeek(data,startDate,filterDateColumn){
 var monday = [];
 var tuesday = [];
 var wednesday = [];
 var thursday = [];
 var friday = [];
 var saturday = [];
 var sunday = [];
 var result = [];
 $.each(data, function(keyList, objList) {  
   if(objList._id)
   {
     if(moment(objList[filterDateColumn]).format('DD MMMM YYYY') <= moment(startDate).format('DD MMMM YYYY'))
     {
       sunday.push(objList);
     }
     else if(moment(objList[filterDateColumn]).format('DD MMMM YYYY') <= moment(startDate).add(1,'day').format('DD MMMM YYYY')  && moment(objList[filterDateColumn]).format('DD MMMM YYYY') > moment(startDate).format('DD MMMM YYYY'))
     {    
       monday.push(objList);
     }
     else if(moment(objList[filterDateColumn]).format('DD MMMM YYYY') <= moment(startDate).add(2,'day').format('DD MMMM YYYY')  && moment(objList[filterDateColumn]).format('DD MMMM YYYY') > moment(startDate).add(1,'day').format('DD MMMM YYYY'))
     {   
       tuesday.push(objList);
     }
     else if(moment(objList[filterDateColumn]).format('DD MMMM YYYY') <= moment(startDate).add(3,'day').format('DD MMMM YYYY')  && moment(objList[filterDateColumn]).format('DD MMMM YYYY') > moment(startDate).add(2,'day').format('DD MMMM YYYY'))
     {
       wednesday.push(objList);
     }
     else if(moment(objList[filterDateColumn]).format('DD MMMM YYYY') <= moment(startDate).add(4,'day').format('DD MMMM YYYY')  && moment(objList[filterDateColumn]).format('DD MMMM YYYY') > moment(startDate).add(3,'day').format('DD MMMM YYYY'))
     {   
       thursday.push(objList);
     }
     else if(moment(objList[filterDateColumn]).format('DD MMMM YYYY') <= moment(startDate).add(5,'day').format('DD MMMM YYYY')  && moment(objList[filterDateColumn]).format('DD MMMM YYYY') > moment(startDate).add(4,'day').format('DD MMMM YYYY'))
     {  
       friday.push(objList);
     }
     else if(moment(objList[filterDateColumn]).format('DD MMMM YYYY') <= moment(startDate).add(6,'day').format('DD MMMM YYYY')  && moment(objList[filterDateColumn]).format('DD MMMM YYYY') > moment(startDate).add(5,'day').format('DD MMMM YYYY'))
     {
       saturday.push(objList);
     }
   }
 });
 result = [sunday,monday,tuesday,wednesday,thursday,friday,saturday];
 return result;
}

//data is response received from api"
//startDate is date that user wnats to get data from"
function getDataInMonths(data,startDate,filterDateColumn){
  var week1 = [];
  var week2 = [];
  var week3 = [];
  var week4 = [];
  var week5 = [];
  var result = [];
  $.each(data, function(keyList, objList) {  
    if(objList._id)
    {
      if(moment(objList[filterDateColumn]) >= moment(startDate)   && moment(objList[filterDateColumn]) <= moment(startDate).add(1,'week') )
        week1.push(objList);
      else if(moment(objList[filterDateColumn]) >= moment(startDate).add(1,'week')  && moment(objList[filterDateColumn]) <= moment(startDate).add(2,'week'))
        week2.push(objList);
      else if(moment(objList[filterDateColumn]) >= moment(startDate).add(2,'week')  && moment(objList[filterDateColumn]) <= moment(startDate).add(3,'week'))
       week3.push(objList);
     else if(moment(objList[filterDateColumn]) >= moment(startDate).add(3,'week')  && moment(objList[filterDateColumn]) <= moment(startDate).add(4,'week'))
       week4.push(objList);
     else if(moment(objList[filterDateColumn]) >= moment(startDate).add(4,'week')  && moment(objList[filterDateColumn]) <= moment(startDate).add(5,'week'))
       week5.push(objList);
   }
 });
  result = [week1,week2,week3,week4,week5];
  return result;
}

//data is response received from api"
//startDate is date that user wnats to get data from"
function getDataInQuarter(data,startDate,filterDateColumn){
 var month1 = [];
 var month2 = [];
 var month3 = [];
 var result = [];
 $.each(data, function(keyList, objList) {  
   if(objList._id)
   {
     if(moment(objList[filterDateColumn]) >= moment(startDate)   && moment(objList[filterDateColumn]) <= moment(startDate).add(1,'month') )
       month1.push(objList);
     else if(moment(objList[filterDateColumn]) >= moment(startDate).add(1,'month')  && moment(objList[filterDateColumn]) <= moment(startDate).add(2,'month'))
       month2.push(objList);
     else if(moment(objList[filterDateColumn]) >= moment(startDate).add(2,'month')  && moment(objList[filterDateColumn]) <= moment(startDate).add(3,'month'))
       month3.push(objList);
   }
 });
 result = [month1,month2,month3];
 return result;
}


//data is response received from api"
//startDate is date that user wnats to get data from"
function getDataForDay(data,startDate,filterDateColumn){
 var today = [];
 $.each(data, function(keyList, objList) {  
   if(objList._id)
   {
     if(moment(objList[filterDateColumn]).format('DD MMMM YYYY') == moment().format('DD MMMM YYYY'))
     {
      today.push(objList);
     }
   }
 });
 result = [today];
 return result;
}
//function to get the sum of the values to be ploted"
function getSum(data,columnName){
  var result = [];
  var tempResult = [];
  var  total = 0;
  $.each(data, function(keyList, singleArr) {
    tempResult = [];
    $.each(columnName, function(keyList, colName) {

      total = 0;
      $.each(singleArr, function(keyList, arrObjects) {
        if(arrObjects[colName]){
          total += parseInt(arrObjects[colName]);
        }
      });
      tempResult.push(total);
    });     
    result.push(tempResult);
  });    

  return result;
}


//function to get the data count to be ploted"
function getCount(data){
 var result = [];
 $.each(data, function(keyList, objList) { 
   result.push(objList.length);
 });
 return result
}
//function to get the sum of the values to be ploted"
function getPercentage(data,percentColumn,totalColumn){
  var result = [];
  var tempResult = [];
  var  total = 0;
  var  percentage = 0;
  $.each(data, function(keyList, singleArr) {
    $.each(singleArr, function(keyList, arrObjects) {
      if(arrObjects[totalColumn]){
        total += parseInt(arrObjects[totalColumn]);
      }
    });
  });    
  $.each(data, function(keyList, singleArr) {
    $.each(singleArr, function(keyList, arrObjects) {
      if(arrObjects[percentColumn]){
        percentage += (parseInt(arrObjects[percentColumn]) / parseInt(total));
        result.push(percentage);
      }
    });
  });    

  return result;
}

//function to get the data to be formated in datatable to be send to charts"
function getChartFormatData(data,columns,series){
  var dataTable = new google.visualization.DataTable();
  var index = 0;
  dataTable.addColumn("string","Density");
  $.each(series, function(keyList, valueArray) {  
    dataTable.addColumn("number",valueArray);
  });
  $.each(data, function(keyList, valueArray) {  
    var name = columns[index];
    if(valueArray.constructor === Array){
      valueArray.splice(0, 0, name)
      dataTable.addRow(valueArray);
    }else{
      var inputArray = [];
      inputArray.push(name);
      inputArray.push(valueArray);
      dataTable.addRow(inputArray);
    }
    index = index + 1 ;
  });
  return dataTable
}

//function to get the column names to be displayed in the x-axis"
function getColumnName(groupName){
  switch(groupName){
   case 'Monthly':
   return ['Week 1','Week 2','Week 3','Week 4','Week 5'];
   break;
   case 'Quarterly':
   return ['Quarter 1','Quarter 2','Quarter 3'];
   break;
   case 'Yearly':
   return ['Jan','Feb','Mar','Apr','May','June','July','Aug','Sept','Oct','Nov','Dec'];
   break;
   case 'Weekly':
   return ['Mon','Tues','Wed','Thur','Fri','Sat','Sun'];
   break;
   default:
   return [''+ moment().format("dddd") +''];
   break;
 }
}

//group data into current and last year and sum it
function groupDataByYears(data,filterDateColumn,sumColumn){
  var currentYearData = [];
  var lastYearData = [];
  var currentYear = [];
  var lastYear = [];
  var total = 0;
  var tempResponse = [];
  var response = [];
  data.forEach(function (item, key, mapObj) {  
    if(moment(item[filterDateColumn]).format("YYYY") == moment().format("YYYY")){
      currentYearData.push(item);
    }
    else if(moment(item[filterDateColumn]).format("YYYY") == moment().subtract(1,"year").format("YYYY")){
      lastYearData.push(item);
    }
  });
  currentYearData = getDataInYears(currentYearData,filterDateColumn);
  lastYearData = getDataInYears(lastYearData,filterDateColumn);
  if(currentYearData && currentYearData.length > 0){
    $.each(currentYearData, function(keyList, value) {  
      $.each(value, function(object, objectList) {  
        total += parseInt(objectList[sumColumn]);
      }); 
      currentYear.push(total);
      total = 0;
    }); 
  }
  total = 0;
  if(lastYearData && lastYearData.length > 0){
    $.each(lastYearData, function(keyList, value) {  
      $.each(value, function(object, objectList) {  
        total += parseInt(objectList[sumColumn]);
      }); 
      lastYear.push(total);
      total = 0;
    }); 
  }
  for(index = 0; index < lastYear.length; index++){
    tempResponse = [];
    tempResponse.push(lastYear[index]);
    tempResponse.push(currentYear[index]);
    response.push(tempResponse);
  }
  return response;
}
//group data into current and last year and count it
function groupDataByYearsCount(data,filterDateColumn,sumColumn){
  var currentYearData = [];
  var lastYearData = [];
  var currentYear = [];
  var lastYear = [];
  var total = 0;
  var tempResponse = [];
  var response = [];
  data.forEach(function (item, key, mapObj) {  
    if(moment(item[filterDateColumn]).format("YYYY") == moment().format("YYYY")){
      currentYearData.push(item);
    }
    else if(moment(item[filterDateColumn]).format("YYYY") == moment().subtract(1,"year").format("YYYY")){
      lastYearData.push(item);
    }
  });
  currentYearData = getDataInYears(currentYearData,filterDateColumn);
  lastYearData = getDataInYears(lastYearData,filterDateColumn);
  if(currentYearData && currentYearData.length > 0){
    $.each(currentYearData, function(keyList, value) {  
      if(value && value.length > 0){
        currentYear.push(value.length);
      }
    }); 
  }
  if(lastYearData && lastYearData.length > 0){
    $.each(lastYearData, function(keyList, value) {  
      if(value && value.length > 0){
        lastYear.push(value.length);
      }
    }); 
  }
  for(index = 0; index < lastYear.length; index++){
    tempResponse = [];
    tempResponse.push(lastYear[index]);
    tempResponse.push(currentYear[index]);
    response.push(tempResponse);
  }
  return response;
}
//group data by given column
function groupBy(data, keyGetter) {
  const map = new Map();
  data.forEach((item) => {
    const key = keyGetter(item);
    const collection = map.get(key);
    if (!collection) {
      map.set(key, [item]);
    } else {
      collection.push(item);
    }
  });
  return map;
}
//code to set date range for data to be pulled
function setDateRage(params,groupIn){
  var result = {};
  switch($(".groupBy select").val()){
    case "Weekly":
      params.startDate = moment().startOf('week').format("DD MMMM YYYY, h:mm A");
      params.endDate = moment().endOf('week').format("DD MMMM YYYY, h:mm A");
      groupIn = "Weekly";
    break;
    case "Monthly":
      params.startDate = moment().startOf('month').format("DD MMMM YYYY, h:mm A");
      params.endDate = moment().endOf('month').format("DD MMMM YYYY, h:mm A");
      groupIn = "Monthly";
    break;
    case "Quarterly":
      params.startDate = moment().startOf('Quarter').format("DD MMMM YYYY, h:mm A");
      params.endDate = moment().endOf('Quarter').format("DD MMMM YYYY, h:mm A");
      groupIn = "Quarterly";
    break;
    case "Yearly":
      params.startDate = moment().startOf('year').format("DD MMMM YYYY, h:mm A");
      params.endDate = moment().endOf('year').format("DD MMMM YYYY, h:mm A");
      groupIn = "Yearly";
    break;
    case "CustomDate" :
    var date_diff = moment(getEndDate()).diff(moment(getFromDate()), 'days');
    switch(true){
      case (date_diff <= 7):
        params.startDate = moment().startOf('week').format("DD MMMM YYYY, h:mm A");
        params.endDate = moment().endOf('week').format("DD MMMM YYYY, h:mm A");
        groupIn = "Weekly";
      break;
      case (date_diff > 7 && date_diff < 30):
        params.startDate = moment().startOf('month').format("DD MMMM YYYY, h:mm A");
        params.endDate = moment().endOf('month').format("DD MMMM YYYY, h:mm A");
        groupIn = "Monthly";
      break;
      case (date_diff >= 30 && date_diff < 90):
        params.startDate = moment().startOf('Quarter').format("DD MMMM YYYY, h:mm A");
        params.endDate = moment().endOf('Quarter').format("DD MMMM YYYY, h:mm A");
        groupIn = "Quarterly";
      break;
      case (date_diff >= 90 && date_diff < 360):
        params.startDate = moment().startOf('year').format("DD MMMM YYYY, h:mm A");
        params.endDate = moment().endOf('year').format("DD MMMM YYYY, h:mm A");
        groupIn = "Yearly";
      break;
      default:
        params.startDate = moment().startOf('day').format("DD MMMM YYYY, h:mm A");
        params.endDate = moment().endOf('day').format("DD MMMM YYYY, h:mm A");
      break;
    }
    default:
      params.startDate = moment().startOf('day').format("DD MMMM YYYY, h:mm A");
      params.endDate = moment().endOf('day').format("DD MMMM YYYY, h:mm A");
    break;
  }
  result.params = params;
  result.groupIn = groupIn != '' ? groupIn : 'Today' ;
  return result;
}
//get start date seletced by user
function getFromDate() {
  return $(".start_date input").val() != '' ? $(".start_date input").val() : new Date('1970-01-01');
}
//get end date seletced by user
function getEndDate() {
  return $(".end_date input").val() != '' ? $(".end_date input").val() : new Date();
}
//function to get values for names and values
function getDisplyValues(data,series){
  var result = {};
  var dataValues = [];
  var columnName = [];
  var nameColumn = series[0];
  var dataColumn = series[1];
  $.each(data, function(keyList, singleArr) {
    if(singleArr && singleArr.length > 0){
      $.each(singleArr, function(keyList, arrObjects) {
        if(arrObjects[nameColumn]){
          dataValues.push(arrObjects[dataColumn]);
          columnName.push(arrObjects[nameColumn]);
        }
      });
    }
  });     
  result.data = dataValues;
  result.columnName = columnName;
  return result;
}