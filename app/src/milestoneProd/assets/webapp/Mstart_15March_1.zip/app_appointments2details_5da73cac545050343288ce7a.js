
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
  // $(document).on('click', '#back_2', function() {
  //    window.location.href = "app_appointmentslisting_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=" + getParameterByName('tokenKey') + "&secretKey=" + getParameterByName('secretKey');
  // });
  $(document).on('click', '#reschedule_1', function() {
    window.location.href = "app_timeslot_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=" + getParameterByName('tokenKey') + "&secretKey=" + getParameterByName('secretKey') + "&ordersid=" + getParameterByName('ordersid') + "&recordID=" + getParameterByName('recordID')+ "&reschedule=true" ;
 })
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }
  $(document).on('click', '#back_2', function(e) {
    let params = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    params.recordID = getParameterByName('recordID');
    params.tokenKey = getParameterByName('tokenKey');
    params.secretKey = getParameterByName('secretKey');
    params.status = 'Cancelled';
    $.ajax({
      url: ajaXCallURL+'/milestone003/updateAjaxordersapp_timeslot',
      data: params,
      type: 'POST',
      success: function (response) { 
        shareAppData('Appointment cancelled successfully','toast')
        window.location.href = "app_appointmentslisting_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=" + getParameterByName('tokenKey') + "&secretKey=" + getParameterByName('secretKey');
      }
    });
  })

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = []; 
    $(document).on('click', '#backbutton1', function(e) { 
      
      try{ 
        var element = $(this);
       var nextPage = 'app_appointmentslisting'; 
       var queryParams = queryStringToJSON(); 
         var recordID = $(this).attr("recordID"); 
         if(recordID){ 
           queryParams["recordID"] = recordID; 
         }
       var queryString = $.param(queryParams);
       queryString = queryString.replace(/\+/g, "%20");
       queryString = decodeURIComponent(queryString);
       window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
         return false;  
               // window.history.back();  
         // return false;  
   } catch(error){ 
     console.log("Error in pageredirect workflow - backbutton1", error) 
   } 
    		// window.history.back();  
    		// return false;  
    })
      var paramsEdit = {};
      paramsEdit.tokenKey = getParameterByName('tokenKey');
      paramsEdit.secretKey = getParameterByName('secretKey') 
                       getRecordByIDProcessBeforeCall648002(paramsEdit, function (processBeforeRes) {
      $.ajax({
          url: ajaXCallURL+'/milestone003/getRecordByCustomeQuery_app_appointments2details_Orders5da73cac545050343288ce7a',
          data: paramsEdit,
          type: 'POST',
          jsonpCallback: 'callback',
          success: function (response) { 
                       getRecordByIDProcessAfterCall648002(response, function (processBeforeRes) {
              if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                  var objParamsList = {};
                  var queryMode = $('#queryMode').val(); 
                  objParamsList.queryMode = queryMode;;
                  var tokenKey = $('#tokenKey').val();;
                  objParamsList.tokenKey = tokenKey;;
  if(!$('#appointmentdetails2').html()){
            $('#appointmentdetails2').append(response.recordDetails.undefined);
 }
  if(!$('#appointmentid14').html()){
            $('#appointmentid14').append(response.recordDetails.undefined);
 }
  if(!$('#backbutton1').html()){
            $('#backbutton1').append(response.recordDetails.undefined);
 }
  if(!$('#consultant17').html()){
            $('#consultant17').append(response.recordDetails.undefined);
 }
  if(!$('#emailaddress23').html()){
            $('#emailaddress23').append(response.recordDetails.undefined);
 }
  if(!$('#mobilenumber20').html()){
            $('#mobilenumber20').append(response.recordDetails.undefined);
 }
  if(!$('#notes26').html()){
            $('#notes26').append(response.recordDetails.undefined);
 }
//   if(!$('#clientcontact21').html()){
//             $('#clientcontact21').append(response.recordDetails.clientcontact);
//  }
//   if(!$('#clientname10').html()){
//             $('#clientname10').append(response.recordDetails.clientname);
//  }
  if(!$('#name18').html()){
            $('#name18').append(response.recordDetails.name);
 }
 response.recordDetails['slotdate_preserved'] = response.recordDetails['slotdate'] ;
 response.recordDetails['slotdate'] = response.recordDetails['slotdate']  ? moment(new Date(response.recordDetails['slotdate'])).format('dddd, DD MMMM YYYY') : '';
  if(!$('#slotdate7').html()){
            $('#slotdate7').append(response.recordDetails.slotdate);
 }
 response.recordDetails['slotdate'] =  response.recordDetails['slotdate_preserved'];
  if(!$('#email24').html()){
            $('#email24').append('<a style="color: rgb(175, 147, 93)" id="emailImg" class="mailtolink" href="mailto:'+ response.recordDetails.email+'">'+ response.recordDetails.email+'</a>');
 }
  if(!$('#note28').html()){
            $('#note28').html(response.recordDetails.note);
 }
 if(response.recordDetails.note){
  $('#clientname10').append(response.recordDetails.note);
}
  if(!$('#ordersnumber15').html()){
            $('#ordersnumber15').append(response.recordDetails.ordersnumber);
 }
  if(!$('#policytype_name12').html()){
            $('#policytype_name12').append(response.recordDetails.policytype_name);
 }
  if(!$('#starttime8').html()){
            $('#starttime8').append(response.recordDetails.starttime);
 }
  if(!$('#status11').html()){
            $('#status11').append(response.recordDetails.status);
 }
 if (response.recordDetails.clientcontact) {
  $('#clientcontact21').html(`<a  style="color: rgb(175, 147, 93)" href="tel:${response.recordDetails.clientcontact}">${response.recordDetails.clientcontact}</a>`);
}

 if(localStorage.getItem('consultantphoto')){
   let consultantphoto = JSON.parse(localStorage.getItem('consultantphoto'));
   if (consultantphoto && consultantphoto[0].mediaID) {
     var url = CDN_PATH + consultantphoto[0].mediaID + '_compressed.png';
     $('#img_rounded').attr('src', url);
   }
 }
              Materialize.updateTextFields();
                $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);
  
              } 
              }); // end of getRecord By ID
          },
          error: function (xhr, status, error) {
              handleError(xhr, status, error); 
          },
      }); 
              }); // end of getRecord By ID
   
});//end of ready 
                 function getRecordByIDProcessBeforeCall648002(paramsType,callback) { 
                 var response = paramsType;
 
if(getParameterByName('ordersid') && getParameterByName('ordersid') != 'undefined'){paramsType.recordID = getParameterByName('ordersid')} else if(getParameterByName('recordID') && getParameterByName('recordID') != 'undefined'){paramsType.recordID = getParameterByName('recordID')};callback(); 
                 } 
                 function getRecordByIDProcessAfterCall648002(response,callback) {
 callback(); 
                 }
