var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = "";
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var totaldcard_topimage2x2_collectioncontainer = 0;
var totaldcard_recentappointment_collectioncontainer = 0;
var totaldcard_topimage3_collectioncontainer = 0;
var totallbl_banner_bannerimageupload = 0;
function makeSlidesbannerimageupload6(data) {
  var slide = "";
  var htmlString = "";
  if (data && data.length == 1) {
    data = data[0].bannerimageupload ? data[0].bannerimageupload : [];
  }
  if (data && data.length > 0) {
    for (let index = 0; index < data.length; index++) {
      const element = data[index];
      var mediaID;
      if (element && element.bannerimageupload && element.bannerimageupload[0]) {
        mediaID = element.bannerimageupload[0].mediaID;
      } else if (element && element.mediaID) {
        mediaID = element.mediaID;
      }
      slide += ' <div class="swiper-slide" href="#one!" >';
      slide += '    <div class="row  col s12" style="padding: 0px" !important;>';
      slide += '       <div id="image6_div" style="text-align: center;">';
      slide += '          <img  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + mediaID + '_compressed.png" style="width:100%; height:210px">';
      slide += "       </div>";
      slide += "    </div>";
      slide += "        </div>";
    }
    if (slide) {
      $("#bannerimageupload6").html(slide);
    }
    var swiper = new Swiper(".swiper-container", {
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
      watchOverflow: true,
      pagination: {
        el: ".swiper-pagination",
      },
    });
    $(".dynamic-slider-view").removeClass("shimmer");
  }
}

$(document).ready(function () {
  localStorage.removeItem('consultantphoto');
  refreshAWSToken(function (response) {
    if (response) {
      $("#recordID").val(getParameterByName("recordID"));
      var queryMode = getParameterByName("queryMode");
      var authKey = $("#authKey").val();
      var appID = $("#hdnAppID").val();
      if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"));
      }

      var objParamsToken = {};
      var ajaXCallURL = $.trim($("#ajaXCallURL").val());
      objParamsToken.tokenKey = getParameterByName("tokenKey");
      objParamsToken.secretKey = getParameterByName("secretKey");

      var userRole = $("#userRole").val();
      var userID = $("#userID").val();
      var createrOfRecord = $("#createrOfRecord").val();
      var queryMode = getParameterByName("queryMode");
      var recordID = $.trim($("#recordID").val());
      var addSessionComments = [];

      var queryMode = getParameterByName("queryMode");
      var isMobile = $("#isMobile").val();
      var isiPad = $("#isiPad").val();
      if (queryMode != "") {
        var tokenKey = $("#tokenKey").val();
        var objParamsList = {};
        objParamsList.queryMode = queryMode;
        var ajaXCallURL = $.trim($("#ajaXCallURL").val());
        objParamsList.tokenKey = getParameterByName("tokenKey");
        objParamsList.secretKey = getParameterByName("secretKey");
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = isMobile;
        objParamsList.isiPad = isiPad;
        objParamsList.applyFilter = false;
        getDataProcessBeforeCalldcard_recentappointment_collectioncontainerOrders5da73cac545050343288ce7a(objParamsList, function (processBeforeRes) {
          if (getParameterByName("type") && getParameterByName("type") != "" && getParameterByName("type") != null && getParameterByName("type") != "undefined") {
            objParamsList.type = getParameterByName("type");
          }
          if (getParameterByName("status") && getParameterByName("status") != "" && getParameterByName("status") != null && getParameterByName("status") != "undefined") {
            objParamsList.status = getParameterByName("status");
          }
          if (getParameterByName("clientid") && getParameterByName("clientid") != "" && getParameterByName("clientid") != null && getParameterByName("clientid") != "undefined") {
            objParamsList.clientid = getParameterByName("clientid");
          }
          var dcard_recentappointment_collectioncontainerapp_userhome = localStorage.getItem("dcard_recentappointment_collectioncontainerapp_userhome");
          var applyFilter = getParameterByName("applyFilter");
          $("#display_loading").removeClass("hideme");
          if (dcard_recentappointment_collectioncontainerapp_userhome && applyFilter != "true") {
            response = JSON.parse(dcard_recentappointment_collectioncontainerapp_userhome);
            $("#collectioncontainerDivdcard_recentappointment_collectioncontainer").html("");
            getdcard_recentappointment_collectioncontainerapp_userhomeMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
            dcard_recentappointment_collectioncontainerapp_userhomeSync(response.timestamp);
          } else {
            show_dcard_recentappointment_collectioncontainerapp_userhome_Details(objParamsList);
          }
        }); //End of get data process before call.
      }

      var queryMode = getParameterByName("queryMode");
      var isMobile = $("#isMobile").val();
      var isiPad = $("#isiPad").val();
      if (queryMode != "") {
        var tokenKey = $("#tokenKey").val();
        var objParamsList = {};
        objParamsList.queryMode = queryMode;
        var ajaXCallURL = $.trim($("#ajaXCallURL").val());
        objParamsList.tokenKey = getParameterByName("tokenKey");
        objParamsList.secretKey = getParameterByName("secretKey");
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = isMobile;
        objParamsList.isiPad = isiPad;
        objParamsList.applyFilter = false;
        getDataProcessBeforeCalldcard_topimage2x2_collectioncontainerBazaar5da73cac545050343288ce7a(objParamsList, function (processBeforeRes) {
          var applyFilter = getParameterByName("applyFilter");
          if (applyFilter == null && objParamsList.applyFilter == false) {
            objParamsList.type = "events";
            objParamsList.applystaticfilter = true;
          }
          if (
            getParameterByName("eventdate") &&
            getParameterByName("eventdate") != "" &&
            getParameterByName("eventdate") != null &&
            getParameterByName("eventdate") != "undefined"
          ) {
            objParamsList.eventdate = getParameterByName("eventdate");
          }
          if (
            getParameterByName("eventenddate") &&
            getParameterByName("eventenddate") != "" &&
            getParameterByName("eventenddate") != null &&
            getParameterByName("eventenddate") != "undefined"
          ) {
            objParamsList.eventenddate = getParameterByName("eventenddate");
          }
          var dcard_topimage2x2_collectioncontainerapp_userhome = localStorage.getItem("dcard_topimage2x2_collectioncontainerapp_userhome");
          var applyFilter = getParameterByName("applyFilter");
          $("#display_loading").removeClass("hideme");
          if (dcard_topimage2x2_collectioncontainerapp_userhome && applyFilter != "true") {
            response = JSON.parse(dcard_topimage2x2_collectioncontainerapp_userhome);
            $("#collectioncontainerDivdcard_topimage2x2_collectioncontainer").html("");
            getdcard_topimage2x2_collectioncontainerapp_userhomeMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
            dcard_topimage2x2_collectioncontainerapp_userhomeSync(response.timestamp);
          } else {
            show_dcard_topimage2x2_collectioncontainerapp_userhome_Details(objParamsList);
          }
        }); //End of get data process before call.
      }

      // Discount Code
      var queryMode = getParameterByName("queryMode");
      var isMobile = $("#isMobile").val();
      var isiPad = $("#isiPad").val();
      if (queryMode != "") {
        var tokenKey = $("#tokenKey").val();
        var objParamsList = {};
        objParamsList.queryMode = queryMode;
        var ajaXCallURL = $.trim($("#ajaXCallURL").val());
        objParamsList.tokenKey = getParameterByName("tokenKey");
        objParamsList.secretKey = getParameterByName("secretKey");
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = isMobile;
        objParamsList.isiPad = isiPad;
        objParamsList.applyFilter = false;
        getDataProcessBeforeCalldcard_topimage2x2_collectioncontainerBazaar5da73cac545050343288ce7a__discount(objParamsList, function (processBeforeRes) {
          var dcard_topimage2x2_collectioncontainerapp_userhome = localStorage.getItem("dcard_topimage2x2_collectioncontainerapp_userhome_discount");
          var applyFilter = getParameterByName("applyFilter");
          $("#display_loading").removeClass("hideme");
          if (dcard_topimage2x2_collectioncontainerapp_userhome && applyFilter != "true") {
            response = JSON.parse(dcard_topimage2x2_collectioncontainerapp_userhome);
            $("#collectioncontainerDivdcard_topimage2x2_collectioncontainer__discount").html("");
            getdcard_topimage2x2_collectioncontainerapp_userhomeMobileView__discount(response, objParamsList.tokenKey, objParamsList.queryMode);
            dcard_topimage2x2_collectioncontainerapp_userhomeSync(response.timestamp);
          } else {
            show_dcard_topimage2x2_collectioncontainerapp_userhome_Details__discount(objParamsList);
          }
        }); //End of get data process before call.
      }
      $(document).on("click", "#sg6318", function () {
        try {
          var element = $(this);
          var nextPage = "app_customernotificationlisting";
          var queryParams = queryStringToJSON();
          queryParams["queryMode"] = "mylist";
          var recordID = $(this).attr("recordID");
          if (recordID) {
            queryParams["recordID"] = recordID;
          }
          var parent = "app_userhome";
          var queryString = $.param(queryParams);
          queryString = queryString.replace(/\+/g, "%20");
          queryString = decodeURIComponent(queryString);
          window.location.href = nextPage + "_5da73cac545050343288ce7a.html?" + queryString + "&parent=" + parent;
          return false;
        } catch (error) {
          console.log("Error in pageredirect workflow - notifications27", error);
        }
      });

      $(document).on("click", ".dcard_topimage2x2_collectioncontainer", function () {
        if (dcardLoaded && !dcardLoaded["dcard_topimage2x2_collectioncontainer"]) {
          return false;
        } // added for use should not able to click until data loaded
        localStorage.setItem("headerPageName", "app_productadditionaldetails");
        var recordID = $(this).attr("recordID"); // get record ID;
        var bazaarid = $(this).attr("recordID"); // get record ID;
        var tokenKey = getParameterByName("tokenKey");
        var secretKey = getParameterByName("secretKey");
        var queryMode = "update";
        var nextPage = "app_productadditionaldetails";
        if (!nextPage) {
          return false;
        }
        var parent = "app_userhome";
        var pageurl =
          nextPage +
          "_5da73cac545050343288ce7a.html?queryMode=" +
          queryMode +
          "&tokenKey=" +
          tokenKey +
          "&secretKey=" +
          secretKey +
          "&bazaarid=" +
          bazaarid +
          "&recordID=" +
          recordID +
          "&applyFilter=true" +
          "&parent=" +
          parent;
        window.location.href = pageurl;
        return false;
      }); // to add New record

      var queryMode = getParameterByName("queryMode");
      var isMobile = $("#isMobile").val();
      var isiPad = $("#isiPad").val();
      if (queryMode != "") {
        var tokenKey = $("#tokenKey").val();
        var objParamsList = {};
        objParamsList.queryMode = queryMode;
        var ajaXCallURL = $.trim($("#ajaXCallURL").val());
        objParamsList.tokenKey = getParameterByName("tokenKey");
        objParamsList.secretKey = getParameterByName("secretKey");
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = isMobile;
        objParamsList.isiPad = isiPad;
        objParamsList.applyFilter = false;
        getDataProcessBeforeCalldcard_topimage3_collectioncontainerBazaar5da73cac545050343288ce7a(objParamsList, function (processBeforeRes) {
          var applyFilter = getParameterByName("applyFilter");
          if (applyFilter == null && objParamsList.applyFilter == false) {
            objParamsList.type = "merchants";
            objParamsList.applystaticfilter = true;
          }
          var dcard_topimage3_collectioncontainerapp_userhome = localStorage.getItem("dcard_topimage3_collectioncontainerapp_userhome");
          var applyFilter = getParameterByName("applyFilter");
          $("#display_loading").removeClass("hideme");
          if (dcard_topimage3_collectioncontainerapp_userhome && applyFilter != "true") {
            response = JSON.parse(dcard_topimage3_collectioncontainerapp_userhome);
            $("#collectioncontainerDivdcard_topimage3_collectioncontainer").html("");
            getdcard_topimage3_collectioncontainerapp_userhomeMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
            dcard_topimage3_collectioncontainerapp_userhomeSync(response.timestamp);
          } else {
            show_dcard_topimage3_collectioncontainerapp_userhome_Details(objParamsList);
          }
        }); //End of get data process before call.
      }
      $(document).on("click", ".dcard_topimage3_collectioncontainer", function () {
        if (dcardLoaded && !dcardLoaded["dcard_topimage3_collectioncontainer"]) {
          return false;
        } // added for use should not able to click until data loaded
        localStorage.setItem("headerPageName", "app_merchantdetails");
        var recordID = $(this).attr("recordID"); // get record ID;
        //var bazaarid = $(this).attr('recordID'); // old
        var bazaarid = $(this).attr("bazaarid"); // new
        var merchantID = $(this).attr("merchantID"); // new
        var tokenKey = getParameterByName("tokenKey");
        var secretKey = getParameterByName("secretKey");
        var queryMode = "update";
        var nextPage = "app_merchantdetails";
        if (!nextPage) {
          return false;
        }
        localStorage.setItem("isFromHome", true);
        var pageurl =
          nextPage +
          "_5da73cac545050343288ce7a.html?queryMode=" +
          queryMode +
          "&tokenKey=" +
          tokenKey +
          "&secretKey=" +
          secretKey +
          "&bazaarid=" +
          bazaarid +
          "&recordID=" +
          recordID +
          "&applyFilter=true&merchantID=" +
          merchantID;
        window.location.href = pageurl;
        return false;
      }); // to add New record

      var paramsType = {};
      paramsType.tokenKey = getParameterByName("tokenKey");
      paramsType.secretKey = getParameterByName("secretKey");
      var bannerimages = localStorage.getItem("bannerimages");

      if (bannerimages) {
        response = JSON.parse(bannerimages);
        $("#collectioncontainerDivdcard_recentappointment_collectioncontainer").html("");
        if (response.status == 0) {
          makeSlidesbannerimageupload6(response.data);
        } else {
          makeSlidesbannerimageupload6([]);
        }
        //getdcard_recentappointment_collectioncontainerapp_userhomeMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
        getbannerImageSync(response.timestamp);
      } else {
        getbannerImage(objParamsList);
      }
      getbottombannerImage(objParamsList)
      getmiddlebannerImage(objParamsList);
      // getCountProcessBeforeCallbannerimageupload6(paramsType, function (processBeforeRes) {
      //     var ajaXCallURL = $.trim($('#ajaXCallURL').val());
      //     $.ajax({
      //         url: ajaXCallURL + '/milestone003/showslider_app_userhome_Customerbanner5da73cac545050343288ce7alblbannerbannerimageupload',
      //         data: paramsType,
      //         type: 'POST',
      //         success: function (response) {
      //             if (response.status == 0) {
      //                 makeSlidesbannerimageupload6(response.data)
      //             } else {
      //                 makeSlidesbannerimageupload6([])
      //             }
      //         },
      //         error: function (xhr, status, error) {
      //         },
      //     });
      // });
      function getCountProcessBeforeCallbannerimageupload6(paramsType, callback) {
        callback();
      }
      function getbannerImage() {
        var paramsType = {};
        paramsType.tokenKey = getParameterByName("tokenKey");
        paramsType.secretKey = getParameterByName("secretKey");
        //getCountProcessBeforeCallbannerimageupload6(paramsType, function (processBeforeRes) {
        var ajaXCallURL = $.trim($("#ajaXCallURL").val());
        $.ajax({
          url: ajaXCallURL + "/milestone003/showslider_app_userhome_Customerbanner5da73cac545050343288ce7alblbannerbannerimageupload",
          data: paramsType,
          type: "POST",
          success: function (response) {
            // localStorage.setItem("bannerimages", JSON.stringify(response));

            if (response.status == 0) {
              makeSlidesbannerimageupload6(response.data);
            } else {
              makeSlidesbannerimageupload6([]);
            }
          },
          error: function (xhr, status, error) { },
        });
        // });
      }

      function getbannerImageSync(timestamp) {
        var paramsType = {};
        paramsType.tokenKey = getParameterByName("tokenKey");
        paramsType.secretKey = getParameterByName("secretKey");
        getCountProcessBeforeCallbannerimageupload6(paramsType, function (processBeforeRes) {
          var ajaXCallURL = $.trim($("#ajaXCallURL").val());
          paramsType.timestamp = timestamp;

          $.ajax({
            url: ajaXCallURL + "/milestone003/synclist_showslider_app_userhome_Customerbanner5da73cac545050343288ce7alblbannerbannerimageupload",
            data: paramsType,
            type: "POST",
            success: function (response) {
              if (response.status != undefined && response.status == 1) {
                localStorage.removeItem("bannerimages");
                getbannerImage();
              } else {
                makeSlidesbannerimageupload6([]);
              }
            },
            error: function (xhr, status, error) { },
          });
        });
      }
      // var paramsType = {};
      // paramsType.tokenKey = getParameterByName('tokenKey');
      // paramsType.secretKey = getParameterByName('secretKey');
      // getCountProcessBeforeCallbannerimageupload6(paramsType, function (processBeforeRes) {
      //     var ajaXCallURL = $.trim($('#ajaXCallURL').val());
      //     $.ajax({
      //         url: ajaXCallURL + '/milestone003/showslider_app_userhome_Customerbanner5da73cac545050343288ce7alblbannerbannerimageupload',
      //         data: paramsType,
      //         type: 'POST',
      //         success: function (response) {
      //             if (response.status == 0) {
      //                 makeSlidesbannerimageupload6(response.data)
      //             } else {
      //                 makeSlidesbannerimageupload6([])
      //             }
      //         },
      //         error: function (xhr, status, error) {
      //         },
      //     });
      // });
      function getCountProcessBeforeCallbannerimageupload6(paramsType, callback) {
        callback();
      }
      var addedRecords = [];
      localStorage.setItem("addedRecords", []);
      $(document).on("click", "#viewall9", function (e) {
        try {
          var element = $(this);
          var parent = "app_userhome";
          // var nextPage = "app_allupcomingeventslist";
          var nextPage = 'app_alleventpromotionslist';
          var queryParams = queryStringToJSON();
          queryParams["queryMode"] = "mylist";
          var recordID = $(this).attr("recordID");
          if (recordID) {
            queryParams["recordID"] = recordID;
          }
          var queryString = $.param(queryParams);
          queryString = queryString.replace(/\+/g, "%20");
          queryString = decodeURIComponent(queryString);
          window.location.href = nextPage + "_5da73cac545050343288ce7a.html?" + queryString + "&parent=" + parent;
          return false;
        } catch (error) {
          console.log("Error in pageredirect workflow - viewall9", error);
        }
      });
      var addedRecords = [];
      localStorage.setItem("addedRecords", []);
      $(document).on("click", "#viewallmerchants26", function (e) {
        try {
          var element = $(this);
          var nextPage = "app_merchantlisting";
          var queryParams = queryStringToJSON();
          queryParams["queryMode"] = "mylist";
          var recordID = $(this).attr("recordID");
          if (recordID) {
            queryParams["recordID"] = recordID;
          }
          var queryString = $.param(queryParams);
          queryString = queryString.replace(/\+/g, "%20");
          queryString = decodeURIComponent(queryString);
          window.location.href = nextPage + "_5da73cac545050343288ce7a.html?" + queryString;
          return false;
        } catch (error) {
          console.log("Error in pageredirect workflow - viewallmerchants26", error);
        }
      });
      showBottomMenu();
    } else {
      writeLog("weblog : logout token refresh fail app_userhome.js");
      window.location.href = "login_cognito.html";
      return false;
    }
  });

  $(document).on('click', '#sgrow3809', function() {
    var nextPage = 'app_alleventpromotionslist';
    var queryParams = queryStringToJSON();
    queryParams["queryMode"] = "mylist";
    queryString = $.param(queryParams);
    queryString = queryString.replace(/\+/g, "%20");
    queryString = decodeURIComponent(queryString);
    window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
    return false;
  })
}); //end of ready
function getDataProcessBeforeCalldcard_recentappointment_collectioncontainerOrders5da73cac545050343288ce7a(objParamsList, callback) {
  var response = objParamsList;
  objParamsList.type = "appointments";
  objParamsList.status = "Accepted";
  objParamsList.clientid = localStorage.getItem("userID");

  callback();
}
function dcard_recentappointment_collectioncontainerapp_userhomeSync(timestamp) {
  try {
    var objParamsList = {};
    objParamsList.queryMode = "mylist";
    var ajaXCallURL = $.trim($("#ajaXCallURL").val());
    objParamsList.tokenKey = getParameterByName("tokenKey");
    objParamsList.secretKey = getParameterByName("secretKey");
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.isMobile = true;
    objParamsList.timestamp = timestamp;
    $.ajax({
      url: objParamsList.ajaXCallURL + "/milestone003/syncListDetails_Orders5da73cac545050343288ce7a_app_userhome",
      data: objParamsList,
      type: "POST",
      success: function (response) {
        $("#display_loading").addClass("hideme");
        if (response.status != undefined && response.status == 1) {
          localStorage.removeItem("dcard_recentappointment_collectioncontainerapp_userhome");
          var objParamsList = {};
          objParamsList.queryMode = "mylist";
          var ajaXCallURL = $.trim($("#ajaXCallURL").val());
          objParamsList.tokenKey = getParameterByName("tokenKey");
          objParamsList.secretKey = getParameterByName("secretKey");
          objParamsList.ajaXCallURL = ajaXCallURL;
          objParamsList.isMobile = "true";
          objParamsList.isiPad = false;
          objParamsList.timestamp = timestamp;
          if (getParameterByName("type") && getParameterByName("type") != "" && getParameterByName("type") != null && getParameterByName("type") != "undefined") {
            objParamsList.type = getParameterByName("type");
          }
          if (getParameterByName("status") && getParameterByName("status") != "" && getParameterByName("status") != null && getParameterByName("status") != "undefined") {
            objParamsList.status = getParameterByName("status");
          }
          if (getParameterByName("clientid") && getParameterByName("clientid") != "" && getParameterByName("clientid") != null && getParameterByName("clientid") != "undefined") {
            objParamsList.clientid = getParameterByName("clientid");
          }
          show_dcard_recentappointment_collectioncontainerapp_userhome_Details(objParamsList);
        }
      },
      error: function (xhr, status, error) {
        handleError(xhr, status, error);
      },
    });
  } catch (err) {
    // console.log('Error in workingtoolsSync', err);
  }
}
function show_dcard_recentappointment_collectioncontainerapp_userhome_Details(objParamsList) {
  if (getParameterByName("type") && getParameterByName("type") != "" && getParameterByName("type") != null && getParameterByName("type") != "undefined") {
    objParamsList.type = getParameterByName("type");
  }
  if (getParameterByName("status") && getParameterByName("status") != "" && getParameterByName("status") != null && getParameterByName("status") != "undefined") {
    objParamsList.status = getParameterByName("status");
  }
  if (getParameterByName("clientid") && getParameterByName("clientid") != "" && getParameterByName("clientid") != null && getParameterByName("clientid") != "undefined") {
    objParamsList.clientid = getParameterByName("clientid");
  }
  localStorage.setItem("appuserhomeFilterBox", "");

  $.ajax({
    url: objParamsList.ajaXCallURL + "/milestone003/getListDetails_Orders5da73cac545050343288ce7a_app_userhome_dcard_recentappointment_collectioncontainer",
    data: objParamsList,
    type: "POST",
    success: function (response) {
      getDataProcessAfterCalldcard_recentappointment_collectioncontainerOrders5da73cac545050343288ce7a(response, function () {
        if (response.status != undefined && response.status == 0) {
          if (objParamsList.isMobile == "true") {
            $("#collectioncontainerDivdcard_recentappointment_collectioncontainer").html("");
            // localStorage.setItem("dcard_recentappointment_collectioncontainerapp_userhome", JSON.stringify(response));
            getdcard_recentappointment_collectioncontainerapp_userhomeMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
          } else if (objParamsList.isiPad == "true") {
            getdcard_recentappointment_collectioncontainerapp_userhomeiPadView(response, objParamsList.tokenKey, objParamsList.queryMode);
          } else {
            getdcard_recentappointment_collectioncontainerapp_userhomeWebView(response, objParamsList.tokenKey, objParamsList.queryMode);
          }
          $("#display_loading").addClass("hideme");
        } else {
          $("#display_loading").addClass("hideme");
        }
      });
    },
    error: function (xhr, status, error) {
      $("#display_loading").addClass("hideme");
      handleError(xhr, status, error);
    },
  });
} // end of function

function getDataProcessAfterCalldcard_recentappointment_collectioncontainerOrders5da73cac545050343288ce7a(response, callback) {
  callback();
}

function getdcard_recentappointment_collectioncontainerapp_userhomeMobileView(response, tokenKey, queryMode) {
  var html = "";
  if (response.data.length == 0) {
    html += '<div class="nodatafound">';
    html += '<img src="nodatafound.gif" width="100%">';
    html += "<br>";
    html += "<!-- span>No record found</span -->";
    html += "</div>";
    $("#collectioncontainerDivdcard_recentappointment_collectioncontainer").html(html);
  } else {
    html = "";
    var radioGroups = [];
    $.each(response.data, function (keyList, objList) {
      html +=
        '      <div class="row plain-card search" search="' +
        removeSpecialChars(objList.eventimage + objList.eventname + objList.eventdate + objList.clientid_name + objList.note + objList.date) +
        '">';
      html += '      		<div class="col s12 m12">';
      html += '               <div class="card-content">';
      html +=
        '                  <div     status="' +
        objList.status +
        '"  recordID="' +
        objList._id +
        '" class="shimmer card  view_list_record dcard_recentappointment_collectioncontainer" style="" >';
      html += '      <div class="row  element" style=""  >';
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg8169 hide  ' + adddbclass + ' " style=" cursor: pointer;">';
      html += '           <div recordID="' + objList._id + '"  id="consultantname19" class="languagetranslation hide"style="" >Consultant Name </div>';
      html += "     </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg0269  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["name"] = objList["name"] ? objList["name"] : "";
      if (response.showShimmer) {
        objList["name"] = "";
      }
      var name = objList["name"];
      html +=
        '           <div recordID="' +
        objList._id +
        '"   id="name20" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Consultant :</span>' +
        name +
        "</div>";
      html += "     </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg2269  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["note"] = objList["note"] ? objList["note"] : "";
      if (response.showShimmer) {
        objList["note"] = "";
      }
      var note = objList["note"];
      html += '           <div recordID="' + objList._id + '"   id="note21" class="languagetranslation " style="" >' + note + "</div>";
      html += "     </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg4269  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["date"] = objList["date"] ? moment(new Date(objList["date"])).format("DD MMM YYYY") : "";
      var date = objList["date"];
      html += '           <div recordID="' + objList._id + '"   id="date22" class="languagetranslation " style="" >' + date + "</div>";
      html += "     </div>";
      html += '           <div class="col s12" style="">';
      html +=
        '               <a id="contact23"  status="Rejected" target="null"  recordID="' +
        objList._id +
        '"  style="" class="btn languagetranslation clssg6269 updateStatus">Contact</a>';
      html += "           </div>";
      html += "     </div>";
      html += "      				</div>";
      html += "          </div>";
      html += "        </div>";
      html += "     </div>";
      html += "   </div>";
    });
    $("#collectioncontainerDivdcard_recentappointment_collectioncontainer").html(html);
    $("#full-body-container").addClass("fadeInUp");
    if (!response.showShimmer) {
      dcardLoaded["dcard_recentappointment_collectioncontainer"] = true;
      $("#collectioncontainerDivdcard_recentappointment_collectioncontainer").find(".view_list_record").removeClass("shimmer");
    }
    $(".carddropdown").material_select();
    $("<input>").attr({ type: "hidden", class: "cardtoggleswitch", id: "togleswitchvalue" }).appendTo("body");
    if ($(".js-candlestick").length)
      $(".js-candlestick").candlestick({
        afterSetting: function (input, wrapper, value) {
          $("#togleswitchvalue").val(value).attr("recordID", input.attr("id")).trigger("click");
        },
      });
    if (radioGroups && radioGroups.length) {
      for (var key in radioGroups) {
        var groupName = radioGroups[key];
        $("input:radio[name=" + groupName + "]:first").prop("checked", true);
        $("input:radio[name=" + groupName + "]:first").trigger("change");
      }
    }
  }
}
function getLocalImagedcard_recentappointment_collectioncontainer(objList, mediaID, fileName) {
  try {
    var appJSON = {};
    appJSON.nextButtonCallback = "handleLocalImagedcard_recentappointment_collectioncontainer";
    appJSON.url = CDN_PATH + mediaID + "_compressed.png";
    appJSON.fileMimeType = "image/png";
    appJSON.fileName = fileName;
    appJSON.objList = objList;
    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    if (isAndroid > -1) {
      window.Android.getLocalImage(JSON.stringify(appJSON));
    } else {
      setupWebViewJavascriptBridge(function (bridge) {
        bridgeObj = bridge;
        bridgeObj.callHandler("getLocalImage", appJSON, function (response) { });
        bridgeObj.registerHandler("handleLocalImagedcard_recentappointment_collectioncontainer", function (responseData, responseCallback) {
          handleLocalImagedcard_recentappointment_collectioncontainer(responseData);
        });
      });
    }
  } catch (err) { }
}
function handleLocalImagedcard_recentappointment_collectioncontainer(response) {
  var objList = response.dataDictionay.objList;
  var html = "";

  html +=
    '      <div class="row plain-card search" search="' +
    removeSpecialChars(objList.eventimage + objList.eventname + objList.eventdate + objList.clientid_name + objList.note + objList.date) +
    '">';
  html += '      		<div class="col s12 m12">';
  html += '               <div class="card-content">';
  html +=
    '                  <div     status="' +
    objList.status +
    '"  recordID="' +
    objList._id +
    '" class="shimmer card  view_list_record dcard_recentappointment_collectioncontainer" style="" >';
  html += '      <div class="row  element" style=""  >';
  var adddbclass = "";
  html += '           <div recordID="' + objList._id + '" class="col s12 clssg8169 hide  ' + adddbclass + ' " style=" cursor: pointer;">';
  html += '           <div recordID="' + objList._id + '"  id="consultantname19" class="languagetranslation hide"style="" >Consultant Name </div>';
  html += "     </div>";
  var adddbclass = "";
  html += '           <div recordID="' + objList._id + '" class="col s12 clssg0269  ' + adddbclass + ' " style=" cursor: pointer;">';
  objList["name"] = objList["name"] ? objList["name"] : "";
  if (response.showShimmer) {
    objList["name"] = "";
  }
  var name = objList["name"];
  html +=
    '           <div recordID="' +
    objList._id +
    '"   id="name20" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Consultant :</span>' +
    name +
    "</div>";
  html += "     </div>";
  var adddbclass = "";
  html += '           <div recordID="' + objList._id + '" class="col s12 clssg2269  ' + adddbclass + ' " style=" cursor: pointer;">';
  objList["note"] = objList["note"] ? objList["note"] : "";
  if (response.showShimmer) {
    objList["note"] = "";
  }
  var note = objList["note"];
  html += '           <div recordID="' + objList._id + '"   id="note21" class="languagetranslation " style="" >' + note + "</div>";
  html += "     </div>";
  var adddbclass = "";
  html += '           <div recordID="' + objList._id + '" class="col s12 clssg4269  ' + adddbclass + ' " style=" cursor: pointer;">';
  objList["date"] = objList["date"] ? moment(new Date(objList["date"])).format("DD MMM YYYY") : "";
  var date = objList["date"];
  html += '           <div recordID="' + objList._id + '"   id="date22" class="languagetranslation " style="" >' + date + "</div>";
  html += "     </div>";
  html += '           <div class="col s12" style="">';
  html +=
    '               <a id="contact23"  status="Rejected" target="null"  recordID="' +
    objList._id +
    '"  style="" class="btn languagetranslation clssg6269 updateStatus">Contact</a>';
  html += "           </div>";
  html += "     </div>";
  html += "      				</div>";
  html += "          </div>";
  html += "        </div>";
  html += "     </div>";
  html += "   </div>";
  $("#collectioncontainerDivdcard_recentappointment_collectioncontainer").append(html);
  $("#full-body-container").addClass("fadeInUp");
  dcardLoaded["dcard_recentappointment_collectioncontainer"] = true;
  $("#collectioncontainerDivdcard_recentappointment_collectioncontainer").find(".view_list_record").removeClass("shimmer");
  // after html bining code
}

function getdcard_recentappointment_collectioncontainerapp_userhomePadView(response, tokenKey, queryMode) {
  var html = "";
  if (response.data.length == 0) {
    html += "<tr>";
    html += '<td colspan="1" class="text_center first_row_table_td">';
    html += "No record found";
    html += "</td>";
    html += "</tr>";
  } else {
    html = "";
    $.each(response.data, function (keyList, objList) {
      html +=
        '      <div class="row plain-card search" search="' +
        removeSpecialChars(objList.eventimage + objList.eventname + objList.eventdate + objList.clientid_name + objList.note + objList.date) +
        '">';
      html += '      		<div class="col s12 m12">';
      html += '               <div class="card-content">';
      html +=
        '                  <div     status="' +
        objList.status +
        '"  recordID="' +
        objList._id +
        '" class="shimmer card  view_list_record dcard_recentappointment_collectioncontainer" style="" >';
      html += '      <div class="row  element" style=""  >';
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg8169 hide  ' + adddbclass + ' " style=" cursor: pointer;">';
      html += '           <div recordID="' + objList._id + '"  id="consultantname19" class="languagetranslation hide"style="" >Consultant Name </div>';
      html += "     </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg0269  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["name"] = objList["name"] ? objList["name"] : "";
      if (response.showShimmer) {
        objList["name"] = "";
      }
      var name = objList["name"];
      html +=
        '           <div recordID="' +
        objList._id +
        '"   id="name20" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Consultant :</span>' +
        name +
        "</div>";
      html += "     </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg2269  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["note"] = objList["note"] ? objList["note"] : "";
      if (response.showShimmer) {
        objList["note"] = "";
      }
      var note = objList["note"];
      html += '           <div recordID="' + objList._id + '"   id="note21" class="languagetranslation " style="" >' + note + "</div>";
      html += "     </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg4269  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["date"] = objList["date"] ? moment(new Date(objList["date"])).format("DD MMM YYYY") : "";
      var date = objList["date"];
      html += '           <div recordID="' + objList._id + '"   id="date22" class="languagetranslation " style="" >' + date + "</div>";
      html += "     </div>";
      html += '           <div class="col s12" style="">';
      html +=
        '               <a id="contact23"  status="Rejected" target="null"  recordID="' +
        objList._id +
        '"  style="" class="btn languagetranslation clssg6269 updateStatus">Contact</a>';
      html += "           </div>";
      html += "     </div>";
      html += "      				</div>";
      html += "          </div>";
      html += "        </div>";
      html += "     </div>";
      html += "   </div>";
    }); // end of each loop
  }
  $("#collectioncontainerDivdcard_recentappointment_collectioncontainer").html(html);
}

function getdcard_recentappointment_collectioncontainerapp_userhomeWebView(response, tokenKey, queryMode) {
  var html = "";
  if (response.data.length == 0) {
    html += "<tr>";
    html += '<td colspan="1" class="text_center first_row_table_td">';
    html += "No record found";
    html += "</td>";
    html += "</tr>";
  } else {
    html = "";
    $.each(response.data, function (keyList, objList) {
      html +=
        '      <div class="row plain-card search" search="' +
        removeSpecialChars(objList.eventimage + objList.eventname + objList.eventdate + objList.clientid_name + objList.note + objList.date) +
        '">';
      html += '      		<div class="col s12 m12">';
      html += '               <div class="card-content">';
      html +=
        '                  <div     status="' +
        objList.status +
        '"  recordID="' +
        objList._id +
        '" class="shimmer card  view_list_record dcard_recentappointment_collectioncontainer" style="" >';
      html += '      <div class="row  element" style=""  >';
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg8169 hide  ' + adddbclass + ' " style=" cursor: pointer;">';
      html += '           <div recordID="' + objList._id + '"  id="consultantname19" class="languagetranslation hide"style="" >Consultant Name </div>';
      html += "     </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg0269  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["name"] = objList["name"] ? objList["name"] : "";
      if (response.showShimmer) {
        objList["name"] = "";
      }
      var name = objList["name"];
      html +=
        '           <div recordID="' +
        objList._id +
        '"   id="name20" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Consultant :</span>' +
        name +
        "</div>";
      html += "     </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg2269  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["note"] = objList["note"] ? objList["note"] : "";
      if (response.showShimmer) {
        objList["note"] = "";
      }
      var note = objList["note"];
      html += '           <div recordID="' + objList._id + '"   id="note21" class="languagetranslation " style="" >' + note + "</div>";
      html += "     </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg4269  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["date"] = objList["date"] ? moment(new Date(objList["date"])).format("DD MMM YYYY") : "";
      var date = objList["date"];
      html += '           <div recordID="' + objList._id + '"   id="date22" class="languagetranslation " style="" >' + date + "</div>";
      html += "     </div>";
      html += '           <div class="col s12" style="">';
      html +=
        '               <a id="contact23"  status="Rejected" target="null"  recordID="' +
        objList._id +
        '"  style="" class="btn languagetranslation clssg6269 updateStatus">Contact</a>';
      html += "           </div>";
      html += "     </div>";
      html += "      				</div>";
      html += "          </div>";
      html += "        </div>";
      html += "     </div>";
      html += "   </div>";
    }); // end of each loop 1
  }
  $("#collectioncontainerDivdcard_recentappointment_collectioncontainer").html(html);
}
function getDataProcessBeforeCalldcard_topimage2x2_collectioncontainerBazaar5da73cac545050343288ce7a(objParamsList, callback) {
  var response = objParamsList;
  objParamsList.eventdate = new Date();
  objParamsList.eventenddate = new Date();
  objParamsList.type = "events";
  callback();
}
function dcard_topimage2x2_collectioncontainerapp_userhomeSync(timestamp) {
  try {
    var objParamsList = {};
    objParamsList.queryMode = "mylist";
    var ajaXCallURL = $.trim($("#ajaXCallURL").val());
    objParamsList.tokenKey = getParameterByName("tokenKey");
    objParamsList.secretKey = getParameterByName("secretKey");
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.isMobile = true;
    objParamsList.timestamp = timestamp;
    objParamsList.type = "events";

    $.ajax({
      url: objParamsList.ajaXCallURL + "/milestone003/syncListDetails_Bazaar5da73cac545050343288ce7a_app_userhome",
      data: objParamsList,
      type: "POST",
      success: function (response) {
        $("#display_loading").addClass("hideme");
        if (response.status != undefined && response.status == 1) {
          localStorage.removeItem("dcard_topimage2x2_collectioncontainerapp_userhome");
          var objParamsList = {};
          objParamsList.queryMode = "mylist";
          var ajaXCallURL = $.trim($("#ajaXCallURL").val());
          objParamsList.tokenKey = getParameterByName("tokenKey");
          objParamsList.secretKey = getParameterByName("secretKey");
          objParamsList.ajaXCallURL = ajaXCallURL;
          objParamsList.isMobile = "true";
          objParamsList.isiPad = false;
          objParamsList.timestamp = timestamp;
          var applyFilter = getParameterByName("applyFilter");
          if (applyFilter == null && objParamsList.applyFilter == false) {
            objParamsList.type = "events";
            objParamsList.applystaticfilter = true;
          }
          if (
            getParameterByName("eventdate") &&
            getParameterByName("eventdate") != "" &&
            getParameterByName("eventdate") != null &&
            getParameterByName("eventdate") != "undefined"
          ) {
            objParamsList.eventdate = getParameterByName("eventdate");
          }
          if (
            getParameterByName("eventenddate") &&
            getParameterByName("eventenddate") != "" &&
            getParameterByName("eventenddate") != null &&
            getParameterByName("eventenddate") != "undefined"
          ) {
            objParamsList.eventenddate = getParameterByName("eventenddate");
          }
          show_dcard_topimage2x2_collectioncontainerapp_userhome_Details(objParamsList);
        }
      },
      error: function (xhr, status, error) {
        handleError(xhr, status, error);
      },
    });
  } catch (err) {
    // console.log('Error in workingtoolsSync', err);
  }
}
function show_dcard_topimage2x2_collectioncontainerapp_userhome_Details(objParamsList) {
  var applyFilter = getParameterByName("applyFilter");
  if (applyFilter == null && objParamsList.applyFilter == false) {
    objParamsList.type = "events";
    objParamsList.applystaticfilter = true;
  }
  if (getParameterByName("eventdate") && getParameterByName("eventdate") != "" && getParameterByName("eventdate") != null && getParameterByName("eventdate") != "undefined") {
    objParamsList.eventdate = getParameterByName("eventdate");
  }
  if (
    getParameterByName("eventenddate") &&
    getParameterByName("eventenddate") != "" &&
    getParameterByName("eventenddate") != null &&
    getParameterByName("eventenddate") != "undefined"
  ) {
    objParamsList.eventenddate = getParameterByName("eventenddate");
  }
  localStorage.setItem("appuserhomeFilterBox", "");

  $.ajax({
    url: objParamsList.ajaXCallURL + "/milestone003/getListDetails_Bazaar5da73cac545050343288ce7a_app_userhome_dcard_topimage2x2_collectioncontainer",
    data: objParamsList,
    type: "POST",
    success: function (response) {
      // getDataProcessAfterCalldcard_topimage2x2_collectioncontainerBazaar5da73cac545050343288ce7a(response, function () {
      if (response.status != undefined && response.status == 0) {
        if (objParamsList.isMobile == "true") {
          $("#collectioncontainerDivdcard_topimage2x2_collectioncontainer").html("");
          // localStorage.setItem("dcard_topimage2x2_collectioncontainerapp_userhome", JSON.stringify(response));
          getdcard_topimage2x2_collectioncontainerapp_userhomeMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
        } else if (objParamsList.isiPad == "true") {
          getdcard_topimage2x2_collectioncontainerapp_userhomeiPadView(response, objParamsList.tokenKey, objParamsList.queryMode);
        } else {
          getdcard_topimage2x2_collectioncontainerapp_userhomeWebView(response, objParamsList.tokenKey, objParamsList.queryMode);
        }
        $("#display_loading").addClass("hideme");
      } else {
        $("#display_loading").addClass("hideme");
      }
      // });
    },
    error: function (xhr, status, error) {
      $("#display_loading").addClass("hideme");
      handleError(xhr, status, error);
    },
  });
} // end of function

function getDataProcessAfterCalldcard_topimage2x2_collectioncontainerBazaar5da73cac545050343288ce7a(response, callback) {
  callback();
}

function getdcard_topimage2x2_collectioncontainerapp_userhomeMobileView(response, tokenKey, queryMode) {
  var html = "";
  if (response.data.length == 0) {
    html += '<div class="nodatafound">';
    html += '<img src="nodatafound.gif" width="100%">';
    html += "<br>";
    html += "<!-- span>No record found</span -->";
    html += "</div>";
    $("#collectioncontainerDivdcard_topimage2x2_collectioncontainer").html(html);
  } else {
    html = "";
    var radioGroups = [];
    $.each(response.data, function (keyList, objList) {
      var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
      var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
      if (isAndroid > -1 || ios > -1) {
        // need to fix with native gyes.. images not getting download
        var mediaID = "";
        var fileName = "";
        if (objList["eventimage"] && objList["eventimage"][0].mediaID) {
          mediaID = objList["eventimage"][0].mediaID;
          fileName = objList["eventimage"][0].mediaID + ".png";
        }
        getLocalImagedcard_topimage2x2_collectioncontainer(objList, mediaID, fileName);
      } else {
        html += '      <div class="row plain-card_latest_events search" search="' + removeSpecialChars(objList.eventimage + objList.eventname + objList.eventdate) + '">';
        html += '      		<div class="col s12 m12">';
        html += '               <div class="card-content">';
        html +=
          '                  <div     status="' +
          objList.status +
          '"  recordID="' +
          objList._id +
          '" class="shimmer card  view_list_record dcard_topimage2x2_collectioncontainer" style="" >';
        html += '      <div class="row  element" style=""  >';
        var localFilePath = "";
        if (response && response.localFilePath) {
          localFilePath = response.localFilePath;
        }
        html += '           <div class="col s12 clssg6069" style="">';
        var filetodisplay = "";
        if (objList.eventimage && objList.eventimage[0] && objList.eventimage[0].mediaID) {
          filetodisplay = getuploadedfilepreview(objList.eventimage[0].fileNm);
        }
        if (localFilePath && localFilePath != "") {
          html +=
            '               <img recordID="' +
            objList._id +
            '"  id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
            localFilePath +
            '" mediaid="' +
            objList.mediaID +
            '" filenm="' +
            objList.filenm +
            '" >';
        } else if (objList.eventimage && objList.eventimage[0] && objList.eventimage[0].mediaID) {
          if (filetodisplay && filetodisplay != objList.eventimage[0].fileNm) {
            html +=
              '               <img recordID="' +
              objList._id +
              '"    id="eventimage13"   class=" clssg6069image eventimage13" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
              filetodisplay +
              '">';
          } else {
            html +=
              '               <img recordID="' +
              objList._id +
              '"    id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
              CDN_PATH +
              objList.eventimage[0].mediaID +
              '_compressed.png">';
          }
        } else {
          // stage 6666666666666666
          html +=
            '               <img recordID="' +
            objList._id +
            '"   id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
        }
        html += "           </div>";
        var adddbclass = "";
        html += '           <div recordID="' + objList._id + '" class="col s12 clssg8069  ' + adddbclass + ' " style=" cursor: pointer;">';
        objList["eventname"] = objList["eventname"] ? objList["eventname"] : "";
        if (response.showShimmer) {
          objList["eventname"] = "";
        }
        var eventname = objList["eventname"];
        html += '           <div recordID="' + objList._id + '"   id="eventname14" class="languagetranslation " style="" >' + eventname + "</div>";
        html += "     </div>";
        var adddbclass = "";
        html += '           <div recordID="' + objList._id + '" class="col s12 clssg0169  ' + adddbclass + ' " style=" cursor: pointer;">';
        objList["eventdate"] = objList["eventdate"] ? moment(new Date(objList["eventdate"])).format("DD MMM YYYY") : "";
        var eventdate = objList["eventdate"];
        html += '           <div recordID="' + objList._id + '"   id="eventdate15" class="languagetranslation " style="" >' + eventdate + "</div>";
        html += "     </div>";
        html += "     </div>";
        html += "      				</div>";
        html += "          </div>";
        html += "        </div>";
        html += "     </div>";
        html += "   </div>";
      }
    });
    var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    if (1) {
      $("#collectioncontainerDivdcard_topimage2x2_collectioncontainer").html(html);
      $("#full-body-container").addClass("fadeInUp");
    }
    if (!response.showShimmer) {
      dcardLoaded["dcard_topimage2x2_collectioncontainer"] = true;
      $("#collectioncontainerDivdcard_topimage2x2_collectioncontainer").find(".view_list_record").removeClass("shimmer");
    }
    $(".carddropdown").material_select();
    $("<input>").attr({ type: "hidden", class: "cardtoggleswitch", id: "togleswitchvalue" }).appendTo("body");
    if ($(".js-candlestick").length)
      $(".js-candlestick").candlestick({
        afterSetting: function (input, wrapper, value) {
          $("#togleswitchvalue").val(value).attr("recordID", input.attr("id")).trigger("click");
        },
      });
    if (radioGroups && radioGroups.length) {
      for (var key in radioGroups) {
        var groupName = radioGroups[key];
        $("input:radio[name=" + groupName + "]:first").prop("checked", true);
        $("input:radio[name=" + groupName + "]:first").trigger("change");
      }
    }
  }
}
function getLocalImagedcard_topimage2x2_collectioncontainer(objList, mediaID, fileName) {
  try {
    var appJSON = {};
    appJSON.nextButtonCallback = "handleLocalImagedcard_topimage2x2_collectioncontainer";
    appJSON.url = CDN_PATH + mediaID + "_compressed.png";
    appJSON.fileMimeType = "image/png";
    appJSON.fileName = fileName;
    appJSON.objList = objList;
    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    if (isAndroid > -1) {
      window.Android.getLocalImage(JSON.stringify(appJSON));
    } else {
      setupWebViewJavascriptBridge(function (bridge) {
        bridgeObj = bridge;
        bridgeObj.callHandler("getLocalImage", appJSON, function (response) { });
        bridgeObj.registerHandler("handleLocalImagedcard_topimage2x2_collectioncontainer", function (responseData, responseCallback) {
          handleLocalImagedcard_topimage2x2_collectioncontainer(responseData);
        });
      });
    }
  } catch (err) { }
}
function handleLocalImagedcard_topimage2x2_collectioncontainer(response) {
  var objList = response.dataDictionay.objList;
  var html = "";

  html += '      <div class="row plain-card_latest_events search" search="' + removeSpecialChars(objList.eventimage + objList.eventname + objList.eventdate) + '">';
  html += '      		<div class="col s12 m12">';
  html += '               <div class="card-content">';
  html +=
    '                  <div     status="' +
    objList.status +
    '"  recordID="' +
    objList._id +
    '" class="shimmer card  view_list_record dcard_topimage2x2_collectioncontainer" style="" >';
  html += '      <div class="row  element" style=""  >';
  var localFilePath = "";
  if (response && response.localFilePath) {
    localFilePath = response.localFilePath;
  }
  html += '           <div class="col s12 clssg6069 " style="">';
  var filetodisplay = "";
  if (objList.eventimage && objList.eventimage[0] && objList.eventimage[0].mediaID) {
    filetodisplay = getuploadedfilepreview(objList.eventimage[0].fileNm);
  }
  if (localFilePath && localFilePath != "") {
    html +=
      '               <img recordID="' +
      objList._id +
      '"  id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
      localFilePath +
      '" mediaid="' +
      objList.mediaID +
      '" filenm="' +
      objList.filenm +
      '" >';
  } else if (objList.eventimage && objList.eventimage[0] && objList.eventimage[0].mediaID) {
    if (filetodisplay && filetodisplay != objList.eventimage[0].fileNm) {
      html +=
        '               <img recordID="' +
        objList._id +
        '"    id="eventimage13"   class=" clssg6069image eventimage13" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
        filetodisplay +
        '">';
    } else {
      html +=
        '               <img recordID="' +
        objList._id +
        '"    id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
        CDN_PATH +
        objList.eventimage[0].mediaID +
        '_compressed.png">';
    }
  } else {
    // stage 6666666666666666
    html +=
      '               <img recordID="' +
      objList._id +
      '"   id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
  }
  html += "           </div>";
  var adddbclass = "";
  html += '           <div recordID="' + objList._id + '" class="col s12 clssg8069  ' + adddbclass + ' " style=" cursor: pointer;">';
  objList["eventname"] = objList["eventname"] ? objList["eventname"] : "";
  if (response.showShimmer) {
    objList["eventname"] = "";
  }
  var eventname = objList["eventname"];
  html += '           <div recordID="' + objList._id + '"   id="eventname14" class="languagetranslation " style="" >' + eventname + "</div>";
  html += "     </div>";
  var adddbclass = "";
  html += '           <div recordID="' + objList._id + '" class="col s12 clssg0169  ' + adddbclass + ' " style=" cursor: pointer;">';
  objList["eventdate"] = objList["eventdate"] ? moment(new Date(objList["eventdate"])).format("DD MMM YYYY") : "";
  var eventdate = objList["eventdate"];
  html += '           <div recordID="' + objList._id + '"   id="eventdate15" class="languagetranslation " style="" >' + eventdate + "</div>";
  html += "     </div>";
  html += "     </div>";
  html += "      				</div>";
  html += "          </div>";
  html += "        </div>";
  html += "     </div>";
  html += "   </div>";
  $("#collectioncontainerDivdcard_topimage2x2_collectioncontainer").append(html);
  $("#full-body-container").addClass("fadeInUp");
  dcardLoaded["dcard_topimage2x2_collectioncontainer"] = true;
  $("#collectioncontainerDivdcard_topimage2x2_collectioncontainer").find(".view_list_record").removeClass("shimmer");
  // after html bining code
}

function getdcard_topimage2x2_collectioncontainerapp_userhomePadView(response, tokenKey, queryMode) {
  var html = "";
  if (response.data.length == 0) {
    html += "<tr>";
    html += '<td colspan="1" class="text_center first_row_table_td">';
    html += "No record found";
    html += "</td>";
    html += "</tr>";
  } else {
    html = "";
    $.each(response.data, function (keyList, objList) {
      html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.eventimage + objList.eventname + objList.eventdate) + '">';
      html += '      		<div class="col s12 m12">';
      html += '               <div class="card-content">';
      html +=
        '                  <div     status="' +
        objList.status +
        '"  recordID="' +
        objList._id +
        '" class="shimmer card  view_list_record dcard_topimage2x2_collectioncontainer" style="" >';
      html += '      <div class="row  element" style=""  >';
      var localFilePath = "";
      if (response && response.localFilePath) {
        localFilePath = response.localFilePath;
      }
      html += '           <div class="col s12 clssg6069" style="">';
      var filetodisplay = "";
      if (objList.eventimage && objList.eventimage[0] && objList.eventimage[0].mediaID) {
        filetodisplay = getuploadedfilepreview(objList.eventimage[0].fileNm);
      }
      if (localFilePath && localFilePath != "") {
        html +=
          '               <img recordID="' +
          objList._id +
          '"  id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
          localFilePath +
          '" mediaid="' +
          objList.mediaID +
          '" filenm="' +
          objList.filenm +
          '" >';
      } else if (objList.eventimage && objList.eventimage[0] && objList.eventimage[0].mediaID) {
        if (filetodisplay && filetodisplay != objList.eventimage[0].fileNm) {
          html +=
            '               <img recordID="' +
            objList._id +
            '"    id="eventimage13"   class=" clssg6069image eventimage13" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
            filetodisplay +
            '">';
        } else {
          html +=
            '               <img recordID="' +
            objList._id +
            '"    id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
            CDN_PATH +
            objList.eventimage[0].mediaID +
            '_compressed.png">';
        }
      } else {
        // stage 6666666666666666
        html +=
          '               <img recordID="' +
          objList._id +
          '"   id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
      }
      html += "           </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg8069  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["eventname"] = objList["eventname"] ? objList["eventname"] : "";
      if (response.showShimmer) {
        objList["eventname"] = "";
      }
      var eventname = objList["eventname"];
      html += '           <div recordID="' + objList._id + '"   id="eventname14" class="languagetranslation " style="" >' + eventname + "</div>";
      html += "     </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg0169  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["eventdate"] = objList["eventdate"] ? moment(new Date(objList["eventdate"])).format("DD MMM YYYY") : "";
      var eventdate = objList["eventdate"];
      html += '           <div recordID="' + objList._id + '"   id="eventdate15" class="languagetranslation " style="" >' + eventdate + "</div>";
      html += "     </div>";
      html += "     </div>";
      html += "      				</div>";
      html += "          </div>";
      html += "        </div>";
      html += "     </div>";
      html += "   </div>";
    }); // end of each loop
  }
  $("#collectioncontainerDivdcard_topimage2x2_collectioncontainer").html(html);
}

function getdcard_topimage2x2_collectioncontainerapp_userhomeWebView(response, tokenKey, queryMode) {
  var html = "";
  if (response.data.length == 0) {
    html += "<tr>";
    html += '<td colspan="1" class="text_center first_row_table_td">';
    html += "No record found";
    html += "</td>";
    html += "</tr>";
  } else {
    html = "";
    $.each(response.data, function (keyList, objList) {
      html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.eventimage + objList.eventname + objList.eventdate) + '">';
      html += '      		<div class="col s12 m12">';
      html += '               <div class="card-content">';
      html +=
        '                  <div     status="' +
        objList.status +
        '"  recordID="' +
        objList._id +
        '" class="shimmer card  view_list_record dcard_topimage2x2_collectioncontainer" style="" >';
      html += '      <div class="row  element" style=""  >';
      var localFilePath = "";
      if (response && response.localFilePath) {
        localFilePath = response.localFilePath;
      }
      html += '           <div class="col s12 clssg6069" style="">';
      var filetodisplay = "";
      if (objList.eventimage && objList.eventimage[0] && objList.eventimage[0].mediaID) {
        filetodisplay = getuploadedfilepreview(objList.eventimage[0].fileNm);
      }
      if (localFilePath && localFilePath != "") {
        html +=
          '               <img recordID="' +
          objList._id +
          '"  id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
          localFilePath +
          '" mediaid="' +
          objList.mediaID +
          '" filenm="' +
          objList.filenm +
          '" >';
      } else if (objList.eventimage && objList.eventimage[0] && objList.eventimage[0].mediaID) {
        if (filetodisplay && filetodisplay != objList.eventimage[0].fileNm) {
          html +=
            '               <img recordID="' +
            objList._id +
            '"    id="eventimage13"   class=" clssg6069image eventimage13" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
            filetodisplay +
            '">';
        } else {
          html +=
            '               <img recordID="' +
            objList._id +
            '"    id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
            CDN_PATH +
            objList.eventimage[0].mediaID +
            '_compressed.png">';
        }
      } else {
        // stage 6666666666666666
        html +=
          '               <img recordID="' +
          objList._id +
          '"   id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
      }
      html += "           </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg8069  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["eventname"] = objList["eventname"] ? objList["eventname"] : "";
      if (response.showShimmer) {
        objList["eventname"] = "";
      }
      var eventname = objList["eventname"];
      html += '           <div recordID="' + objList._id + '"   id="eventname14" class="languagetranslation " style="" >' + eventname + "</div>";
      html += "     </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg0169  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["eventdate"] = objList["eventdate"] ? moment(new Date(objList["eventdate"])).format("DD MMM YYYY") : "";
      var eventdate = objList["eventdate"];
      html += '           <div recordID="' + objList._id + '"   id="eventdate15" class="languagetranslation " style="" >' + eventdate + "</div>";
      html += "     </div>";
      html += "     </div>";
      html += "      				</div>";
      html += "          </div>";
      html += "        </div>";
      html += "     </div>";
      html += "   </div>";
    }); // end of each loop 1
  }
  $("#collectioncontainerDivdcard_topimage2x2_collectioncontainer").html(html);
}
function getDataProcessBeforeCalldcard_topimage3_collectioncontainerBazaar5da73cac545050343288ce7a(objParamsList, callback) {
  var response = objParamsList;

  var data = {};
  functfada2b20f0cb11e9b8cc058871cb4a77(response, function (responsefunctfada2b20f0cb11e9b8cc058871cb4a77) {
    if (responsefunctfada2b20f0cb11e9b8cc058871cb4a77.inValid) {
      callback();
    } else {
      callback();
    }
  });

  function functfada2b20f0cb11e9b8cc058871cb4a77(response, callback) {
    objParamsList.type = "merchants";
    callback({ inValid: 1 });
  }
}
function dcard_topimage3_collectioncontainerapp_userhomeSync(timestamp) {
  try {
    var objParamsList = {};
    objParamsList.queryMode = "mylist";
    var ajaXCallURL = $.trim($("#ajaXCallURL").val());
    objParamsList.tokenKey = getParameterByName("tokenKey");
    objParamsList.secretKey = getParameterByName("secretKey");
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.isMobile = true;
    objParamsList.timestamp = timestamp;
    objParamsList.type = "merchants";

    $.ajax({
      url: objParamsList.ajaXCallURL + "/milestone003/syncListDetails_Bazaar5da73cac545050343288ce7a_app_userhome",
      data: objParamsList,
      type: "POST",
      success: function (response) {
        $("#display_loading").addClass("hideme");
        if (response.status != undefined && response.status == 1) {
          localStorage.removeItem("dcard_topimage3_collectioncontainerapp_userhome");
          var objParamsList = {};
          objParamsList.queryMode = "mylist";
          var ajaXCallURL = $.trim($("#ajaXCallURL").val());
          objParamsList.tokenKey = getParameterByName("tokenKey");
          objParamsList.secretKey = getParameterByName("secretKey");
          objParamsList.ajaXCallURL = ajaXCallURL;
          objParamsList.isMobile = "true";
          objParamsList.isiPad = false;
          objParamsList.timestamp = timestamp;
          var applyFilter = getParameterByName("applyFilter");
          if (applyFilter == null && objParamsList.applyFilter == false) {
            objParamsList.type = "merchants";
            objParamsList.applystaticfilter = true;
          }
          show_dcard_topimage3_collectioncontainerapp_userhome_Details(objParamsList);
        }
      },
      error: function (xhr, status, error) {
        handleError(xhr, status, error);
      },
    });
  } catch (err) {
    // console.log('Error in workingtoolsSync', err);
  }
}
function show_dcard_topimage3_collectioncontainerapp_userhome_Details(objParamsList) {
  var applyFilter = getParameterByName("applyFilter");
  if (applyFilter == null && objParamsList.applyFilter == false) {
    objParamsList.type = "merchants";
    objParamsList.applystaticfilter = true;
  }
  objParamsList.status = "Active";

  localStorage.setItem("appuserhomeFilterBox", "");

  $.ajax({
    url: objParamsList.ajaXCallURL + "/milestone003/getListDetails_Bazaar5da73cac545050343288ce7a_app_userhome_dcard_topimage3_collectioncontainer",
    data: objParamsList,
    type: "POST",
    success: function (response) {
      getDataProcessAfterCalldcard_topimage3_collectioncontainerBazaar5da73cac545050343288ce7a(response, function () {
        if (response.status != undefined && response.status == 0) {
          if (objParamsList.isMobile == "true") {
            $("#collectioncontainerDivdcard_topimage3_collectioncontainer").html("");
            // localStorage.setItem("dcard_topimage3_collectioncontainerapp_userhome", JSON.stringify(response));
            getdcard_topimage3_collectioncontainerapp_userhomeMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
          } else if (objParamsList.isiPad == "true") {
            getdcard_topimage3_collectioncontainerapp_userhomeiPadView(response, objParamsList.tokenKey, objParamsList.queryMode);
          } else {
            getdcard_topimage3_collectioncontainerapp_userhomeWebView(response, objParamsList.tokenKey, objParamsList.queryMode);
          }
          $("#display_loading").addClass("hideme");
        } else {
          $("#display_loading").addClass("hideme");
        }
      });
    },
    error: function (xhr, status, error) {
      $("#display_loading").addClass("hideme");
      handleError(xhr, status, error);
    },
  });
} // end of function

function getDataProcessAfterCalldcard_topimage3_collectioncontainerBazaar5da73cac545050343288ce7a(response, callback) {
  callback();
}

function getdcard_topimage3_collectioncontainerapp_userhomeMobileView(response, tokenKey, queryMode) {
  var html = "";
  if (response.data.length == 0) {
    html += '<div class="nodatafound">';
    html += '<img src="nodatafound.gif" width="100%">';
    html += "<br>";
    html += "<!-- span>No record found</span -->";
    html += "</div>";
    $("#collectioncontainerDivdcard_topimage3_collectioncontainer").html(html);
  } else {
    html = "";
    var radioGroups = [];
    $.each(response.data, function (keyList, objList) {
      //            var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
      //            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
      //            if (isAndroid > -1 || ios > -1) {  // need to fix with native gyes.. images not getting download
      //                var mediaID = '';
      //                var fileName = '';
      //                if (objList['merchantimage'] && objList['merchantimage'][0].mediaID) {
      //                    mediaID = objList['merchantimage'][0].mediaID;
      //                    fileName = objList['merchantimage'][0].mediaID + '.png';
      //                }
      //                getLocalImagedcard_topimage3_collectioncontainer(objList, mediaID, fileName);
      //            }
      if (true && objList.outlets > 0) {
        html +=
          '      <div class="row plain-card search" search="' +
          removeSpecialChars(
            objList.eventimage +
            objList.eventname +
            objList.eventdate +
            objList.clientid_name +
            objList.note +
            objList.date +
            objList.merchantimage +
            objList.name +
            objList.merchantcategory
          ) +
          '">';
        html += '      		<div class="col s12 m12">';
        html += '               <div class="card-content" >';
        var recordID = objList._id;
        if (objList.outletList && objList.outletList[0]) {
          recordID = objList.outletList[0]._id;
        }
        html +=
          '                  <div  status="' +
          objList.status +
          '"  recordID="' +
          recordID +
          '" bazaarid="' +
          recordID +
          '" merchantID="' +
          objList._id +
          '" class="shimmer card  view_list_record dcard_topimage3_collectioncontainer" style="" >';
        html += '      <div class="row  element" style=""  >';
        html += '      <div class="col s12 cls_sg0469" style="">';
        html += "     </div>";
        html += '      <div class="col s12 cls_sg2469 addshimmer" style="">';
        html += "     </div>";
        var localFilePath = "";
        if (response && response.localFilePath) {
          localFilePath = response.localFilePath;
        }
        html += '           <div class="col s12 clssg4469" style="">';
        var filetodisplay = "";
        if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
          filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
        }
        if (localFilePath && localFilePath != "") {
          html +=
            '               <img recordID="' +
            objList._id +
            '"  id="merchantimage32"   class=" clssg4469image merchantimage32" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
            localFilePath +
            '" mediaid="' +
            objList.mediaID +
            '" filenm="' +
            objList.filenm +
            '" >';
        } else if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
          if (filetodisplay && filetodisplay != objList.merchantimage[0].fileNm) {
            html +=
              '               <img recordID="' +
              objList._id +
              '"    id="merchantimage32"   class=" clssg4469image merchantimage32" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
              filetodisplay +
              '">';
          } else {
            html +=
              '               <img recordID="' +
              objList._id +
              '"    id="merchantimage32"   class=" clssg4469image merchantimage32" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
              CDN_PATH +
              objList.merchantimage[0].mediaID +
              '_compressed.png">';
          }
        } else {
          // stage 6666666666666666
          html +=
            '               <img recordID="' +
            objList._id +
            '"   id="merchantimage32"   class=" clssg4469image merchantimage32" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
        }
        html += "           </div>";
        var adddbclass = "";
        html += '           <div recordID="' + objList._id + '" class="col s12 clssg6469  ' + adddbclass + ' " style=" cursor: pointer;">';
        objList["name"] = objList["name"] ? objList["name"] : "";
        if (response.showShimmer) {
          objList["name"] = "";
        }
        // var name = objList["name"];
        // html += '           <div recordID="' + objList._id + '"   id="name33" class="languagetranslation " style="" >' + name + "</div>";
        // html += "     </div>";
        // var adddbclass = "";
        // html += '           <div recordID="' + objList._id + '" class="col s12 clssg8469' + adddbclass + ' " style=" cursor: pointer;">';
        // objList["merchantcategory_name"] = objList["merchantcategory_name"] ? objList["merchantcategory_name"] : "";
        // if (response.showShimmer) {
        //   objList["merchantcategory_name"] = "";
        // }
        // var merchantcategory = objList["merchantcategory_name"];
        // if (merchantcategory.length > 60) {
        //   merchantcategory = merchantcategory.slice(0, 54);
        //   merchantcategory = `${merchantcategory}...`;
        // }
        // html += '           <div recordID="' + objList._id + '"   id="merchantcategory34" class="languagetranslation " style="" >' + merchantcategory + "</div>";
        // html += "     </div>";
        // html += "     </div>";
        html += "      				</div>";
        html += "          </div>";
        html += "        </div>";
        html += "     </div>";
        html += "   </div>";
      }
    });
    var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    if (1) {
      $("#collectioncontainerDivdcard_topimage3_collectioncontainer").html(html);
      $("#full-body-container").addClass("fadeInUp");
    }
    if (!response.showShimmer) {
      dcardLoaded["dcard_topimage3_collectioncontainer"] = true;
      $("#collectioncontainerDivdcard_topimage3_collectioncontainer").find(".view_list_record").removeClass("shimmer");
    }
    $(".carddropdown").material_select();
    $("<input>").attr({ type: "hidden", class: "cardtoggleswitch", id: "togleswitchvalue" }).appendTo("body");
    if ($(".js-candlestick").length)
      $(".js-candlestick").candlestick({
        afterSetting: function (input, wrapper, value) {
          $("#togleswitchvalue").val(value).attr("recordID", input.attr("id")).trigger("click");
        },
      });
    if (radioGroups && radioGroups.length) {
      for (var key in radioGroups) {
        var groupName = radioGroups[key];
        $("input:radio[name=" + groupName + "]:first").prop("checked", true);
        $("input:radio[name=" + groupName + "]:first").trigger("change");
      }
    }
  }
}
function getLocalImagedcard_topimage3_collectioncontainer(objList, mediaID, fileName) {
  try {
    var appJSON = {};
    appJSON.nextButtonCallback = "handleLocalImagedcard_topimage3_collectioncontainer";
    appJSON.url = CDN_PATH + mediaID + "_compressed.png";
    appJSON.fileMimeType = "image/png";
    appJSON.fileName = fileName;
    appJSON.objList = objList;
    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    if (isAndroid > -1) {
      window.Android.getLocalImage(JSON.stringify(appJSON));
    } else {
      setupWebViewJavascriptBridge(function (bridge) {
        bridgeObj = bridge;
        bridgeObj.callHandler("getLocalImage", appJSON, function (response) { });
        bridgeObj.registerHandler("handleLocalImagedcard_topimage3_collectioncontainer", function (responseData, responseCallback) {
          handleLocalImagedcard_topimage3_collectioncontainer(responseData);
        });
      });
    }
  } catch (err) { }
}
function handleLocalImagedcard_topimage3_collectioncontainer(response) {
  var objList = response.dataDictionay.objList;
  var html = "";

  html +=
    '      <div class="row plain-card search" search="' +
    removeSpecialChars(
      objList.eventimage +
      objList.eventname +
      objList.eventdate +
      objList.clientid_name +
      objList.note +
      objList.date +
      objList.merchantimage +
      objList.name +
      objList.merchantcategory
    ) +
    '">';
  html += '      		<div class="col s12 m12">';
  html += '               <div class="card-content">';
  html +=
    '                  <div     status="' +
    objList.status +
    '"  recordID="' +
    objList._id +
    '" class="shimmer card  view_list_record dcard_topimage3_collectioncontainer" style="" >';
  html += '      <div class="row  element" style=""  >';
  html += '      <div class="col s12 cls_sg0469" style="">';
  html += "     </div>";
  html += '      <div class="col s12 cls_sg2469 addshimmer" style="">';
  html += "     </div>";
  var localFilePath = "";
  if (response && response.localFilePath) {
    localFilePath = response.localFilePath;
  }
  html += '           <div class="col s12 clssg4469" style="">';
  var filetodisplay = "";
  if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
    filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
  }
  if (localFilePath && localFilePath != "") {
    html +=
      '               <img recordID="' +
      objList._id +
      '"  id="merchantimage32"   class=" clssg4469image merchantimage32" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
      localFilePath +
      '" mediaid="' +
      objList.mediaID +
      '" filenm="' +
      objList.filenm +
      '" >';
  } else if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
    if (filetodisplay && filetodisplay != objList.merchantimage[0].fileNm) {
      html +=
        '               <img recordID="' +
        objList._id +
        '"    id="merchantimage32"   class=" clssg4469image merchantimage32" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
        filetodisplay +
        '">';
    } else {
      html +=
        '               <img recordID="' +
        objList._id +
        '"    id="merchantimage32"   class=" clssg4469image merchantimage32" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
        CDN_PATH +
        objList.merchantimage[0].mediaID +
        '_compressed.png">';
    }
  } else {
    // stage 6666666666666666
    html +=
      '               <img recordID="' +
      objList._id +
      '"   id="merchantimage32"   class=" clssg4469image merchantimage32" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
  }
  html += "           </div>";
  var adddbclass = "";
  html += '           <div recordID="' + objList._id + '" class="col s12 clssg6469  ' + adddbclass + ' " style=" cursor: pointer;">';
  objList["name"] = objList["name"] ? objList["name"] : "";
  if (response.showShimmer) {
    objList["name"] = "";
  }
  var name = objList["name"];
  html += '           <div recordID="' + objList._id + '"   id="name33" class="languagetranslation " style="" >' + name + "</div>";
  html += "     </div>";
  var adddbclass = "";
  html += '           <div recordID="' + objList._id + '" class="col s12 clssg8469 hide  ' + adddbclass + ' " style=" cursor: pointer;">';
  objList["merchantcategory"] = objList["merchantcategory"] ? objList["merchantcategory"] : "";
  if (response.showShimmer) {
    objList["merchantcategory"] = "";
  }
  var merchantcategory = objList["merchantcategory"];
  html += '           <div recordID="' + objList._id + '"   id="merchantcategory34" class="languagetranslation hide" style="" >' + merchantcategory + "</div>";
  html += "     </div>";
  html += "     </div>";
  html += "      				</div>";
  html += "          </div>";
  html += "        </div>";
  html += "     </div>";
  html += "   </div>";
  $("#collectioncontainerDivdcard_topimage3_collectioncontainer").append(html);
  $("#full-body-container").addClass("fadeInUp");
  dcardLoaded["dcard_topimage3_collectioncontainer"] = true;
  $("#collectioncontainerDivdcard_topimage3_collectioncontainer").find(".view_list_record").removeClass("shimmer");
  // after html bining code
}

function getdcard_topimage3_collectioncontainerapp_userhomePadView(response, tokenKey, queryMode) {
  var html = "";
  if (response.data.length == 0) {
    html += "<tr>";
    html += '<td colspan="1" class="text_center first_row_table_td">';
    html += "No record found";
    html += "</td>";
    html += "</tr>";
  } else {
    html = "";
    $.each(response.data, function (keyList, objList) {
      html +=
        '      <div class="row plain-card search" search="' +
        removeSpecialChars(
          objList.eventimage +
          objList.eventname +
          objList.eventdate +
          objList.clientid_name +
          objList.note +
          objList.date +
          objList.merchantimage +
          objList.name +
          objList.merchantcategory
        ) +
        '">';
      html += '      		<div class="col s12 m12">';
      html += '               <div class="card-content">';
      html +=
        '                  <div     status="' +
        objList.status +
        '"  recordID="' +
        objList._id +
        '" class="shimmer card  view_list_record dcard_topimage3_collectioncontainer" style="" >';
      html += '      <div class="row  element" style=""  >';
      html += '      <div class="col s12 cls_sg0469" style="">';
      html += "     </div>";
      html += '      <div class="col s12 cls_sg2469 addshimmer" style="">';
      html += "     </div>";
      var localFilePath = "";
      if (response && response.localFilePath) {
        localFilePath = response.localFilePath;
      }
      html += '           <div class="col s12 clssg4469" style="">';
      var filetodisplay = "";
      if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
        filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
      }
      if (localFilePath && localFilePath != "") {
        html +=
          '               <img recordID="' +
          objList._id +
          '"  id="merchantimage32"   class=" clssg4469image merchantimage32" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
          localFilePath +
          '" mediaid="' +
          objList.mediaID +
          '" filenm="' +
          objList.filenm +
          '" >';
      } else if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
        if (filetodisplay && filetodisplay != objList.merchantimage[0].fileNm) {
          html +=
            '               <img recordID="' +
            objList._id +
            '"    id="merchantimage32"   class=" clssg4469image merchantimage32" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
            filetodisplay +
            '">';
        } else {
          html +=
            '               <img recordID="' +
            objList._id +
            '"    id="merchantimage32"   class=" clssg4469image merchantimage32" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
            CDN_PATH +
            objList.merchantimage[0].mediaID +
            '_compressed.png">';
        }
      } else {
        // stage 6666666666666666
        html +=
          '               <img recordID="' +
          objList._id +
          '"   id="merchantimage32"   class=" clssg4469image merchantimage32" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
      }
      html += "           </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg6469  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["name"] = objList["name"] ? objList["name"] : "";
      if (response.showShimmer) {
        objList["name"] = "";
      }
      var name = objList["name"];
      html += '           <div recordID="' + objList._id + '"   id="name33" class="languagetranslation " style="" >' + name + "</div>";
      html += "     </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg8469 hide  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["merchantcategory"] = objList["merchantcategory"] ? objList["merchantcategory"] : "";
      if (response.showShimmer) {
        objList["merchantcategory"] = "";
      }
      var merchantcategory = objList["merchantcategory"];
      html += '           <div recordID="' + objList._id + '"   id="merchantcategory34" class="languagetranslation hide" style="" >' + merchantcategory + "</div>";
      html += "     </div>";
      html += "     </div>";
      html += "      				</div>";
      html += "          </div>";
      html += "        </div>";
      html += "     </div>";
      html += "   </div>";
    }); // end of each loop
  }
  $("#collectioncontainerDivdcard_topimage3_collectioncontainer").html(html);
}

function getdcard_topimage3_collectioncontainerapp_userhomeWebView(response, tokenKey, queryMode) {
  var html = "";
  if (response.data.length == 0) {
    html += "<tr>";
    html += '<td colspan="1" class="text_center first_row_table_td">';
    html += "No record found";
    html += "</td>";
    html += "</tr>";
  } else {
    html = "";
    $.each(response.data, function (keyList, objList) {
      html +=
        '      <div class="row plain-card search" search="' +
        removeSpecialChars(
          objList.eventimage +
          objList.eventname +
          objList.eventdate +
          objList.clientid_name +
          objList.note +
          objList.date +
          objList.merchantimage +
          objList.name +
          objList.merchantcategory
        ) +
        '">';
      html += '      		<div class="col s12 m12">';
      html += '               <div class="card-content">';
      html +=
        '                  <div     status="' +
        objList.status +
        '"  recordID="' +
        objList._id +
        '" class="shimmer card  view_list_record dcard_topimage3_collectioncontainer" style="" >';
      html += '      <div class="row  element" style=""  >';
      html += '      <div class="col s12 cls_sg0469" style="">';
      html += "     </div>";
      html += '      <div class="col s12 cls_sg2469 addshimmer" style="">';
      html += "     </div>";
      var localFilePath = "";
      if (response && response.localFilePath) {
        localFilePath = response.localFilePath;
      }
      html += '           <div class="col s12 clssg4469" style="">';
      var filetodisplay = "";
      if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
        filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
      }
      if (localFilePath && localFilePath != "") {
        html +=
          '               <img recordID="' +
          objList._id +
          '"  id="merchantimage32"   class=" clssg4469image merchantimage32" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
          localFilePath +
          '" mediaid="' +
          objList.mediaID +
          '" filenm="' +
          objList.filenm +
          '" >';
      } else if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
        if (filetodisplay && filetodisplay != objList.merchantimage[0].fileNm) {
          html +=
            '               <img recordID="' +
            objList._id +
            '"    id="merchantimage32"   class=" clssg4469image merchantimage32" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
            filetodisplay +
            '">';
        } else {
          html +=
            '               <img recordID="' +
            objList._id +
            '"    id="merchantimage32"   class=" clssg4469image merchantimage32" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
            CDN_PATH +
            objList.merchantimage[0].mediaID +
            '_compressed.png">';
        }
      } else {
        // stage 6666666666666666
        html +=
          '               <img recordID="' +
          objList._id +
          '"   id="merchantimage32"   class=" clssg4469image merchantimage32" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
      }
      html += "           </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg6469  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["name"] = objList["name"] ? objList["name"] : "";
      if (response.showShimmer) {
        objList["name"] = "";
      }
      var name = objList["name"];
      html += '           <div recordID="' + objList._id + '"   id="name33" class="languagetranslation " style="" >' + name + "</div>";
      html += "     </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg8469 hide  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["merchantcategory"] = objList["merchantcategory"] ? objList["merchantcategory"] : "";
      if (response.showShimmer) {
        objList["merchantcategory"] = "";
      }
      var merchantcategory = objList["merchantcategory"];
      if (merchantcategory.length > 60) {
        merchantcategory = merchantcategory.slice(0, 54);
        merchantcategory = `${merchantcategory}...`;
      }
      html += '           <div recordID="' + objList._id + '"   id="merchantcategory34" class="languagetranslation hide" style="" >' + merchantcategory + "</div>";
      html += "     </div>";
      html += "     </div>";
      html += "      				</div>";
      html += "          </div>";
      html += "        </div>";
      html += "     </div>";
      html += "   </div>";
    }); // end of each loop 1
  }
  $("#collectioncontainerDivdcard_topimage3_collectioncontainer").html(html);
}
function showBottomMenu() {
  //    var  appUser = JSON.parse(localStorage.getItem("appUser"));
  var notificationCount = 0;
  //    if(appUser.notificationunreadcount)
  //    {
  //        notificationCount = appUser.notificationunreadcount
  //    }
  //    $("#notificationcount5").html(notificationCount)
  var appointmentunreadcount = 0;
  //    if(appUser.appointmentunreadcount)
  //    {
  //        appointmentunreadcount = appUser.appointmentunreadcount
  //    }
  var menuObj = localStorage.getItem("objGetUserDetailsWithmenu");
  if (menuObj) {
    menuObj = JSON.parse(menuObj);
    if (menuObj.data && menuObj.data.roleName) {
      var roleName = menuObj.data.roleName;
    }
  }
  try {
    var bottommenu = "";
    bottommenu += '<div class="mobilebottommenu">';
    bottommenu += '    <div class="row">';
    bottommenu +=
      '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Home" fileName="app_userhome_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_homeactive.svg"><span style ="color :#af935d !important;">Home</span></a></div>';
    bottommenu +=
      '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Appointment" fileName="app_alleventpromotionslist_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_calendar.svg"><span>Discover</span></a></a><div id="appointmentCount" class="chatunreadcount active hide">' +
      appointmentunreadcount +
      "</div></div>";
    bottommenu +=
      '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Scan" fileName="app_sacaner_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_barcode.svg" class="scannerbottommenu"><span>Scan</span></a></div>';
    bottommenu +=
      '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Chat" fileName="undefined_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_chat.svg"><span>Messages</span></a><div id="chatCount" style="display:none !important"  class="chatunreadcount active">0</div></div>';
    bottommenu +=
      '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="More" fileName="app_custmoreinfodetails_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_more.svg"><span>Account</span></a></div>';
    bottommenu += "    </div>";
    bottommenu += "</div>";
    $("#bottommenu35").html(bottommenu);
  } catch (err) {
    // console.log('Error in showBottomMenu', err);
  }
}





function getDataProcessBeforeCalldcard_topimage2x2_collectioncontainerBazaar5da73cac545050343288ce7a__discount(objParamsList, callback) {
  var response = objParamsList;
  objParamsList.eventdate = new Date();
  objParamsList.eventenddate = new Date();
  objParamsList.type = "events";
  callback();
}

function show_dcard_topimage2x2_collectioncontainerapp_userhome_Details__discount(objParamsList) {
  var applyFilter = getParameterByName("applyFilter");
  if (applyFilter == null && objParamsList.applyFilter == false) {
    objParamsList.applystaticfilter = true;
  }
  objParamsList.type = "dealsoftheday";
  $.ajax({
    url: objParamsList.ajaXCallURL + "/milestone003/getListDetails_Bazaar5da73cac545050343288ce7a_app_userhome_dcard_topimage3_collectioncontainer__discount",
    data: objParamsList,
    type: "POST",
    success: function (response) {
      if (response.status != undefined && response.status == 0) {
        if (objParamsList.isMobile == "true") {
          $("#collectioncontainerDivdcard_topimage2x2_collectioncontainer__discount").html("");
          // localStorage.setItem("dcard_topimage2x2_collectioncontainerapp_userhome_discount", JSON.stringify(response));
          getdcard_topimage2x2_collectioncontainerapp_userhomeMobileView__discount(response, objParamsList.tokenKey, objParamsList.queryMode);
        } else {
          getdcard_topimage2x2_collectioncontainerapp_userhomeWebView__discount(response, objParamsList.tokenKey, objParamsList.queryMode);
        }
        $("#display_loading").addClass("hideme");
      } else {
        $("#display_loading").addClass("hideme");
      }
    },
    error: function (xhr, status, error) {
      $("#display_loading").addClass("hideme");
      handleError(xhr, status, error);
    },
  });
}



function getdcard_topimage2x2_collectioncontainerapp_userhomeMobileView__discount(response, tokenKey, queryMode) {
  var html = "";
  if (response.data.length == 0) {
    html += '<div class="nodatafound">';
    html += '<img src="nodatafound.gif" width="100%">';
    html += "<br>";
    html += "<!-- span>No record found</span -->";
    html += "</div>";
    $("#collectioncontainerDivdcard_topimage2x2_collectioncontainer__discount").html(html);
  } else {
    html = "";
    var radioGroups = [];
    $.each(response.data, function (keyList, objList) {
      var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
      var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
      if (isAndroid > -1 || ios > -1) {
        // need to fix with native gyes.. images not getting download
        var mediaID = "";
        var fileName = "";
        if (objList["merchantimage"] && objList["merchantimage"][0].mediaID) {
          mediaID = objList["merchantimage"][0].mediaID;
          fileName = objList["merchantimage"][0].mediaID + ".png";
        }
        getLocalImagedcard_topimage2x2_collectioncontainer__discount(objList, mediaID, fileName);
      } else {
        html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.merchantimage + objList.eventname + objList.eventdate) + '">';
        html += '         <div class="col s12 m12">';
        html += '               <div class="card-content">';
        html +=
          '                  <div     status="' +
          objList.status +
          '"  recordID="' +
          objList._id +
          '" class="shimmer card  view_list_record dcard_topimage2x2_collectioncontainer__discount" style="" >';
        html += '      <div class="row  element" style=""  >';
        var localFilePath = "";
        if (response && response.localFilePath) {
          localFilePath = response.localFilePath;
        }
        html += '           <div class="col s12 clssg6069" style="">';
        var filetodisplay = "";
        if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
          filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
        }
        if (localFilePath && localFilePath != "") {
          html +=
            '               <img recordID="' +
            objList._id +
            '"  id="merchantimage13"   class=" clssg6069image merchantimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
            localFilePath +
            '" mediaid="' +
            objList.mediaID +
            '" filenm="' +
            objList.filenm +
            '" >';
        } else if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
          if (filetodisplay && filetodisplay != objList.merchantimage[0].fileNm) {
            html +=
              '               <img recordID="' +
              objList._id +
              '"    id="merchantimage13"   class=" clssg6069image merchantimage13" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
              filetodisplay +
              '">';
          } else {
            html +=
              '               <img recordID="' +
              objList._id +
              '"    id="merchantimage13"   class=" clssg6069image merchantimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
              CDN_PATH +
              objList.merchantimage[0].mediaID +
              '_compressed.png">';
          }
        } else {
          // stage 6666666666666666
          html +=
            '               <img recordID="' +
            objList._id +
            '"   id="merchantimage13"   class=" clssg6069image merchantimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
        }
        html += "           </div>";
        var adddbclass = "";
        html += '           <div recordID="' + objList._id + '" class="col s12 clssg8069 clssg8069__copy  ' + adddbclass + ' " style=" cursor: pointer;">';
        objList["merchanttype"] = objList["merchanttype"] ? objList["merchanttype"] : "";
        if (response.showShimmer) {
          objList["merchanttype"] = "";
        }
        var merchanttype = objList["merchanttype"];
        html += '           <div recordID="' + objList._id + '"   id="merchanttype14" class="languagetranslation " style="" >' + merchanttype + "</div>";
        html += "     </div>";

        var adddbclass = "";
        html += '           <div recordID="' + objList._id + '" class="col s12 clssg8069  ' + adddbclass + ' " style=" cursor: pointer;">';
        objList["code"] = objList["code"] ? objList["code"] : "";
        if (response.showShimmer) {
          objList["code"] = "";
        }
        var code = objList["code"];
        html += '           <div recordID="' + objList._id + '"   id="code14" class="languagetranslation " style="" >' + code + "</div>";
        html += "     </div>";
        var adddbclass = "";
        html += '           <div recordID="' + objList._id + '" class="col s12 clssg0169  ' + adddbclass + ' " style=" cursor: pointer;">';
        var description = objList["description"] || '';
        description = description.replace(/<[^>]*>?/gm, '');
        if (description.length > 75) {
          description = description.slice(0, 69);
          description = `${description}...`;
        }
        html += '           <div recordID="' + objList._id + '"   id="description15" class="languagetranslation " style="width: 100% !important; text-overflow: ellipsis !important; white-space: nowrap !important; overflow: hidden !important;" >' + description + "</div>";
        html += "     </div>";
        html += "     </div>";
        html += "             </div>";
        html += "          </div>";
        html += "        </div>";
        html += "     </div>";
        html += "   </div>";
      }
    });
    var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    if (1) {
      $("#collectioncontainerDivdcard_topimage2x2_collectioncontainer__discount").html(html);
      $("#full-body-container").addClass("fadeInUp");
    }
    if (!response.showShimmer) {
      dcardLoaded["dcard_topimage2x2_collectioncontainer"] = true;
      $("#collectioncontainerDivdcard_topimage2x2_collectioncontainer__discount").find(".view_list_record").removeClass("shimmer");
    }
    $(".carddropdown").material_select();
    $("<input>").attr({ type: "hidden", class: "cardtoggleswitch", id: "togleswitchvalue" }).appendTo("body");
    if ($(".js-candlestick").length)
      $(".js-candlestick").candlestick({
        afterSetting: function (input, wrapper, value) {
          $("#togleswitchvalue").val(value).attr("recordID", input.attr("id")).trigger("click");
        },
      });
    if (radioGroups && radioGroups.length) {
      for (var key in radioGroups) {
        var groupName = radioGroups[key];
        $("input:radio[name=" + groupName + "]:first").prop("checked", true);
        $("input:radio[name=" + groupName + "]:first").trigger("change");
      }
    }
  }
}

function getdcard_topimage2x2_collectioncontainerapp_userhomeWebView__discount(response, tokenKey, queryMode) {
  var html = "";
  if (response.data.length == 0) {
    html += "<tr>";
    html += '<td colspan="1" class="text_center first_row_table_td">';
    html += "No record found";
    html += "</td>";
    html += "</tr>";
  } else {
    html = "";
    $.each(response.data, function (keyList, objList) {
      html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.merchantimage + objList.eventname + objList.eventdate) + '">';
      html += '         <div class="col s12 m12">';
      html += '               <div class="card-content">';
      html +=
        '                  <div     status="' +
        objList.status +
        '"  recordID="' +
        objList._id +
        '" class="shimmer card  view_list_record dcard_topimage2x2_collectioncontainer__discount" style="" >';
      html += '      <div class="row  element" style=""  >';
      var localFilePath = "";
      if (response && response.localFilePath) {
        localFilePath = response.localFilePath;
      }
      html += '           <div class="col s12 clssg6069" style="">';
      var filetodisplay = "";
      if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
        filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
      }
      if (localFilePath && localFilePath != "") {
        html +=
          '               <img recordID="' +
          objList._id +
          '"  id="merchantimage13"   class=" clssg6069image merchantimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
          localFilePath +
          '" mediaid="' +
          objList.mediaID +
          '" filenm="' +
          objList.filenm +
          '" >';
      } else if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
        if (filetodisplay && filetodisplay != objList.merchantimage[0].fileNm) {
          html +=
            '               <img recordID="' +
            objList._id +
            '"    id="merchantimage13"   class=" clssg6069image merchantimage13" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
            filetodisplay +
            '">';
        } else {
          html +=
            '               <img recordID="' +
            objList._id +
            '"    id="merchantimage13"   class=" clssg6069image merchantimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
            CDN_PATH +
            objList.merchantimage[0].mediaID +
            '_compressed.png">';
        }
      } else {
        // stage 6666666666666666
        html +=
          '               <img recordID="' +
          objList._id +
          '"   id="merchantimage13"   class=" clssg6069image merchantimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
      }
      html += "           </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg8069 clssg8069__copy  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["merchanttype"] = objList["merchanttype"] ? objList["merchanttype"] : "";
      if (response.showShimmer) {
        objList["merchanttype"] = "";
      }
      var merchanttype = objList["merchanttype"];
      html += '           <div recordID="' + objList._id + '"   id="merchanttype14" class="languagetranslation " style="" >' + merchanttype + "</div>";
      html += "     </div>";

      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg8069  ' + adddbclass + ' " style=" cursor: pointer;">';
      objList["code"] = objList["code"] ? objList["code"] : "";
      if (response.showShimmer) {
        objList["code"] = "";
      }
      var code = objList["code"];
      html += '           <div recordID="' + objList._id + '"   id="code14" class="languagetranslation " style="" >' + code + "</div>";
      html += "     </div>";
      var adddbclass = "";
      html += '           <div recordID="' + objList._id + '" class="col s12 clssg0169  ' + adddbclass + ' " style=" cursor: pointer;">';
      var description = objList["description"] || '';
      description = description.replace(/<[^>]*>?/gm, '');
      if (description.length > 75) {
        description = description.slice(0, 69);
        description = `${description}...`;
      }
      html += '           <div recordID="' + objList._id + '"   id="description15" class="languagetranslation " style="width: 100% !important; text-overflow: ellipsis !important; white-space: nowrap !important; overflow: hidden !important;" >' + description + "</div>";
      html += "     </div>";
      html += "     </div>";
      html += "             </div>";
      html += "          </div>";
      html += "        </div>";
      html += "     </div>";
      html += "   </div>";
    }); // end of each loop 1
  }
  $("#collectioncontainerDivdcard_topimage2x2_collectioncontainer__discount").html(html);
}




function getLocalImagedcard_topimage2x2_collectioncontainer__discount(objList, mediaID, fileName) {
  try {
    var appJSON = {};
    appJSON.nextButtonCallback = "handleLocalImagedcard_topimage2x2_collectioncontainer__discount";
    appJSON.url = CDN_PATH + mediaID + "_compressed.png";
    appJSON.fileMimeType = "image/png";
    appJSON.fileName = fileName;
    appJSON.objList = objList;
    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    if (isAndroid > -1) {
      window.Android.getLocalImage(JSON.stringify(appJSON));
    } else {
      setupWebViewJavascriptBridge(function (bridge) {
        bridgeObj = bridge;
        bridgeObj.callHandler("getLocalImage", appJSON, function (response) { });
        bridgeObj.registerHandler("handleLocalImagedcard_topimage2x2_collectioncontainer__discount", function (responseData, responseCallback) {
          handleLocalImagedcard_topimage2x2_collectioncontainer__discount(responseData);
        });
      });
    }
  } catch (err) { }
}
function handleLocalImagedcard_topimage2x2_collectioncontainer__discount(response) {
  var objList = response.dataDictionay.objList;
  var html = "";

  html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.eventimage + objList.eventname + objList.eventdate) + '">';
  html += '         <div class="col s12 m12">';
  html += '               <div class="card-content">';
  html +=
    '                  <div     status="' +
    objList.status +
    '"  recordID="' +
    objList._id +
    '" class="shimmer card  view_list_record dcard_topimage2x2_collectioncontainer__discount" style="" >';
  html += '      <div class="row  element" style=""  >';
  var localFilePath = "";
  if (response && response.localFilePath) {
    localFilePath = response.localFilePath;
  }
  html += '           <div class="col s12 clssg6069" style="">';
  var filetodisplay = "";
  if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
    filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
  }
  if (localFilePath && localFilePath != "") {
    html +=
      '               <img recordID="' +
      objList._id +
      '"  id="merchantimage13"   class=" clssg6069image merchantimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
      localFilePath +
      '" mediaid="' +
      objList.mediaID +
      '" filenm="' +
      objList.filenm +
      '" >';
  } else if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
    if (filetodisplay && filetodisplay != objList.merchantimage[0].fileNm) {
      html +=
        '               <img recordID="' +
        objList._id +
        '"    id="merchantimage13"   class=" clssg6069image merchantimage13" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
        filetodisplay +
        '">';
    } else {
      html +=
        '               <img recordID="' +
        objList._id +
        '"    id="merchantimage13"   class=" clssg6069image merchantimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' +
        CDN_PATH +
        objList.merchantimage[0].mediaID +
        '_compressed.png">';
    }
  } else {
    // stage 6666666666666666
    html +=
      '               <img recordID="' +
      objList._id +
      '"   id="merchantimage13"   class=" clssg6069image merchantimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
  }
  html += "           </div>";
  var adddbclass = "";
  var adddbclass = "";
  html += '           <div recordID="' + objList._id + '" class="col s12 clssg8069 clssg8069__copy  ' + adddbclass + ' " style=" cursor: pointer;">';
  objList["merchanttype"] = objList["merchanttype"] ? objList["merchanttype"] : "";
  if (response.showShimmer) {
    objList["merchanttype"] = "";
  }
  var merchanttype = objList["merchanttype"];
  html += '           <div recordID="' + objList._id + '"   id="merchanttype14" class="languagetranslation " style="" >' + merchanttype + "</div>";
  html += "     </div>";
  html += '           <div recordID="' + objList._id + '" class="col s12 clssg8069  ' + adddbclass + ' " style=" cursor: pointer;">';
  objList["code"] = objList["code"] ? objList["code"] : "";
  if (response.showShimmer) {
    objList["code"] = "";
  }
  var code = objList["code"];
  html += '           <div recordID="' + objList._id + '"   id="code14" class="languagetranslation " style="" >' + code + "</div>";
  html += "     </div>";
  var adddbclass = "";
  html += '           <div recordID="' + objList._id + '" class="col s12 clssg0169  ' + adddbclass + ' " style=" cursor: pointer;">';
  var description = objList["description"] || '';
  description = description.replace(/<[^>]*>?/gm, '');
  if (description.length > 75) {
    description = description.slice(0, 69);
    description = `${description}...`;
  }
  html += '           <div recordID="' + objList._id + '"   id="description15" class="languagetranslation " style="width: 100% !important; text-overflow: ellipsis !important; white-space: nowrap !important; overflow: hidden !important;" >' + description + "</div>";
  html += "     </div>";
  html += "     </div>";
  html += "             </div>";
  html += "          </div>";
  html += "        </div>";
  html += "     </div>";
  html += "   </div>";
  $("#collectioncontainerDivdcard_topimage2x2_collectioncontainer__discount").append(html);
  $("#full-body-container").addClass("fadeInUp");
  dcardLoaded["dcard_topimage2x2_collectioncontainer"] = true;
  $("#collectioncontainerDivdcard_topimage2x2_collectioncontainer__discount").find(".view_list_record").removeClass("shimmer");
  // after html bining code
}





function getbottombannerImage() {
  var paramsType = {};
  paramsType.tokenKey = getParameterByName('tokenKey');
  paramsType.secretKey = getParameterByName('secretKey');
  paramsType.bannershowtype = 'Bottom';
  //getCountProcessBeforeCallbannerbottomimageupload6(paramsType, function (processBeforeRes) {
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  $.ajax({
    url: ajaXCallURL + '/milestone003/showslider_app_userhome_Customerbanner5da73cac545050343288ce7alblbannerbannerimageupload',
    data: paramsType,
    type: 'POST',
    success: function (response) {
      // localStorage.setItem("bannerimages", JSON.stringify(response));

      if (response.status == 0) {
        makeSlidesbannerbottomimageupload6(response.data);
      } else {
        makeSlidesbannerbottomimageupload6([]);
      }
    },
    error: function (xhr, status, error) { },
  });
  // });
}

function makeSlidesbannerbottomimageupload6(data) {
  var slide = '';
  var htmlString = '';
  if (data && data.length == 1) {
    data = data[0].bannerimageupload ? data[0].bannerimageupload : [];
  }
  if (data && data.length > 0) {
    for (let index = 0; index < data.length; index++) {
      const element = data[index];
      var mediaID;
      if (element && element.bannerimageupload && element.bannerimageupload[0]) {
        mediaID = element.bannerimageupload[0].mediaID;
      } else if (element && element.mediaID) {
        mediaID = element.mediaID;
      }
      slide += ' <div class="swiper-slide" href="#one!" >';
      slide += '    <div class="row  col s12" style="padding: 0px" !important;>';
      slide += '       <div id="image6_div" style="text-align: center;">';
      slide += '          <img  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + mediaID + '_compressed.png" style="width:100%; height:150px">';
      slide += '       </div>';
      slide += '    </div>';
      slide += '        </div>';
    }
    if (slide) {
      $('#bannerbottomimageupload6').html(slide);
    }
    var swiper = new Swiper('.swiper-container .swiperbottom', {
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
      watchOverflow: true,
      pagination: {
        el: '.swiper-paginationbottom',
      },
    });
    $('.dynamic-slider-view').removeClass('shimmer');
  }
}


function getmiddlebannerImage() {
  var paramsType = {};
  paramsType.tokenKey = getParameterByName('tokenKey');
  paramsType.secretKey = getParameterByName('secretKey');
  paramsType.bannershowtype = 'Middle';
  //getCountProcessBeforeCallbannermiddleimageupload6(paramsType, function (processBeforeRes) {
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  $.ajax({
    url: ajaXCallURL + '/milestone003/showslider_app_userhome_Customerbanner5da73cac545050343288ce7alblbannerbannerimageupload',
    data: paramsType,
    type: 'POST',
    success: function (response) {
      // localStorage.setItem("bannerimages", JSON.stringify(response));

      if (response.status == 0) {
        makeSlidesbannermiddleimageupload6(response.data);
      } else {
        makeSlidesbannermiddleimageupload6([]);
      }
    },
    error: function (xhr, status, error) { },
  });
  // });
}

function makeSlidesbannermiddleimageupload6(data) {
  var slide = '';
  var htmlString = '';
  if (data && data.length == 1) {
    data = data[0].bannerimageupload ? data[0].bannerimageupload : [];
  }
  if (data && data.length > 0) {
    for (let index = 0; index < data.length; index++) {
      const element = data[index];
      var mediaID;
      if (element && element.bannerimageupload && element.bannerimageupload[0]) {
        mediaID = element.bannerimageupload[0].mediaID;
      } else if (element && element.mediaID) {
        mediaID = element.mediaID;
      }
      slide += ' <div class="swiper-slide" href="#one!" >';
      slide += '    <div class="row  col s12" style="padding: 0px" !important;>';
      slide += '       <div id="image6_div" style="text-align: center;">';
      slide += '          <img  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + mediaID + '_compressed.png" style="width:100%; height:150px">';
      slide += '       </div>';
      slide += '    </div>';
      slide += '        </div>';
    }
    if (slide) {
      $('#bannermiddleimageupload6').html(slide);
    }
    var swiper = new Swiper('.swiper-container .swipermiddle', {
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
      watchOverflow: true,
      pagination: {
        el: '.swiper-paginationmiddle',
      },
    });
    $('.dynamic-slider-view').removeClass('shimmer');
  }
}






$(document).on('click', '#merchantdiscountid', function (e) {
  try {
    var element = $(this);
    var nextPage = 'app_allmerchantdiscountslist';
    var queryParams = queryStringToJSON();
    queryParams["queryMode"] = "mylist";
    var recordID = $(this).attr("recordID");
    if (recordID) {
      queryParams["recordID"] = recordID;
    }
    var queryString = $.param(queryParams);
    queryString = queryString.replace(/\+/g, "%20");
    queryString = decodeURIComponent(queryString);
    window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
    return false;
  } catch (error) {
    console.log("Error in pageredirect workflow - myevents7", error)
  }
});


$(document).on('click', '#eventandpromoid', function (e) {
  try {
    var element = $(this);
    var nextPage = 'app_alleventpromotionslist';
    var queryParams = queryStringToJSON();
    queryParams["queryMode"] = "mylist";
    var recordID = $(this).attr("recordID");
    if (recordID) {
      queryParams["recordID"] = recordID;
    }
    var queryString = $.param(queryParams);
    queryString = queryString.replace(/\+/g, "%20");
    queryString = decodeURIComponent(queryString);
    window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
    return false;
  } catch (error) {
    console.log("Error in pageredirect workflow - myevents7", error)
  }
});

$(document).on('click', '#financialservicesid', function (e) {
  try {
    var element = $(this);
    var nextPage = 'app_allfinancialserviceslist';
    var queryParams = queryStringToJSON();
    queryParams["queryMode"] = "mylist";
    var recordID = $(this).attr("recordID");
    if (recordID) {
      queryParams["recordID"] = recordID;
    }
    var queryString = $.param(queryParams);
    queryString = queryString.replace(/\+/g, "%20");
    queryString = decodeURIComponent(queryString);
    window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
    return false;
  } catch (error) {
    console.log("Error in pageredirect workflow - myevents7", error)
  }
});


$(document).on("click", "#discountviewall9", function (e) {
  try {
    var element = $(this);
    var parent = "app_userhome";
    // var nextPage = "app_allupcomingeventslist";
    var nextPage = 'app_deallisting';
    var queryParams = queryStringToJSON();
    queryParams["queryMode"] = "mylist";
    var recordID = $(this).attr("recordID");
    if (recordID) {
      queryParams["recordID"] = recordID;
    }
    var queryString = $.param(queryParams);
    queryString = queryString.replace(/\+/g, "%20");
    queryString = decodeURIComponent(queryString);
    window.location.href = nextPage + "_5da73cac545050343288ce7a.html?" + queryString + "&parent=" + parent;
    return false;
  } catch (error) {
    console.log("Error in pageredirect workflow - viewall9", error);
  }
});
$(document).on('click', '.dcard_topimage2x2_collectioncontainer__discount', function () {
  // if (dcardLoaded && !dcardLoaded['dcard_topimage2_collectioncontainer']) { return false; }; // added for use should not able to click until data loaded
  localStorage.setItem("headerPageName", 'app_myeventdetails');
  var recordID = $(this).attr('recordID');// get record ID;
  var bazaarid = $(this).attr('recordID');// get record ID;
  var tokenKey = getParameterByName('tokenKey');
  var secretKey = getParameterByName('secretKey');
  var queryMode = 'update';
  var parent = "app_allupcomingeventslist"
  var nextPage = 'app_discountdetails';
  if (!nextPage) {
    return false;
  }
  localStorage.setItem('discountbackpage', 'app_allmerchantdiscountslist');
  var pageurl = nextPage + '_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&bazaarid=' + bazaarid + '&recordID=' + recordID + '&applyFilter=true' + "&parent=" + parent;
  window.location.href = pageurl;
  return false;
}); // to add New record
