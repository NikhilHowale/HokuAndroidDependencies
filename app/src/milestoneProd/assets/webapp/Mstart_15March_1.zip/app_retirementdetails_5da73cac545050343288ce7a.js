
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_retirementcalculateadd'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "add"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#ok15', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_retirementcalculateadd'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "add"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - ok15", error) 
		} 
	})
      $('#display_loading1').removeClass('hideme');
      var paramsEdit = {};
      paramsEdit.tokenKey = getParameterByName('tokenKey');
      paramsEdit.secretKey = getParameterByName('secretKey') 
                       getRecordByIDProcessBeforeCall929074(paramsEdit, function (processBeforeRes) {
      $.ajax({
          url: ajaXCallURL+'/milestone003/getRecordByCustomeQuery_app_retirementdetails_Usermanagement5da73cac545050343288ce7a',
          data: paramsEdit,
          type: 'POST',
          jsonpCallback: 'callback',
          success: function (response) { 
                       getRecordByIDProcessAfterCall929074(response, function (processBeforeRes) {
                        $('#display_loading1').addClass('hideme');
                        $('#sg2778').removeClass('hideme');
                        
              if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                  var objParamsList = {};
                  var queryMode = $('#queryMode').val(); 
                  objParamsList.queryMode = queryMode;;
                  var tokenKey = $('#tokenKey').val();;
                  objParamsList.tokenKey = tokenKey;;
  if(!$('#backbutton1').html()){
            $('#backbutton1').append(response.recordDetails.undefined);
 }
 response.recordDetails['testdate_preserved'] = response.recordDetails['testdate'] ;
 response.recordDetails['testdate'] = response.recordDetails['testdate']  ? moment(new Date(response.recordDetails['testdate'])).format('DD MMM YYYY') : '';
  if(!$('#testdate8').html()){
            $('#testdate8').append(response.recordDetails.testdate);
 }
 response.recordDetails['testdate'] =  response.recordDetails['testdate_preserved'];
  if(!$('#time9').html()){
            $('#time9').append(response.recordDetails.time);
 }
  if(!$('#resultmessage14').html()){
            $('#resultmessage14').append(response.recordDetails.resultmessage);
 }
  if(!$('#status10').html()){
            $('#status10').append(response.recordDetails.status);
 }
  if(!$('#result111').html()){
            $('#result111').append(response.recordDetails.result1);
 }
  if(!$('#result212').html()){
            $('#result212').append(parseInt(response.recordDetails.result2).toFixed(2));
 }
  if(!$('#results7').html()){
            $('#results7').append(response.recordDetails.undefined);
 }
  if(!$('#retirementfunddetails2').html()){
            $('#retirementfunddetails2').append(response.recordDetails.undefined);
 }

              Materialize.updateTextFields();
                $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);
  
              } 
              }); // end of getRecord By ID
          },
          error: function (xhr, status, error) {
              handleError(xhr, status, error); 
          },
      }); 
              }); // end of getRecord By ID
   
});//end of ready 
                 function getRecordByIDProcessBeforeCall929074(paramsType,callback) { 
                 var response = paramsType;
 
paramsType.recordID = localStorage.userID;
callback(); 
                 } 
                 function getRecordByIDProcessAfterCall929074(response,callback) {
 
var resultmessage = 'Something went wrong, please try again later.';
if (response.status != undefined && response.status == 0 && response.recordDetails != undefined && response.recordDetails.result1 ) {
        var result1 = response.recordDetails.result1;
        result1 = parseFloat(result1);
        var result2 = response.recordDetails.result2;
        result2 = parseFloat(result2);
    resultmessage = "Based on your intended retirement age And your desired monthly income you will need a retirement nest egg of <b>$" + formatNumber(result1.toFixed(2)) + "</b> <br/><br/> In order to achieve it, you need to start saving <b>$" + formatNumber(result2.toFixed(2)) + "</b> every month. In order to reach your desired monthly income by age <b>" + response.recordDetails.retirementage + "</b> <br/><br/>If you wish to find out how you can save towards your retirement efficiently, you can book an appointment with a consultant at the appointment page."
}
$('div[id^="resultmessage"]').html(resultmessage);
callback(); 
                 }
                 function formatNumber(num) {
                  return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
                }