 
                 $(document).ready(function () {  
                       
                     $(document).on('click', '#490259', function () {  
                         $('#email_error').html('Email is required');  
                         $('#error_message').hide();  
                         var objParams = {};  
                         var email = $.trim($('#email').val());  
                         if ($('#email_div').is(':visible')) {  
                             if (email == '') {  
                                 $('#email_error').show();  
                                 $('#email').focus();  
                                 return false;  
                             } else {  
                                 $('#email_error').hide();  
                   
                                 // get user forgotpassword link  
                                 paramsType = {};  
                                 paramsType.appID = $.trim($('#hdnAppID').val());  
                                 paramsType.email = email;  
                                 paramsType.organizationID = '58b7fab92a866b2d21cbf2e0';  
                                 paramsType.triggerID = 7;  
                                      
     								domainName = $("#domainName").val();
     								var forgotPasswordURL = 'https://apps.'+domainName+'.com/api/getForgotPasswordLink' 
                                 $.ajax({  
                                     url: forgotPasswordURL, 
                                     data: paramsType,  
                                     type: 'POST',  
                                     success: function (respAppRolesUsers) {  
                                         if (respAppRolesUsers && respAppRolesUsers.status == 0) {  
                                             $('#display_loading').addClass('hideme');  
                                             $('#email_error').html('Reset password link is sent to you email address');  
                                             $('#email_error').show();  
                                             $('#email').val('');  
                                             Materialize.updateTextFields();  
                                         } else {  
                                             $('#display_loading').addClass('hideme');  
                                             $('#email_error').html('Email address does not exists');  
                                             $('#email_error').show();  
                                         }  
                                     },  
                                     error: function (xhr, status, error) {  
                                            
                                     },  
                                 });  
                   
                             }  
                         }  
                         return false;  
                     });  
                 });  
                    
                   
                 function apiCall(params, callback) {  
                     try {  
                         var https = new XMLHttpRequest();  
                         var URL = params.URL;  
                         https.open("POST", URL, true);  
                         https.setRequestHeader('content-type', 'application/json');  
                         https.setRequestHeader("token", params.token);  
                         if (params.token) delete params.token;  
                           
                         https.onreadystatechange = function () {  
                             if (https.readyState == 4 && https.status == 200) {  
                                 var response = https.responseText;  
                                 if (typeof response != 'object') {  
                                     response = JSON.parse(response);  
                                 }  
                                 callback(response);  
                             }  
                         }  
                         params = JSON.stringify(params);  
                         https.send(params);  
                     } catch (err) {  
                           
                     }  
                 } 