
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
     var totaldcard_leftimage_collectioncontainer = 0;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_addresslist'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
      var paramsEdit = {};
      paramsEdit.tokenKey = getParameterByName('tokenKey');
      paramsEdit.secretKey = getParameterByName('secretKey') 
                       getRecordByIDProcessBeforeCall112814(paramsEdit, function (processBeforeRes) {
      $.ajax({
          url: ajaXCallURL+'/milestone003/getRecordByCustomeQuery_app_ordersummarydetails_Orders5da73cac545050343288ce7a',
          data: paramsEdit,
          type: 'POST',
          jsonpCallback: 'callback',
          success: function (response) { 
                       getRecordByIDProcessAfterCall112814(response, function (processBeforeRes) {
              if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                  var objParamsList = {};
                  var queryMode = $('#queryMode').val(); 
                  objParamsList.queryMode = queryMode;;
                  var tokenKey = $('#tokenKey').val();;
                  objParamsList.tokenKey = tokenKey;;
  if(!$('#22').html()){
            $('#22').append(response.recordDetails.undefined);
 }
  if(!$('#24').html()){
            $('#24').append(response.recordDetails.undefined);
 }
  if(!$('#10').html()){
            $('#10').append(response.recordDetails.undefined);
 }
  if(!$('#13').html()){
            $('#13').append(response.recordDetails.undefined);
 }
  if(!$('#15').html()){
            $('#15').append(response.recordDetails.undefined);
 }
              $('#ordersnumber58_value').html(response.recordDetails.ordersnumber);
  if(!$('#backbutton1').html()){
            $('#backbutton1').append(response.recordDetails.undefined);
 }
  if(!$('#billingsummary26').html()){
            $('#billingsummary26').append(response.recordDetails.undefined);
 }
  if(!$('#byplacingyourorderyouagreetohrusticbrothersprivacynoticeandconditionsofuse56').html()){
            $('#byplacingyourorderyouagreetohrusticbrothersprivacynoticeandconditionsofuse56').append(response.recordDetails.undefined);
 }
  if(!$('#deliverydate19').html()){
            $('#deliverydate19').append(response.recordDetails.undefined);
 }
  if(!$('#extracharges28').html()){
            $('#extracharges28').append(response.recordDetails.undefined);
 }
  if(!$('#handling32').html()){
            $('#handling32').append(response.recordDetails.undefined);
 }
  if(!$('#labourcharges34').html()){
            $('#labourcharges34').append(response.recordDetails.undefined);
 }
  if(!$('#address_name11').html()){
            $('#address_name11').append(response.recordDetails.address_name);
 }
              response.recordDetails.carttotal = getCurrancy(response.recordDetails.carttotal, 'USD','$'); 
  if(!$('#carttotal29').html()){
            $('#carttotal29').append(response.recordDetails.carttotal);
 }
             if(response.recordDetails.categoryid_name != undefined) $('#categoryid_name52').val(response.recordDetails.categoryid_name);
  if(!$('#city12').html()){
            $('#city12').append(response.recordDetails.city);
 }
  if(!$('#country_name17').html()){
            $('#country_name17').append(response.recordDetails.country_name);
 }
  if(!$('#fullname9').html()){
            $('#fullname9').append(response.recordDetails.fullname);
 }
              response.recordDetails.handlingcost = getCurrancy(response.recordDetails.handlingcost, 'USD','$'); 
  if(!$('#handlingcost33').html()){
            $('#handlingcost33').append(response.recordDetails.handlingcost);
 }
             if(response.recordDetails.imageupload != undefined) $('#imageupload49').val(response.recordDetails.imageupload);
              response.recordDetails.labourcharges = getCurrancy(response.recordDetails.labourcharges, 'USD','$'); 
  if(!$('#labourcharges35').html()){
            $('#labourcharges35').append(response.recordDetails.labourcharges);
 }
  if(!$('#pincode16').html()){
            if(!response.recordDetails.pincode){
            	response.recordDetails.pincode = '0';
            }
            $('#pincode16').append(response.recordDetails.pincode);
 }
              $('#price51').maskMoney({thousands:',', decimal:'.', allowZero:true, prefix: '$'}).maskMoney('mask', response.recordDetails.price);  
             if(response.recordDetails.productname != undefined) $('#productname50').val(response.recordDetails.productname);
             if(response.recordDetails.quantity != undefined) $('#quantity53').val(response.recordDetails.quantity);
 response.recordDetails['slotdate_preserved'] = response.recordDetails['slotdate'] ;
 response.recordDetails['slotdate'] = response.recordDetails['slotdate']  ? moment(new Date(response.recordDetails['slotdate'])).format('DD MMM YYYY') : '';
  if(!$('#slotdate21').html()){
            $('#slotdate21').append(response.recordDetails.slotdate);
 }
 response.recordDetails['slotdate'] =  response.recordDetails['slotdate_preserved'];
  if(!$('#slottime23').html()){
            $('#slottime23').append(response.recordDetails.slottime);
 }
  if(!$('#state14').html()){
            $('#state14').append(response.recordDetails.state);
 }
              response.recordDetails.subtotal = getCurrancy(response.recordDetails.subtotal, 'USD','$'); 
  if(!$('#subtotal37').html()){
            $('#subtotal37').append(response.recordDetails.subtotal);
 }
              response.recordDetails.taxes = getCurrancy(response.recordDetails.taxes, 'USD','$'); 
  if(!$('#taxes39').html()){
            $('#taxes39').append(response.recordDetails.taxes);
 }
              response.recordDetails.totalamount = getCurrancy(response.recordDetails.totalamount, 'USD','$'); 
  if(!$('#totalamount41').html()){
            $('#totalamount41').append(response.recordDetails.totalamount);
 }
              response.recordDetails.transportationcost = getCurrancy(response.recordDetails.transportationcost, 'USD','$'); 
  if(!$('#transportationcost31').html()){
            $('#transportationcost31').append(response.recordDetails.transportationcost);
 }
             if(response.recordDetails.uom != undefined) $('#uom54').val(response.recordDetails.uom);
  if(!$('#placeyourorder2').html()){
            $('#placeyourorder2').append(response.recordDetails.undefined);
 }
  if(!$('#productlist43').html()){
            $('#productlist43').append(response.recordDetails.undefined);
 }
  if(!$('#shippingaddress7').html()){
            $('#shippingaddress7').append(response.recordDetails.undefined);
 }
  if(!$('#subtotal36').html()){
            $('#subtotal36').append(response.recordDetails.undefined);
 }
  if(!$('#taxes38').html()){
            $('#taxes38').append(response.recordDetails.undefined);
 }
  if(!$('#totalamount40').html()){
            $('#totalamount40').append(response.recordDetails.undefined);
 }
  if(!$('#transportation30').html()){
            $('#transportation30').append(response.recordDetails.undefined);
 }

              Materialize.updateTextFields();
                $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);
  
              } 
              }); // end of getRecord By ID
          },
          error: function (xhr, status, error) {
              handleError(xhr, status, error); 
          },
      }); 
              }); // end of getRecord By ID
   
});//end of ready 
                 function getRecordByIDProcessBeforeCall112814(paramsType,callback) { 
                 var response = paramsType;
 
if(getParameterByName('ordersid') && getParameterByName('ordersid') != 'undefined'){paramsType.recordID = getParameterByName('ordersid')} else if(getParameterByName('recordID') && getParameterByName('recordID') != 'undefined'){paramsType.recordID = getParameterByName('recordID')};callback(); 
                 } 
                 function getRecordByIDProcessAfterCall112814(response,callback) {
 
if(response && response.recordDetails && response.recordDetails.starttime && response.recordDetails.endtime){
response.recordDetails.slottime = response.recordDetails.starttime+'-'+response.recordDetails.endtime;
}
callback(); 
                 }