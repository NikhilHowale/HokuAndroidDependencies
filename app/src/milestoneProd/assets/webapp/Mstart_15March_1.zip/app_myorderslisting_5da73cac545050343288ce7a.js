
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
     var totaldcard_lefticon_collectioncontainer = 0;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
  showFilterBox(); 
  showBottomMenu(); 
});//end of ready
 function showFilterBox(){ 
   try { 
      var filterboxmenu = ''; 
 $(document).on('click', '#Filtersfilterbox', function () {
      var recordID = getParameterByName('recordID');
      var ordersid = getParameterByName('ordersid');
      var tokenKey = getParameterByName('tokenKey');
      var secretKey = getParameterByName('secretKey');
      var queryMode = 'mylist';
      var nextPage = 'app_myorderslistingdatefilter';
      if(!nextPage){
          return false;
      }
      window.location.href =  nextPage + '_5da73cac545050343288ce7a.html?queryMode='+ queryMode+'&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&applyFilter=true';
      return false;
 });
	    filterboxmenu += '    <div id="Filtersfilterbox" class="filterboxeachredirect" status="Filters">Filters</div>'
	    filterboxmenu += '    <div id="Newfilterbox" class="filterboxeach" status="New">New</div>'
	    filterboxmenu += '    <div id="Delayedfilterbox" class="filterboxeach" status="Delayed">Delayed</div>'
	    filterboxmenu += '    <div id="Enroutefilterbox" class="filterboxeach" status="Enroute">Enroute</div>'
	    filterboxmenu += '    <div id="Deliveredfilterbox" class="filterboxeach" status="Delivered">Delivered</div>'
      $('#chipfilter5').html(filterboxmenu)
 $(document).on('click', '.filterboxeach', function () {
     var status = $(this).attr('status');
     if($(this).hasClass('active')){
         $(this).removeClass('active');
         if(localStorage.getItem('appmyorderslistingFilterBox')){
             var arrFilterBox = localStorage.getItem('appmyorderslistingFilterBox').split(',');
         } else {
             var arrFilterBox = [];
         }
         var arrFilterBox = arrFilterBox.filter(function(elem){
             return elem != status; 
         });
         localStorage.setItem('appmyorderslistingFilterBox',arrFilterBox.toString());
     } else {
      $('.filterboxeach').removeClass('active');
      $('.filterboxeachredirect ').removeClass('active');
      $('.filterboxeachredirect ').css('background-image', 'url(chipfilter.svg)');
         $(this).addClass('active');
         if(localStorage.getItem('appmyorderslistingFilterBox')){
             var arrFilterBox = [];
         } else {
             var arrFilterBox = [];
         }
          arrFilterBox.push(status);
         localStorage.setItem('appmyorderslistingFilterBox',arrFilterBox.toString());
     }
      if(localStorage.getItem('appmyorderslistingFilterBox')){
          var arrFilterBox = localStorage.getItem('appmyorderslistingFilterBox').split(',');
          if(arrFilterBox.length > 0){
              for(count=0;count<arrFilterBox.length;count++){
                  $('#'+arrFilterBox[count]+'filterbox').addClass('active');
              }
          }
      }
 var queryMode = getParameterByName('queryMode');
 var isMobile = $('#isMobile').val();
 var isiPad = $('#isiPad').val();
 if(queryMode != ''){
    var tokenKey = $('#tokenKey').val();
    var objParamsList = {};
    objParamsList.queryMode = queryMode;
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsList.tokenKey = getParameterByName('tokenKey');
    objParamsList.secretKey = getParameterByName('secretKey');
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.isMobile = isMobile;
    objParamsList.isiPad = isiPad;
    objParamsList.applyFilter = false;
    objParamsList.applyFilterStatus = false;
      if(localStorage.getItem('appmyorderslistingFilterBox') == 'New'){
    objParamsList.status = arrFilterBox.toString();
      }
      if(localStorage.getItem('appmyorderslistingFilterBox') == 'Delayed'){
    objParamsList.status = arrFilterBox.toString();
      }
      if(localStorage.getItem('appmyorderslistingFilterBox') == 'Enroute'){
    objParamsList.status = arrFilterBox.toString();
      }
      if(localStorage.getItem('appmyorderslistingFilterBox') == 'Delivered'){
    objParamsList.status = arrFilterBox.toString();
      }
                      $('#collectioncontainerDivdcard_lefticon_collectioncontainer').html('');
                      $('#collectioncontainerDivdcard_lefticon_collectioncontainer').find('.view_list_record').removeClass('shimmer');
                      getDataProcessBeforeCalldcard_lefticon_collectioncontainerOrders5da73cac545050343288ce7a(objParamsList,function(processBeforeRes){
    show_dcard_lefticon_collectioncontainerapp_myorderslisting_Details(objParamsList)
                      })
 }
 });
 if(localStorage.getItem('appmyorderslistingFilterBox')){
     var arrFilterBox = localStorage.getItem('appmyorderslistingFilterBox').split(',');
     if(arrFilterBox.length > 0){
         for(count=0;count<arrFilterBox.length;count++){
             $('#'+arrFilterBox[count]+'filterbox').addClass('active');
         }
     }
 }
  } catch(err){
     // console.log('Error in showFilterBox', err);
  }
}
 function showBottomMenu(){ 
   var menuObj = localStorage.getItem('objGetUserDetailsWithmenu');
   if(menuObj){
     menuObj = JSON.parse(menuObj);
     if( menuObj.data && menuObj.data.roleName ) {
          var roleName = menuObj.data.roleName;
     }
   }
   try { 
      var bottommenu = ''; 
	    bottommenu += '<div class="mobilebottommenu">'
	    bottommenu += '    <div class="row">'
	    bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Home" fileName="app_userhome_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_home.svg"><span>Home</span></a></div>'
	    bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="QuickShop" fileName="app_productpickerlist_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_quickshop.svg"><span>Quick Shop</span></a></div>'
	    bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Orders" fileName="app_myorderslisting_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_allprductsactive.svg"><span>Orders</span></a></div>'
	    bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Chat" fileName="undefined_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_chat.svg"><span>Chat</span></a><div style="display:none !important"  class="chatunreadcount"></div></div>'
	    bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="More" fileName="app_custmoreinfodetails_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_more.svg"><span>More</span></a></div>'
	    bottommenu += '    </div>'
	    bottommenu += '</div>'
      $('#bottommenu16').html(bottommenu)
  } catch(err){
     // console.log('Error in showBottomMenu', err);
  }
}
