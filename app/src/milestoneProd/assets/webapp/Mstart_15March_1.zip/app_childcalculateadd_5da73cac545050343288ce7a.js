
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"))
    }

    var objParamsToken = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsToken.tokenKey = getParameterByName('tokenKey');
    objParamsToken.secretKey = getParameterByName('secretKey');

    var userRole = $('#userRole').val();
    var userID = $('#userID').val();
    var createrOfRecord = $('#createrOfRecord').val();
    var queryMode = getParameterByName('queryMode');
    var recordID = $.trim($('#recordID').val());
    var addSessionComments = [];
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('click', '#result20', function () {
        var objParams = {};
        var childage = $.trim($('#childage13').val());
        var obj = {}
        if ($('#childage13_div').is(':visible')) {
            if (childage == '') {
                $('#childage13_error').show();
                if (!Object.keys(errorFields).length) errorFields['childage13'] = 'textbox';
                validAll = false;
            } else {
                $('#childage13_error').hide();
            }
        }
        if ($('#childage13_div').is(':visible')) {
            objParams.childage = childage;
        }
        var universityage = $.trim($('#universityage14').val());
        var obj = {}
        if ($('#universityage14_div').is(':visible')) {
            if (universityage == '') {
                $('#universityage14_error').show();
                if (!Object.keys(errorFields).length) errorFields['universityage14'] = 'textbox';
                validAll = false;
            } else {
                $('#universityage14_error').hide();
            }
        }
        if ($('#universityage14_div').is(':visible')) {
            objParams.universityage = universityage;
        }
        var university = $.trim($('#university15').val());
        var obj = {}
        if ($('#university15_div').is(':visible')) {
            if (university == '') {
                $('#university15_error').show();
                if (!Object.keys(errorFields).length) errorFields['university15'] = 'dropdown';
                validAll = false;
            } else {
                objParams.university_name = $("#university15 option:selected").text();
                $('#university15_error').hide();
            }
        }
        if ($('#university15_div').is(':visible')) {
            objParams.university = university;
        }
        // var setasite = $.trim($('#setasite16').val());
        // var obj = {}
        // if ($('#setasite16_div').is(':visible')) {
        //     if (setasite == '') {
        //         $('#setasite16_error').show();
        //         if (!Object.keys(errorFields).length) errorFields['setasite16'] = 'textbox';
        //         validAll = false;
        //     } else {
        //         $('#setasite16_error').hide();
        //     }
        // }
        // if ($('#setasite16_div').is(':visible')) {
        //     objParams.setasite = setasite;
        // }
        var coursename = $.trim($('#coursename17').val());
        var obj = {}
        if ($('#coursename17_div').is(':visible')) {
            if (coursename == '') {
                $('#coursename17_error').show();
                if (!Object.keys(errorFields).length) errorFields['coursename17'] = 'dropdown';
                validAll = false;
            } else {
                objParams.coursename_name = $("#coursename17 option:selected").text();
                $('#coursename17_error').hide();
            }
        }
        if ($('#coursename17_div').is(':visible')) {
            objParams.coursename = coursename;
        }
        var inflationrate = $.trim($('#inflationrate18').val());
        var obj = {}
        if ($('#inflationrate18_div').is(':visible')) {
            if (inflationrate == '') {
                $('#inflationrate18_error').show();
                if (!Object.keys(errorFields).length) errorFields['inflationrate18'] = 'textbox';
                validAll = false;
            } else {
                $('#inflationrate18_error').hide();
            }
        }
        if ($('#inflationrate18_div').is(':visible')) {
            objParams.inflationrate = inflationrate;
        }
        var childnumber = $.trim($('#childnumber21').val());
        if ($('#childnumber21_div').is(':visible')) {
            objParams.childnumber = childnumber;
        }
        var shortfall1 = $.trim($('#shortfall122').val());
        if ($('#shortfall122_div').is(':visible')) {
            objParams.shortfall1 = shortfall1;
        }
        var shortfall2 = $.trim($('#shortfall223').val());
        if ($('#shortfall223_div').is(':visible')) {
            objParams.shortfall2 = shortfall2;
        }
        var fundrange1 = $.trim($('#fundrange124').val());
        if ($('#fundrange124_div').is(':visible')) {
            objParams.fundrange1 = fundrange1;
        }
        var fundrange2 = $.trim($('#fundrange225').val());
        if ($('#fundrange225_div').is(':visible')) {
            objParams.fundrange2 = fundrange2;
        }
        var incomerange1 = $.trim($('#incomerange126').val());
        if ($('#incomerange126_div').is(':visible')) {
            objParams.incomerange1 = incomerange1;
        }
        var incomerange2 = $.trim($('#incomerange227').val());
        if ($('#incomerange227_div').is(':visible')) {
            objParams.incomerange2 = incomerange2;
        }
        var inflationrate = $.trim($('#inflationrate18').val());
        var obj = {}
        if ($('#inflationrate18_div').is(':visible')) {
            if (inflationrate == '') {
                $('#inflationrate18_error').show();
                if (!Object.keys(errorFields).length) errorFields['inflationrate18'] = 'textbox';
                validAll = false;
            } else {
                $('#inflationrate18_error').hide();
            }
        }
        if ($('#inflationrate18_div').is(':visible')) {
            objParams.inflationrate = inflationrate;
        }
        var shortfall1 = $.trim($('#shortfall122').val());
        if ($('#shortfall122_div').is(':visible')) {
            objParams.shortfall1 = shortfall1;
        }
        var shortfall2 = $.trim($('#shortfall223').val());
        if ($('#shortfall223_div').is(':visible')) {
            objParams.shortfall2 = shortfall2;
        }
        var fundrange1 = $.trim($('#fundrange124').val());
        if ($('#fundrange124_div').is(':visible')) {
            objParams.fundrange1 = fundrange1;
        }
        var fundrange2 = $.trim($('#fundrange225').val());
        if ($('#fundrange225_div').is(':visible')) {
            objParams.fundrange2 = fundrange2;
        }
        var incomerange1 = $.trim($('#incomerange126').val());
        if ($('#incomerange126_div').is(':visible')) {
            objParams.incomerange1 = incomerange1;
        }
        var incomerange2 = $.trim($('#incomerange227').val());
        if ($('#incomerange227_div').is(':visible')) {
            objParams.incomerange2 = incomerange2;
        }
        var tempobjParams = getParams(window.location.href)
        function extend(obj, src) {
            for (var key in src) {
                if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
            }
            return obj;
        }
        objParams = extend(objParams, tempobjParams);
        var recordID = $('#recordID').val();
        objParams.isDelete = 0;
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParams.tokenKey = getParameterByName('tokenKey');
        objParams.secretKey = getParameterByName('secretKey');
        objParams.offlineDataID = localStorage.getItem("offlineDataID");
        var queryMode = getParameterByName('queryMode')
        if (queryMode == 'mylist') {
            objParams.callUrl = ajaXCallURL + '/milestone003/saveAjaxusermanagement3934resultapp_childcalculateadd';
        } else {
            objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxusermanagement3934resultapp_childcalculateadd';
            objParams.recordID = recordID;
        }
        if (errorFields && Object.keys(errorFields).length) {
            $('#display_loading1').addClass('hideme');
            for (var firstErrorField in errorFields) {
                var controlType = errorFields[firstErrorField];
                errorFields = []
                var errField = $('#' + firstErrorField);
                if (controlType == 'dropdown') {
                    errField.prev().prev().focus();
                } else {
                    errField.focus()
                }
                validAll = true;
                return false;
            }
        }
        if (!validAll) {
            validAll = true;
            return false;
        }
        $('#result20').prop('disabled', true);
        $('#display_loading1').removeClass('hideme');
        if (addSessionComments.length > 0) {
            objParams.addSessionComments = addSessionComments;
        } else {
            objParams.addSessionComments = [];
        }
        var parentID = $('#parentID').val();
        var parentName = $('#parentName').val();
        if (parentID != '') {
            objParams.parentID = parentID;
            objParams.parentName = parentName
        }
        if (typeof (addedFiles) != "undefined" && addedFiles && addedFiles.length > 0) {
            objParams.addedFiles = addedFiles;
        }
        objParams.ajaXCallURL = $("#ajaXCallURL").val();;
        objParams.organizationID = $("#organizationID").val();;
        objParams.ajaXCallURL = $("#ajaXCallURL").val();;
        objParams.organizationID = $("#organizationID").val();;
        processBeforeCallForSave3934result(objParams, {}, function (processBeforeRes) {
            $.ajax({
                url: objParams.callUrl,
                data: objParams,
                type: 'POST',
                success: function (response) {
                    if (response.status == 0) {
                        $('#display_loading1').addClass('hideme');
                        response.nextPage = 'app_financialchilddetails'
                        processAfterCallForSave3934result(response, function (processAfterRes) {
                            var tokenKey = getParameterByName('tokenKey');
                            var secretKey = getParameterByName('secretKey');
                            var queryMode = getParameterByName('queryMode');
                            queryMode = queryMode.replace('edit', '');
                            localStorage.setItem("headerPageName", 'app_financialchilddetails');
                            var queryString = window.location.search.slice(1);
                            var newQuery = queryString + '&queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&queryMode=mylist' + '&childid=' + response.data._id + '&recordID=' + response.data._id
                            var queryParams = queryStringToJSON(newQuery);
                            queryString = $.param(queryParams);
                            queryString = queryString.replace(/\+/g, "%20");
                            queryString = decodeURIComponent(queryString);
                            if (recordID == '') {
                                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
                            } else {
                                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
                            }
                            return false;
                        }); // End of After Process
                    } else {
                        $('#display_loading1').addClass('hideme');
                        $('#2656d_error').html(response.error);
                        $('#2656d_error').show();
                    }
                    $('#result20').removeProp('disabled');
                },
                error: function (xhr, status, error) {
                    $('#display_loading1').addClass('hideme');
                    $('#result20').removeProp('disabled');
                },
            });
            return false;
        }); // End of Before Process
    });//end of Event Result_is_click 
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};
    var addedRecords = [];

    ///
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#backbutton1', function (e) {
        try {
            var element = $(this);
            var rolename = localStorage.getItem("roleName");
            // var nextPage = 'app_custmoreinfodetails';
            var nextPage = 'app_allfinancialservicesstepfinallist';
            if (rolename == "consultant") {
              nextPage = "app_consultantcustmoreinfodetails";
            }   
                     var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "update";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - backbutton1", error)
        }
    })
    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#retirementfund7', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_retirementcalculateadd';
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "add";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - retirementfund7", error)
        }
    })
    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#financialgoals8', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_financialcalculateadd';
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "add";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - financialgoals8", error)
        }
    })
});//end of ready
function getParams(url) {
    var urlParams = {};
    url.replace(
        new RegExp("([^?=&]+)(=([^&]*))?", "g"),
        function ($0, $1, $2, $3) {
            if ($3 && $3 != 'undefined') urlParams[$1] = $3;
        }
    );
    return urlParams;
}
function processBeforeCallForSave3934result(objParams, response, callback) {


    objParams.recordID = localStorage.userID;
    var childage13 = $("#childage13").val();

    var universityage14 = $("#universityage14").val();

    if (parseFloat(childage13) > parseFloat(universityage14)) {
        $('#display_loading1').addClass('hideme');
        $('#universityage15_error').show();
        $('#result20').removeProp('disabled');

        return false;

    }
    else {
        $('#universityage15_error').hide();

    }
    var university14 = $("#university15").val();
    var setasite15 = 0;// parseFloat($("#setasite16").val());
    var coursename16 = $("#coursename17").val();
    var inflationrate17 = parseFloat($("#inflationrate18").val());

    inflationrate17 = inflationrate17 / 100;


    var yearsforunivercity = universityage14 - childage13;





    var inflationrate17value = (1 + inflationrate17);
    var inflationrate17value1 = inflationrate17value;
    for (var i = 1; i < yearsforunivercity; i++) {
        inflationrate17value1 = inflationrate17value1 * inflationrate17value
    }
localStorage.setItem("univesity",university14)
localStorage.setItem("course",coursename16)

    if (university14 == 'Local' && coursename16 == 'Non-Medical') {
           if(setasite15 > 10000)
           {
               $('#display_loading1').addClass('hideme');
                $('#setasite17_error').show();
        
        
           }
           else
           {
               $('#setasite17_error').hide();
        
           }
        var shortfall1 = 10000 - setasite15;
        if (shortfall1 < 0) {
            objParams.shortfall1 = 0;

        }else
        {
            objParams.shortfall1 = shortfall1;
        }
        firstlevelvalue = objParams.shortfall1 * inflationrate17value1
        firstlevelvalue1 = firstlevelvalue / yearsforunivercity;
        objParams.incomerange1 = firstlevelvalue1 / 12;

        var shortfall2 = 36000 - setasite15;
        if (shortfall2 < 0) {
            objParams.shortfall2 = 0;
        }
        else {
            objParams.shortfall2 = shortfall2;

        }
        var firstlevelvaluer1 = objParams.shortfall2 * inflationrate17value1
        firstlevelvaluer1 = firstlevelvaluer1 / yearsforunivercity;
        objParams.incomerange2 = firstlevelvaluer1 / 12;

        objParams.fundrange1 = 10000  ; 
        objParams.fundrange2 = 36000;

    } else if (university14 == 'Local' && coursename16 == 'Medical') {

        var shortfall1 = 102533 - setasite15;
        if (shortfall1 < 0) {
            objParams.shortfall1 = 0;
        }
        else {
            objParams.shortfall1 = shortfall1;

        }

        firstlevelvalue = objParams.shortfall1 * inflationrate17value1
        firstlevelvalue1 = firstlevelvalue / yearsforunivercity;
        objParams.incomerange1 = firstlevelvalue1 / 12;

        var shortfall2 = 144300 - setasite15;

        if (shortfall2 < 0) {
            objParams.shortfall2 = 0;
        }
        else {
            objParams.shortfall2 = shortfall2;

        }
        var firstlevelvaluer1 = objParams.shortfall2 * inflationrate17value1
        firstlevelvaluer1 = firstlevelvaluer1 / yearsforunivercity;
        objParams.incomerange2 = firstlevelvaluer1 / 12;

        objParams.fundrange1 = 102533;
        objParams.fundrange2 = 144300;
    } else if (university14 == 'Overseas' && coursename16 == 'Non-Medical') {

        var shortfall1 = 179400 - setasite15;
        if (shortfall1 < 0) {
            objParams.shortfall1 = 0;
        }
        else {
            objParams.shortfall1 = shortfall1;
        }


        firstlevelvalue = objParams.shortfall1 * inflationrate17value1
        firstlevelvalue1 = firstlevelvalue / yearsforunivercity;
        objParams.incomerange1 = firstlevelvalue1 / 12;

        var shortfall2 = 310700 - setasite15;
        if (shortfall2 < 0) {
            objParams.shortfall2 = 0;
        }
        else {
            objParams.shortfall2 = shortfall2;

        }


        var firstlevelvaluer1 = objParams.shortfall2 * inflationrate17value1
        firstlevelvaluer1 = firstlevelvaluer1 / yearsforunivercity;
        objParams.incomerange2 = firstlevelvaluer1 / 12;

        objParams.fundrange1 = 179400;
        objParams.fundrange2 = 310700;
    } else if (university14 == 'Overseas' && coursename16 == 'Medical') {
        var shortfall1 = 476520 - setasite15;
        if (shortfall1 < 0) {
            objParams.shortfall1 = 0;
        }
        else {
            objParams.shortfall1 = shortfall1;
        }


        firstlevelvalue = objParams.shortfall1 * inflationrate17value1
        firstlevelvalue1 = firstlevelvalue / yearsforunivercity;
        objParams.incomerange1 = firstlevelvalue1 / 12;
        var shortfall2 = 676056 - setasite15;

        if (shortfall2 < 0) {
            objParams.shortfall2 = 0;
        }
        else {
            objParams.shortfall2 = shortfall2;

        }
        var firstlevelvaluer1 = objParams.shortfall2 * inflationrate17value1
        firstlevelvaluer1 = firstlevelvaluer1 / yearsforunivercity;
        objParams.incomerange2 = firstlevelvaluer1 / 12;

        objParams.fundrange1 = 476520;
        objParams.fundrange2 = 676056;

    }

    objParams.universityage = $("#universityage14").val();
    objParams.inflationrate = $("#inflationrate18").val();
    objParams.fundrange1 =  objParams.fundrange1 * inflationrate17value1;
    objParams.fundrange1 =   objParams.fundrange1.toFixed(2);
    objParams.fundrange2 = objParams.fundrange2 * inflationrate17value1;;
    objParams.fundrange2 =   objParams.fundrange2.toFixed(2);


    callback();
}
function processAfterCallForSave3934result(response, callback) {

    callback();
}
