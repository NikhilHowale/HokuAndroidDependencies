
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var financialCalculator = JSON.parse(localStorage.financialCalculator)

$(document).ready(function () {
  $('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
    $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }
  $('#mycurrentage123').val(financialCalculator.intendedRetireAge)
var skiprowonepassive =false;
var skiprowonelumsum =false;
var isPage2 = false;
  $('#monthlyexpense123').val(financialCalculator.monthlyexpnceCurrent)
  var passiveArray = [];
  if (financialCalculator.passiveArray.length > 0 && financialCalculator.passiveArray[0].insuer != '' && financialCalculator.passiveArray[0].startpayout != 'Start of passive income payout' && financialCalculator.passiveArray[0].passiveincome != '' && financialCalculator.passiveArray[0].endpayout != 'End of passive income payout') {
    passiveArray = financialCalculator.passiveArray;
   
  }
  else if (financialCalculator.passiveArrayYourGoal && financialCalculator.passiveArrayYourGoal != undefined && financialCalculator.passiveArrayYourGoal.length > 0) {

    passiveArray = financialCalculator.passiveArrayYourGoal;
    skiprowonepassive = true;
    isPage2 = true;
     

  }
  else
  {
    $('#passivedcard').attr('isPage2',true)
  }

  if (passiveArray.length > 0) {
    $('#passivedcard .insuer').val((passiveArray[0].insuer))
    $('#passivedcard .passiveincome').val((passiveArray[0].passiveincome))
    $('#passivedcard').attr('isPage2',isPage2)
    $('#startpayout').find('option[value="' + passiveArray[0].startpayout + '"]').prop('selected', true);
    $("#startpayout").material_select();
    $("#endpayout").find('option[value="' + passiveArray[0].endpayout + '"]').prop('selected', true);
    $("#endpayout").material_select();
  }
  var lumbsumArray = [];
  if (financialCalculator.lumbsumArray && financialCalculator.lumbsumArray != undefined && financialCalculator.lumbsumArray != null && financialCalculator.lumbsumArray.length > 0 && financialCalculator.lumbsumArray[0].insuer != '' && financialCalculator.lumbsumArray[0].lumpsumd != '') {
    lumbsumArray = financialCalculator.lumbsumArray;
    isPage2 = false;
  }
  else if (financialCalculator.lumbsumArrayYourGoal && financialCalculator.lumbsumArrayYourGoal != undefined && financialCalculator.lumbsumArrayYourGoal.length > 0) {
    lumbsumArray = financialCalculator.lumbsumArrayYourGoal;
    isPage2 = true;
      skiprowonelumsum =true;

  }
  else{
    $('.lumpsumdcard').attr('isPage2',true)
  }
  if (lumbsumArray.length > 0) {
    $('#lumpsumdcard .insuer').val((lumbsumArray[0].insuer))
    $('#lumpsumdcard .lumpsumd').val((lumbsumArray[0].lumpsumd))
    $('.lumpsumdcard').attr('isPage2',isPage2)
    var lumsumamt = '';
    lumsumamt = lumbsumArray[0].ExpectedLumpsumat



  }
  if (lumsumamt == '' && financialCalculator.intendedRetireAge && financialCalculator.intendedRetireAge != undefined && financialCalculator.intendedRetireAge != null) {
    lumsumamt = financialCalculator.intendedRetireAge
  }
  $('#ExpectedLumpsumatSel').find('option[value="' + lumsumamt + '"]').prop('selected', true);
  $('#ExpectedLumpsumatSel').material_select();

  var objParamsToken = {};
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  objParamsToken.tokenKey = getParameterByName('tokenKey');
  objParamsToken.secretKey = getParameterByName('secretKey');

  var userRole = $('#userRole').val();
  var userID = $('#userID').val();
  var createrOfRecord = $('#createrOfRecord').val();
  var queryMode = getParameterByName('queryMode');
  var recordID = $.trim($('#recordID').val());
  var addSessionComments = [];
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  setValuesFromStep1();
  setValuesFromStep2(skiprowonepassive,skiprowonelumsum);
  $(document).on('click', '#result18', function () {
    var objParams = {};
    var currentage = $.trim($('#currentage13').val());
    var obj = {}
    if ($('#currentage13_div').is(':visible')) {
      if (currentage == '') {
        $('#currentage13_error').show();
        if (!Object.keys(errorFields).length) errorFields['currentage13'] = 'textbox';
        validAll = false;
      } else {
        $('#currentage13_error').hide();
      }
    }
    if ($('#currentage13_div').is(':visible')) {
      objParams.currentage = currentage;
    }
    var retirementage = $.trim($('#retirementage14').val());
    var obj = {}
    if ($('#retirementage14_div').is(':visible')) {
      if (retirementage == '') {
        $('#retirementage14_error').show();
        if (!Object.keys(errorFields).length) errorFields['retirementage14'] = 'textbox';
        validAll = false;
      } else {
        $('#retirementage14_error').hide();
      }
    }
    if ($('#retirementage14_div').is(':visible')) {
      objParams.retirementage = retirementage;
    }
    var monthlyincome = $.trim($('#monthlyincome15').val());
    var obj = {}
    if ($('#monthlyincome15_div').is(':visible')) {
      if (monthlyincome == '') {
        $('#monthlyincome15_error').show();
        if (!Object.keys(errorFields).length) errorFields['monthlyincome15'] = 'textbox';
        validAll = false;
      } else {
        $('#monthlyincome15_error').hide();
      }
    }
    if ($('#monthlyincome15_div').is(':visible')) {
      objParams.monthlyincome = monthlyincome;
    }
    var incomeyearsrequired = $.trim($('#incomeyearsrequired16').val());
    var obj = {}
    if ($('#incomeyearsrequired16_div').is(':visible')) {
      if (incomeyearsrequired == '') {
        $('#incomeyearsrequired16_error').show();
        if (!Object.keys(errorFields).length) errorFields['incomeyearsrequired16'] = 'textbox';
        validAll = false;
      } else {
        $('#incomeyearsrequired16_error').hide();
      }
    }
    if ($('#incomeyearsrequired16_div').is(':visible')) {
      objParams.incomeyearsrequired = incomeyearsrequired;
    }
    var inflationrate = $.trim($('#inflationrate17').val());
    var obj = {}
    if ($('#inflationrate17_div').is(':visible')) {
      if (inflationrate == '') {
        $('#inflationrate17_error').show();
        if (!Object.keys(errorFields).length) errorFields['inflationrate17'] = 'textbox';
        validAll = false;
      } else {
        $('#inflationrate17_error').hide();
      }
    }
    if ($('#inflationrate17_div').is(':visible')) {
      objParams.inflationrate = inflationrate;
    }
    var fundnumber = $.trim($('#fundnumber19').val());
    if ($('#fundnumber19_div').is(':visible')) {
      objParams.fundnumber = fundnumber;
    }
    var tempobjParams = getParams(window.location.href)
    function extend(obj, src) {
      for (var key in src) {
        if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
      }
      return obj;
    }
    objParams = extend(objParams, tempobjParams);
    var recordID = $('#recordID').val();
    objParams.isDelete = 0;
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParams.tokenKey = getParameterByName('tokenKey');
    objParams.secretKey = getParameterByName('secretKey');
    objParams.offlineDataID = localStorage.getItem("offlineDataID");
    var queryMode = getParameterByName('queryMode')
    if (queryMode == 'add121') {
      objParams.callUrl = ajaXCallURL + '/milestone003/saveAjaxusermanagement4524resultapp_retirementcalculateadd';
    } else {
      objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxusermanagement4524resultapp_retirementcalculateadd';
      objParams.recordID = recordID;
    }
    if (errorFields && Object.keys(errorFields).length) {
      $('#display_loading1').addClass('hideme');
      for (var firstErrorField in errorFields) {
        var controlType = errorFields[firstErrorField];
        errorFields = []
        var errField = $('#' + firstErrorField);
        if (controlType == 'dropdown') {
          errField.prev().prev().focus();
        } else {
          errField.focus()
        }
        validAll = true;
        return false;
      }
    }
    if (!validAll) {
      validAll = true;
      return false;
    }
    $('#result18').prop('disabled', true);
    $('#display_loading1').removeClass('hideme');
    if (addSessionComments.length > 0) {
      objParams.addSessionComments = addSessionComments;
    } else {
      objParams.addSessionComments = [];
    }
    var parentID = $('#parentID').val();
    var parentName = $('#parentName').val();
    if (parentID != '') {
      objParams.parentID = parentID;
      objParams.parentName = parentName
    }
    if (typeof (addedFiles) != "undefined" && addedFiles && addedFiles.length > 0) {
      objParams.addedFiles = addedFiles;
    }
    objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    objParams.organizationID = $("#organizationID").val();;
    objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    objParams.organizationID = $("#organizationID").val();;
    processBeforeCallForSave4524result(objParams, {}, function (processBeforeRes) {
      $.ajax({
        url: objParams.callUrl,
        data: objParams,
        type: 'POST',
        success: function (response) {
          if (response.status == 0) {
            $('#display_loading1').addClass('hideme');
            response.nextPage = 'app_retirementdetails'
            processAfterCallForSave4524result(response, function (processAfterRes) {
              var tokenKey = getParameterByName('tokenKey');
              var secretKey = getParameterByName('secretKey');
              var queryMode = getParameterByName('queryMode');
              queryMode = queryMode.replace('edit', '');
              localStorage.setItem("headerPageName", 'app_retirementdetails');
              var queryString = window.location.search.slice(1);
              var newQuery = queryString + '&queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&queryMode=mylist' + '&fundid=' + response.data._id + '&recordID=' + response.data._id
              var queryParams = queryStringToJSON(newQuery);
              queryString = $.param(queryParams);
              queryString = queryString.replace(/\+/g, "%20");
              queryString = decodeURIComponent(queryString);
              if (recordID == '') {
                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
              } else {
                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
              }
              return false;
            }); // End of After Process
          } else {
            $('#display_loading1').addClass('hideme');
            $('#2656d_error').html(response.error);
            $('#2656d_error').show();
          }
          $('#result18').removeProp('disabled');
        },
        error: function (xhr, status, error) {
          $('#display_loading1').addClass('hideme');
          $('#result18').removeProp('disabled');
        },
      });
      return false;
    }); // End of Before Process
  });//end of Event Result_is_click 
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#backbutton1,.prevbtn123', function (e) {
    try {
      var element = $(this);
      var rolename = localStorage.getItem("roleName");
      // var nextPage = 'app_custmoreinfodetails';
      var nextPage = 'app_retirementgoalstep1';
      // if (rolename == "consultant") {
      //   nextPage = "app_consultantcustmoreinfodetails";
      // }

      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "update";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error)
    }
  })
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#financialgoals8', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_financialcalculateadd';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "add";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - financialgoals8", error)
    }
  })
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#childuniversityfund9', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_childcalculateadd';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "add";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - childuniversityfund9", error)
    }
  });

  $(document).on('click', '#retiremetgoal11', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_retirementgoalstep';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "add";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - childuniversityfund9", error)
    }
  })

  $(document).on('click', '.nextbtn123', function (e) {
    try {

      var passiveArrayYourGoal = []
      $('.passivedcard').each(function () {
        let objFileds = {};
        objFileds.insuer = $(this).find('.insuer').val();

        objFileds.passiveincome = $(this).find('.passiveincome').val();
        objFileds.startpayout = $(this).find('select.startpayout').val();
        objFileds.endpayout = $(this).find('select.endpayout').val();

        var isPage2 = $(this).attr('isPage2')
        if (isPage2 && isPage2 != undefined)
          objFileds.isPage2 = isPage2;
        else
          objFileds.isPage2 = false;
        passiveArrayYourGoal.push(objFileds)




      });

      var lumbsumArrayYourGoal = []
      $('.lumpsumdcard').each(function () {

        var isPage2 = $(this).attr('isPage2')
        if (isPage2 && isPage2 != undefined && isPage2 != null) {

          let objFileds = {};
          objFileds.insuer = $(this).find('.insuer').val();
          objFileds.lumpsumd = $(this).find('.lumpsumd').val();
          objFileds.ExpectedLumpsumat = $(this).find('select.ExpectedLumpsumat').val();
          var isPage2 = $(this).attr('isPage2')
          if (isPage2 && isPage2 != undefined)
            objFileds.isPage2 = isPage2;
          else
            objFileds.isPage2 = false;
          lumbsumArrayYourGoal.push(objFileds)
        }
      });

      console.log(lumbsumArrayYourGoal)

      financialCalculator.passiveArrayYourGoal = passiveArrayYourGoal;
      financialCalculator.lumbsumArrayYourGoal = lumbsumArrayYourGoal;
      financialCalculator.currentAge = $('#mycurrentage123').val();
      financialCalculator.intendedRetireAge = $('#mycurrentage123').val();

      
      financialCalculator.monthlyexpnceYourGoal = $('#monthlyexpense123').val();
      localStorage.financialCalculator = JSON.stringify(financialCalculator);
      var element = $(this);
      var parent = getParameterByName('parent');
      var nextPage = 'app_retirementgoalgraph';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);

      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error)
    }

  })
  $(document).on('click', '#lumpsumincomeadd', function (e) {
    console.log('here')
    addLumpsumRow(null, true);

  })

  $(document).on('click', '#passiveincomeadd', function (e) {
    console.log('here')
    addPassiveRow(null, true);

  })
});//end of ready
function getParams(url) {
  var urlParams = {};
  url.replace(
    new RegExp("([^?=&]+)(=([^&]*))?", "g"),
    function ($0, $1, $2, $3) {
      if ($3 && $3 != 'undefined') urlParams[$1] = $3;
    }
  );
  return urlParams;
}
function processBeforeCallForSave4524result(objParams, response, callback) {


  objParams.recordID = localStorage.userID;

  var currentage13 = $("#currentage13").val();
  var retirementage14 = $("#retirementage14").val();
  if (retirementage14 < currentage13) {
    $('#retirementage15_error').show();
    $('#result18').removeProp('disabled');
    $('#display_loading1').addClass('hideme');


    return false;

  }
  {
    $('#retirementage15_error').hide();

  }
  var monthlyincome15 = $("#monthlyincome15").val();
  var incomeyearsrequired16 = parseInt($("#incomeyearsrequired16").val());
  var inflationrate17 = $("#inflationrate17").val();
  inflationrate17 = inflationrate17 / 100;
  var yeartoachive = retirementage14 - currentage13;

  var inflationrate17value = (1 + inflationrate17);
  var inflationrate17value1 = inflationrate17value;
  for (var i = 1; i < yeartoachive; i++) {
    inflationrate17value1 = inflationrate17value1 * inflationrate17value
  }
  var firstlevelvalue0 = monthlyincome15 * 12 * incomeyearsrequired16;
  firstlevelvalue = firstlevelvalue0 * inflationrate17value1



  objParams.result1 = firstlevelvalue //monthlyincome15 * 12 * incomeyearsrequired16;
  objParams.result2 = firstlevelvalue / yeartoachive;
  objParams.result2 = objParams.result2 / 12
  callback();
}



function setValuesFromStep2(skiprowonepassive,skiprowonelumsum) {
  let financialCalculator = JSON.parse(localStorage.getItem("financialCalculator"));
  var passiveArray = [];
  var lumbsumArray = [];
var i = 0
 

  if (financialCalculator.passiveArrayYourGoal && financialCalculator.passiveArrayYourGoal != undefined && financialCalculator.passiveArrayYourGoal != null && financialCalculator.passiveArrayYourGoal.length > 0) {
    passiveArray = financialCalculator.passiveArrayYourGoal;
  }

  if (financialCalculator.lumbsumArrayYourGoal && financialCalculator.lumbsumArrayYourGoal != undefined && financialCalculator.lumbsumArrayYourGoal != null && financialCalculator.lumbsumArrayYourGoal.length > 0) {
    lumbsumArray = financialCalculator.lumbsumArrayYourGoal;
  }
  if (passiveArray.length > 0) {
    passiveArray.forEach(passiveObject => {

      if (skiprowonepassive == false && passiveObject != null && passiveObject.isPage2 && (passiveObject.isPage2 == true || passiveObject.isPage2 == 'true')) {
        
        addPassiveRow(passiveObject, true);
      }
      skiprowonepassive = false;
    });
  }


  if (lumbsumArray.length > 0) {

    lumbsumArray.forEach(lumbsumObject => {

      console.log("Adding from 1")
      if (skiprowonelumsum == false && lumbsumObject != null && lumbsumObject.isPage2 && (lumbsumObject.isPage2 == true || lumbsumObject.isPage2 == 'true')) {
        addLumpsumRow(lumbsumObject, true);
      }
      skiprowonelumsum = false;

    });
  }

}
function setValuesFromStep1() {
  let financialCalculator = JSON.parse(localStorage.getItem("financialCalculator"));
  var passiveArray = financialCalculator.passiveArray;
  var lumbsumArray = financialCalculator.lumbsumArray;
  if (passiveArray.length > 1) {
    var i = 0;
    passiveArray.forEach(element => {
      if (i > 0) {

        addPassiveRow(element, false);
      }
      i++;
    });
  }

  var i = 0;
  if (lumbsumArray.length > 1) {

    lumbsumArray.forEach(element => {
      if (i > 0) {
        console.log("Adding from 1")
        addLumpsumRow(element, false);
      }
      i++;
    });
  }




}
function addPassiveRow(passiveObject, isPage2) {
  try {
    //let html = '<div class="row">' + $('#lumpsumdarcddemo').html() + '</div>';
    //$('#lumpsumdcard').append(html);
    //endpayout
    //: 
    // "75"
    // insuer
    // : 
    // "abc"
    // passiveincome
    // : 
    // "500"
    // startpayout
    // : 
    //"65"
    var insuer = '';
    var passiveincome = '';
    var startpayout = '';
    var endpayout = '';
    if (passiveObject != null) {
      insuer = passiveObject.insuer;
      passiveincome = passiveObject.passiveincome;
      startpayout = passiveObject.startpayout;
      endpayout = passiveObject.endpayout;

    }


    count = $('select.startpayout').length;
    console.log(count)
    html = `<div id="passivedcard" class="passivedcard row"  isPage2=` + isPage2 + `>

    <div class="col s6 pt-1 mt-1">
      <input type="text" class="input insuer" placeholder="Insurer" value="`+ insuer + `">
    </div>
    <div class="col s6 pt-1 mt-1">
      <input type="text" class="input passiveincome" placeholder="Passive Income" value="`+ passiveincome + `">
    </div>

    <div class="col s6 pt-1 mt-1">
    <div class="select-wrapper input startpayout">

      <select id="startselect`+ count + `" style="font-size:16px !important; color:#C8C8C8" class="input startpayout" placeholder="E.g. 500000">
        <option>Start of passive income payout</option>
        <option value='40'>40</option>
        <option value='41'>41</option>
                    <option value='42'>42</option>
                    <option value='43'>43</option>
                    <option value='44'>44</option>
                    <option value='45'>45</option>
                    <option value='46'>46</option>
                    <option value='47'>47</option>
                    <option value='48'>48</option>
                    <option value='49'>49</option>
                    <option value='50'>50</option>
                    <option value='51'>51</option>
                    <option value='52'>52</option>
                    <option value='53'>53</option>
                    <option value='54'>54</option>
                    <option value='55'>55</option>
                    <option value='56'>56</option>
                    <option value='57'>57</option>
                    <option value='58'>58</option>
                    <option value='59'>59</option>
                    <option value='60'>60</option>
                    <option value='61'>61</option>
                    <option value='62'>62</option>
                    <option value='63'>63</option>
                    <option value='64'>64</option>
                    <option value='65'>65</option>
                    <option value='66'>66</option>
                    <option value='67'>67</option>
                    <option value='68'>68</option>
                    <option value='69'>69</option>
                    <option value='70'>70</option>
                    <option value='71'>71</option>
                    <option value='72'>72</option>
                    <option value='73'>73</option>
                    <option value='74'>74</option>
                    <option value='75'>75</option>
                    <option value='76'>76</option>
                    <option value='77'>77</option>
                    <option value='78'>78</option>
                    <option value='79'>79</option>
                    <option value='80'>80</option>
                    <option value='81'>81</option> 
                    <option value='82'>82</option> 
                    <option value='83'>83</option> 
                    <option value='84'>84</option> 
                    <option value='85'>85</option> 
               
        
      </select>
      </div>
    </div>
    <div class="col s6 pt-1 mt-1">
    <div class="select-wrapper input endpayout">
      <select  id="endselect`+ count + `" style="font-size:16px !important; color:#C8C8C8" class="input endpayout" placeholder="E.g. 500000">
        <option>End of passive income payout</option>
        <option value='40'>40</option>
        <option value='41'>41</option>
        <option value='42'>42</option>
        <option value='43'>43</option>
        <option value='44'>44</option>
        <option value='45'>45</option>
        <option value='46'>46</option>
        <option value='47'>47</option>
        <option value='48'>48</option>
        <option value='49'>49</option>
        <option value='50'>50</option>
        <option value='51'>51</option>
        <option value='52'>52</option>
        <option value='53'>53</option>
        <option value='54'>54</option>
        <option value='55'>55</option>
        <option value='56'>56</option>
        <option value='57'>57</option>
        <option value='58'>58</option>
        <option value='59'>59</option>
        <option value='60'>60</option>
        <option value='61'>61</option>
        <option value='62'>62</option>
        <option value='63'>63</option>
        <option value='64'>64</option>
        <option value='65'>65</option>
        <option value='66'>66</option>
        <option value='67'>67</option>
        <option value='68'>68</option>
        <option value='69'>69</option>
        <option value='70'>70</option>
        <option value='71'>71</option>
        <option value='72'>72</option>
        <option value='73'>73</option>
        <option value='74'>74</option>
        <option value='75'>75</option>
        <option value='76'>76</option>
        <option value='77'>77</option>
        <option value='78'>78</option>
        <option value='79'>79</option>
        <option value='80'>80</option>
        <option value='81'>81</option> 
        <option value='82'>82</option> 
        <option value='83'>83</option> 
        <option value='84'>84</option> 
        <option value='85'>85</option> 
 

      </select>
    </div>
    </div>
  </div>`;

    $('#passiveincomedcard').append(html);
    $('#startselect' + count).material_select();
    $('#endselect' + count).material_select();
    if (startpayout != '') {

      $('#startselect' + count).find('option[value="' + startpayout + '"]').prop('selected', true);
      $("#startselect" + count).material_select();
    }

    if (endpayout != '') {
      $('#endselect' + count).find('option[value="' + endpayout + '"]').prop('selected', true);
      $("#endselect" + count).material_select();
    }

  } catch (e) {

  }
}
function addLumpsumRow(lumpsumObject, isPage2) {
  try {
    //let html = '<div class="row">' + $('#lumpsumdarcddemo').html() + '</div>';
    //$('#lumpsumdcard').append(html);
    // insuer
    // : 
    // ""
    // lumpsumd
    // : 
    // ""
    var insuer = '';
    var lumpsumd = '';
    var lumsumamt = '';
    if (lumpsumObject != null) {
      insuer = lumpsumObject.insuer;
      lumpsumd = lumpsumObject.lumpsumd;
      lumsumamt = lumpsumObject.ExpectedLumpsumat;

    }
    count = $('select.ExpectedLumpsumat').length;

    html = `<div class="row" id="lumpsumdarcddemo">'
            <div class="lumpsumdcard" isPage2=`+ isPage2 + `>
              <div class="col s6 pt-1 mt-1">
                <input type="text" class="input insuer" placeholder="Personal / Insurer" value="`+ insuer + `">
              </div>
              <div class="col s6 pt-1 mt-1">
                <input type="text" class="input lumpsumd" placeholder="Lumpsum"  value="`+ lumpsumd + `">
              </div>

              <div class="col s6 pt-1 mt-1">
                <div class="select-wrapper input ExpectedLumpsumat">
                  <select id="select`+ count + `" style="font-size:16px !important; color:#C8C8C8" class="input ExpectedLumpsumat initialized" placeholder="E.g. 500000">
                    <option>Expected Lumpsum</option>
                    <option value='40'>40</option>
                    <option value='41'>41</option>
                    <option value='42'>42</option>
                    <option value='43'>43</option>
                    <option value='44'>44</option>
                    <option value='45'>45</option>
                    <option value='46'>46</option>
                    <option value='47'>47</option>
                    <option value='48'>48</option>
                    <option value='49'>49</option>
                    <option value='50'>50</option>
                    <option value='51'>51</option>
                    <option value='52'>52</option>
                    <option value='53'>53</option>
                    <option value='54'>54</option>
                    <option value='55'>55</option>
                    <option value='56'>56</option>
                    <option value='57'>57</option>
                    <option value='58'>58</option>
                    <option value='59'>59</option>
                    <option value='60'>60</option>
                    <option value='61'>61</option>
                    <option value='62'>62</option>
                    <option value='63'>63</option>
                    <option value='64'>64</option>
                    <option value='65'>65</option>
                    <option value='66'>66</option>
                    <option value='67'>67</option>
                    <option value='68'>68</option>
                    <option value='69'>69</option>
                    <option value='70'>70</option>
                    <option value='71'>71</option>
                    <option value='72'>72</option>
                    <option value='73'>73</option>
                    <option value='74'>74</option>
                    <option value='75'>75</option>
                    <option value='76'>76</option>
                    <option value='77'>77</option>
                    <option value='78'>78</option>
                    <option value='79'>79</option>
                    <option value='80'>80</option>
                    <option value='81'>81</option> 
                    <option value='82'>82</option> 
                    <option value='83'>83</option> 
                    <option value='84'>84</option> 
                    <option value='85'>85</option> 
              
                  </select>
                </div>
              </div>
            </div>
          </div>`;
    console.log("here?? " + html)
    $('#lumpsumdcard').append(html);
    $('#select' + count).material_select();

    if (lumsumamt == '' && financialCalculator.intendedRetireAge && financialCalculator.intendedRetireAge != undefined && financialCalculator.intendedRetireAge != null) {
      lumsumamt = financialCalculator.intendedRetireAge

    }
    $('#select' + count).find('option[value="' + lumsumamt + '"]').prop('selected', true);
    $("#select" + count).material_select();


  } catch (e) {

  }
}

function processAfterCallForSave4524result(response, callback) {

  callback();
}
