
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var totaldcard_topimage2_collectioncontainer = 0;
$(document).ready(function () {
  showBottomMenu();
  $(".bodytabs").scrollLeft(500);
  $('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
    $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }
  var roleName = localStorage.getItem('roleName');
  if (roleName == "consultant") {

    $("#sg1907").hide()
  }
  var objParamsToken = {};

  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  objParamsToken.tokenKey = getParameterByName('tokenKey');
  objParamsToken.secretKey = getParameterByName('secretKey');

  var userRole = $('#userRole').val();
  var userID = $('#userID').val();
  var createrOfRecord = $('#createrOfRecord').val();
  var queryMode = getParameterByName('queryMode');
  var recordID = $.trim($('#recordID').val());
  var addSessionComments = [];
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#backbutton1', function (e) {
    try {
      var element = $(this);
      var parent = getParameterByName('parent');
      var nextPage = 'app_userhome';
      var activemenu = localStorage.getItem("activeMenu")
      if (activemenu == "Home") {
        var roleName = localStorage.getItem('roleName');
        if (roleName == "consultant") {
          nextPage = "app_consultantuserhome";

        }
        else {
          nextPage = "app_userhome";
        }


      }
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error)
    }
  })
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  getbannerImage();
  getmiddlebannerImage();
  getbottombannerImage();
  // $(document).on('click', '#myevents7', function (e) {
  //     try {
  //         var element = $(this);
  //         var nextPage = 'app_myupcomingeventslist';
  //         var queryParams = queryStringToJSON();
  //         queryParams["queryMode"] = "mylist";
  //         var recordID = $(this).attr("recordID");
  //         if (recordID) {
  //             queryParams["recordID"] = recordID;
  //         }
  //         var queryString = $.param(queryParams);
  //         queryString = queryString.replace(/\+/g, "%20");
  //         queryString = decodeURIComponent(queryString);
  //         window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
  //         return false;
  //     } catch (error) {
  //         console.log("Error in pageredirect workflow - myevents7", error)
  //     }
  // })
});//end of ready




$(document).on('click', '#myevents7', function (e) {
  try {
    var element = $(this);
    var nextPage = 'app_allmerchantdiscountslist';
    var queryParams = queryStringToJSON();
    queryParams["queryMode"] = "mylist";
    var recordID = $(this).attr("recordID");
    if (recordID) {
      queryParams["recordID"] = recordID;
    }
    var queryString = $.param(queryParams);
    queryString = queryString.replace(/\+/g, "%20");
    queryString = decodeURIComponent(queryString);
    window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
    return false;
  } catch (error) {
    console.log("Error in pageredirect workflow - myevents7", error)
  }
});


$(document).on('click', '#allevents8', function (e) {
  try {
    var element = $(this);
    var nextPage = 'app_alleventpromotionslist';
    var queryParams = queryStringToJSON();
    queryParams["queryMode"] = "mylist";
    var recordID = $(this).attr("recordID");
    if (recordID) {
      queryParams["recordID"] = recordID;
    }
    var queryString = $.param(queryParams);
    queryString = queryString.replace(/\+/g, "%20");
    queryString = decodeURIComponent(queryString);
    window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
    return false;
  } catch (error) {
    console.log("Error in pageredirect workflow - myevents7", error)
  }
});

$(document).on('click', '#financeevents7', function (e) {
  try {
    var element = $(this);
    var nextPage = 'app_allfinancialserviceslist';
    var queryParams = queryStringToJSON();
    queryParams["queryMode"] = "mylist";
    var recordID = $(this).attr("recordID");
    if (recordID) {
      queryParams["recordID"] = recordID;
    }
    var queryString = $.param(queryParams);
    queryString = queryString.replace(/\+/g, "%20");
    queryString = decodeURIComponent(queryString);
    window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
    return false;
  } catch (error) {
    console.log("Error in pageredirect workflow - myevents7", error)
  }
});

$(document).on('click', '#sg6017', function(e) {
        try{ 
            var element = $(this);
            var nextPage = 'app_customernotificationlisting'; 
            var queryParams = queryStringToJSON(); 
            queryParams["queryMode"] = "mylist"; 
            queryParams["applyFilter"]  = false;
            var recordID = $(this).attr("recordID"); 
            if(recordID){ 
                queryParams["recordID"] = recordID; 
            }
            queryParams.parent="app_allfinancialserviceslist";
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString; // + "&parent=app_allfinancialserviceslist"; 
            return false;  
    } catch(error){ 
        console.log("Error in pageredirect workflow - notifications27", error) 
    } 
})

function getbannerImage() {
  var paramsType = {};
  paramsType.tokenKey = getParameterByName("tokenKey");
  paramsType.secretKey = getParameterByName("secretKey");
  //getCountProcessBeforeCallbannerimageupload6(paramsType, function (processBeforeRes) {
  var ajaXCallURL = $.trim($("#ajaXCallURL").val());
  $.ajax({
    url: ajaXCallURL + "/milestone003/showslider_app_allfinancialserviceslist_Financialbanner5da73cac545050343288ce7alblbannerbannerimageupload",
    data: paramsType,
    type: "POST",
    success: function (response) {
      // localStorage.setItem("bannerimages", JSON.stringify(response));

      if (response.status == 0) {
        makeSlidesbannerimageupload6(response.data);
      } else {
        makeSlidesbannerimageupload6([]);
      }
    },
    error: function (xhr, status, error) { },
  });
  // });
}


function makeSlidesbannerimageupload6(data) {
  var slide = "";
  var htmlString = "";
  let title = '';
  let description = '';
  if (data && data.length == 1) {
    title = data[0].title || '';
    description = data[0].description || '';
    data = data[0].userphotoupload ? data[0].userphotoupload : [];
  }
  if (data && data.length > 0) {
    for (let index = 0; index < data.length; index++) {
      const element = data[index];
      var mediaID;
      if (element && element.userphotoupload && element.userphotoupload[0]) {
        mediaID = element.userphotoupload[0].mediaID;
      } else if (element && element.mediaID) {
        mediaID = element.mediaID;
      }
      // if (data[index] && data.length != 1) {
      //   title = data[index].title || '';
      //   description = data[index].description || '';
      // }
      slide += ' <div class="swiper-slide" href="#one!" >';
      slide += '    <div class="row  col s12" style="padding: 0px" !important;>';
      slide += '       <div id="image6_div" style="text-align: center;">';
      slide += '          <img  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + mediaID + '_compressed.png" style="width:100%; height:192px">';
      slide += "       </div>";
      slide += "    </div>";
      // slide += '    <div class="row  col s12" style="padding: 0px;font-size:21px;font-weight:bold;color:#b18d4f; text-align:center !important;font-size: 18px !important; line-height: 22px !important;font-weight : bold !important;font-family: \'Roboto\', sans-serif !important; color : #af935d !important;"> ' + title + '';
      // slide += '    </div>';
      // slide += '    <div class="row  col s12" style="padding: 0px;font-size:14px;font-weight:bold;color:#000000a8; text-align:center !important;font-size: 16px !important; line-height: 20px !important;font-weight : bold !important;font-family: \'Roboto\', sans-serif !important; color : #252525 !important;"> ' + description + '';
      // slide += '    </div>';
      slide += "        </div>";
    }
    if (slide) {
      $("#bannerimageupload6").html(slide);
    }
    var swiper = new Swiper(".swiper-container", {
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
      watchOverflow: true,
      pagination: {
        el: ".swiper-pagination",
      },
    });
    $(".dynamic-slider-view").removeClass("shimmer");
  }
}


function getbottombannerImage() {
  var paramsType = {};
  paramsType.tokenKey = getParameterByName('tokenKey');
  paramsType.secretKey = getParameterByName('secretKey');
  paramsType.bannershowtype = 'Financial Planning';
  //getCountProcessBeforeCallbannerbottomimageupload6(paramsType, function (processBeforeRes) {
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  $.ajax({
    url: ajaXCallURL + '/milestone003/showslider_app_allfinancialserviceslist_Financialbanner5da73cac545050343288ce7alblbannerbannerimageupload',
    data: paramsType,
    type: 'POST',
    success: function (response) {
      // localStorage.setItem("bannerimages", JSON.stringify(response));

      if (response.status == 0) {
        makeSlidesbannerbottomimageupload6(response.data);
      } else {
        makeSlidesbannerbottomimageupload6([]);
      }
    },
    error: function (xhr, status, error) { },
  });
  // });
}

function makeSlidesbannerbottomimageupload6(data) {
  var slide = '';
  var htmlString = '';
  let title = '';
  let description = '';
  if (data && data.length == 1) {
    title = data[0].title || '';
    description = data[0].description || '';
    data = data[0].userphotoupload ? data[0].userphotoupload : [];
  }
  if (data && data.length > 0) {
    for (let index = 0; index < data.length; index++) {
      const element = data[index];
      var mediaID;
      if (element && element.userphotoupload && element.userphotoupload[0]) {
        mediaID = element.userphotoupload[0].mediaID;
      } else if (element && element.mediaID) {
        mediaID = element.mediaID;
      }
      if (data[index] && data.length != 1) {
        title = data[index].title || '';
        description = data[index].description || '';
      }
      slide += ' <div class="swiper-slide" href="#one!" >';
      slide += '    <div class="row  col s12" style="padding: 0px" !important;>';
      slide += '       <div id="image6_div" style="text-align: center;">';
      slide += '          <img  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + mediaID + '_compressed.png" style="width:100%; height:150px">';
      slide += '       </div>';
      slide += '    </div>';
      slide += '    <div class="row  col s12" style="padding: 0px;font-size:21px;font-weight:bold;font-size: 18px !important; line-height: 22px !important;font-weight : bold !important;font-family: \'Roboto\', sans-serif !important;margin-top:10px !important; "> ' + title + '';
      slide += '    </div>';
      slide += '    <div class="row  col s12" style="padding: 0px;font-size: 16px !important; line-height: 20px !important;font-family: \'Roboto\', sans-serif !important; color: #252525 !important;"> ' + description + '';
      slide += '    </div>';
      slide += '        </div>';
    }
    if (slide) {
      $('#bannerbottomimageupload6').html(slide);
    }
    var swiper = new Swiper('.swiper-container .swiperbottom', {
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
      watchOverflow: true,
      pagination: {
        el: '.swiper-paginationbottom',
      },
    });
    $('.dynamic-slider-view').removeClass('shimmer');
  }
}


function getmiddlebannerImage() {
  var paramsType = {};
  paramsType.tokenKey = getParameterByName('tokenKey');
  paramsType.secretKey = getParameterByName('secretKey');
  paramsType.bannershowtype = 'Get In Touch';
  //getCountProcessBeforeCallbannermiddleimageupload6(paramsType, function (processBeforeRes) {
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  $.ajax({
    url: ajaXCallURL + '/milestone003/showslider_app_allfinancialserviceslist_Financialbanner5da73cac545050343288ce7alblbannerbannerimageupload',
    data: paramsType,
    type: 'POST',
    success: function (response) {
      // localStorage.setItem("bannerimages", JSON.stringify(response));

      if (response.status == 0) {
        makeSlidesbannermiddleimageupload6(response.data);
      } else {
        makeSlidesbannermiddleimageupload6([]);
      }
    },
    error: function (xhr, status, error) { },
  });
  // });
}

function makeSlidesbannermiddleimageupload6(data) {
  var slide = '';
  var htmlString = '';
  let title = '';
  let description = '';
  if (data && data.length == 1) {
    title = data[0].title || '';
    description = data[0].description || '';
    data = data[0].userphotoupload ? data[0].userphotoupload : [];
  }
  if (data && data.length > 0) {
    for (let index = 0; index < data.length; index++) {
      const element = data[index];
      var mediaID;
      if (element && element.userphotoupload && element.userphotoupload[0]) {
        mediaID = element.userphotoupload[0].mediaID;
      } else if (element && element.mediaID) {
        mediaID = element.mediaID;
      }
      if (data[index] && data.length != 1) {
        title = data[index].title || '';
        description = data[index].description || '';
      }
      slide += ' <div class="swiper-slide" href="#one!" >';
      slide += '    <div class="row  col s12" style="padding: 0px" !important;>';
      slide += '       <div id="image6_div" style="text-align: center;">';
      slide += '          <img  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + mediaID + '_compressed.png" style="width:100%; height:150px">';
      slide += '       </div>';
      slide += '    </div>';
      slide += '    <div class="row  col s12" style="width:auto !important;    position: absolute;right: 25px;top: 100px;"> <img recordid="c79eca6544feb547f994edec" id="merchantimage12" class=" clssg3017image__discount merchantimage12" style="height: 35px;width: 35px !important;" onerror="this.src=" https:="" appscdn-us.hokuapps.com="" card.png"="" src="FinancialServices-GetInTouch-White.svg"></div>';
      slide += '    <div class="row  col s12" style="padding: 0px;font-size:21px;font-weight:bold;font-size: 18px !important; line-height: 22px !important;font-weight : bold !important;font-family: \'Roboto\', sans-serif !important;margin-top:10px !important; "> ' + title + '';
      slide += '    </div>';
      slide += '    <div class="row  col s12" style="padding: 0px;font-size: 16px !important; line-height: 20px !important;font-family: \'Roboto\', sans-serif !important; color: #252525 !important;"> ' + description + '';
      slide += '    </div>';
      slide += '        </div>';
    }
    if (slide) {
      $('#bannermiddleimageupload6').html(slide);
    }
    var swiper = new Swiper('.swiper-container .swipermiddle', {
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
      watchOverflow: true,
      pagination: {
        el: '.swiper-paginationmiddle',
      },
    });
    $('.dynamic-slider-view').removeClass('shimmer');
  }
}



$(document).on("click", "#viewall9", function (e) {
  try {
    var element = $(this);
    var parent = "app_userhome";
    var nextPage = "app_allfinancialservicessteponelist";
    var queryParams = queryStringToJSON();
    queryParams["queryMode"] = "mylist";
    var recordID = $(this).attr("recordID");
    if (recordID) {
      queryParams["recordID"] = recordID;
    }
    var queryString = $.param(queryParams);
    queryString = queryString.replace(/\+/g, "%20");
    queryString = decodeURIComponent(queryString);
    window.location.href = nextPage + "_5da73cac545050343288ce7a.html?" + queryString + "&parent=" + parent;
    return false;
  } catch (error) {
    console.log("Error in pageredirect workflow - viewall9", error);
  }
});
function showBottomMenu() {
  //    var  appUser = JSON.parse(localStorage.getItem("appUser"));
  var notificationCount = 0;
  //    if(appUser.notificationunreadcount)
  //    {
  //        notificationCount = appUser.notificationunreadcount
  //    }
  //    $("#notificationcount5").html(notificationCount)
  var appointmentunreadcount = 0;
  //    if(appUser.appointmentunreadcount)
  //    {
  //        appointmentunreadcount = appUser.appointmentunreadcount
  //    }
  var menuObj = localStorage.getItem("objGetUserDetailsWithmenu");
  if (menuObj) {
    menuObj = JSON.parse(menuObj);
    if (menuObj.data && menuObj.data.roleName) {
      var roleName = menuObj.data.roleName;
    }
  }
  try {
    var bottommenu = "";
    bottommenu += '<div class="mobilebottommenu">';
    bottommenu += '    <div class="row">';
    bottommenu +=
      '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Home" fileName="app_userhome_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_home.svg"><span>Home</span></a></div>';
    bottommenu +=
      '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Appointment" fileName="app_alleventpromotionslist_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_calendaractive.svg"><span  style ="color :#af935d !important;">Discover</span></a></a><div id="appointmentCount" class="chatunreadcount active hide">' +
      appointmentunreadcount +
      "</div></div>";
    bottommenu +=
      '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Scan" fileName="app_sacaner_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_barcode.svg" class="scannerbottommenu"><span>Scan</span></a></div>';
    bottommenu +=
      '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Chat" fileName="undefined_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_chat.svg"><span>Messages</span></a><div id="chatCount" style="display:none !important"  class="chatunreadcount active">0</div></div>';
    bottommenu +=
      '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="More" fileName="app_custmoreinfodetails_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_more.svg"><span>Account</span></a></div>';
    bottommenu += "    </div>";
    bottommenu += "</div>";
    $("#bottommenu35").html(bottommenu);
  } catch (err) {
    // console.log('Error in showBottomMenu', err);
  }
}
