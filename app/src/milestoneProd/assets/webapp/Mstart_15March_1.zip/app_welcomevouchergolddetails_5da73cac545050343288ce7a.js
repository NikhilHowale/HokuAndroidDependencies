
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"))
    }

    var objParamsToken = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsToken.tokenKey = getParameterByName('tokenKey');
    objParamsToken.secretKey = getParameterByName('secretKey');

    var userRole = $('#userRole').val();
    var userID = $('#userID').val();
    var createrOfRecord = $('#createrOfRecord').val();
    var queryMode = getParameterByName('queryMode');
    var recordID = $.trim($('#recordID').val());
    var addSessionComments = [];
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;

    $(document).on('click', '#redeem29', function () {
        var paramsEdit = {};
        paramsEdit.tokenKey = getParameterByName('tokenKey');
        paramsEdit.secretKey = getParameterByName('secretKey');
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());;
        paramsEdit.recordID = localStorage.getItem('userID');
        paramsEdit.isredeemdisplay = 1;
        paramsEdit.isupdateonly = 1;

        $.ajax({
            url: ajaXCallURL + '/milestone003/updateAjaxusermanagementusermanagementlistweb',
            data: paramsEdit,
            type: 'POST',
            jsonpCallback: 'callback',
            success: function (response) {
                if (response.status != undefined && response.status == 0) {

                    shareAppData('You can redeem this gift once consultant has been assigned to you.', 'toast');
                    // $('#display_loading1').addClass('hideme');
                    // $('#redeem29').removeProp('disabled');
                    // return false;

                    var tokenKey = getParameterByName('tokenKey');
                    var secretKey = getParameterByName('secretKey');
                    var queryMode = getParameterByName('queryMode');
                    queryMode = 'mylist';
                    window.location.href = 'app_referafrienddetails_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                    return false;

                } else {
                    return false;
                }
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            },
        });
    });

    // $(document).on('click', '#redeem29', function () {
    //     var objParams = {};

    //     objParams.recordID = localStorage.getItem('userID');

    //     $('#redeem29').prop('disabled', true);
    //     $('#display_loading1').removeClass('hideme');

    //     objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxredeemedvouchers9607redeemapp_voucherdetails';

    //     objParams.isredeemdisplay = 1;
    //     objParams.queryMode = 'update';
    //     var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    //     objParams.tokenKey = getParameterByName('tokenKey');
    //     objParams.secretKey = getParameterByName('secretKey');
    //     objParams.ajaXCallURL = ajaXCallURL;

    //     objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    //     objParams.organizationID = $("#organizationID").val();;
    //     objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    //     objParams.organizationID = $("#organizationID").val();;
    //     processBeforeCallForSave9607redeem(objParams, {}, function (processBeforeRes) {
    //         $.ajax({
    //             url: objParams.callUrl,
    //             data: objParams,
    //             type: 'POST',
    //             success: function (response) {
    //                 if (response.status == 0) {
    //                     $('#display_loading1').addClass('hideme');
    //                     response.nextPage = 'app_vouchersuccess'
    //                     processAfterCallForSave9607redeem(response, function (processAfterRes) {

    //                         var tokenKey = getParameterByName('tokenKey');
    //                         var secretKey = getParameterByName('secretKey');
    //                         var queryMode = getParameterByName('queryMode');
    //                         var recordID = getParameterByName('recordID');
    //                         queryMode = 'mylist';
    //                         window.location.href = 'app_userhome_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey;

    //                         return false;
    //                     }); // End of After Process
    //                 } else {
    //                     $('#display_loading1').addClass('hideme');
    //                     $('#2656d_error').html(response.error);
    //                     $('#2656d_error').show();
    //                 }
    //                 $('#redeem29').removeProp('disabled');
    //             },
    //             error: function (xhr, status, error) {
    //                 $('#display_loading1').addClass('hideme');
    //                 $('#redeem29').removeProp('disabled');
    //             },
    //         });
    //         return false;
    //     }); // End of Before Process
    // });//end of Event Redeem_is_click 
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('click', '#backbutton1', function () {
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = getParameterByName('queryMode');
        var recordID = getParameterByName('recordID');
        queryMode = 'mylist';
        window.location.href = 'app_allvoucherlisting_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey
        return false;
    });//end of Event backbutton_is_click 

    $(document).on('click', '#next29', function () {

        var paramsEdit = {};
        paramsEdit.tokenKey = getParameterByName('tokenKey');
        paramsEdit.secretKey = getParameterByName('secretKey');
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());;
        paramsEdit.recordID = localStorage.getItem('userID');
        paramsEdit.isredeemdisplay = 1;
        paramsEdit.isupdateonly = 1;

        $.ajax({
            url: ajaXCallURL + '/milestone003/updateAjaxusermanagementusermanagementlistweb',
            data: paramsEdit,
            type: 'POST',
            jsonpCallback: 'callback',
            success: function (response) {
                if (response.status != undefined && response.status == 0) {

                    // shareAppData('You have already requested  for voucher.', 'toast');
                    // $('#display_loading1').addClass('hideme');
                    // $('#redeem29').removeProp('disabled');
                    // return false;

                    var tokenKey = getParameterByName('tokenKey');
                    var secretKey = getParameterByName('secretKey');
                    var queryMode = getParameterByName('queryMode');
                    queryMode = 'mylist';
                    window.location.href = 'app_userhome_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                    return false;

                } else {
                    return false;
                }
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            },
        });
    });//end of Event backbutton_is_click

    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};
    var paramsEdit = {};
    paramsEdit.tokenKey = getParameterByName('tokenKey');
    paramsEdit.secretKey = getParameterByName('secretKey')
    getRecordByIDProcessBeforeCall543526(paramsEdit, function (processBeforeRes) {
        $.ajax({
            url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_voucherdetails_Bazaar5da73cac545050343288ce7a',
            data: paramsEdit,
            type: 'POST',
            jsonpCallback: 'callback',
            success: function (response) {
                getRecordByIDProcessAfterCall543526(response, function (processBeforeRes) {
                    if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                        var objParamsList = {};
                        var queryMode = $('#queryMode').val();
                        objParamsList.queryMode = queryMode;;
                        var tokenKey = $('#tokenKey').val();;
                        objParamsList.tokenKey = tokenKey;;
                        $('#referralAmount33').html(response.recordDetails.referralAmount);
                        $('#ordersnumber30_value').html(response.recordDetails.ordersnumber);
                        $('#bazaarid31').html(response.recordDetails.bazaarid);
                        if (!$('#backbutton1').html()) {
                            $('#backbutton1').append(response.recordDetails.undefined);
                        }
                        $('#consultantid32').html(response.recordDetails.consultantid);
                        if (!$('#expireson17').html()) {
                            $('#expireson17').append(response.recordDetails.undefined);
                        }
                        // getrecordbycustomquery - Stage - 111111111111
                        if (response.recordDetails['imageupload'] && response.recordDetails['imageupload'].length > 0) {
                            if (response.recordDetails['imageupload'][0].displayType = 'html') {
                                var eleParent = $('#imageupload6').parent();
                                for (var key in response.recordDetails['imageupload']) {
                                    var objImage = response.recordDetails['imageupload'][key];
                                    if (response.recordDetails['imageupload'][key].name == 'Audio') {
                                        var token = $('#tokenKey').val();
                                        if (token && token != '') {
                                            token = $('#tokenKey').val();
                                        } else {
                                            token = getParameterByName('tokenKey');
                                        }
                                        var mediaIDa = response.recordDetails['imageupload'][0].mediaID
                                        var filenamea = response.recordDetails['imageupload'][0].fileName
                                        var CDN_PATH2 = 'https://devfiles.hokuapps.com/downloadOriginal?f=' + mediaIDa + '&fn=' + filenamea + '&t=' + token
                                        var url = CDN_PATH2
                                    } else {
                                        var filetodisplay = getuploadedfilepreview(objImage.fileNm);
                                        if (filetodisplay && filetodisplay != objImage.fileNm) {
                                            var url = filetodisplay;
                                        } else {
                                            var url = CDN_PATH + objImage.mediaID + '_compressed.png';
                                        }
                                    }
                                    if (response.recordDetails['imageupload'][key].name == 'Audio') {
                                        var html = '';
                                        html += '<div class="col s12" style="float: right;">'
                                        html += '<audio class="" src="' + url + '" controls></audio>'
                                        html += '</div>'
                                    } else {
                                        var html = '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + url + '" />';
                                    }
                                    if (!key || key == '0') {
                                        eleParent.html(html);
                                    } else {
                                        eleParent.append(html);
                                    }
                                }
                            } else {
                                if (response.recordDetails['imageupload'][key].name == 'Audio') {
                                    var url = CDN_PATH + response.recordDetails['imageupload'][0].mediaID;
                                } else {
                                    var url = CDN_PATH + response.recordDetails['imageupload'][0].mediaID + '_compressed.png';
                                }
                                $('#imageupload6').attr("src", url);
                            }
                        }
                        response.recordDetails['createdOn_preserved'] = response.recordDetails['createdOn'];
                        response.recordDetails['createdOn'] = response.recordDetails['createdOn'] ? moment(new Date(response.recordDetails['createdOn'])).format('DD MMMM YYYY hh:mm A') : '';
                        if (!$('#createdOn8').html()) {
                            $('#createdOn8').append(response.recordDetails.createdOn);
                        }
                        response.recordDetails['createdOn'] = response.recordDetails['createdOn_preserved'];
                        response.recordDetails['expirationdate_preserved'] = response.recordDetails['expirationdate'];
                        response.recordDetails['expirationdate'] = response.recordDetails['expirationdate'] ? moment(new Date(response.recordDetails['expirationdate'])).format('DD MMM YYYY') : '';
                        if (!$('#expirationdate18').html()) {
                            $('#expirationdate18').append(response.recordDetails.expirationdate);
                        }
                        response.recordDetails['expirationdate'] = response.recordDetails['expirationdate_preserved'];
                        if (!$('#name10').html()) {
                            $('#name10').append(response.recordDetails.name);
                        }
                        if (!$('#outlets21').html()) {
                            if (!response.recordDetails.outlets) {
                                response.recordDetails.outlets = '0';
                            }
                            $('#outlets21').append(response.recordDetails.outlets);
                        }
                        $('#redeemstarqty15').html(response.recordDetails.redeemstarqty);
                        if (!$('#status9').html()) {
                            $('#status9').append(response.recordDetails.status);
                        }
                        if (!$('#termsandconditions28').html()) {
                            $('#termsandconditions28').append(response.recordDetails.termsandconditions);
                        }
                        if (!$('#validity24').html()) {
                            $('#validity24').append(response.recordDetails.validity);
                        }
                        if (!$('#outlets20').html()) {
                            $('#outlets20').append(response.recordDetails.undefined);
                        }
                        if (!$('#termsconditions26').html()) {
                            $('#termsconditions26').append(response.recordDetails.undefined);
                        }
                        if (!$('#validity23').html()) {
                            $('#validity23').append(response.recordDetails.undefined);
                        }
                        if (!$('#voucherdetails12').html()) {
                            $('#voucherdetails12').append(response.recordDetails.undefined);
                        }
                        if (!$('#voucherdetails2').html()) {
                            $('#voucherdetails2').append(response.recordDetails.undefined);
                        }
                        if (!$('#voucherpoints14').html()) {
                            $('#voucherpoints14').append(response.recordDetails.undefined);
                        }

                        Materialize.updateTextFields();
                        $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

                    }
                }); // end of getRecord By ID
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            },
        });
    }); // end of getRecord By ID

    var paramsEdit = {};
    paramsEdit.tokenKey = getParameterByName('tokenKey');
    paramsEdit.secretKey = getParameterByName('secretKey')
    getRecordByIDProcessBeforeCallbackbutton1(paramsEdit, function (processBeforeRes) {
        $.ajax({
            url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_voucherdetails_Usermanagement5da73cac545050343288ce7a',
            data: paramsEdit,
            type: 'POST',
            jsonpCallback: 'callback',
            success: function (response) {
                getRecordByIDProcessAfterCallbackbutton1(response, function (processBeforeRes) {
                    if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                        var objParamsList = {};
                        var queryMode = $('#queryMode').val();
                        objParamsList.queryMode = queryMode;;
                        var tokenKey = $('#tokenKey').val();;
                        objParamsList.tokenKey = tokenKey;;
                        $('#referralAmount33').html(response.recordDetails.referralAmount);
                        $('#ordersnumber30_value').html(response.recordDetails.ordersnumber);
                        $('#bazaarid31').html(response.recordDetails.bazaarid);
                        if (!$('#backbutton1').html()) {
                            $('#backbutton1').append(response.recordDetails.undefined);
                        }
                        $('#consultantid32').html(response.recordDetails.consultantid);
                        if (!$('#expireson17').html()) {
                            $('#expireson17').append(response.recordDetails.undefined);
                        }
                        // getrecordbycustomquery - Stage - 111111111111
                        if (response.recordDetails['imageupload'] && response.recordDetails['imageupload'].length > 0) {
                            if (response.recordDetails['imageupload'][0].displayType = 'html') {
                                var eleParent = $('#imageupload6').parent();
                                for (var key in response.recordDetails['imageupload']) {
                                    var objImage = response.recordDetails['imageupload'][key];
                                    if (response.recordDetails['imageupload'][key].name == 'Audio') {
                                        var token = $('#tokenKey').val();
                                        if (token && token != '') {
                                            token = $('#tokenKey').val();
                                        } else {
                                            token = getParameterByName('tokenKey');
                                        }
                                        var mediaIDa = response.recordDetails['imageupload'][0].mediaID
                                        var filenamea = response.recordDetails['imageupload'][0].fileName
                                        var CDN_PATH2 = 'https://devfiles.hokuapps.com/downloadOriginal?f=' + mediaIDa + '&fn=' + filenamea + '&t=' + token
                                        var url = CDN_PATH2
                                    } else {
                                        var filetodisplay = getuploadedfilepreview(objImage.fileNm);
                                        if (filetodisplay && filetodisplay != objImage.fileNm) {
                                            var url = filetodisplay;
                                        } else {
                                            var url = CDN_PATH + objImage.mediaID + '_compressed.png';
                                        }
                                    }
                                    if (response.recordDetails['imageupload'][key].name == 'Audio') {
                                        var html = '';
                                        html += '<div class="col s12" style="float: right;">'
                                        html += '<audio class="" src="' + url + '" controls></audio>'
                                        html += '</div>'
                                    } else {
                                        var html = '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + url + '" />';
                                    }
                                    if (!key || key == '0') {
                                        eleParent.html(html);
                                    } else {
                                        eleParent.append(html);
                                    }
                                }
                            } else {
                                if (response.recordDetails['imageupload'][key].name == 'Audio') {
                                    var url = CDN_PATH + response.recordDetails['imageupload'][0].mediaID;
                                } else {
                                    var url = CDN_PATH + response.recordDetails['imageupload'][0].mediaID + '_compressed.png';
                                }
                                $('#imageupload6').attr("src", url);
                            }
                        }
                        response.recordDetails['createdOn_preserved'] = response.recordDetails['createdOn'];
                        response.recordDetails['createdOn'] = response.recordDetails['createdOn'] ? moment(new Date(response.recordDetails['createdOn'])).format('DD MMMM YYYY hh:mm A') : '';
                        if (!$('#createdOn8').html()) {
                            $('#createdOn8').append(response.recordDetails.createdOn);
                        }
                        response.recordDetails['createdOn'] = response.recordDetails['createdOn_preserved'];
                        response.recordDetails['expirationdate_preserved'] = response.recordDetails['expirationdate'];
                        response.recordDetails['expirationdate'] = response.recordDetails['expirationdate'] ? moment(new Date(response.recordDetails['expirationdate'])).format('DD MMM YYYY') : '';
                        if (!$('#expirationdate18').html()) {
                            $('#expirationdate18').append(response.recordDetails.expirationdate);
                        }
                        response.recordDetails['expirationdate'] = response.recordDetails['expirationdate_preserved'];
                        if (!$('#name10').html()) {
                            $('#name10').append(response.recordDetails.name);
                        }
                        if (!$('#outlets21').html()) {
                            if (!response.recordDetails.outlets) {
                                response.recordDetails.outlets = '0';
                            }
                            $('#outlets21').append(response.recordDetails.outlets);
                        }
                        $('#redeemstarqty15').html(response.recordDetails.redeemstarqty);
                        if (!$('#status9').html()) {
                            $('#status9').append(response.recordDetails.status);
                        }
                        if (!$('#termsandconditions28').html()) {
                            $('#termsandconditions28').append(response.recordDetails.termsandconditions);
                        }
                        if (!$('#validity24').html()) {
                            $('#validity24').append(response.recordDetails.validity);
                        }
                        if (!$('#outlets20').html()) {
                            $('#outlets20').append(response.recordDetails.undefined);
                        }
                        if (!$('#termsconditions26').html()) {
                            $('#termsconditions26').append(response.recordDetails.undefined);
                        }
                        if (!$('#validity23').html()) {
                            $('#validity23').append(response.recordDetails.undefined);
                        }
                        if (!$('#voucherdetails12').html()) {
                            $('#voucherdetails12').append(response.recordDetails.undefined);
                        }
                        if (!$('#voucherdetails2').html()) {
                            $('#voucherdetails2').append(response.recordDetails.undefined);
                        }
                        if (!$('#voucherpoints14').html()) {
                            $('#voucherpoints14').append(response.recordDetails.undefined);
                        }

                        Materialize.updateTextFields();
                        $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

                    }
                }); // end of getRecord By ID
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            },
        });
    }); // end of getRecord By ID

    var paramsEdit = {};
    paramsEdit.tokenKey = getParameterByName('tokenKey');
    paramsEdit.secretKey = getParameterByName('secretKey')
    if (getParameterByName('bazaarid') && getParameterByName('bazaarid') != null && getParameterByName('bazaarid') != '') {
        paramsEdit.bazaarid = getParameterByName('bazaarid');
    }
    getRecordByIDProcessBeforeCallgroup13row7(paramsEdit, function (processBeforeRes) {
        $.ajax({
            url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_voucherdetails_Redeemedvouchers5da73cac545050343288ce7a',
            data: paramsEdit,
            type: 'POST',
            jsonpCallback: 'callback',
            success: function (response) {
                getRecordByIDProcessAfterCallgroup13row7(response, function (processBeforeRes) {
                    if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                        var objParamsList = {};
                        var queryMode = $('#queryMode').val();
                        objParamsList.queryMode = queryMode;;
                        var tokenKey = $('#tokenKey').val();;
                        objParamsList.tokenKey = tokenKey;;
                        $('#referralAmount33').html(response.recordDetails.referralAmount);
                        $('#ordersnumber30_value').html(response.recordDetails.ordersnumber);
                        $('#bazaarid31').html(response.recordDetails.bazaarid);
                        if (!$('#backbutton1').html()) {
                            $('#backbutton1').append(response.recordDetails.undefined);
                        }
                        $('#consultantid32').html(response.recordDetails.consultantid);
                        if (!$('#expireson17').html()) {
                            $('#expireson17').append(response.recordDetails.undefined);
                        }
                        // getrecordbycustomquery - Stage - 111111111111
                        if (response.recordDetails['imageupload'] && response.recordDetails['imageupload'].length > 0) {
                            if (response.recordDetails['imageupload'][0].displayType = 'html') {
                                var eleParent = $('#imageupload6').parent();
                                for (var key in response.recordDetails['imageupload']) {
                                    var objImage = response.recordDetails['imageupload'][key];
                                    if (response.recordDetails['imageupload'][key].name == 'Audio') {
                                        var token = $('#tokenKey').val();
                                        if (token && token != '') {
                                            token = $('#tokenKey').val();
                                        } else {
                                            token = getParameterByName('tokenKey');
                                        }
                                        var mediaIDa = response.recordDetails['imageupload'][0].mediaID
                                        var filenamea = response.recordDetails['imageupload'][0].fileName
                                        var CDN_PATH2 = 'https://devfiles.hokuapps.com/downloadOriginal?f=' + mediaIDa + '&fn=' + filenamea + '&t=' + token
                                        var url = CDN_PATH2
                                    } else {
                                        var filetodisplay = getuploadedfilepreview(objImage.fileNm);
                                        if (filetodisplay && filetodisplay != objImage.fileNm) {
                                            var url = filetodisplay;
                                        } else {
                                            var url = CDN_PATH + objImage.mediaID + '_compressed.png';
                                        }
                                    }
                                    if (response.recordDetails['imageupload'][key].name == 'Audio') {
                                        var html = '';
                                        html += '<div class="col s12" style="float: right;">'
                                        html += '<audio class="" src="' + url + '" controls></audio>'
                                        html += '</div>'
                                    } else {
                                        var html = '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + url + '" />';
                                    }
                                    if (!key || key == '0') {
                                        eleParent.html(html);
                                    } else {
                                        eleParent.append(html);
                                    }
                                }
                            } else {
                                if (response.recordDetails['imageupload'][key].name == 'Audio') {
                                    var url = CDN_PATH + response.recordDetails['imageupload'][0].mediaID;
                                } else {
                                    var url = CDN_PATH + response.recordDetails['imageupload'][0].mediaID + '_compressed.png';
                                }
                                $('#imageupload6').attr("src", url);
                            }
                        }
                        response.recordDetails['createdOn_preserved'] = response.recordDetails['createdOn'];
                        response.recordDetails['createdOn'] = response.recordDetails['createdOn'] ? moment(new Date(response.recordDetails['createdOn'])).format('DD MMMM YYYY hh:mm A') : '';
                        if (!$('#createdOn8').html()) {
                            $('#createdOn8').append(response.recordDetails.createdOn);
                        }
                        response.recordDetails['createdOn'] = response.recordDetails['createdOn_preserved'];
                        response.recordDetails['expirationdate_preserved'] = response.recordDetails['expirationdate'];
                        response.recordDetails['expirationdate'] = response.recordDetails['expirationdate'] ? moment(new Date(response.recordDetails['expirationdate'])).format('DD MMM YYYY') : '';
                        if (!$('#expirationdate18').html()) {
                            $('#expirationdate18').append(response.recordDetails.expirationdate);
                        }
                        response.recordDetails['expirationdate'] = response.recordDetails['expirationdate_preserved'];
                        if (!$('#name10').html()) {
                            $('#name10').append(response.recordDetails.name);
                        }
                        if (!$('#outlets21').html()) {
                            if (!response.recordDetails.outlets) {
                                response.recordDetails.outlets = '0';
                            }
                            $('#outlets21').append(response.recordDetails.outlets);
                        }
                        $('#redeemstarqty15').html(response.recordDetails.redeemstarqty);
                        if (!$('#status9').html()) {
                            $('#status9').append(response.recordDetails.status);
                        }
                        if (!$('#termsandconditions28').html()) {
                            $('#termsandconditions28').append(response.recordDetails.termsandconditions);
                        }
                        if (!$('#validity24').html()) {
                            $('#validity24').append(response.recordDetails.validity);
                        }
                        if (!$('#outlets20').html()) {
                            $('#outlets20').append(response.recordDetails.undefined);
                        }
                        if (!$('#termsconditions26').html()) {
                            $('#termsconditions26').append(response.recordDetails.undefined);
                        }
                        if (!$('#validity23').html()) {
                            $('#validity23').append(response.recordDetails.undefined);
                        }
                        if (!$('#voucherdetails12').html()) {
                            $('#voucherdetails12').append(response.recordDetails.undefined);
                        }
                        if (!$('#voucherdetails2').html()) {
                            $('#voucherdetails2').append(response.recordDetails.undefined);
                        }
                        if (!$('#voucherpoints14').html()) {
                            $('#voucherpoints14').append(response.recordDetails.undefined);
                        }

                        Materialize.updateTextFields();
                        $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

                    }
                }); // end of getRecord By ID
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            },
        });
    }); // end of getRecord By ID

});//end of ready
function getParams(url) {
    var urlParams = {};
    url.replace(
        new RegExp("([^?=&]+)(=([^&]*))?", "g"),
        function ($0, $1, $2, $3) {
            if ($3 && $3 != 'undefined') urlParams[$1] = $3;
        }
    );
    return urlParams;
}
function processBeforeCallForSave9607redeem(objParams, response, callback) {


    objParams.type = 'merchantstampcard';
    objParams.status = 'Requested';
    objParams.bazaarid = getParameterByName('bazaarid');

    var referralAmount = localStorage.getItem('referralAmount');
    var redeemedstampqty = $('[id^="redeemstarqty"]').html();
    var appUser = localStorage.getItem("appUser");
    if (appUser && appUser !== '') {
        appUser = JSON.parse(appUser);
        if (appUser && appUser.consultantid) {
            objParams.consultantid = appUser.consultantid;
        } else {
            $('#display_loading1').addClass('hideme');
            $('#redeem29').removeProp('disabled');
            shareAppData('Consultant not assgined to you.', 'toast');
            return false;
        }
    } else {
        $('#display_loading1').addClass('hideme');
        $('#redeem29').removeProp('disabled');
        shareAppData('Consultant not assgined to you.', 'toast');
        return false;
    }
    if (redeemedstampqty != '' && referralAmount != '' && referralAmount != null) {
        objParams.redeemstarqty = redeemedstampqty;
        redeemedstampqty = parseInt(redeemedstampqty);
        referralAmount = parseInt(referralAmount);
        if (referralAmount >= redeemedstampqty) {
            objParams.redeemedstampqty = redeemedstampqty;
            var paramsEdit = {};
            paramsEdit.tokenKey = getParameterByName('tokenKey');
            paramsEdit.secretKey = getParameterByName('secretKey');
            var ajaXCallURL = $.trim($('#ajaXCallURL').val());;
            paramsEdit.todaydate = new Date();
            paramsEdit.bazaarid = getParameterByName('bazaarid');
            $.ajax({
                url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_voucherdetails_Redeemedvouchers5da73cac545050343288ce7a',
                data: paramsEdit,
                type: 'POST',
                jsonpCallback: 'callback',
                success: function (response) {
                    if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {

                        shareAppData('You have already requested  for voucher.', 'toast');
                        $('#display_loading1').addClass('hideme');
                        $('#redeem29').removeProp('disabled');
                        return false;
                    } else {
                        callback();
                    }
                },
                error: function (xhr, status, error) {
                    handleError(xhr, status, error);
                },
            });
        } else {
            $('#display_loading1').addClass('hideme');
            $('#redeem29').removeProp('disabled');
            shareAppData('You dont have  sufficient points to redeem this voucher.', 'toast');
            return false;
        }
    } else {
        $('#display_loading1').addClass('hideme');
        $('#redeem29').removeProp('disabled');
        shareAppData('You dont have  sufficient points to redeem this voucher.', 'toast');
        return false;
    }
}
function processAfterCallForSave9607redeem(response, callback) {

    callback();
}
function getRecordByIDProcessBeforeCall543526(paramsType, callback) {
    var response = paramsType;

    if (getParameterByName('bazaarid') && getParameterByName('bazaarid') != 'undefined') { paramsType.recordID = getParameterByName('bazaarid') } else if (getParameterByName('recordID') && getParameterByName('recordID') != 'undefined') { paramsType.recordID = getParameterByName('recordID') }; callback();
}
function getRecordByIDProcessAfterCall543526(response, callback) {
    callback();
}
function getRecordByIDProcessBeforeCallbackbutton1(paramsType, callback) {
    var response = paramsType;

    paramsType.recordID = localStorage.getItem("userID");
    callback();
}
function getRecordByIDProcessAfterCallbackbutton1(response, callback) {

    if (response && response.recordDetails.referralAmount && response.recordDetails.referralAmount) {

        localStorage.setItem('referralAmount', response.recordDetails.referralAmount);
    }

    callback();
}
function getRecordByIDProcessBeforeCallgroup13row7(paramsType, callback) {
    var response = paramsType;

    paramsType.todaydate = new Date();
    paramsType.bazaarid = localStorage.getItem('bazaarid');
    callback();
}
function getRecordByIDProcessAfterCallgroup13row7(response, callback) {
    callback();
}