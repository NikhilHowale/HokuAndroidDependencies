
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
     var totaldcard_leftimageproduct_collectioncontainer = 0;
     var totaldcard_leftimageperson_collectioncontainer = 0;
     var totaldcard_leftimageparticipant_collectioncontainer = 0;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#addedit62', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorderdetailsaddupdatemembers'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - addedit62", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorderslisting'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#modify11', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_modifytstatuslist'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - modify11", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#additionalinformation30', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorders2details'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "update"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - additionalinformation30", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#iconnext131', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorders2details'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "update"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - iconnext131", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#orderhistory33', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorderloglisting'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - orderhistory33", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#iconnext234', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorderloglisting'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - iconnext234", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#trackorder39', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_livetracking'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - trackorder39", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#iconnext440', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_livetracking'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - iconnext440", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#viewall43', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myordersviewproductslisting'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - viewall43", error) 
		} 
	})
      var paramsEdit = {};
      paramsEdit.tokenKey = getParameterByName('tokenKey');
      paramsEdit.secretKey = getParameterByName('secretKey') 
                       getRecordByIDProcessBeforeCall816416(paramsEdit, function (processBeforeRes) {
      $.ajax({
          url: ajaXCallURL+'/milestone003/getRecordByCustomeQuery_app_myorderdetails_Orders5da73cac545050343288ce7a',
          data: paramsEdit,
          type: 'POST',
          jsonpCallback: 'callback',
          success: function (response) { 
                       getRecordByIDProcessAfterCall816416(response, function (processBeforeRes) {
              if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                  var objParamsList = {};
                  var queryMode = $('#queryMode').val(); 
                  objParamsList.queryMode = queryMode;;
                  var tokenKey = $('#tokenKey').val();;
                  objParamsList.tokenKey = tokenKey;;
  if(!$('#addedit62').html()){
            $('#addedit62').append(response.recordDetails.undefined);
 }
  if(!$('#additionalinformation30').html()){
            $('#additionalinformation30').append(response.recordDetails.undefined);
 }
  if(!$('#backbutton1').html()){
            $('#backbutton1').append(response.recordDetails.undefined);
 }
  if(!$('#estimateddeliverydate27').html()){
            $('#estimateddeliverydate27').append(response.recordDetails.undefined);
 }
             if(response.recordDetails.groupid != undefined) $('#groupid69').val(response.recordDetails.groupid);
             if(response.recordDetails.bazaarid != undefined) $('#bazaarid68').val(response.recordDetails.bazaarid);
           var url = 'icon_next1.png'
          $('#iconnext131').attr("src", url);
           var url = 'icon_next2.png'
          $('#iconnext234').attr("src", url);
           var url = 'icon_next3.png'
          $('#iconnext337').attr("src", url);
           var url = 'icon_next4.png'
          $('#iconnext440').attr("src", url);
  if(!$('#orderdate15').html()){
            $('#orderdate15').append(response.recordDetails.undefined);
 }
  if(!$('#orderdetails2').html()){
            $('#orderdetails2').append(response.recordDetails.undefined);
 }
  if(!$('#orderhistory33').html()){
            $('#orderhistory33').append(response.recordDetails.undefined);
 }
  if(!$('#orderid18').html()){
            $('#orderid18').append(response.recordDetails.undefined);
 }
  if(!$('#orderstatus24').html()){
            $('#orderstatus24').append(response.recordDetails.undefined);
 }
  if(!$('#ordersummary13').html()){
            $('#ordersummary13').append(response.recordDetails.undefined);
 }
  if(!$('#ordertotal21').html()){
            $('#ordertotal21').append(response.recordDetails.undefined);
 }
  if(!$('#addressstring10').html()){
            $('#addressstring10').append(response.recordDetails.addressstring);
 }
             if(response.recordDetails.categoryid_name != undefined) $('#categoryid_name50').val(response.recordDetails.categoryid_name);
 response.recordDetails['createdOn_preserved'] = response.recordDetails['createdOn'] ;
 response.recordDetails['createdOn'] = response.recordDetails['createdOn']  ? moment(new Date(response.recordDetails['createdOn'])).format('DD MMM YYYY') : '';
  if(!$('#createdOn16').html()){
            $('#createdOn16').append(response.recordDetails.createdOn);
 }
 response.recordDetails['createdOn'] =  response.recordDetails['createdOn_preserved'];
             if(response.recordDetails.imageupload != undefined) $('#imageupload47').val(response.recordDetails.imageupload);
  if(!$('#name7').html()){
            $('#name7').append(response.recordDetails.name);
 }
             if(response.recordDetails.name != undefined) $('#name59').val(response.recordDetails.name);
             if(response.recordDetails.name != undefined) $('#name67').val(response.recordDetails.name);
  if(!$('#ordersnumber9').html()){
            if(!response.recordDetails.ordersnumber){
            	response.recordDetails.ordersnumber = '0';
            }
            $('#ordersnumber9').append(response.recordDetails.ordersnumber);
 }
  if(!$('#ordersnumber19').html()){
            if(!response.recordDetails.ordersnumber){
            	response.recordDetails.ordersnumber = '0';
            }
            $('#ordersnumber19').append(response.recordDetails.ordersnumber);
 }
              $('#price49').maskMoney({thousands:',', decimal:'.', allowZero:true, prefix: '$'}).maskMoney('mask', response.recordDetails.price);  
             if(response.recordDetails.productname != undefined) $('#productname48').val(response.recordDetails.productname);
             if(response.recordDetails.quantity != undefined) $('#quantity51').val(response.recordDetails.quantity);
 response.recordDetails['slotdate_preserved'] = response.recordDetails['slotdate'] ;
 response.recordDetails['slotdate'] = response.recordDetails['slotdate']  ? moment(new Date(response.recordDetails['slotdate'])).format('DD MMM YYYY') : '';
  if(!$('#slotdate28').html()){
            $('#slotdate28').append(response.recordDetails.slotdate);
 }
 response.recordDetails['slotdate'] =  response.recordDetails['slotdate_preserved'];
  if(!$('#status8').html()){
            $('#status8').append(response.recordDetails.status);
 }
  if(!$('#status25').html()){
            $('#status25').append(response.recordDetails.status);
 }
              response.recordDetails.totalamount = getCurrancy(response.recordDetails.totalamount, 'USD','$'); 
  if(!$('#totalamount22').html()){
            $('#totalamount22').append(response.recordDetails.totalamount);
 }
             if(response.recordDetails.uom != undefined) $('#uom52').val(response.recordDetails.uom);
             if(response.recordDetails.userphotoupload != undefined) $('#userphotoupload58').val(response.recordDetails.userphotoupload);
             if(response.recordDetails.userphotoupload != undefined) $('#userphotoupload66').val(response.recordDetails.userphotoupload);
  if(!$('#participants61').html()){
            $('#participants61').append(response.recordDetails.undefined);
 }
  if(!$('#productdetails42').html()){
            $('#productdetails42').append(response.recordDetails.undefined);
 }
  if(!$('#quotations36').html()){
            $('#quotations36').append(response.recordDetails.undefined);
 }
  if(!$('#trackorder39').html()){
            $('#trackorder39').append(response.recordDetails.undefined);
 }
  if(!$('#viewall43').html()){
            $('#viewall43').append(response.recordDetails.undefined);
 }

              Materialize.updateTextFields();
                $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);
  
              } 
              }); // end of getRecord By ID
          },
          error: function (xhr, status, error) {
              handleError(xhr, status, error); 
          },
      }); 
              }); // end of getRecord By ID
   
});//end of ready 
                 function getRecordByIDProcessBeforeCall816416(paramsType,callback) { 
                 var response = paramsType;
 
if(getParameterByName('ordersid') && getParameterByName('ordersid') != 'undefined'){paramsType.recordID = getParameterByName('ordersid')} else if(getParameterByName('recordID') && getParameterByName('recordID') != 'undefined'){paramsType.recordID = getParameterByName('recordID')};callback(); 
                 } 
                 function getRecordByIDProcessAfterCall816416(response,callback) {
 callback(); 
                 }