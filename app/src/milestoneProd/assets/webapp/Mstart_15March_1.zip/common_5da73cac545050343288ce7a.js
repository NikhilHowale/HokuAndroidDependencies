 $(document).ready(function() {

    

     $('.datepicker').pickadate({
         selectMonths: true, // Creates a dropdown to control month
         selectYears: 100, // Creates a dropdown of 15 years to control year
         dateFormat: 'd mmmm, yyyy',
         onSet: function(arg) {
             if ('select' in arg) { //prevent closing on selecting month/year
                 this.close();
                 // $('.fixed-action-btn').show();
             }
         }
     });


     $('#recordID').val(getParameterByName('recordID'));
     $('#queryMode').val(getParameterByName('queryMode'));
     var queryMode = $('#queryMode').val();    
     

 }); //end of ready  


 function getParameterByName(name, url) {
     if (!url) url = window.location.href;
     name = name.replace(/[\[\]]/g, "\\$&");
     var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
         results = regex.exec(url);
     if (!results) return null;
     if (!results[2]) return '';
     return decodeURIComponent(results[2].replace(/\+/g, " "));
 }



 function LoadNativeFileEditor(tokenKey, queryMode, secretKey, ajaXCallURL, imagePath, mediaID) {

     var appJSON = {};
     appJSON.tokenKey = tokenKey;
     appJSON.secretKey = secretKey;
     appJSON.queryMode = queryMode;
     appJSON.ajaXCallURL = ajaXCallURL;
     appJSON.organizationID = $('#organizationID').val();
     appJSON.userID = $('#userID').val();
     appJSON.appID = $('#appID').val();
     appJSON.callbackFunction = 'setLoadNativeFileEditor';
     appJSON.action = queryMode;
     appJSON.colorCode = '#3c3c3c';

     var step = $('#step').val();
     var src = $("#cardImg" + step).attr('src');
     if (src && src.indexOf('noimage.svg') == -1) {
         appJSON.src = src;
     }
     appJSON.step = step;

     bridgeObj.callHandler('LoadNativeFileEditor', appJSON, function(response) {
         //
     });

     bridgeObj.registerHandler('setLoadNativeFileEditor', function(responseData, responseCallback) {
         try {
             localStorage.setItem('offlineDataID', responseData.offlineDataID);
             localStorage.setItem('SummaryDefaultImage', responseData.fileName);
             var step = $('#step').val();
             if (responseData) {
                 //    $("#cardImg" + step).attr('src', responseData.fileName);
                 //    $("#cardImg" + step).removeClass('card_img_noimage');
                 $('#uploadedSliderImagesV2').html('<img src="' + responseData.fileName + '" style="width: 200px;height: 200px;">');
             }
             var addedFileParams = {};                   
             addedFileParams.mediaID = response.mediaID;                   
             addedFileParams.originalFileName = response.originalFileName;                   
             addedFileParams.recentallyAdded = '1';                   
             addedFileParams.S3FilePath = response.filePath;                   
             addedFiles.push(addedFileParams);



         } catch (err) {}
     });
 }

 function LoadNativeFileUpload(tokenKey, queryMode, secretKey, ajaXCallURL, LoadPhotoEditor) {

     var appJSON = {};
     appJSON.tokenKey = tokenKey;
     appJSON.secretKey = secretKey;
     appJSON.queryMode = queryMode;
     appJSON.ajaXCallURL = ajaXCallURL;
     appJSON.LoadPhotoEditor = LoadPhotoEditor;
     appJSON.organizationID = $('#organizationID').val();
     appJSON.userID = $('#userID').val();
     appJSON.appID = $('#appID').val();
     appJSON.callbackFunction = 'setLoadNativeFileUpload';
     appJSON.action = queryMode;
     appJSON.colorCode = '#3c3c3c';
     appJSON.offlineDataID = localStorage.getItem('offlineDataID');

     //var step = $('#step').val();
     
     var step = localStorage.getItem("step");

     // var src = $("#cardImg" + step).attr('src');
     // if (src && src.indexOf('noimage.svg') == -1) {
     //     appJSON.src = src;
     // }
     appJSON.step = step;

     bridgeObj.callHandler('LoadNativeFileUpload', appJSON, function(response) {
         //
     });

     bridgeObj.registerHandler('setLoadNativeFileUpload', function(responseData, responseCallback) {
             try {
                 localStorage.setItem('offlineDataID', responseData.offlineDataID);
                 localStorage.setItem('SummaryDefaultImage', responseData.fileName);
                 var step = $('#step').val();
                 if (responseData) {
                     //$("#cardImg" + step).attr('src', responseData.fileName);
                     //$("#cardImg" + step).removeClass('card_img_noimage');
                     $('#uploadedSliderImagesV2').html('<img src="' + responseData.fileName + '" style="width: 200px;height: 200px;">');
                 }

                 var objLocalImage = {};

                 var returnFile = [];

                 var addedFiles = localStorage.getItem('localImages');

                 if (addedFiles) {
                     addedFiles = JSON.parse(addedFiles);
                     returnFile = $.grep(addedFiles, function(file, index) {
                         return file.step == step;
                     });
                 } else {
                     addedFiles = [];
                 }

                 if (returnFile && returnFile.length) {
                     objLocalImage = returnFile[0];
                 }

                 objLocalImage.step = step;
                 objLocalImage.filePath = responseData.fileName;
                 objLocalImage.offlineDataID = responseData.offlineDataID;

                 if (returnFile && returnFile.length == 0) {
                     addedFiles.push(objLocalImage);
                 }

                 localStorage.setItem('localImages', JSON.stringify(addedFiles));

                 // var params = {};
                 // params.recordType = "addauditroomPage";
                 // params.document_id = '';
                 // params.addedFiles = JSON.stringify(addedFiles);

                 // var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                 // params.tokenKey = getParameterByName('tokenKey');
                 // params.secretKey = getParameterByName('secretKey');
                 // alert(ajaXCallURL);
                 // $.ajax({
                 //     url: ajaXCallURL + '/BigRedv/attachedFiles',
                 //     data: params,
                 //     type: 'POST',
                 //     jsonpCallback: 'callback',
                 //     success: function(data) {
                 //         alert(data);
                 //         $('#sliderImagesV2').html(data);
                 //         // $('#user_file_upload').val('');
                 //         // $('#display_loading').addClass('hideme');
                 //         displayFileUploadButton(addedFiles)
                 //         return false;
                 //     },
                 //     error: function(xhr, status, error) {

                 //     },
                 // });
                 var imageSliderText = '';
                 $.each(addedFiles, function(imageKey, imagesObj) {
                     imageSliderText += '<div class="img-wrap displayInMainImage" imagePath="" mediaID="">';
                     // imageSliderText += '     <span class="close deleteMediaFile" mediaID="">&times;</span>';
                     imageSliderText += '    <img style="width:100px;height: 70px;" class="" src="' + imagesObj.filePath + '" />';
                     imageSliderText += '</div>';
                 });
                 $('#sliderImagesV2').append(imageSliderText);

             // if (addedFiles.length > 1) {
             //     var imageSliderText = '';
             //     $.each(addedFiles, function(imageKey, imagesObj) {;
             //         imageSliderText += '<div class="img-wrap displayInMainImage" imagePath="" mediaID="">';
             //         imageSliderText += '     <span class="close deleteMediaFile" mediaID="">&times;</span>';
             //         imageSliderText += '    <img style="width:100px;height: 70px;" class="" src="' + imagesObj.filePath + '" />';
             //         imageSliderText += '</div>';
             //     });
             //     $('#user_attachment_files').html(imageSliderText);
             // }

         } catch (err) {}
     });
 }



 function displayFileUploadButton(addedFiles) {
     if (addedFiles.length == 6) {
         $('#756869_div').hide();
     } else {
         $('#756869_div').show();
     }
 }

 function infoDebug(data) {
    var params = {}
    params.appID = $('#appID').val();
    params.data = data;
    params.type = "iOS";
    socket.emit('logEvent', params, function(res){
        console.log(res);
    });
}
