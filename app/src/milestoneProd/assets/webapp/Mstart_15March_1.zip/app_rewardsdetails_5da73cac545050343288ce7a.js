
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
  $('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
    $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

  var objParamsToken = {};
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  objParamsToken.tokenKey = getParameterByName('tokenKey');
  objParamsToken.secretKey = getParameterByName('secretKey');

  var userRole = $('#userRole').val();
  var userID = $('#userID').val();
  var createrOfRecord = $('#createrOfRecord').val();
  var queryMode = getParameterByName('queryMode');
  var recordID = $.trim($('#recordID').val());
  var addSessionComments = [];
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#backbutton1', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_custmoreinfodetails';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "update";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error)
    }
  })
  $(document).on('click', '#iconinviteyourfriend18_img', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_referafrienddetails';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "update";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error)
    }
  });
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#membership15', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_rewardsupdate';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - next19", error)
    }
  })
  var paramsEdit = {};
  paramsEdit.tokenKey = getParameterByName('tokenKey');
  paramsEdit.secretKey = getParameterByName('secretKey')
  getRecordByIDProcessBeforeCall490674(paramsEdit, function (processBeforeRes) {
    $.ajax({
      url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_rewardsdetails_Usermanagement5da73cac545050343288ce7a',
      data: paramsEdit,
      type: 'POST',
      jsonpCallback: 'callback',
      success: function (response) {
        getRecordByIDProcessAfterCall490674(response, function (processBeforeRes) {
          if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
            var objParamsList = {};
            var queryMode = $('#queryMode').val();
            objParamsList.queryMode = queryMode;;
            var tokenKey = $('#tokenKey').val();;
            objParamsList.tokenKey = tokenKey;;
            if (!$('#backbutton1').html()) {
              $('#backbutton1').append(response.recordDetails.undefined);
            }
            if (!$('#hi9').html()) {
              $('#hi9').append(response.recordDetails.undefined);
            }
            var url = 'icon_accumulatepoints.png'
            $('#iconaccumulatepoints15').attr("src", url);
            var url = 'icon_inviteyourfriend.png'
            $('#iconinviteyourfriend18').attr("src", url);


            var url = 'icon_silvermembership.png'
            if (response.recordDetails.membershipplan.toLowerCase() == "gold") {
              url = 'icon_goldmembership.png'
              $("#sg22987").hide();
              $("#membership15").hide();
              $("#sg229879").show();
              $('.dcard_topimage2x2_collectioncontainer').removeClass('silvermember');
              $('.dcard_topimage2x2_collectioncontainer').addClass('goldmember');
              $(".goldmember").css("background-image", "url(MyMembership_Gold.svg)");
              $(".goldmember").css("background-repeat", "no-repeat");
              $(".goldmember").css("background-size", "100%");
            }
            else {
              $("#membership15").show();

              $("#sg229879").hide();

              $("#sg22987").show();
              $('.dcard_topimage2x2_collectioncontainer').addClass('silvermember');
              $('.dcard_topimage2x2_collectioncontainer').removeClass('goldmember');
              $(".silvermember").css("background-image", "url(MyMembership_Silver.svg)");
              $(".silvermember").css("background-repeat", "no-repeat");
              $(".silvermember").css("background-size", "100%");

              url = 'icon_silvermembership.png'
              $('#membership15').html("Upgrade to gold Membership");

            }
            $('#iconsilvermembership7_img').attr("src", url);
            if (!$('#knowmore17').html()) {
              $('#knowmore17').append(response.recordDetails.undefined);
            }
            if (!$('#mymembership2').html()) {
              $('#mymembership2').append(response.recordDetails.undefined);
            }
            if (!$('#totalaccumulatedpoints16').html()) {
              $('#totalaccumulatedpoints16').append(response.recordDetails.undefined);
            }
            if (!$('#accumalatedpoints14').html()) {
              if (!response.recordDetails.accumalatedpoints) {
                response.recordDetails.accumalatedpoints = '0';
              }
              $('#accumalatedpoints14').append(response.recordDetails.accumalatedpoints);
            }
            if (!$('#membershipplan11').html()) {
              var planstring = response.recordDetails.membershipplan + " Membership";
              $('#membershipplan11').append(planstring);
            }
            if (!$('#membershipservices12').html()) {
              $('#membershipservices12').append(response.recordDetails.membershipservices);
            }
            if (!$('#name10').html()) {
              $('#name10').append(response.recordDetails.name);
            }

            Materialize.updateTextFields();
            $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

          }
        }); // end of getRecord By ID
      },
      error: function (xhr, status, error) {
        handleError(xhr, status, error);
      },
    });
  }); // end of getRecord By ID


  var queryMode = getParameterByName('queryMode');
  var isMobile = $('#isMobile').val();
  var isiPad = $('#isiPad').val();
  if (queryMode != '') {
    var tokenKey = $('#tokenKey').val();
    var objParamsList = {};
    objParamsList.queryMode = queryMode;
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsList.tokenKey = getParameterByName('tokenKey');
    objParamsList.secretKey = getParameterByName('secretKey');
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.isMobile = isMobile;
    objParamsList.isiPad = isiPad;
    objParamsList.applyFilter = false;
    getDataProcessBeforeCalldcard_topimage2_collectioncontainerBazaar5da73cac545050343288ce7a(objParamsList, function (processBeforeRes) {
      var applyFilter = getParameterByName('applyFilter');
      if (applyFilter == null && objParamsList.applyFilter == false) {
        objParamsList.type = 'events';
        objParamsList.applystaticfilter = true;
      }
      if (getParameterByName('eventdate') && getParameterByName('eventdate') != '' && getParameterByName('eventdate') != null && getParameterByName('eventdate') != 'undefined') {
        objParamsList.eventdate = getParameterByName('eventdate');
      }
      if (getParameterByName('eventenddate') && getParameterByName('eventenddate') != '' && getParameterByName('eventenddate') != null && getParameterByName('eventenddate') != 'undefined') {
        objParamsList.eventenddate = getParameterByName('eventenddate');
      }
      var dcard_topimage2_collectioncontainerapp_allupcomingeventslist = localStorage.getItem('dcard_topimage2_collectioncontainerapp_allupcomingeventslist');
      var applyFilter = getParameterByName('applyFilter');
      $('#display_loading').removeClass('hideme');
      if (dcard_topimage2_collectioncontainerapp_allupcomingeventslist && applyFilter != 'true') {
        response = JSON.parse(dcard_topimage2_collectioncontainerapp_allupcomingeventslist);
        $('#collectioncontainerDivdcard_topimage2_collectioncontainer').html('');

        getdcard_topimage2_collectioncontainerapp_allupcomingeventslistMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
        dcard_topimage2_collectioncontainerapp_allupcomingeventslistSync(response.timestamp);
      } else {
        show_dcard_topimage2_collectioncontainerapp_allupcomingeventslist_Details(objParamsList)
      }
    });//End of get data process before call.
  }


});//end of ready 

function show_dcard_topimage2_collectioncontainerapp_allupcomingeventslist_Details(objParamsList) {
  var applyFilter = getParameterByName('applyFilter');
  if (applyFilter == null && objParamsList.applyFilter == false) {
    objParamsList.type = 'events';
    objParamsList.applystaticfilter = true;
  }
  if (getParameterByName('eventdate') && getParameterByName('eventdate') != '' && getParameterByName('eventdate') != null && getParameterByName('eventdate') != 'undefined') {
    objParamsList.eventdate = getParameterByName('eventdate');
  }
  if (getParameterByName('eventenddate') && getParameterByName('eventenddate') != '' && getParameterByName('eventenddate') != null && getParameterByName('eventenddate') != 'undefined') {
    objParamsList.eventenddate = getParameterByName('eventenddate');
  }
  localStorage.setItem('appallupcomingeventslistFilterBox', '');

  $.ajax({
    url: objParamsList.ajaXCallURL + '/milestone003/getListDetails_Bazaar5da73cac545050343288ce7a_app_userhome_dcard_topimage3_collectioncontainer__discount',
    data: objParamsList,
    type: 'POST',
    success: function (response) {
      getDataProcessAfterCalldcard_topimage2_collectioncontainerBazaar5da73cac545050343288ce7a(response, function () {
        if (response.status != undefined && response.status == 0) {
          if (objParamsList.isMobile == 'true') {
            $('#collectioncontainerDivdcard_topimage2_collectioncontainer').html('');

            // localStorage.setItem('dcard_topimage2_collectioncontainerapp_allupcomingeventslist', JSON.stringify(response));
            getdcard_topimage2_collectioncontainerapp_allupcomingeventslistMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
          } else if (objParamsList.isiPad == 'true') {
            getdcard_topimage2_collectioncontainerapp_allupcomingeventslistiPadView(response, objParamsList.tokenKey, objParamsList.queryMode);
          } else {
            getdcard_topimage2_collectioncontainerapp_allupcomingeventslistWebView(response, objParamsList.tokenKey, objParamsList.queryMode);
          }
          $('#display_loading').addClass('hideme');
        } else {
          $('#display_loading').addClass('hideme')
        }
      });
    },
    error: function (xhr, status, error) {
      $('#display_loading').addClass('hideme')
      handleError(xhr, status, error);
    },
  });
} // end of function     

function getdcard_topimage2_collectioncontainerapp_allupcomingeventslistMobileView(response, tokenKey, queryMode) {
  var html = '';
  if (response.data.length == 0) {
    html += '<div class="nodatafound">';
    html += '<img src="nodatafound.gif" width="100%">';
    html += '<br>';
    html += '<!-- span>No record found</span -->';
    html += '</div>';
    $('#collectioncontainerDivdcard_topimage2_collectioncontainer').html(html);


  } else {
    html = '';
    var radioGroups = [];
    $.each(response.data, function (keyList, objList) {

      var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
      var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
      if (isAndroid > -1 || ios > -1) {  // need to fix with native gyes.. images not getting download
        var mediaID = '';
        var fileName = '';
        if (objList['merchantimage'] && objList['merchantimage'][0].mediaID) {
          mediaID = objList['merchantimage'][0].mediaID;
          fileName = objList['merchantimage'][0].mediaID + '.png';
        }
        getLocalImagedcard_topimage2_collectioncontainer(objList, mediaID, fileName);
        handleLocalImagedcard_topimage2_collectioncontainer(response);
      } else {
        // handleLocalImagedcard_topimage2_collectioncontainer(response);

        html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.merchantimage + objList.code + objList.eventdate) + '">';
        html += '      		<div class="col s12 m12">';
        html += '               <div class="card-content">';
        html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_topimage2_collectioncontainer" style="" >';
        html += '      <div class="row  element" style=""  >';
        var localFilePath = '';
        if (response && response.localFilePath) {
          localFilePath = response.localFilePath;
        }
        html += '<div class="row">';
        html += '<div class="col s4">';
        html += '           <div class="col s12 clssg3017" style="">';
        var filetodisplay = '';
        if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
          filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
        }
        if (localFilePath && localFilePath != '') {
          html += '               <img recordID="' + objList._id + '"  id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
        } else if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
          if (filetodisplay && filetodisplay != objList.merchantimage[0].fileNm) {
            html += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
          } else {
            html += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + objList.merchantimage[0].mediaID + '_compressed.png">';
          }
        } else {
          // stage 6666666666666666
          html += '               <img recordID="' + objList._id + '"   id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
        }
        html += '           </div>';
        var adddbclass = ''
        html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017__merchanttype' + adddbclass + ' " style=" cursor: pointer;">';
        objList['merchanttype'] = objList['merchanttype'] ? objList['merchanttype'] : '';
        if (response.showShimmer) {
          objList['merchanttype'] = '';
        }
        var merchanttype = objList['merchanttype'];
        html += '           <div recordID="' + objList._id + '"   id="merchanttype13" class="languagetranslation " style="" ><img onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="Merchant-Location-White.svg" width=15%; style=""> &nbsp' + merchanttype + '</div>';
        html += '     </div>';
        html += '           </div>';
        html += '<div class="col s8 leftcards">';
        var adddbclass = ''
        html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017__name  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
        objList['merchantname'] = objList['merchantname'] ? objList['merchantname'] : '';
        if (response.showShimmer) {
          objList['merchantname'] = '';
        }
        var merchantname = objList['merchantname'];
        html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + merchantname + '</div>';
        html += '     </div>';

        var adddbclass = ''
        html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
        objList['code'] = objList['code'] ? objList['code'] : '';
        if (response.showShimmer) {
          objList['code'] = '';
        }
        var code = objList['code'];
        html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + code + '</div>';
        html += '     </div>';
        var adddbclass = ''
        html += '           <div recordID="' + objList._id + '" class="col s12 clssg7017  ' + adddbclass + ' " style=" cursor: pointer;">';
        objList['eventdate'] = objList['eventdate'] ? moment(new Date(objList['eventdate'])).format('DD MMM YYYY') : '';
        var eventdate = objList['eventdate'];
        var description = objList["description"] || '';
        var description = objList["description"] || '';
        description = description.replace(/<[^>]*>?/gm, '');
        // if (description.length > 75) {
        //   description = description.slice(0, 69);
        //   description = `${description}...`;
        // }
        // description = description.replace(/<[^>]*>?/gm, '');
        html += '           <div recordID="' + objList._id + '"   id="eventdate14" class="languagetranslation " style="width: 100% !important; text-overflow: ellipsis !important; white-space: nowrap !important; overflow: hidden !important;" >' + description + '</div>';
        html += '     </div>';
        var adddbclass = ''
        html += '           <div recordID="' + objList._id + '" class="col s9 clssg5017  codeclssg5017__getdiscount' + adddbclass + ' " style=" cursor: pointer;">';
        html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >Get Discount</div>';
        html += '     </div>';
        html += '           <div recordID="' + objList._id + '" class="col s3 clssg5017  codeclssg5017__getdiscountimg' + adddbclass + ' " style=" cursor: pointer;">';
        html += '         <img recordid="c79eca6544feb547f994edec" id="merchantimage12" class=" clssg3017image__discount merchantimage12" style="" onerror="this.src="https://appscdn-us.hokuapps.com/card.png" src="Merchant-Stamp-White.svg">';
        html += '     </div>';
        html += '     </div>';
        html += '     </div>';
        html += '     </div>';
        html += '      				</div>';
        html += '          </div>';
        html += '        </div>';
        html += '     </div>';
        html += '   </div>';
      }
    });

    function handleLocalImagedcard_topimage2_collectioncontainer(response) {
      // var objList = response.dataDictionay.objList;


      // var html = "";

      // html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.merchantimage + objList.code + objList.eventdate) + '">';
      // html += '      		<div class="col s12 m12">';
      // html += '               <div class="card-content">';
      // html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_topimage2_collectioncontainer" style="" >';
      // html += '      <div class="row  element" style=""  >';
      // var localFilePath = '';
      // if (response && response.localFilePath) {
      //   localFilePath = response.localFilePath;
      // }
      // html += '<div class="row">';
      // html += '<div class="col s4">';
      // html += '           <div class="col s12 clssg3017" style="">';
      // var filetodisplay = '';
      // if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
      //   filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
      // }
      // if (localFilePath && localFilePath != '') {
      //   html += '               <img recordID="' + objList._id + '"  id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
      // } else if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
      //   if (filetodisplay && filetodisplay != objList.merchantimage[0].fileNm) {
      //     html += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
      //   } else {
      //     html += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + objList.merchantimage[0].mediaID + '_compressed.png">';
      //   }
      // } else {
      //   // stage 6666666666666666
      //   html += '               <img recordID="' + objList._id + '"   id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
      // }
      // html += '           </div>';
      // var adddbclass = ''
      // html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017__merchanttype' + adddbclass + ' " style=" cursor: pointer;">';
      // objList['merchanttype'] = objList['merchanttype'] ? objList['merchanttype'] : '';
      // if (response.showShimmer) {
      //   objList['merchanttype'] = '';
      // }
      // var merchanttype = objList['merchanttype'];
      // html += '           <div recordID="' + objList._id + '"   id="merchanttype13" class="languagetranslation " style="" ><img onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="Merchant-Location-White.svg" width=15%; style=""> &nbsp' + merchanttype + '</div>';
      // html += '     </div>';
      // html += '           </div>';
      // html += '<div class="col s8 leftcards">';
      // var adddbclass = ''
      // html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017__name  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
      // objList['merchantname'] = objList['merchantname'] ? objList['merchantname'] : '';
      // if (response.showShimmer) {
      //   objList['merchantname'] = '';
      // }
      // var merchantname = objList['merchantname'];
      // html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + merchantname + '</div>';
      // html += '     </div>';

      // var adddbclass = ''
      // html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
      // objList['code'] = objList['code'] ? objList['code'] : '';
      // if (response.showShimmer) {
      //   objList['code'] = '';
      // }
      // var code = objList['code'];
      // html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + code + '</div>';
      // html += '     </div>';
      // var adddbclass = ''
      // html += '           <div recordID="' + objList._id + '" class="col s12 clssg7017  ' + adddbclass + ' " style=" cursor: pointer;">';
      // objList['eventdate'] = objList['eventdate'] ? moment(new Date(objList['eventdate'])).format('DD MMM YYYY') : '';
      // var eventdate = objList['eventdate'];
      // var description = objList["description"] || '';
      // description = description.replace(/<[^>]*>?/gm, '');
      // html += '           <div recordID="' + objList._id + '"   id="eventdate14" class="languagetranslation " style="" >' + description + '</div>';
      // html += '     </div>';
      // var adddbclass = ''
      // html += '           <div recordID="' + objList._id + '" class="col s9 clssg5017  codeclssg5017__getdiscount' + adddbclass + ' " style=" cursor: pointer;">';
      // html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >Get Discount</div>';
      // html += '     </div>';
      // html += '           <div recordID="' + objList._id + '" class="col s3 clssg5017  codeclssg5017__getdiscountimg' + adddbclass + ' " style=" cursor: pointer;">';
      // html += '         <img recordid="c79eca6544feb547f994edec" id="merchantimage12" class=" clssg3017image__discount merchantimage12" style="" onerror="this.src="https://appscdn-us.hokuapps.com/card.png" src="Merchant-Stamp-White.svg">';
      // html += '     </div>';
      // html += '     </div>';
      // html += '     </div>';
      // html += '     </div>';
      // html += '      				</div>';
      // html += '          </div>';
      // html += '        </div>';
      // html += '     </div>';
      // html += '   </div>';

      // $("#collectioncontainerDivdcard_topimage2_collectioncontainer").append(html);
      // $("#full-body-container").addClass("fadeInUp");
      // dcardLoaded["dcard_topimage2x2_collectioncontainer"] = true;
      // $("#collectioncontainerDivdcard_topimage2_collectioncontainer").find(".view_list_record").removeClass("shimmer");
      // after html bining code
      $.each(response.data, function (keyList, objList) {

        var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        if (isAndroid > -1 || ios > -1) {  // need to fix with native gyes.. images not getting download

          html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.merchantimage + objList.code + objList.eventdate) + '">';
          html += '      		<div class="col s12 m12">';
          html += '               <div class="card-content">';
          html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_topimage2_collectioncontainer" style="" >';
          html += '      <div class="row  element" style=""  >';
          var localFilePath = '';
          if (response && response.localFilePath) {
            localFilePath = response.localFilePath;
          }
          html += '<div class="row">';
          html += '<div class="col s4">';
          html += '           <div class="col s12 clssg3017" style="">';
          var filetodisplay = '';
          if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
            filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
          }
          if (localFilePath && localFilePath != '') {
            html += '               <img recordID="' + objList._id + '"  id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
          } else if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
            if (filetodisplay && filetodisplay != objList.merchantimage[0].fileNm) {
              html += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
            } else {
              html += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + objList.merchantimage[0].mediaID + '_compressed.png">';
            }
          } else {
            // stage 6666666666666666
            html += '               <img recordID="' + objList._id + '"   id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
          }
          html += '           </div>';
          var adddbclass = ''
          html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017__merchanttype' + adddbclass + ' " style=" cursor: pointer;">';
          objList['merchanttype'] = objList['merchanttype'] ? objList['merchanttype'] : '';
          if (response.showShimmer) {
            objList['merchanttype'] = '';
          }
          var merchanttype = objList['merchanttype'];
          html += '           <div recordID="' + objList._id + '"   id="merchanttype13" class="languagetranslation " style="" ><img onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="Merchant-Location-White.svg" width=15%; style=""> &nbsp' + merchanttype + '</div>';
          html += '     </div>';
          html += '           </div>';
          html += '<div class="col s8 leftcards">';
          var adddbclass = ''
          html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017__name  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
          objList['merchantname'] = objList['merchantname'] ? objList['merchantname'] : '';
          if (response.showShimmer) {
            objList['merchantname'] = '';
          }
          var merchantname = objList['merchantname'];
          html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + merchantname + '</div>';
          html += '     </div>';

          var adddbclass = ''
          html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
          objList['code'] = objList['code'] ? objList['code'] : '';
          if (response.showShimmer) {
            objList['code'] = '';
          }
          var code = objList['code'];
          html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + code + '</div>';
          html += '     </div>';
          var adddbclass = ''
          html += '           <div recordID="' + objList._id + '" class="col s12 clssg7017  ' + adddbclass + ' " style=" cursor: pointer;">';
          objList['eventdate'] = objList['eventdate'] ? moment(new Date(objList['eventdate'])).format('DD MMM YYYY') : '';
          var eventdate = objList['eventdate'];
          var description = objList["description"] || '';
          var description = objList["description"] || '';
          description = description.replace(/<[^>]*>?/gm, '');
          // if (description.length > 75) {
          //   description = description.slice(0, 69);
          //   description = `${description}...`;
          // }
          // description = description.replace(/<[^>]*>?/gm, '');
          html += '           <div recordID="' + objList._id + '"   id="eventdate14" class="languagetranslation " style="width: 100% !important; text-overflow: ellipsis !important; white-space: nowrap !important; overflow: hidden !important;" >' + description + '</div>';
          html += '     </div>';
          var adddbclass = ''
          html += '           <div recordID="' + objList._id + '" class="col s9 clssg5017  codeclssg5017__getdiscount' + adddbclass + ' " style=" cursor: pointer;">';
          html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >Get Discount</div>';
          html += '     </div>';
          html += '           <div recordID="' + objList._id + '" class="col s3 clssg5017  codeclssg5017__getdiscountimg' + adddbclass + ' " style=" cursor: pointer;">';
          html += '         <img recordid="c79eca6544feb547f994edec" id="merchantimage12" class=" clssg3017image__discount merchantimage12" style="" onerror="this.src="https://appscdn-us.hokuapps.com/card.png" src="Merchant-Stamp-White.svg">';
          html += '     </div>';
          html += '     </div>';
          html += '     </div>';
          html += '     </div>';
          html += '      				</div>';
          html += '          </div>';
          html += '        </div>';
          html += '     </div>';
          html += '   </div>';
        }
      });
    }

    //     function handleLocalImagedcard_topimage2_collectioncontainer(response) {
    //       var objList = response.dataDictionay.objList;
    //       var html = "";

    //       html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.merchantimage + objList.code + objList.eventdate) + '">';
    //       html += '      		<div class="col s12 m12">';
    //       html += '               <div class="card-content">';
    //       html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_topimage2_collectioncontainer" style="" >';
    //       html += '      <div class="row  element" style=""  >';
    //       var localFilePath = '';
    //       if (response && response.localFilePath) {
    //         localFilePath = response.localFilePath;
    //       }
    //       html += '<div class="row">';
    //       html += '<div class="col s4">';
    //       html += '           <div class="col s12 clssg3017" style="">';
    //       var filetodisplay = '';
    //       if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
    //         filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
    //       }
    //       if (localFilePath && localFilePath != '') {
    //         html += '               <img recordID="' + objList._id + '"  id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
    //       } else if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
    //         if (filetodisplay && filetodisplay != objList.merchantimage[0].fileNm) {
    //           html += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
    //         } else {
    //           html += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + objList.merchantimage[0].mediaID + '_compressed.png">';
    //         }
    //       } else {
    //         // stage 6666666666666666
    //         html += '               <img recordID="' + objList._id + '"   id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
    //       }
    //       html += '           </div>';
    //       var adddbclass = ''
    //       html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017__merchanttype' + adddbclass + ' " style=" cursor: pointer;">';
    //       objList['merchanttype'] = objList['merchanttype'] ? objList['merchanttype'] : '';
    //       if (response.showShimmer) {
    //         objList['merchanttype'] = '';
    //       }
    //       var merchanttype = objList['merchanttype'];
    //       html += '           <div recordID="' + objList._id + '"   id="merchanttype13" class="languagetranslation " style="" ><img onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="Merchant-Location-White.svg" width=15%; style=""> &nbsp' + merchanttype + '</div>';
    //       html += '     </div>';
    //       html += '           </div>';
    //       html += '<div class="col s8 leftcards">';
    //       var adddbclass = ''
    //       html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017__name  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
    //       objList['merchantname'] = objList['merchantname'] ? objList['merchantname'] : '';
    //       if (response.showShimmer) {
    //         objList['merchantname'] = '';
    //       }
    //       var merchantname = objList['merchantname'];
    //       html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + merchantname + '</div>';
    //       html += '     </div>';

    //       var adddbclass = ''
    //       html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
    //       objList['code'] = objList['code'] ? objList['code'] : '';
    //       if (response.showShimmer) {
    //         objList['code'] = '';
    //       }
    //       var code = objList['code'];
    //       html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + code + '</div>';
    //       html += '     </div>';
    //       var adddbclass = ''
    //       html += '           <div recordID="' + objList._id + '" class="col s12 clssg7017  ' + adddbclass + ' " style=" cursor: pointer;">';
    //       objList['eventdate'] = objList['eventdate'] ? moment(new Date(objList['eventdate'])).format('DD MMM YYYY') : '';
    //       var eventdate = objList['eventdate'];
    //       var description = objList["description"] || '';
    //       description = description.replace(/<[^>]*>?/gm, '');
    //       html += '           <div recordID="' + objList._id + '"   id="eventdate14" class="languagetranslation " style="" >' + description + '</div>';
    //       html += '     </div>';
    //       var adddbclass = ''
    //       html += '           <div recordID="' + objList._id + '" class="col s9 clssg5017  codeclssg5017__getdiscount' + adddbclass + ' " style=" cursor: pointer;">';
    //       html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >Get Discount</div>';
    //       html += '     </div>';
    //       html += '           <div recordID="' + objList._id + '" class="col s3 clssg5017  codeclssg5017__getdiscountimg' + adddbclass + ' " style=" cursor: pointer;">';
    //       html += '         <img recordid="c79eca6544feb547f994edec" id="merchantimage12" class=" clssg3017image__discount merchantimage12" style="" onerror="this.src="https://appscdn-us.hokuapps.com/card.png" src="Merchant-Stamp-White.svg">';
    //       html += '     </div>';
    //       html += '     </div>';
    //       html += '     </div>';
    //       html += '     </div>';
    //       html += '      				</div>';
    //       html += '          </div>';
    //       html += '        </div>';
    //       html += '     </div>';
    //       html += '   </div>';

    //       $("#collectioncontainerDivdcard_topimage2_collectioncontainer").append(html);
    //       $("#full-body-container").addClass("fadeInUp");
    //       dcardLoaded["dcard_topimage2x2_collectioncontainer"] = true;
    //       $("#collectioncontainerDivdcard_topimage2_collectioncontainer").find(".view_list_record").removeClass("shimmer");
    //       // after html bining code
    //     }

    function getLocalImagedcard_topimage2_collectioncontainer(objList, mediaID, fileName) {
      try {
        var appJSON = {};
        appJSON.nextButtonCallback = "handleLocalImagedcard_topimage2_collectioncontainer";
        appJSON.url = CDN_PATH + mediaID + "_compressed.png";
        appJSON.fileMimeType = "image/png";
        appJSON.fileName = fileName;
        appJSON.objList = objList;
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        if (isAndroid > -1) {
          window.Android.getLocalImage(JSON.stringify(appJSON));
        } else {
          setupWebViewJavascriptBridge(function (bridge) {
            bridgeObj = bridge;
            bridgeObj.callHandler("getLocalImage", appJSON, function (response) { });
            bridgeObj.registerHandler("handleLocalImagedcard_topimage2_collectioncontainer", function (responseData, responseCallback) {
              handleLocalImagedcard_topimage2_collectioncontainer(responseData);
            });
          });
        }
      } catch (err) { }
    }



    var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    if (1) {
      $('#collectioncontainerDivdcard_topimage2_collectioncontainer').html(html);


      $('#full-body-container').addClass('fadeInUp');
    };
    if (!response.showShimmer) {
      dcardLoaded['dcard_topimage2_collectioncontainer'] = true;
      $('#collectioncontainerDivdcard_topimage2_collectioncontainer').find('.view_list_record').removeClass('shimmer');


    }
    $('.carddropdown').material_select();
    $('<input>').attr({ type: 'hidden', class: 'cardtoggleswitch', id: 'togleswitchvalue' }).appendTo('body')
    if ($('.js-candlestick').length) $('.js-candlestick').candlestick({ afterSetting: function (input, wrapper, value) { $('#togleswitchvalue').val(value).attr('recordID', input.attr('id')).trigger('click'); } });
    if (radioGroups && radioGroups.length) {
      for (var key in radioGroups) {
        var groupName = radioGroups[key];
        $('input:radio[name=' + groupName + ']:first').prop('checked', true);
        $('input:radio[name=' + groupName + ']:first').trigger('change');
      }
    }
  };
};

function getRecordByIDProcessBeforeCall490674(paramsType, callback) {
  var response = paramsType;

  if (getParameterByName('usermanagementid') && getParameterByName('usermanagementid') != 'undefined') { paramsType.recordID = getParameterByName('usermanagementid') } else if (getParameterByName('recordID') && getParameterByName('recordID') != 'undefined') { paramsType.recordID = getParameterByName('recordID') }; paramsType.recordID = localStorage.userID; callback();
}
function getRecordByIDProcessAfterCall490674(response, callback) {

  if (response && response.recordDetails && typeof (response.recordDetails.membershipplan) == 'undefined') {
    response.recordDetails.membershipplan = "Silver";
  }
  callback();
}

function getDataProcessBeforeCalldcard_topimage2_collectioncontainerBazaar5da73cac545050343288ce7a(objParamsList, callback) {
  var response = objParamsList
  objParamsList.eventdate = new Date();
  objParamsList.eventenddate = new Date();
  objParamsList.type = 'events';
  callback();
}

function getDataProcessAfterCalldcard_topimage2_collectioncontainerBazaar5da73cac545050343288ce7a(response, callback) {

  callback();
}
$(document).on('click', '.dcard_topimage2_collectioncontainer', function () {
  if (dcardLoaded && !dcardLoaded['dcard_topimage2_collectioncontainer']) { return false; }; // added for use should not able to click until data loaded
  localStorage.setItem("headerPageName", 'app_myeventdetails');
  var recordID = $(this).attr('recordID');// get record ID;
  var bazaarid = $(this).attr('recordID');// get record ID;
  var tokenKey = getParameterByName('tokenKey');
  var secretKey = getParameterByName('secretKey');
  var queryMode = 'update';
  var parent = "app_allupcomingeventslist"
  var nextPage = 'app_discountdetails';
  if (!nextPage) {
      return false;
  }
  localStorage.setItem('discountbackpage', 'app_allmerchantdiscountslist');
  var pageurl = nextPage + '_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&bazaarid=' + bazaarid + '&recordID=' + recordID + '&applyFilter=true' + "&parent=" + parent;
  window.location.href = pageurl;
  return false;
}); // to add New record


$(document).on("click", "#discountviewall9", function (e) {
  try {
    var element = $(this);
    var parent = "app_userhome";
    // var nextPage = "app_allupcomingeventslist";
    var nextPage = 'app_allmerchantdiscountslist';
    var queryParams = queryStringToJSON();
    queryParams["queryMode"] = "mylist";
    var recordID = $(this).attr("recordID");
    if (recordID) {
      queryParams["recordID"] = recordID;
    }
    var queryString = $.param(queryParams);
    queryString = queryString.replace(/\+/g, "%20");
    queryString = decodeURIComponent(queryString);
    window.location.href = nextPage + "_5da73cac545050343288ce7a.html?" + queryString + "&parent=" + parent;
    return false;
  } catch (error) {
    console.log("Error in pageredirect workflow - viewall9", error);
  }
});
