
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
  $('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
    $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

  var objParamsToken = {};
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  objParamsToken.tokenKey = getParameterByName('tokenKey');
  objParamsToken.secretKey = getParameterByName('secretKey');

  var userRole = $('#userRole').val();
  var userID = $('#userID').val();
  var createrOfRecord = $('#createrOfRecord').val();
  var queryMode = getParameterByName('queryMode');
  var recordID = $.trim($('#recordID').val());
  var addSessionComments = [];
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on('click', '#accept29', function () {
    var objParams = {};
    var note = $.trim($('#note27').val());
    var obj = {}
    if ($('#note27_div').is(':visible')) {
      if (note == '') {
        $('#note27_error').show();
        if (!Object.keys(errorFields).length) errorFields['note27'] = 'divtag';
        validAll = false;
      } else {
        $('#note27_error').hide();
      }
    }
    if ($('#note27_div').is(':visible')) {
      objParams.note = note;
    }
    var policytype_name = $.trim($('#policytype_name11').val());
    var obj = {}
    if ($('#policytype_name11_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name11'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name11_error').hide();
      }
    }
    if ($('#policytype_name11_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var slotdate = $.trim($('#slotdate7').val());
    var obj = {}
    if ($('#slotdate7_div').is(':visible')) {
      if (slotdate == '') {
        $('#slotdate7_error').show();
        if (!Object.keys(errorFields).length) errorFields['slotdate7'] = 'divtag';
        validAll = false;
      } else {
        $('#slotdate7_error').hide();
      }
    }
    if ($('#slotdate7_div').is(':visible')) {
      objParams.slotdate = slotdate;
    }
    var policytype_name = $.trim($('#policytype_name11').val());
    var obj = {}
    if ($('#policytype_name11_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name11'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name11_error').hide();
      }
    }
    if ($('#policytype_name11_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var slotdate = $.trim($('#slotdate7').val());
    var obj = {}
    if ($('#slotdate7_div').is(':visible')) {
      if (slotdate == '') {
        $('#slotdate7_error').show();
        if (!Object.keys(errorFields).length) errorFields['slotdate7'] = 'divtag';
        validAll = false;
      } else {
        $('#slotdate7_error').hide();
      }
    }
    if ($('#slotdate7_div').is(':visible')) {
      objParams.slotdate = slotdate;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var policytype_name = $.trim($('#policytype_name11').val());
    var obj = {}
    if ($('#policytype_name11_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name11'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name11_error').hide();
      }
    }
    if ($('#policytype_name11_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var name = $.trim($('#name17').val());
    var obj = {}
    if ($('#name17_div').is(':visible')) {
      if (name == '') {
        $('#name17_error').show();
        if (!Object.keys(errorFields).length) errorFields['name17'] = 'divtag';
        validAll = false;
      } else {
        $('#name17_error').hide();
      }
    }
    if ($('#name17_div').is(':visible')) {
      objParams.name = name;
    }
    var clientcontact = $.trim($('#clientcontact20').val());
    var obj = {}
    if ($('#clientcontact20_div').is(':visible')) {
      if (clientcontact == '') {
        $('#clientcontact20_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientcontact20'] = 'divtag';
        validAll = false;
      } else {
        $('#clientcontact20_error').hide();
      }
    }
    if ($('#clientcontact20_div').is(':visible')) {
      var dialCode = $('#clientcontact20').attr('dialCode');
      var countryCode = $('#clientcontact20').attr('countryCode');
      var placeholder = $('#clientcontact20').attr('placeholder');
      clientcontact = clientcontact.replace(/[^0-9]/gi, '');
      placeholder = placeholder.replace(/[^0-9]/gi, '');
      if (placeholder.length != clientcontact.length) {
        $('#clientcontact20_error').html('Valid orders_clientcontact is required').show();
        $('#clientcontact20').fadeIn(1000);
        errorFields.push('clientcontact20');
      }
      clientcontact = '+' + dialCode + clientcontact;
      objParams.clientcontact_dialcode = dialCode;
      objParams.clientcontact_countrycode = countryCode;
    }
    if ($('#clientcontact20_div').is(':visible')) {
      objParams.clientcontact = clientcontact;
    }
    var email = $.trim($('#email23').val());
    var obj = {}
    if ($('#email23_div').is(':visible')) {
      if (email == '') {
        $('#email23_error').html('Email is required');
        $('#email23_error').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email23_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else {
        $('#email23_error').hide();
      }
    }
    if ($('#email23_div').is(':visible')) {
      objParams.email = email;
    }
    var note = $.trim($('#note27').val());
    var obj = {}
    if ($('#note27_div').is(':visible')) {
      if (note == '') {
        $('#note27_error').show();
        if (!Object.keys(errorFields).length) errorFields['note27'] = 'divtag';
        validAll = false;
      } else {
        $('#note27_error').hide();
      }
    }
    if ($('#note27_div').is(':visible')) {
      objParams.note = note;
    }
    var slotdate = $.trim($('#slotdate7').val());
    var obj = {}
    if ($('#slotdate7_div').is(':visible')) {
      if (slotdate == '') {
        $('#slotdate7_error').show();
        if (!Object.keys(errorFields).length) errorFields['slotdate7'] = 'divtag';
        validAll = false;
      } else {
        $('#slotdate7_error').hide();
      }
    }
    if ($('#slotdate7_div').is(':visible')) {
      objParams.slotdate = slotdate;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var clientname = $.trim($('#clientname10').val());
    var obj = {}
    if ($('#clientname10_div').is(':visible')) {
      if (clientname == '') {
        $('#clientname10_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientname10'] = 'divtag';
        validAll = false;
      } else {
        $('#clientname10_error').hide();
      }
    }
    if ($('#clientname10_div').is(':visible')) {
      objParams.clientname = clientname;
    }
    var policytype_name = $.trim($('#policytype_name11').val());
    var obj = {}
    if ($('#policytype_name11_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name11'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name11_error').hide();
      }
    }
    if ($('#policytype_name11_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var name = $.trim($('#name17').val());
    var obj = {}
    if ($('#name17_div').is(':visible')) {
      if (name == '') {
        $('#name17_error').show();
        if (!Object.keys(errorFields).length) errorFields['name17'] = 'divtag';
        validAll = false;
      } else {
        $('#name17_error').hide();
      }
    }
    if ($('#name17_div').is(':visible')) {
      objParams.name = name;
    }
    var clientcontact = $.trim($('#clientcontact20').val());
    var obj = {}
    if ($('#clientcontact20_div').is(':visible')) {
      if (clientcontact == '') {
        $('#clientcontact20_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientcontact20'] = 'divtag';
        validAll = false;
      } else {
        $('#clientcontact20_error').hide();
      }
    }
    if ($('#clientcontact20_div').is(':visible')) {
      var dialCode = $('#clientcontact20').attr('dialCode');
      var countryCode = $('#clientcontact20').attr('countryCode');
      var placeholder = $('#clientcontact20').attr('placeholder');
      clientcontact = clientcontact.replace(/[^0-9]/gi, '');
      placeholder = placeholder.replace(/[^0-9]/gi, '');
      if (placeholder.length != clientcontact.length) {
        $('#clientcontact20_error').html('Valid orders_clientcontact is required').show();
        $('#clientcontact20').fadeIn(1000);
        errorFields.push('clientcontact20');
      }
      clientcontact = '+' + dialCode + clientcontact;
      objParams.clientcontact_dialcode = dialCode;
      objParams.clientcontact_countrycode = countryCode;
    }
    if ($('#clientcontact20_div').is(':visible')) {
      objParams.clientcontact = clientcontact;
    }
    var email = $.trim($('#email23').val());
    var obj = {}
    if ($('#email23_div').is(':visible')) {
      if (email == '') {
        $('#email23_error').html('Email is required');
        $('#email23_error').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email23_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else {
        $('#email23_error').hide();
      }
    }
    if ($('#email23_div').is(':visible')) {
      objParams.email = email;
    }
    var note = $.trim($('#note27').val());
    var obj = {}
    if ($('#note27_div').is(':visible')) {
      if (note == '') {
        $('#note27_error').show();
        if (!Object.keys(errorFields).length) errorFields['note27'] = 'divtag';
        validAll = false;
      } else {
        $('#note27_error').hide();
      }
    }
    if ($('#note27_div').is(':visible')) {
      objParams.note = note;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var policytype_name = $.trim($('#policytype_name11').val());
    var obj = {}
    if ($('#policytype_name11_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name11'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name11_error').hide();
      }
    }
    if ($('#policytype_name11_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var name = $.trim($('#name17').val());
    var obj = {}
    if ($('#name17_div').is(':visible')) {
      if (name == '') {
        $('#name17_error').show();
        if (!Object.keys(errorFields).length) errorFields['name17'] = 'divtag';
        validAll = false;
      } else {
        $('#name17_error').hide();
      }
    }
    if ($('#name17_div').is(':visible')) {
      objParams.name = name;
    }
    var clientcontact = $.trim($('#clientcontact20').val());
    var obj = {}
    if ($('#clientcontact20_div').is(':visible')) {
      if (clientcontact == '') {
        $('#clientcontact20_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientcontact20'] = 'divtag';
        validAll = false;
      } else {
        $('#clientcontact20_error').hide();
      }
    }
    if ($('#clientcontact20_div').is(':visible')) {
      var dialCode = $('#clientcontact20').attr('dialCode');
      var countryCode = $('#clientcontact20').attr('countryCode');
      var placeholder = $('#clientcontact20').attr('placeholder');
      clientcontact = clientcontact.replace(/[^0-9]/gi, '');
      placeholder = placeholder.replace(/[^0-9]/gi, '');
      if (placeholder.length != clientcontact.length) {
        $('#clientcontact20_error').html('Valid orders_clientcontact is required').show();
        $('#clientcontact20').fadeIn(1000);
        errorFields.push('clientcontact20');
      }
      clientcontact = '+' + dialCode + clientcontact;
      objParams.clientcontact_dialcode = dialCode;
      objParams.clientcontact_countrycode = countryCode;
    }
    if ($('#clientcontact20_div').is(':visible')) {
      objParams.clientcontact = clientcontact;
    }
    var email = $.trim($('#email23').val());
    var obj = {}
    if ($('#email23_div').is(':visible')) {
      if (email == '') {
        $('#email23_error').html('Email is required');
        $('#email23_error').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email23_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else {
        $('#email23_error').hide();
      }
    }
    if ($('#email23_div').is(':visible')) {
      objParams.email = email;
    }
    var note = $.trim($('#note27').val());
    var obj = {}
    if ($('#note27_div').is(':visible')) {
      if (note == '') {
        $('#note27_error').show();
        if (!Object.keys(errorFields).length) errorFields['note27'] = 'divtag';
        validAll = false;
      } else {
        $('#note27_error').hide();
      }
    }
    if ($('#note27_div').is(':visible')) {
      objParams.note = note;
    }
    var policytype_name = $.trim($('#policytype_name11').val());
    var obj = {}
    if ($('#policytype_name11_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name11'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name11_error').hide();
      }
    }
    if ($('#policytype_name11_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var slotdate = $.trim($('#slotdate7').val());
    var obj = {}
    if ($('#slotdate7_div').is(':visible')) {
      if (slotdate == '') {
        $('#slotdate7_error').show();
        if (!Object.keys(errorFields).length) errorFields['slotdate7'] = 'divtag';
        validAll = false;
      } else {
        $('#slotdate7_error').hide();
      }
    }
    if ($('#slotdate7_div').is(':visible')) {
      objParams.slotdate = slotdate;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var clientname = $.trim($('#clientname10').val());
    var obj = {}
    if ($('#clientname10_div').is(':visible')) {
      if (clientname == '') {
        $('#clientname10_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientname10'] = 'divtag';
        validAll = false;
      } else {
        $('#clientname10_error').hide();
      }
    }
    if ($('#clientname10_div').is(':visible')) {
      objParams.clientname = clientname;
    }
    var policytype_name = $.trim($('#policytype_name11').val());
    var obj = {}
    if ($('#policytype_name11_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name11'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name11_error').hide();
      }
    }
    if ($('#policytype_name11_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var name = $.trim($('#name17').val());
    var obj = {}
    if ($('#name17_div').is(':visible')) {
      if (name == '') {
        $('#name17_error').show();
        if (!Object.keys(errorFields).length) errorFields['name17'] = 'divtag';
        validAll = false;
      } else {
        $('#name17_error').hide();
      }
    }
    if ($('#name17_div').is(':visible')) {
      objParams.name = name;
    }
    var clientcontact = $.trim($('#clientcontact20').val());
    var obj = {}
    if ($('#clientcontact20_div').is(':visible')) {
      if (clientcontact == '') {
        $('#clientcontact20_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientcontact20'] = 'divtag';
        validAll = false;
      } else {
        $('#clientcontact20_error').hide();
      }
    }
    if ($('#clientcontact20_div').is(':visible')) {
      var dialCode = $('#clientcontact20').attr('dialCode');
      var countryCode = $('#clientcontact20').attr('countryCode');
      var placeholder = $('#clientcontact20').attr('placeholder');
      clientcontact = clientcontact.replace(/[^0-9]/gi, '');
      placeholder = placeholder.replace(/[^0-9]/gi, '');
      if (placeholder.length != clientcontact.length) {
        $('#clientcontact20_error').html('Valid orders_clientcontact is required').show();
        $('#clientcontact20').fadeIn(1000);
        errorFields.push('clientcontact20');
      }
      clientcontact = '+' + dialCode + clientcontact;
      objParams.clientcontact_dialcode = dialCode;
      objParams.clientcontact_countrycode = countryCode;
    }
    if ($('#clientcontact20_div').is(':visible')) {
      objParams.clientcontact = clientcontact;
    }
    var email = $.trim($('#email23').val());
    var obj = {}
    if ($('#email23_div').is(':visible')) {
      if (email == '') {
        $('#email23_error').html('Email is required');
        $('#email23_error').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email23_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else {
        $('#email23_error').hide();
      }
    }
    if ($('#email23_div').is(':visible')) {
      objParams.email = email;
    }
    var note = $.trim($('#note27').val());
    var obj = {}
    if ($('#note27_div').is(':visible')) {
      if (note == '') {
        $('#note27_error').show();
        if (!Object.keys(errorFields).length) errorFields['note27'] = 'divtag';
        validAll = false;
      } else {
        $('#note27_error').hide();
      }
    }
    if ($('#note27_div').is(':visible')) {
      objParams.note = note;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var policytype_name = $.trim($('#policytype_name11').val());
    var obj = {}
    if ($('#policytype_name11_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name11'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name11_error').hide();
      }
    }
    if ($('#policytype_name11_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var name = $.trim($('#name17').val());
    var obj = {}
    if ($('#name17_div').is(':visible')) {
      if (name == '') {
        $('#name17_error').show();
        if (!Object.keys(errorFields).length) errorFields['name17'] = 'divtag';
        validAll = false;
      } else {
        $('#name17_error').hide();
      }
    }
    if ($('#name17_div').is(':visible')) {
      objParams.name = name;
    }
    var clientcontact = $.trim($('#clientcontact20').val());
    var obj = {}
    if ($('#clientcontact20_div').is(':visible')) {
      if (clientcontact == '') {
        $('#clientcontact20_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientcontact20'] = 'divtag';
        validAll = false;
      } else {
        $('#clientcontact20_error').hide();
      }
    }
    if ($('#clientcontact20_div').is(':visible')) {
      var dialCode = $('#clientcontact20').attr('dialCode');
      var countryCode = $('#clientcontact20').attr('countryCode');
      var placeholder = $('#clientcontact20').attr('placeholder');
      clientcontact = clientcontact.replace(/[^0-9]/gi, '');
      placeholder = placeholder.replace(/[^0-9]/gi, '');
      if (placeholder.length != clientcontact.length) {
        $('#clientcontact20_error').html('Valid orders_clientcontact is required').show();
        $('#clientcontact20').fadeIn(1000);
        errorFields.push('clientcontact20');
      }
      clientcontact = '+' + dialCode + clientcontact;
      objParams.clientcontact_dialcode = dialCode;
      objParams.clientcontact_countrycode = countryCode;
    }
    if ($('#clientcontact20_div').is(':visible')) {
      objParams.clientcontact = clientcontact;
    }
    var email = $.trim($('#email23').val());
    var obj = {}
    if ($('#email23_div').is(':visible')) {
      if (email == '') {
        $('#email23_error').html('Email is required');
        $('#email23_error').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email23_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else {
        $('#email23_error').hide();
      }
    }
    if ($('#email23_div').is(':visible')) {
      objParams.email = email;
    }
    var note = $.trim($('#note27').val());
    var obj = {}
    if ($('#note27_div').is(':visible')) {
      if (note == '') {
        $('#note27_error').show();
        if (!Object.keys(errorFields).length) errorFields['note27'] = 'divtag';
        validAll = false;
      } else {
        $('#note27_error').hide();
      }
    }
    if ($('#note27_div').is(':visible')) {
      objParams.note = note;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var note = $.trim($('#note27').val());
    var obj = {}
    if ($('#note27_div').is(':visible')) {
      if (note == '') {
        $('#note27_error').show();
        if (!Object.keys(errorFields).length) errorFields['note27'] = 'divtag';
        validAll = false;
      } else {
        $('#note27_error').hide();
      }
    }
    if ($('#note27_div').is(':visible')) {
      objParams.note = note;
    }
    var tempobjParams = getParams(window.location.href)
    function extend(obj, src) {
      for (var key in src) {
        if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
      }
      return obj;
    }
    objParams = extend(objParams, tempobjParams);
    var recordID = $('#recordID').val();
    objParams.isDelete = 0;
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParams.tokenKey = getParameterByName('tokenKey');
    objParams.secretKey = getParameterByName('secretKey');
    objParams.offlineDataID = localStorage.getItem("offlineDataID");
    var queryMode = getParameterByName('queryMode')
    if (queryMode == 'add') {
      objParams.callUrl = ajaXCallURL + '/milestone003/saveAjaxordersordersacceptednewapp_consultantappointment2details';
    } else {
      objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxordersordersacceptednewapp_consultantappointment2details';
      objParams.recordID = recordID;
    }
    if (errorFields && Object.keys(errorFields).length) {
      $('#display_loading1').addClass('hideme');
      for (var firstErrorField in errorFields) {
        var controlType = errorFields[firstErrorField];
        errorFields = []
        var errField = $('#' + firstErrorField);
        if (controlType == 'dropdown') {
          errField.prev().prev().focus();
        } else {
          errField.focus()
        }
        validAll = true;
        return false;
      }
    }
    if (!validAll) {
      validAll = true;
      return false;
    }
    $('#accept29').prop('disabled', true);
    $('#display_loading1').removeClass('hideme');
    if (addSessionComments.length > 0) {
      objParams.addSessionComments = addSessionComments;
    } else {
      objParams.addSessionComments = [];
    }
    var parentID = $('#parentID').val();
    var parentName = $('#parentName').val();
    if (parentID != '') {
      objParams.parentID = parentID;
      objParams.parentName = parentName
    }
    if (typeof (addedFiles) != "undefined" && addedFiles && addedFiles.length > 0) {
      objParams.addedFiles = addedFiles;
    }
    objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    objParams.organizationID = $("#organizationID").val();;
    objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    objParams.organizationID = $("#organizationID").val();;
    processBeforeCallForSaveordersacceptednew(objParams, {}, function (processBeforeRes) {
      $.ajax({
        url: objParams.callUrl,
        data: objParams,
        type: 'POST',
        success: function (response) {
          if (response.status == 0) {
            $('#display_loading1').addClass('hideme');
            response.nextPage = 'app_consultantacceptappointmentslisting'
            processAfterCallForSaveordersacceptednew(response, function (processAfterRes) {
              var tokenKey = getParameterByName('tokenKey');
              var secretKey = getParameterByName('secretKey');
              var queryMode = getParameterByName('queryMode');
              queryMode = queryMode.replace('edit', '');
              localStorage.setItem("headerPageName", 'app_consultantacceptappointmentslisting');
              var queryString = window.location.search.slice(1);
              var newQuery = queryString + '&queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey
              var queryParams = queryStringToJSON(newQuery);
              queryString = $.param(queryParams);
              queryString = queryString.replace(/\+/g, "%20");
              queryString = decodeURIComponent(queryString);
              if (recordID == '') {
                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
              } else {
                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
              }
              return false;
            }); // End of After Process
          } else {
            $('#display_loading1').addClass('hideme');
            $('#2656d_error').html(response.error);
            $('#2656d_error').show();
          }
          $('#accept29').removeProp('disabled');
        },
        error: function (xhr, status, error) {
          $('#display_loading1').addClass('hideme');
          $('#accept29').removeProp('disabled');
        },
      });
      return false;
    }); // End of Before Process
  });//end of Event Accept_is_click 
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on('click', '#reject30', function () {
    var objParams = {};
    var note = $.trim($('#note27').val());
    var obj = {}
    if ($('#note27_div').is(':visible')) {
      if (note == '') {
        $('#note27_error').show();
        if (!Object.keys(errorFields).length) errorFields['note27'] = 'divtag';
        validAll = false;
      } else {
        $('#note27_error').hide();
      }
    }
    if ($('#note27_div').is(':visible')) {
      objParams.note = note;
    }
    var policytype_name = $.trim($('#policytype_name11').val());
    var obj = {}
    if ($('#policytype_name11_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name11'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name11_error').hide();
      }
    }
    if ($('#policytype_name11_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var slotdate = $.trim($('#slotdate7').val());
    var obj = {}
    if ($('#slotdate7_div').is(':visible')) {
      if (slotdate == '') {
        $('#slotdate7_error').show();
        if (!Object.keys(errorFields).length) errorFields['slotdate7'] = 'divtag';
        validAll = false;
      } else {
        $('#slotdate7_error').hide();
      }
    }
    if ($('#slotdate7_div').is(':visible')) {
      objParams.slotdate = slotdate;
    }
    var policytype_name = $.trim($('#policytype_name11').val());
    var obj = {}
    if ($('#policytype_name11_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name11'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name11_error').hide();
      }
    }
    if ($('#policytype_name11_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var slotdate = $.trim($('#slotdate7').val());
    var obj = {}
    if ($('#slotdate7_div').is(':visible')) {
      if (slotdate == '') {
        $('#slotdate7_error').show();
        if (!Object.keys(errorFields).length) errorFields['slotdate7'] = 'divtag';
        validAll = false;
      } else {
        $('#slotdate7_error').hide();
      }
    }
    if ($('#slotdate7_div').is(':visible')) {
      objParams.slotdate = slotdate;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var policytype_name = $.trim($('#policytype_name11').val());
    var obj = {}
    if ($('#policytype_name11_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name11'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name11_error').hide();
      }
    }
    if ($('#policytype_name11_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var name = $.trim($('#name17').val());
    var obj = {}
    if ($('#name17_div').is(':visible')) {
      if (name == '') {
        $('#name17_error').show();
        if (!Object.keys(errorFields).length) errorFields['name17'] = 'divtag';
        validAll = false;
      } else {
        $('#name17_error').hide();
      }
    }
    if ($('#name17_div').is(':visible')) {
      objParams.name = name;
    }
    var clientcontact = $.trim($('#clientcontact20').val());
    var obj = {}
    if ($('#clientcontact20_div').is(':visible')) {
      if (clientcontact == '') {
        $('#clientcontact20_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientcontact20'] = 'divtag';
        validAll = false;
      } else {
        $('#clientcontact20_error').hide();
      }
    }
    if ($('#clientcontact20_div').is(':visible')) {
      var dialCode = $('#clientcontact20').attr('dialCode');
      var countryCode = $('#clientcontact20').attr('countryCode');
      var placeholder = $('#clientcontact20').attr('placeholder');
      clientcontact = clientcontact.replace(/[^0-9]/gi, '');
      placeholder = placeholder.replace(/[^0-9]/gi, '');
      if (placeholder.length != clientcontact.length) {
        $('#clientcontact20_error').html('Valid orders_clientcontact is required').show();
        $('#clientcontact20').fadeIn(1000);
        errorFields.push('clientcontact20');
      }
      clientcontact = '+' + dialCode + clientcontact;
      objParams.clientcontact_dialcode = dialCode;
      objParams.clientcontact_countrycode = countryCode;
    }
    if ($('#clientcontact20_div').is(':visible')) {
      objParams.clientcontact = clientcontact;
    }
    var email = $.trim($('#email23').val());
    var obj = {}
    if ($('#email23_div').is(':visible')) {
      if (email == '') {
        $('#email23_error').html('Email is required');
        $('#email23_error').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email23_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else {
        $('#email23_error').hide();
      }
    }
    if ($('#email23_div').is(':visible')) {
      objParams.email = email;
    }
    var note = $.trim($('#note27').val());
    var obj = {}
    if ($('#note27_div').is(':visible')) {
      if (note == '') {
        $('#note27_error').show();
        if (!Object.keys(errorFields).length) errorFields['note27'] = 'divtag';
        validAll = false;
      } else {
        $('#note27_error').hide();
      }
    }
    if ($('#note27_div').is(':visible')) {
      objParams.note = note;
    }
    var slotdate = $.trim($('#slotdate7').val());
    var obj = {}
    if ($('#slotdate7_div').is(':visible')) {
      if (slotdate == '') {
        $('#slotdate7_error').show();
        if (!Object.keys(errorFields).length) errorFields['slotdate7'] = 'divtag';
        validAll = false;
      } else {
        $('#slotdate7_error').hide();
      }
    }
    if ($('#slotdate7_div').is(':visible')) {
      objParams.slotdate = slotdate;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var clientname = $.trim($('#clientname10').val());
    var obj = {}
    if ($('#clientname10_div').is(':visible')) {
      if (clientname == '') {
        $('#clientname10_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientname10'] = 'divtag';
        validAll = false;
      } else {
        $('#clientname10_error').hide();
      }
    }
    if ($('#clientname10_div').is(':visible')) {
      objParams.clientname = clientname;
    }
    var policytype_name = $.trim($('#policytype_name11').val());
    var obj = {}
    if ($('#policytype_name11_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name11'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name11_error').hide();
      }
    }
    if ($('#policytype_name11_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var name = $.trim($('#name17').val());
    var obj = {}
    if ($('#name17_div').is(':visible')) {
      if (name == '') {
        $('#name17_error').show();
        if (!Object.keys(errorFields).length) errorFields['name17'] = 'divtag';
        validAll = false;
      } else {
        $('#name17_error').hide();
      }
    }
    if ($('#name17_div').is(':visible')) {
      objParams.name = name;
    }
    var clientcontact = $.trim($('#clientcontact20').val());
    var obj = {}
    if ($('#clientcontact20_div').is(':visible')) {
      if (clientcontact == '') {
        $('#clientcontact20_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientcontact20'] = 'divtag';
        validAll = false;
      } else {
        $('#clientcontact20_error').hide();
      }
    }
    if ($('#clientcontact20_div').is(':visible')) {
      var dialCode = $('#clientcontact20').attr('dialCode');
      var countryCode = $('#clientcontact20').attr('countryCode');
      var placeholder = $('#clientcontact20').attr('placeholder');
      clientcontact = clientcontact.replace(/[^0-9]/gi, '');
      placeholder = placeholder.replace(/[^0-9]/gi, '');
      if (placeholder.length != clientcontact.length) {
        $('#clientcontact20_error').html('Valid orders_clientcontact is required').show();
        $('#clientcontact20').fadeIn(1000);
        errorFields.push('clientcontact20');
      }
      clientcontact = '+' + dialCode + clientcontact;
      objParams.clientcontact_dialcode = dialCode;
      objParams.clientcontact_countrycode = countryCode;
    }
    if ($('#clientcontact20_div').is(':visible')) {
      objParams.clientcontact = clientcontact;
    }
    var email = $.trim($('#email23').val());
    var obj = {}
    if ($('#email23_div').is(':visible')) {
      if (email == '') {
        $('#email23_error').html('Email is required');
        $('#email23_error').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email23_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else {
        $('#email23_error').hide();
      }
    }
    if ($('#email23_div').is(':visible')) {
      objParams.email = email;
    }
    var note = $.trim($('#note27').val());
    var obj = {}
    if ($('#note27_div').is(':visible')) {
      if (note == '') {
        $('#note27_error').show();
        if (!Object.keys(errorFields).length) errorFields['note27'] = 'divtag';
        validAll = false;
      } else {
        $('#note27_error').hide();
      }
    }
    if ($('#note27_div').is(':visible')) {
      objParams.note = note;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var policytype_name = $.trim($('#policytype_name11').val());
    var obj = {}
    if ($('#policytype_name11_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name11'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name11_error').hide();
      }
    }
    if ($('#policytype_name11_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var name = $.trim($('#name17').val());
    var obj = {}
    if ($('#name17_div').is(':visible')) {
      if (name == '') {
        $('#name17_error').show();
        if (!Object.keys(errorFields).length) errorFields['name17'] = 'divtag';
        validAll = false;
      } else {
        $('#name17_error').hide();
      }
    }
    if ($('#name17_div').is(':visible')) {
      objParams.name = name;
    }
    var clientcontact = $.trim($('#clientcontact20').val());
    var obj = {}
    if ($('#clientcontact20_div').is(':visible')) {
      if (clientcontact == '') {
        $('#clientcontact20_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientcontact20'] = 'divtag';
        validAll = false;
      } else {
        $('#clientcontact20_error').hide();
      }
    }
    if ($('#clientcontact20_div').is(':visible')) {
      var dialCode = $('#clientcontact20').attr('dialCode');
      var countryCode = $('#clientcontact20').attr('countryCode');
      var placeholder = $('#clientcontact20').attr('placeholder');
      clientcontact = clientcontact.replace(/[^0-9]/gi, '');
      placeholder = placeholder.replace(/[^0-9]/gi, '');
      if (placeholder.length != clientcontact.length) {
        $('#clientcontact20_error').html('Valid orders_clientcontact is required').show();
        $('#clientcontact20').fadeIn(1000);
        errorFields.push('clientcontact20');
      }
      clientcontact = '+' + dialCode + clientcontact;
      objParams.clientcontact_dialcode = dialCode;
      objParams.clientcontact_countrycode = countryCode;
    }
    if ($('#clientcontact20_div').is(':visible')) {
      objParams.clientcontact = clientcontact;
    }
    var email = $.trim($('#email23').val());
    var obj = {}
    if ($('#email23_div').is(':visible')) {
      if (email == '') {
        $('#email23_error').html('Email is required');
        $('#email23_error').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email23_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else {
        $('#email23_error').hide();
      }
    }
    if ($('#email23_div').is(':visible')) {
      objParams.email = email;
    }
    var note = $.trim($('#note27').val());
    var obj = {}
    if ($('#note27_div').is(':visible')) {
      if (note == '') {
        $('#note27_error').show();
        if (!Object.keys(errorFields).length) errorFields['note27'] = 'divtag';
        validAll = false;
      } else {
        $('#note27_error').hide();
      }
    }
    if ($('#note27_div').is(':visible')) {
      objParams.note = note;
    }
    var policytype_name = $.trim($('#policytype_name11').val());
    var obj = {}
    if ($('#policytype_name11_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name11'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name11_error').hide();
      }
    }
    if ($('#policytype_name11_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var slotdate = $.trim($('#slotdate7').val());
    var obj = {}
    if ($('#slotdate7_div').is(':visible')) {
      if (slotdate == '') {
        $('#slotdate7_error').show();
        if (!Object.keys(errorFields).length) errorFields['slotdate7'] = 'divtag';
        validAll = false;
      } else {
        $('#slotdate7_error').hide();
      }
    }
    if ($('#slotdate7_div').is(':visible')) {
      objParams.slotdate = slotdate;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var clientname = $.trim($('#clientname10').val());
    var obj = {}
    if ($('#clientname10_div').is(':visible')) {
      if (clientname == '') {
        $('#clientname10_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientname10'] = 'divtag';
        validAll = false;
      } else {
        $('#clientname10_error').hide();
      }
    }
    if ($('#clientname10_div').is(':visible')) {
      objParams.clientname = clientname;
    }
    var policytype_name = $.trim($('#policytype_name11').val());
    var obj = {}
    if ($('#policytype_name11_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name11'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name11_error').hide();
      }
    }
    if ($('#policytype_name11_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var name = $.trim($('#name17').val());
    var obj = {}
    if ($('#name17_div').is(':visible')) {
      if (name == '') {
        $('#name17_error').show();
        if (!Object.keys(errorFields).length) errorFields['name17'] = 'divtag';
        validAll = false;
      } else {
        $('#name17_error').hide();
      }
    }
    if ($('#name17_div').is(':visible')) {
      objParams.name = name;
    }
    var clientcontact = $.trim($('#clientcontact20').val());
    var obj = {}
    if ($('#clientcontact20_div').is(':visible')) {
      if (clientcontact == '') {
        $('#clientcontact20_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientcontact20'] = 'divtag';
        validAll = false;
      } else {
        $('#clientcontact20_error').hide();
      }
    }
    if ($('#clientcontact20_div').is(':visible')) {
      var dialCode = $('#clientcontact20').attr('dialCode');
      var countryCode = $('#clientcontact20').attr('countryCode');
      var placeholder = $('#clientcontact20').attr('placeholder');
      clientcontact = clientcontact.replace(/[^0-9]/gi, '');
      placeholder = placeholder.replace(/[^0-9]/gi, '');
      if (placeholder.length != clientcontact.length) {
        $('#clientcontact20_error').html('Valid orders_clientcontact is required').show();
        $('#clientcontact20').fadeIn(1000);
        errorFields.push('clientcontact20');
      }
      clientcontact = '+' + dialCode + clientcontact;
      objParams.clientcontact_dialcode = dialCode;
      objParams.clientcontact_countrycode = countryCode;
    }
    if ($('#clientcontact20_div').is(':visible')) {
      objParams.clientcontact = clientcontact;
    }
    var email = $.trim($('#email23').val());
    var obj = {}
    if ($('#email23_div').is(':visible')) {
      if (email == '') {
        $('#email23_error').html('Email is required');
        $('#email23_error').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email23_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else {
        $('#email23_error').hide();
      }
    }
    if ($('#email23_div').is(':visible')) {
      objParams.email = email;
    }
    var note = $.trim($('#note27').val());
    var obj = {}
    if ($('#note27_div').is(':visible')) {
      if (note == '') {
        $('#note27_error').show();
        if (!Object.keys(errorFields).length) errorFields['note27'] = 'divtag';
        validAll = false;
      } else {
        $('#note27_error').hide();
      }
    }
    if ($('#note27_div').is(':visible')) {
      objParams.note = note;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var policytype_name = $.trim($('#policytype_name11').val());
    var obj = {}
    if ($('#policytype_name11_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name11'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name11_error').hide();
      }
    }
    if ($('#policytype_name11_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var name = $.trim($('#name17').val());
    var obj = {}
    if ($('#name17_div').is(':visible')) {
      if (name == '') {
        $('#name17_error').show();
        if (!Object.keys(errorFields).length) errorFields['name17'] = 'divtag';
        validAll = false;
      } else {
        $('#name17_error').hide();
      }
    }
    if ($('#name17_div').is(':visible')) {
      objParams.name = name;
    }
    var clientcontact = $.trim($('#clientcontact20').val());
    var obj = {}
    if ($('#clientcontact20_div').is(':visible')) {
      if (clientcontact == '') {
        $('#clientcontact20_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientcontact20'] = 'divtag';
        validAll = false;
      } else {
        $('#clientcontact20_error').hide();
      }
    }
    if ($('#clientcontact20_div').is(':visible')) {
      var dialCode = $('#clientcontact20').attr('dialCode');
      var countryCode = $('#clientcontact20').attr('countryCode');
      var placeholder = $('#clientcontact20').attr('placeholder');
      clientcontact = clientcontact.replace(/[^0-9]/gi, '');
      placeholder = placeholder.replace(/[^0-9]/gi, '');
      if (placeholder.length != clientcontact.length) {
        $('#clientcontact20_error').html('Valid orders_clientcontact is required').show();
        $('#clientcontact20').fadeIn(1000);
        errorFields.push('clientcontact20');
      }
      clientcontact = '+' + dialCode + clientcontact;
      objParams.clientcontact_dialcode = dialCode;
      objParams.clientcontact_countrycode = countryCode;
    }
    if ($('#clientcontact20_div').is(':visible')) {
      objParams.clientcontact = clientcontact;
    }
    var email = $.trim($('#email23').val());
    var obj = {}
    if ($('#email23_div').is(':visible')) {
      if (email == '') {
        $('#email23_error').html('Email is required');
        $('#email23_error').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email23_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email23'] = 'divtag';
        validAll = false;
      } else {
        $('#email23_error').hide();
      }
    }
    if ($('#email23_div').is(':visible')) {
      objParams.email = email;
    }
    var note = $.trim($('#note27').val());
    var obj = {}
    if ($('#note27_div').is(':visible')) {
      if (note == '') {
        $('#note27_error').show();
        if (!Object.keys(errorFields).length) errorFields['note27'] = 'divtag';
        validAll = false;
      } else {
        $('#note27_error').hide();
      }
    }
    if ($('#note27_div').is(':visible')) {
      objParams.note = note;
    }
    var ordersnumber = $.trim($('#ordersnumber14').val());
    var obj = {}
    if ($('#ordersnumber14_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber14_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber14'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber14_error').hide();
      }
    }
    if ($('#ordersnumber14_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var note = $.trim($('#note27').val());
    var obj = {}
    if ($('#note27_div').is(':visible')) {
      if (note == '') {
        $('#note27_error').show();
        if (!Object.keys(errorFields).length) errorFields['note27'] = 'divtag';
        validAll = false;
      } else {
        $('#note27_error').hide();
      }
    }
    if ($('#note27_div').is(':visible')) {
      objParams.note = note;
    }
    var tempobjParams = getParams(window.location.href)
    function extend(obj, src) {
      for (var key in src) {
        if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
      }
      return obj;
    }
    objParams = extend(objParams, tempobjParams);
    var recordID = $('#recordID').val();
    objParams.isDelete = 0;
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParams.tokenKey = getParameterByName('tokenKey');
    objParams.secretKey = getParameterByName('secretKey');
    objParams.offlineDataID = localStorage.getItem("offlineDataID");
    var queryMode = getParameterByName('queryMode')
    if (queryMode == 'add') {
      objParams.callUrl = ajaXCallURL + '/milestone003/saveAjaxordersordersrejectedapp_consultantappointment2details';
    } else {
      objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxordersordersrejectedapp_consultantappointment2details';
      objParams.recordID = recordID;
    }
    if (errorFields && Object.keys(errorFields).length) {
      $('#display_loading1').addClass('hideme');
      for (var firstErrorField in errorFields) {
        var controlType = errorFields[firstErrorField];
        errorFields = []
        var errField = $('#' + firstErrorField);
        if (controlType == 'dropdown') {
          errField.prev().prev().focus();
        } else {
          errField.focus()
        }
        validAll = true;
        return false;
      }
    }
    if (!validAll) {
      validAll = true;
      return false;
    }
    $('#reject30').prop('disabled', true);
    $('#display_loading1').removeClass('hideme');
    if (addSessionComments.length > 0) {
      objParams.addSessionComments = addSessionComments;
    } else {
      objParams.addSessionComments = [];
    }
    var parentID = $('#parentID').val();
    var parentName = $('#parentName').val();
    if (parentID != '') {
      objParams.parentID = parentID;
      objParams.parentName = parentName
    }
    if (typeof (addedFiles) != "undefined" && addedFiles && addedFiles.length > 0) {
      objParams.addedFiles = addedFiles;
    }
    objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    objParams.organizationID = $("#organizationID").val();;
    objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    objParams.organizationID = $("#organizationID").val();;
    processBeforeCallForSaveordersrejected(objParams, {}, function (processBeforeRes) {
      $.ajax({
        url: objParams.callUrl,
        data: objParams,
        type: 'POST',
        success: function (response) {
          if (response.status == 0) {
            $('#display_loading1').addClass('hideme');
            response.nextPage = 'app_consultantacceptappointmentslisting'
            processAfterCallForSaveordersrejected(response, function (processAfterRes) {
              var tokenKey = getParameterByName('tokenKey');
              var secretKey = getParameterByName('secretKey');
              var queryMode = getParameterByName('queryMode');
              queryMode = queryMode.replace('edit', '');
              localStorage.setItem("headerPageName", 'app_consultantacceptappointmentslisting');
              var queryString = window.location.search.slice(1);
              var newQuery = queryString + '&queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey
              var queryParams = queryStringToJSON(newQuery);
              queryString = $.param(queryParams);
              queryString = queryString.replace(/\+/g, "%20");
              queryString = decodeURIComponent(queryString);
              if (recordID == '') {
                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
              } else {
                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
              }
              return false;
            }); // End of After Process
          } else {
            $('#display_loading1').addClass('hideme');
            $('#2656d_error').html(response.error);
            $('#2656d_error').show();
          }
          $('#reject30').removeProp('disabled');
        },
        error: function (xhr, status, error) {
          $('#display_loading1').addClass('hideme');
          $('#reject30').removeProp('disabled');
        },
      });
      return false;
    }); // End of Before Process
  });//end of Event Reject_is_click 
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#backbutton1', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_consultantacceptappointmentslisting';
                 
                 var activemenu =  localStorage.getItem("activeMenu")
                 if(activemenu == "Home" )
                 {
                 var roleName = localStorage.getItem('roleName');
                 if (roleName == "consultant") {
                 nextPage =  "app_consultantuserhome";
                 
                 }
                 else
                 {
                 nextPage =  "app_userhome";
                 }
                 
                 
                 }
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error)
    }
  })
  var paramsEdit = {};
  paramsEdit.tokenKey = getParameterByName('tokenKey');
  paramsEdit.secretKey = getParameterByName('secretKey')
  getRecordByIDProcessBeforeCall220345(paramsEdit, function (processBeforeRes) {
    $.ajax({
      url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_consultantappointment2details_Orders5da73cac545050343288ce7a',
      data: paramsEdit,
      type: 'POST',
      jsonpCallback: 'callback',
      success: function (response) {
        getRecordByIDProcessAfterCall220345(response, function (processBeforeRes) {
          if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
            var objParamsList = {};
            var queryMode = $('#queryMode').val();
            objParamsList.queryMode = queryMode;;
            var tokenKey = $('#tokenKey').val();;
            objParamsList.tokenKey = tokenKey;;
          
            if(response.recordDetails.status && response.recordDetails.status != "Requested")
            {
              $("#accept29").hide()
              $("#reject30").hide()
            }
           
            if (!$('#appointmentid13').html()) {
              $('#appointmentid13').append(response.recordDetails.undefined);
            }
            if (!$('#appointmentsdetails2').html()) {
              $('#appointmentsdetails2').append(response.recordDetails.undefined);
            }
            if (!$('#backbutton1').html()) {
              $('#backbutton1').append(response.recordDetails.undefined);
            }
            if (!$('#consultant16').html()) {
              $('#consultant16').append(response.recordDetails.undefined);
            }
            if (!$('#emailaddress22').html()) {
              $('#emailaddress22').append(response.recordDetails.undefined);
            }
            if (!$('#mobilenumber19').html()) {
              $('#mobilenumber19').append(response.recordDetails.undefined);
            }
            if (!$('#notes25').html()) {
              $('#notes25').append(response.recordDetails.undefined);
            }
            if (!$('#clientcontact20').html()) {
              $('#clientcontact20').append(response.recordDetails.clientcontact);
            }
            if (!$('#clientname10').html()) {
              $('#clientname10').append('<span class="prefixlink">Meeting with</span>' + response.recordDetails.clientname);
            }
            if (!$('#name17').html()) {
              $('#name17').append(response.recordDetails.name);
            }
            response.recordDetails['slotdate_preserved'] = response.recordDetails['slotdate'];
            response.recordDetails['slotdate'] = response.recordDetails['slotdate'] ? moment(new Date(response.recordDetails['slotdate'])).format('DD MMM YYYY') : '';
            if (!$('#slotdate7').html()) {
              $('#slotdate7').append(response.recordDetails.slotdate);
            }
            response.recordDetails['slotdate'] = response.recordDetails['slotdate_preserved'];
            if (!$('#email23').html()) {
              $('#email23').append('<a id="emailImg" class="mailtolink" href="mailto:' + response.recordDetails.email + '">' + response.recordDetails.email + '</a>');
            }
            if (!$('#note27').html()) {
              $('#note27').append(response.recordDetails.note);
            }
            if (!$('#ordersnumber14').html()) {
              $('#ordersnumber14').append(response.recordDetails.ordersnumber);
            }
            if (!$('#policytype_name11').html()) {
              $('#policytype_name11').append(response.recordDetails.policytype_name);
            }
            if (!$('#starttime8').html()) {
              $('#starttime8').append('<span class="prefixlink">Time</span>' + response.recordDetails.starttime);
            }

            Materialize.updateTextFields();
            $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

          }
        }); // end of getRecord By ID
      },
      error: function (xhr, status, error) {
        handleError(xhr, status, error);
      },
    });
  }); // end of getRecord By ID

});//end of ready
function getParams(url) {
  var urlParams = {};
  url.replace(
    new RegExp("([^?=&]+)(=([^&]*))?", "g"),
    function ($0, $1, $2, $3) {
      if ($3 && $3 != 'undefined') urlParams[$1] = $3;
    }
  );
  return urlParams;
}
function processBeforeCallForSaveordersacceptednew(objParams, response, callback) {


  objParams.status = 'Accepted';

  callback();
}
function processAfterCallForSaveordersacceptednew(response, callback) {

  callback();
}
function getParams(url) {
  var urlParams = {};
  url.replace(
    new RegExp("([^?=&]+)(=([^&]*))?", "g"),
    function ($0, $1, $2, $3) {
      if ($3 && $3 != 'undefined') urlParams[$1] = $3;
    }
  );
  return urlParams;
}
function processBeforeCallForSaveordersrejected(objParams, response, callback) {


  objParams.status = 'Rejected';

  callback();
}
function processAfterCallForSaveordersrejected(response, callback) {

  callback();
}
function getRecordByIDProcessBeforeCall220345(paramsType, callback) {
  var response = paramsType;

  if (getParameterByName('ordersid') && getParameterByName('ordersid') != 'undefined') { paramsType.recordID = getParameterByName('ordersid') } else if (getParameterByName('recordID') && getParameterByName('recordID') != 'undefined') { paramsType.recordID = getParameterByName('recordID') }; callback();
}
function getRecordByIDProcessAfterCall220345(response, callback) {
  callback();
}
