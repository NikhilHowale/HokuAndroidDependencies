
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_consultantcustmoreinfodetails'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "update"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
      var paramsEdit = {};
      paramsEdit.tokenKey = getParameterByName('tokenKey');
      paramsEdit.secretKey = getParameterByName('secretKey') 
                       getRecordByIDProcessBeforeCall982279(paramsEdit, function (processBeforeRes) {
      $.ajax({
          url: ajaXCallURL+'/milestone003/getRecordByCustomeQuery_app_consultantworkingofflinedetails_Bazaar5da73cac545050343288ce7a',
          data: paramsEdit,
          type: 'POST',
          jsonpCallback: 'callback',
          success: function (response) { 
                       getRecordByIDProcessAfterCall982279(response, function (processBeforeRes) {
              if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                  var objParamsList = {};
                  var queryMode = $('#queryMode').val(); 
                  objParamsList.queryMode = queryMode;;
                  var tokenKey = $('#tokenKey').val();;
                  objParamsList.tokenKey = tokenKey;;
  if(!$('#anychangesintheappwillbebasedonthepreviousreleasehoweverincaseyoustillcannotfindthetoolfunctionyoucancontactyoursupportteamforinformationonthelatestreleasedetailsitisalsoadvisedtoreadallversionreleaseinformationtokeepyourselfupdatedonpertinentchanges18').html()){
            $('#anychangesintheappwillbebasedonthepreviousreleasehoweverincaseyoustillcannotfindthetoolfunctionyoucancontactyoursupportteamforinformationonthelatestreleasedetailsitisalsoadvisedtoreadallversionreleaseinformationtokeepyourselfupdatedonpertinentchanges18').append(response.recordDetails.undefined);
 }
  if(!$('#anychangesthatyoumakeintheappinofflinemodewillnotbepushedforwarduntilanetworkconnectionisreestablishedoncethemobileapplicationisconnectedtoanetworktheappwillsynchronizeautomaticallyandalldatawillbedisplayedtoallusers31').html()){
            $('#anychangesthatyoumakeintheappinofflinemodewillnotbepushedforwarduntilanetworkconnectionisreestablishedoncethemobileapplicationisconnectedtoanetworktheappwillsynchronizeautomaticallyandalldatawillbedisplayedtoallusers31').append(response.recordDetails.undefined);
 }
  if(!$('#anychangesthatyoumakeintheappinofflinemodewillnotbepushedforwarduntilanetworkconnectionisreestablishedoncethemobileapplicationisconnectedtoanetworktheappwillsynchronizeautomaticallyandalldatawillbedisplayedtoallusers34').html()){
            $('#anychangesthatyoumakeintheappinofflinemodewillnotbepushedforwarduntilanetworkconnectionisreestablishedoncethemobileapplicationisconnectedtoanetworktheappwillsynchronizeautomaticallyandalldatawillbedisplayedtoallusers34').append(response.recordDetails.undefined);
 }
  if(!$('#appfunctionalitywillbelimitedwhennotconnectedtotheinternetaswithanycloudtechnologynetworkconnectivityisarequisitetoappproductivity9').html()){
            $('#appfunctionalitywillbelimitedwhennotconnectedtotheinternetaswithanycloudtechnologynetworkconnectivityisarequisitetoappproductivity9').append(response.recordDetails.undefined);
 }
  if(!$('#arefaqsavailableformyofflineusers32').html()){
            $('#arefaqsavailableformyofflineusers32').append(response.recordDetails.undefined);
 }
  if(!$('#backbutton1').html()){
            $('#backbutton1').append(response.recordDetails.undefined);
 }
  if(!$('#caniusetheappwhenihavenonetworkconnectivity7').html()){
            $('#caniusetheappwhenihavenonetworkconnectivity7').append(response.recordDetails.undefined);
 }
  if(!$('#howtoforcequitonanandroiddevice26').html()){
            $('#howtoforcequitonanandroiddevice26').append(response.recordDetails.undefined);
 }
  if(!$('#howtoforcequitonaniosdevice23').html()){
            $('#howtoforcequitonaniosdevice23').append(response.recordDetails.undefined);
 }
           var url = 'icon_workoffline.png'
          $('#iconworkoffline6').attr("src", url);
  if(!$('#ifyouknowthatyourworkwilltakeyoutoalocationwithlimitednetworkconnectivityyoushouldviewtheinformationthatmightbeofusewhenyouareonlineonceinofflinemodeyourappwilldisplayallcacheditemsaccessedpreviously12').html()){
            $('#ifyouknowthatyourworkwilltakeyoutoalocationwithlimitednetworkconnectivityyoushouldviewtheinformationthatmightbeofusewhenyouareonlineonceinofflinemodeyourappwilldisplayallcacheditemsaccessedpreviously12').append(response.recordDetails.undefined);
 }
  if(!$('#nowhileafewfunctionslikeformsandreportswillbecachedcloudfunctionsandtoolswillbeunavailableforuse15').html()){
            $('#nowhileafewfunctionslikeformsandreportswillbecachedcloudfunctionsandtoolswillbeunavailableforuse15').append(response.recordDetails.undefined);
 }
  if(!$('#one1logoutoftheappandsignbackin2turnyourmobiledeviceoffwaitfor10secondsandthenthedevicebackon3turnmobiledataoffwaittensecondsandthenturnitbackon4forcequitstoptheapponyourdevice22').html()){
            $('#one1logoutoftheappandsignbackin2turnyourmobiledeviceoffwaitfor10secondsandthenthedevicebackon3turnmobiledataoffwaittensecondsandthenturnitbackon4forcequitstoptheapponyourdevice22').append(response.recordDetails.undefined);
 }
  if(!$('#stepstotakeifyouareinalocationwithlimitednetworkconnectivity10').html()){
            $('#stepstotakeifyouareinalocationwithlimitednetworkconnectivity10').append(response.recordDetails.undefined);
 }
  if(!$('#troubleshootingsolutions19').html()){
            $('#troubleshootingsolutions19').append(response.recordDetails.undefined);
 }
  if(!$('#tryanyoralltostartworkinginofflinemode20').html()){
            $('#tryanyoralltostartworkinginofflinemode20').append(response.recordDetails.undefined);
 }
  if(!$('#whataboutdatasynchronization29').html()){
            $('#whataboutdatasynchronization29').append(response.recordDetails.undefined);
 }
  if(!$('#whatifmyappversionisdifferentfromthelatestrelease16').html()){
            $('#whatifmyappversionisdifferentfromthelatestrelease16').append(response.recordDetails.undefined);
 }
  if(!$('#willtheofflinemodefunctionthesameaswheniamonline13').html()){
            $('#willtheofflinemodefunctionthesameaswheniamonline13').append(response.recordDetails.undefined);
 }
  if(!$('#workingoffline2').html()){
            $('#workingoffline2').append(response.recordDetails.undefined);
 }
  if(!$('#gotosettingsfindandselectappsandnotificationshereyoullfindallapplicationsrunningonyourdevicetapontherelevantappandclickonforcestoptoclosetheapplication28').html()){
            $('#gotosettingsfindandselectappsandnotificationshereyoullfindallapplicationsrunningonyourdevicetapontherelevantappandclickonforcestoptoclosetheapplication28').append(response.recordDetails.undefined);
 }
  if(!$('#viewrecentlyusedappsbydoubletappingthehomebuttonfindtherelevantscreenshotandswipeupwardstodismisstheappyoucannowpressthehomeicontoreturntothehomescreen25').html()){
            $('#viewrecentlyusedappsbydoubletappingthehomebuttonfindtherelevantscreenshotandswipeupwardstodismisstheappyoucannowpressthehomeicontoreturntothehomescreen25').append(response.recordDetails.undefined);
 }

              Materialize.updateTextFields();
                $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);
  
              } 
              }); // end of getRecord By ID
          },
          error: function (xhr, status, error) {
              handleError(xhr, status, error); 
          },
      }); 
              }); // end of getRecord By ID
   
});//end of ready 
                 function getRecordByIDProcessBeforeCall982279(paramsType,callback) { 
                 var response = paramsType;
 
if(getParameterByName('bazaarid') && getParameterByName('bazaarid') != 'undefined'){paramsType.recordID = getParameterByName('bazaarid')} else if(getParameterByName('recordID') && getParameterByName('recordID') != 'undefined'){paramsType.recordID = getParameterByName('recordID')};callback(); 
                 } 
                 function getRecordByIDProcessAfterCall982279(response,callback) {
 callback(); 
                 }