
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_consultanthandovervoucherlisting'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
      var paramsEdit = {};
      paramsEdit.tokenKey = getParameterByName('tokenKey');
      paramsEdit.secretKey = getParameterByName('secretKey') 
                       getRecordByIDProcessBeforeCall239684(paramsEdit, function (processBeforeRes) {
      $.ajax({
          url: ajaXCallURL+'/milestone003/getRecordByCustomeQuery_app_handedovervoucherdetails_Orders5da73cac545050343288ce7a',
          data: paramsEdit,
          type: 'POST',
          jsonpCallback: 'callback',
          success: function (response) { 
                       getRecordByIDProcessAfterCall239684(response, function (processBeforeRes) {
              if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                  var objParamsList = {};
                  var queryMode = $('#queryMode').val(); 
                  objParamsList.queryMode = queryMode;;
                  var tokenKey = $('#tokenKey').val();;
                  objParamsList.tokenKey = tokenKey;;
  if(!$('#backbutton1').html()){
            $('#backbutton1').append(response.recordDetails.undefined);
 }
  if(!$('#expireson17').html()){
            $('#expireson17').append(response.recordDetails.undefined);
 }
  if(!$('#handoverdate23').html()){
            $('#handoverdate23').append(response.recordDetails.undefined);
 }
    // getrecordbycustomquery - Stage - 111111111111
    if(response.recordDetails['imageupload'] && response.recordDetails['imageupload'].length > 0 ) {
    	if(response.recordDetails['imageupload'][0].displayType = 'html'){
    		var eleParent = $('#imageupload6').parent();
    	    for(var key in response.recordDetails['imageupload']){
    	        var objImage = response.recordDetails['imageupload'][key];
if(response.recordDetails['imageupload'][key].name=='Audio'){
         var token =  $('#tokenKey').val();
         if( token && token != '' ){
             token = $('#tokenKey').val();
         }else {
             token = getParameterByName('tokenKey');
         }
         var mediaIDa = response.recordDetails['imageupload'][0].mediaID
         var filenamea = response.recordDetails['imageupload'][0].fileName
          var CDN_PATH2 = 'https://devfiles.hokuapps.com/downloadOriginal?f='+mediaIDa+'&fn='+filenamea+'&t='+token
          var url = CDN_PATH2
}else{
 var filetodisplay = getuploadedfilepreview(objImage.fileNm); 
 if(filetodisplay && filetodisplay != objImage.fileNm){
          var url = filetodisplay ;
 } else {
          var url = CDN_PATH + objImage.mediaID+'_compressed.png';
 }
}
if(response.recordDetails['imageupload'][key].name=='Audio'){
    	        var html = '';
               html+='<div class="col s12" style="float: right;">'
               html+='<audio class="" src="' + url + '" controls></audio>'
               html+='</div>'
}else{
               var html = '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + url + '" />';
}
    	        if(!key || key == '0'){
    	        	eleParent.html(html);
    	        } else {
    	        	eleParent.append(html);
    	        } 
    	    }                
    	} else {
if(response.recordDetails['imageupload'][key].name=='Audio'){
    	    var url = CDN_PATH + response.recordDetails['imageupload'][0].mediaID;
}else{
    	    var url = CDN_PATH + response.recordDetails['imageupload'][0].mediaID+'_compressed.png';
}
    	    $('#imageupload6').attr("src", url);
    	}
    } 
 response.recordDetails['createdOn_preserved'] = response.recordDetails['createdOn'] ;
 response.recordDetails['createdOn'] = response.recordDetails['createdOn']  ? moment(new Date(response.recordDetails['createdOn'])).format('DD MMMM YYYY hh:mm A') : '';
  if(!$('#createdOn8').html()){
            $('#createdOn8').append(response.recordDetails.createdOn);
 }
 response.recordDetails['createdOn'] =  response.recordDetails['createdOn_preserved'];
 response.recordDetails['expirationdate_preserved'] = response.recordDetails['expirationdate'] ;
 response.recordDetails['expirationdate'] = response.recordDetails['expirationdate']  ? moment(new Date(response.recordDetails['expirationdate'])).format('DD MMM YYYY') : '';
  if(!$('#expirationdate18').html()){
            $('#expirationdate18').append(response.recordDetails.expirationdate);
 }
 response.recordDetails['expirationdate'] =  response.recordDetails['expirationdate_preserved'];
 response.recordDetails['handoverdate_preserved'] = response.recordDetails['handoverdate'] ;
 response.recordDetails['handoverdate'] = response.recordDetails['handoverdate']  ? moment(new Date(response.recordDetails['handoverdate'])).format('DD MMM YYYY') : '';
  if(!$('#handoverdate24').html()){
            $('#handoverdate24').append(response.recordDetails.handoverdate);
 }
 response.recordDetails['handoverdate'] =  response.recordDetails['handoverdate_preserved'];
  if(!$('#name10').html()){
            $('#name10').append(response.recordDetails.name);
 }
  if(!$('#outlets21').html()){
            if(!response.recordDetails.outlets){
            	response.recordDetails.outlets = '0';
            }
            $('#outlets21').append(response.recordDetails.outlets);
 }
              response.recordDetails.price = getCurrancy(response.recordDetails.price, 'USD','$'); 
  if(!$('#price15').html()){
            $('#price15').append(response.recordDetails.price);
 }
  if(!$('#status9').html()){
            $('#status9').append(response.recordDetails.status);
 }
  if(!$('#termsandconditions28').html()){
            $('#termsandconditions28').append(response.recordDetails.termsandconditions);
 }
  if(!$('#outlets20').html()){
            $('#outlets20').append(response.recordDetails.undefined);
 }
  if(!$('#termsconditions26').html()){
            $('#termsconditions26').append(response.recordDetails.undefined);
 }
  if(!$('#vouchercost14').html()){
            $('#vouchercost14').append(response.recordDetails.undefined);
 }
  if(!$('#voucherdetails12').html()){
            $('#voucherdetails12').append(response.recordDetails.undefined);
 }
  if(!$('#voucherdetails2').html()){
            $('#voucherdetails2').append(response.recordDetails.undefined);
 }

              Materialize.updateTextFields();
                $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);
  
              } 
              }); // end of getRecord By ID
          },
          error: function (xhr, status, error) {
              handleError(xhr, status, error); 
          },
      }); 
              }); // end of getRecord By ID
   
});//end of ready 
                 function getRecordByIDProcessBeforeCall239684(paramsType,callback) { 
                 var response = paramsType;
 
if(getParameterByName('ordersid') && getParameterByName('ordersid') != 'undefined'){paramsType.recordID = getParameterByName('ordersid')} else if(getParameterByName('recordID') && getParameterByName('recordID') != 'undefined'){paramsType.recordID = getParameterByName('recordID')};callback(); 
                 } 
                 function getRecordByIDProcessAfterCall239684(response,callback) {
 callback(); 
                 }