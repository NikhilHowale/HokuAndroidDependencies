
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
  function changeRangeDateChangeCallbackslotdate6(target,range) {
      var date = moment(range.start).format('DD MMM YYYY');
      $('#slotdate6bookdate13').val(date);
      $('#selectedDate').html(date);
      if(date != undefined && date != ''){
         getTimeSlots_Detailsslotdate6($('#slotdate6bookdate13').val());
      }
  }
$(document).ready(function() {
    $('#slotdate6').rangeCalendar({
                       startRangeWidth:1,
                       weekends:true,
                       start:'+0',
                       endDate: moment().add('days', 5),
                       width:'280px',
                       cellWidth:70,
                       theme:'red-light-theme',
                       changeRangeCallback:changeRangeDateChangeCallbackslotdate6
      });
    $('.datepicker2').pickadate({
                      selectMonths: true,
                       selectYears: 200,
                       dateFormat: 'd mmmm, yyyy',
                       min:new Date(),
                       max:new Date(moment().add('days', 4)),
                       onSet: function (arg) {
                         if ('select' in arg) {
                            this.close();
                         }
                        }
      });
      $('#slotdate6bookdate13').val(moment().format('DD MMM YYYY'));
      $(document).on('change', '#slotdate6bookdate13', function () {
         var date = $('#slotdate6bookdate13').val();
             if(date != undefined && date != ''){
                 var dateId = moment(date).format('YYYYMMD');
                 var dateCell = $('#slotdate6').find('.cell[date-id='+dateId+']');
                 dateCell.trigger('click');
             }
             return false;
        });
      $(document).on('click', '.slidercalenderIcon', function () {
         $('#slotdate6bookdate13').focus();
         return false;
      });
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = []; 
                 localStorage.removeItem('slotID'); 
                 $(document).on('click', '.slotsBtn', function () { 
                 		var recordID = $(this).attr('recordID'); 
                 		localStorage.setItem('slotID', recordID); 
                 		$('.slotsBtn').removeClass('selected'); 
                 		$(this).addClass('selected'); 
                 		return false; 
                 }); 
                 //getTimeSlots_Detailsslotdate6($('#slotdate6bookdate13').val()); 
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#continue12', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'paymentmethodlist'; 
				var queryParams = queryStringToJSON(); 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
      		var objResponse = {};
      		objResponse.recordID = recordID;
      		pageredirectProcessBeforeCallCONTINUE(element, queryParams,objResponse, function(updatedNextPage){
     		 	if(objResponse.nextPage){
     		 		nextPage = objResponse.nextPage
     		 	}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
    		}) 
		} catch(error){ 
			console.log("Error in pageredirect workflow - continue12", error) 
		} 
	})
});//end of ready 
                 function getTimeSlots_Detailsslotdate6(slotdate) {  
                     var ajaXCallURL = $.trim($('#ajaXCallURL').val());  
                     var callUrl = ajaXCallURL + '/milestone003/getCalenderSlot_timeslots_Timeslotsdetails5da73cac545050343288ce7a' 
                     var objParams = {};  
                     objParams.tokenKey = getParameterByName('tokenKey');  
                     objParams.secretKey = getParameterByName('secretKey');  
                     objParams.queryMode = getParameterByName('queryMode');  
                     objParams.slotdate = slotdate;  
                     //objParams.slotdate = moment(new Date(slotdate)).utc().format('YYYY-MM-DDTHH:mm:ssZ'); 
                     objParams.deliveryslotconstraint = getParameterByName('deliveryslotconstraint');; 
                     $('#display_loading').removeClass('hideme');  
                     $.ajax({  
                         url: callUrl,  
                         data: objParams,  
                         type: 'POST',  
                         success: function (response) {  
                             //$('.slotsContainer').html(html);  
                             if (response.status != undefined && response.status == 0) {  
                               
                                 getshowTimeSlotlist1MobileViewslotdate6(response);  
                                 $('#display_loading').addClass('hideme');  
                             } else {  
                                 $('#display_loading').addClass('hideme');  
                             }  
                         },  
                         error: function (xhr, status, error) {  
                             $('#display_loading').addClass('hideme')  
                         },  
                     });  
                 }  
                   
 function getcalendarslotProcessBeforeCallTimeslotsdetails5da73cac545050343288ce7aslidercalender(objParams, callback) {
 callback(); 
 } 
                 function getshowTimeSlotlist1MobileViewslotdate6(response) {  
                     var html = '';  
                     if (response.data.length == 0) {  
                         html += '<div class="nodatafound">';  
                         html += '<span>No record found</span>';  
                         html += '</div>';  
                         $('.slotsContainer').html(html);  
                     } else {  
                         html = '';  
                         $.each(response.data, function (keyList, objList) {  
                             var openDeliver = 0;  
                             if (objList.opendelivery != undefined) {  
                                 openDeliver = parseInt(objList.opendelivery);  
                             }  
                             var hrs = moment(objList.starttime,'HH:mm a').format('HH');  
                             var min = moment(objList.starttime,'HH:mm a').format('mm');  
                             var date = new Date($('#slotdate6bookdate13').val());  
                             date.setHours(hrs);  
                             date.setMinutes(min);  
                             var diff = moment().diff(date, 'minutes');  
                             if(diff <= 0){  
                                 if(openDeliver <= 0){  
                                     html += '      <div class="slotsBtn disabled">';  
                                     html += '       <span class="btnText">' + objList.starttime+'-'+ objList.endtime + '</span>';  
                             		 html += '   </div>';  
                                 }else{  
                                     html += '    <div class="slotsBtn" recordID=' + objList._id + '>';  
                                     html += '       <span class="btnText">' + objList.starttime+'-'+ objList.endtime + '</span>';  
                             		 html += '   </div>';  
                                 }  
                             }  
                               
                         });  
                         $('.slotsContainer').html(html);  
                     };  
                 }; 
function pageredirectProcessBeforeCallCONTINUE(element, objParams,response,callback) {
	try{
 var slotID = localStorage.getItem('slotID');
if(slotID && slotID != 'undefined'){
	objParams.slotID = slotID;
	callback();
} else {
	shareAppData('No time slot is availble today', 'toast');
	return false;
}
	} catch(error) { 
		console.log('Error in pageredirectProcessBeforeCallCONTINUE', error);
		callback();
	}
}