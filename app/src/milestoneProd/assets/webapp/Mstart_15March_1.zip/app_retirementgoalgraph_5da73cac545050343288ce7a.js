$(document).ready(function () {
    var isPie2 = true
    financialCalculator = JSON.parse(localStorage.financialCalculator)
    var LeftForAgeCurrent = [];
    var CurrentLeft = [];
    var CurrentLeft2 = [];
    var YourGoalLeft = [];
    var YourGoalLeft2 = [];
    var YearlyExp = [];
    var YearlyExp2 = [];
    var annualExpensesArray = [];
    var objExpectedLumpsumat = [];
    var TotAnnAmtLeft = 0;
    var ageArray = [];
    console.log(financialCalculator)
    var currentAge = financialCalculator.iamcurrent;
    var RetireAge = financialCalculator.intendedRetireAge;


    var lumpsumhtmlproposed = `    <table style="width:90%;border: 1px solid black;border-collapse: collapse; margin-left: 5%;" id="minisummarytable">
    <tr   style="border: 1px solid black;border-collapse: collapse;background-color: #C3A468;color: white;margin-left: 5%;">
   
            <td colspan="3" style="width: 100%; border: 1px solid black;border-collapse: collapse;">
            Lumpsum
            </td>
          
    
    </tr>`;



    var lumpsumhtmlCurrentPolicies = `    <table style="width:90%;border: 1px solid black;border-collapse: collapse; margin-left: 5%;" id="minisummarytable">
    <tr   style="border: 1px solid black;border-collapse: collapse;background-color: #C3A468;color: white;margin-left: 5%;">
   
            <td colspan="3" style="width: 100%; border: 1px solid black;border-collapse: collapse;">
            Lumpsum
            </td>
          
    
    </tr>`;


    var currentminisummaryhtml = `    <table style="width:90%;border: 1px solid black;border-collapse: collapse; margin-left: 5%;   clear: both !important;
    page-break-after: always !important;" id="minisummarytable">
    <tr   style="border: 1px solid black;border-collapse: collapse;background-color: #C3A468;color: white;margin-left: 5%;">
   
    <td colspan="3" style="width: 100%; border: 1px solid black;border-collapse: collapse; text-align:center; font-weight:bold">
    Current Policies
    </td>
  

</tr>


    <tr   style="border: 1px solid black;border-collapse: collapse;background-color: #C3A468;color: white;margin-left: 5%;">
   
            <td style="width: 50%; border: 1px solid black;border-collapse: collapse;">
            Insurer/Self
            </td>
            <td style="width: 25%; border: 1px solid black;border-collapse: collapse;">
            Amount
            
            </td>
            <td style="width: 25%; border: 1px solid black;border-collapse: collapse;">
            Payout Age
    
    </tr>
    <tr   style="border: 1px solid black;border-collapse: collapse;background-color: #C3A468;color: white;margin-left: 5%;">
   
  

    <td colspan="3" style="width: 100%; border: 1px solid black;border-collapse: collapse; text-align:left;  ">
    Passive Income (Monthly)
    </td>
  

</tr>
    
    `

    var minisummaryhtml = `    <table style="width:90%;border: 1px solid black;border-collapse: collapse; margin-left: 5%;" id="minisummarytable">
    <tr   style="border: 1px solid black;border-collapse: collapse;background-color: #C3A468;color: white;margin-left: 5%;">
   
    <td colspan="3" style="width: 100%; border: 1px solid black;border-collapse: collapse; text-align:center; font-weight:bold">
    Proposed Implementation
    </td>
  

</tr>

    <tr   style="border: 1px solid black;border-collapse: collapse;background-color: #C3A468;color: white;margin-left: 5%;">
   
            <td style="width: 50%; border: 1px solid black;border-collapse: collapse;">
            Insurer/Self
            </td>
            <td style="width: 25%; border: 1px solid black;border-collapse: collapse;">
            Amount
            
            </td>
            <td style="width: 25%; border: 1px solid black;border-collapse: collapse;">
            Payout Age
            </td>
    
    </tr>
    <tr   style="border: 1px solid black;border-collapse: collapse;background-color: #C3A468;color: white;margin-left: 5%;">
   
  

    <td colspan="3" style="width: 100%; border: 1px solid black;border-collapse: collapse; text-align:left;  ">
    Passive Income (Monthly)
    </td>
  

</tr>
    `;


    var html = `    <table style="width:90%;border: 1px solid black;border-collapse: collapse; margin-left: 5%;" id="datatable">
    <tr   style="border: 1px solid black;border-collapse: collapse;background-color: #C3A468;color: white;margin-left: 5%;">
   
            <td style="width: 15%; border: 1px solid black;border-collapse: collapse;">
                Age
            </td>
            <td style="width: 43%; border: 1px solid black;border-collapse: collapse;">
            Annual Expenses 
            
            </td>
            <td style="width: 42%; border: 1px solid black;border-collapse: collapse;">
            Beginning Cash Flow
    
    </tr>`;

    let passiveArrayYourGoalStartSorted = financialCalculator.passiveArrayYourGoal;
    let passiveArrayYourGoalEndSorted = financialCalculator.passiveArrayYourGoal;

    passiveArrayYourGoalStartSorted.sort((a, b) => parseFloat(a.startpayout) - parseFloat(b.startpayout));
    passiveArrayYourGoalEndSorted.sort((a, b) => parseFloat(a.endpayout) - parseFloat(b.endpayout));
    let endPayoutYearYorGoal = passiveArrayYourGoalEndSorted[passiveArrayYourGoalEndSorted.length - 1].endpayout;
    // Page 1 Calculation
    var monthlyexpnceCurrent = financialCalculator.monthlyexpnceCurrent
    var monthlyPassiveIncomeCurrent = 0;
    var expectedPersonalSaveMatureCurrent = 0;
    var partLumsum = 0;

    var endPayoutYear =
        $(financialCalculator.passiveArray).each(function (index) {

            endPayoutYearCurrent = this['endpayout'];
            if (endPayoutYearCurrent > endPayoutYear) {
                endPayoutYearCurrent = endPayoutYear;
            }
        });

    var passiveArraySorted = financialCalculator.passiveArray.sort((a, b) => parseFloat(a.startpayout) - parseFloat(b.startpayout));
    var passiveArrayEndSorted = financialCalculator.passiveArray.sort((a, b) => parseFloat(a.endpayout) - parseFloat(b.endpayout));
    console.log(passiveArraySorted);
    var counter = 0;
    var rAge = 0;
    //  $(financialCalculator.passiveArray).each(function (index) {


    insuer = ''// this['insuer'];
    passiveincome = 0; //this['passiveincome'];
    var startpayout = parseInt(financialCalculator.intendedRetireAge);
    var endpayout = 85;
    if (passiveArraySorted.length > 0) {
        startpayout = parseInt(passiveArraySorted[0].startpayout)//this['startpayout'];
        //   endpayout = parseInt(passiveArrayEndSorted[0].endpayout);// this['endpayout'];

    }


    // if (endpayout.toString() != 'NaN' && parseInt(endPayoutYearYorGoal).toString() != 'NaN') {


    //     endpayout = parseInt(endPayoutYearYorGoal)

    // }


    for (rAge = RetireAge; rAge <= endpayout; rAge++) {

        ageArray.push(rAge);
        var passiveincomeTotal = 0;
        passiveincome = 0;
        for (i = 0; i < financialCalculator.passiveArray.length; i++) {


            if (financialCalculator.passiveArray[i].startpayout <= rAge && financialCalculator.passiveArray[i].endpayout >= rAge) {
                passiveincomeTotal = Number(financialCalculator.passiveArray[i].passiveincome) + Number(passiveincomeTotal);
                passiveincome = passiveincomeTotal;
            }
            // if (financialCalculator.passiveArray[i].endpayout < rAge) {
            //     passiveincome = passiveincome - Number(financialCalculator.passiveArray[i].passiveincome)

            // }
        }


        monthlyPassiveIncomeCurrent = Number(passiveincome);

        // $(financialCalculator.lumbsumArray).each(function (index) {
        //     if (this['ExpectedLumpsumat'] == rAge)
        //         expectedPersonalSaveMatureCurrent = Number(expectedPersonalSaveMatureCurrent) + Number(this['lumpsumd']);
        // })



        $(financialCalculator.lumbsumArray).each(function (index) {
            if (this['ExpectedLumpsumat'] == rAge && this['ExpectedLumpsumat'] >= RetireAge)
                expectedPersonalSaveMatureCurrent = Number(expectedPersonalSaveMatureCurrent) + Number(this['lumpsumd']);
            else {
                if (this['ExpectedLumpsumat'] < rAge && rAge == RetireAge)
                    expectedPersonalSaveMatureCurrent = Number(expectedPersonalSaveMatureCurrent) + Number(this['lumpsumd']);
            }





        })
        for (i = 0; i < financialCalculator.passiveArray.length; i++) {
            if (financialCalculator.passiveArray[i].startpayout <= rAge && rAge == RetireAge && financialCalculator.passiveArray[i].endpayout >= rAge) {
                if (rAge == RetireAge) {
                    expectedPersonalSaveMatureCurrent = expectedPersonalSaveMatureCurrent + ((financialCalculator.passiveArray[i].passiveincome * 12) * (rAge - financialCalculator.passiveArray[i].startpayout));
                }
                else if (rAge > RetireAge && financialCalculator.passiveArray[i].endpayout > rAge) {
                    expectedPersonalSaveMatureCurrent = expectedPersonalSaveMatureCurrent + ((financialCalculator.passiveArray[i].passiveincome * 12));
                }



            }

            else if (financialCalculator.passiveArray[i].startpayout <= rAge && rAge == RetireAge) {
                expectedPersonalSaveMatureCurrent = expectedPersonalSaveMatureCurrent + ((financialCalculator.passiveArray[i].passiveincome * 12) * (financialCalculator.passiveArray[i].endpayout - financialCalculator.passiveArray[i].startpayout));
            }


        }



        lastYearLumpSum = expectedPersonalSaveMatureCurrent;

        TotAnnAmtLeft = TotAnnAmtLeft + lastYearLumpSum - (((monthlyexpnceCurrent * ((1 + 0.025) ** (rAge - currentAge))) - monthlyPassiveIncomeCurrent) * 12)
        //TotAnnAmtLeft=lastYearLumpSum-((monthlyexpnceCurrent*((1+0.025)^(rAge-currentAge)))*12)+(monthlyPassiveIncomeCurrent*12)

        TotAnnAmtLeft_display = TotAnnAmtLeft + (((monthlyexpnceCurrent * ((1 + 0.025) ** (rAge - currentAge)))) * 12);
        let objFileds = {};
        objFileds.Age = rAge;
        objFileds.Left = TotAnnAmtLeft_display;
        LeftForAgeCurrent.push(objFileds)

        CurrentLeft.push([rAge, TotAnnAmtLeft_display]);
        CurrentLeft2.push([TotAnnAmtLeft_display, rAge]);

        expectedPersonalSaveMatureCurrent = 0
        console.log(' 1)  ' + rAge + '   ' + TotAnnAmtLeft_display.toFixed(2))
        var annualExpenses = (financialCalculator.monthlyexpnceCurrent * (1.025 ** (rAge - currentAge))) * 12
        annualExpensesArray.push([rAge, Number(annualExpenses)]);
        console.log(' Annual Expenses =   ' + annualExpenses.toFixed(2) + '  Age = ' + rAge);


    }




    //  })

    // Page 2 Calculation
    var yearlyExpectedExpensesYourGoal = 0;
    var monthlyexpnceYourGoal = financialCalculator.monthlyexpnceYourGoal;
    var monthlyPassiveIncomeYourGoal = 0;

    $(financialCalculator.lumbsumArrayYourGoal).each(function (index) {
        let objFileds = {};
        objFileds.ExpectedLumpsumat = Number(this['ExpectedLumpsumat']);
        objFileds.lumpsumAmt = Number(this['lumpsumd']);
        objExpectedLumpsumat.push(objFileds)
    })
    //console.log("Your Goal")

    found = jQuery.grep(LeftForAgeCurrent, function (n, i) {
        return (n.Age == financialCalculator.passiveArrayYourGoal[0].startpayout);
    }, false);



    
    if (counter > 0 && found.length > 0 && financialCalculator.passiveArrayYourGoal[0].startpayout == found[0].Age) {
        lastYearLumpSumYourGoal = found[0].Left;
    } else {
        lastYearLumpSumYourGoal = 0;
    }



    let startPayoutYear = passiveArrayYourGoalStartSorted[0].startpayout;





    var currentLoopedAge = 0;

    //$(passiveArrayYourGoalStartSorted).each(function (index) {
    insuer = ''//this['insuer'];
    passiveincome = 0//'this['passiveincome'];
    startpayout = parseInt(startPayoutYear)//this['startpayout'];
    endpayout = 85;//parseInt(endPayoutYearYorGoal)
    rAge = startpayout;
    if (currentLoopedAge <= startpayout) {
        currentLoopedAge = startpayout;

    }

    counter = 0;
    var isCalculated = false;
    var html = `   <table style="width:90%;border: 1px solid black;border-collapse: collapse; margin-left: 5%;" id="datatable">
    <tr   style="border: 1px solid black;border-collapse: collapse;background-color: #C3A468;color: white;margin-left: 5%;">
   
            <td style="border: 1px solid black;border-collapse: collapse;width: 10%;">
                Age
            </td>
            <td style="border: 1px solid black;border-collapse: collapse;width: 30%;">
            Annual Expenses 
            
            </td>
            <td style="border: 1px solid black;border-collapse: collapse;width: 30%;">
            Beginning Cash Flow
    
            </td>
            <td style="border: 1px solid black;border-collapse: collapse;width: 30%;">
            NEW Beginning Cash Flow
    
            </td>
    </tr>
 `
    var lumbsumArrayYourGoalNew = financialCalculator.lumbsumArrayYourGoal;
    if (startpayout.toString() == 'NaN') {
        startpayout = parseInt(financialCalculator.intendedRetireAge);

    }
    // if (endpayout.toString() == 'NaN') {
    //     endpayout = 90;
    // }




    if (financialCalculator.lumbsumArray.length > 0) {

        for (i = 0; i < financialCalculator.lumbsumArray.length; i++) {
            if (financialCalculator.lumbsumArray[i].ExpectedLumpsumat == rAge) {
                partLumsum = Number(financialCalculator.lumbsumArray[i].lumpsumd) + Number(partLumsum);

            }

            if (counter == 0) {

                var lumpsumd = ''
                if (financialCalculator.lumbsumArray[i] && financialCalculator.lumbsumArray[i].lumpsumd && financialCalculator.lumbsumArray[i].lumpsumd != '')

                    lumpsumd = parseFloat((financialCalculator.lumbsumArray[i].lumpsumd)).toFixed(2)

                var currentExpectedLumpsumat = ''
                if (financialCalculator.lumbsumArray[i].ExpectedLumpsumat && financialCalculator.lumbsumArray[i].ExpectedLumpsumat != 'Payout Year')
                    currentExpectedLumpsumat = financialCalculator.lumbsumArray[i].ExpectedLumpsumat
                lumpsumhtmlCurrentPolicies = lumpsumhtmlCurrentPolicies + `   
                <tr>
                  <td  style="width: 50%; border: 1px solid black;border-collapse: collapse; background-color:white;color: "  >`+ financialCalculator.lumbsumArray[i].insuer + `</td>
                  <td style="width: 25%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black;  text-align: right"  >`+ lumpsumd + `</td>
                  <td style="width: 25%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black; text-align: right "  >`+ currentExpectedLumpsumat + `</td>
                  
                </tr>`
            }

        }
    }
    for (rAge = RetireAge; rAge <= endpayout; rAge++) {

        expectedPersonalSaveMatureForYearYourGoal = 0;




        if (financialCalculator.lumbsumArrayYourGoal.length > 0) {
            var lumbsumArray = financialCalculator.lumbsumArray

            for (i = 0; i < lumbsumArray.length; i++) {

                //     if (this['ExpectedLumpsumat'] == rAge && this['ExpectedLumpsumat'] >= RetireAge)
                //     expectedPersonalSaveMatureCurrent = Number(expectedPersonalSaveMatureCurrent) + Number(this['lumpsumd']);
                // else {
                //     if (this['ExpectedLumpsumat'] < rAge && rAge == RetireAge)
                //         expectedPersonalSaveMatureCurrent = Number(expectedPersonalSaveMatureCurrent) + Number(this['lumpsumd']);
                // }



                if (lumbsumArray[i].ExpectedLumpsumat == rAge && lumbsumArray[i].ExpectedLumpsumat >= RetireAge) {
                    expectedPersonalSaveMatureForYearYourGoal = Number(lumbsumArray[i].lumpsumd) + Number(expectedPersonalSaveMatureForYearYourGoal);


                }
                else {
                    if (lumbsumArray[i].ExpectedLumpsumat < rAge && rAge == RetireAge)
                        expectedPersonalSaveMatureForYearYourGoal = Number(expectedPersonalSaveMatureForYearYourGoal) + Number(lumbsumArray[i].lumpsumd);



                }



            }


        }











        if (financialCalculator.lumbsumArrayYourGoal.length > 0) {
          
            for (i = 0; i < lumbsumArrayYourGoalNew.length; i++) {

                //     if (this['ExpectedLumpsumat'] == rAge && this['ExpectedLumpsumat'] >= RetireAge)
                //     expectedPersonalSaveMatureCurrent = Number(expectedPersonalSaveMatureCurrent) + Number(this['lumpsumd']);
                // else {
                //     if (this['ExpectedLumpsumat'] < rAge && rAge == RetireAge)
                //         expectedPersonalSaveMatureCurrent = Number(expectedPersonalSaveMatureCurrent) + Number(this['lumpsumd']);
                // }



                if (lumbsumArrayYourGoalNew[i].ExpectedLumpsumat == rAge && lumbsumArrayYourGoalNew[i].ExpectedLumpsumat >= RetireAge && (lumbsumArrayYourGoalNew[i].isPage2 == 'true' || lumbsumArrayYourGoalNew[i] == true)) {
                    expectedPersonalSaveMatureForYearYourGoal = Number(lumbsumArrayYourGoalNew[i].lumpsumd) + Number(expectedPersonalSaveMatureForYearYourGoal);


                }
                else {
                    if (lumbsumArrayYourGoalNew[i].ExpectedLumpsumat < rAge && rAge == RetireAge && (lumbsumArrayYourGoalNew[i].isPage2 == 'true' || lumbsumArrayYourGoalNew[i] == true))
                        expectedPersonalSaveMatureForYearYourGoal = Number(expectedPersonalSaveMatureForYearYourGoal) + Number(lumbsumArrayYourGoalNew[i].lumpsumd);




                }
                // var lumbsumArray = financialCalculator.lumbsumArray
                // for (j = 0; j < lumbsumArray.length; j++) {
                //     if (expectedPersonalSaveMatureForYearYourGoal > 0 && lumbsumArray[j].insuer == lumbsumArrayYourGoalNew[i].insuer && lumbsumArray[j].ExpectedLumpsumat == lumbsumArrayYourGoalNew[i].ExpectedLumpsumat && lumbsumArray[j].lumpsumd == lumbsumArrayYourGoalNew[i].lumpsumd)
                //         expectedPersonalSaveMatureForYearYourGoal = Number(expectedPersonalSaveMatureForYearYourGoal) - Number(lumbsumArray[j].lumpsumd);


                // }


                if (counter == 0) {

                    if (financialCalculator.lumbsumArrayYourGoal && financialCalculator.lumbsumArrayYourGoal[i].isPage2 && financialCalculator.lumbsumArrayYourGoal[i].isPage2 == 'true') {


                        if (financialCalculator.lumbsumArrayYourGoal[i].insuer != '' && financialCalculator.lumbsumArrayYourGoal[i].lumpsumd != '' && financialCalculator.lumbsumArrayYourGoal[i].ExpectedLumpsumat != "Payout Year") {
                            lumpsumhtmlproposed = lumpsumhtmlproposed + `   
    <tr>
      <td  style="width: 50%; border: 1px solid black;border-collapse: collapse; background-color:white;color: "  >`+ financialCalculator.lumbsumArrayYourGoal[i].insuer + `</td>
      <td style="width: 25%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black;text-align:right; "  >`+ parseFloat((financialCalculator.lumbsumArrayYourGoal[i].lumpsumd)).toFixed(2) + `</td>
      <td style="width: 25%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black; text-align:right;"  >`+ financialCalculator.lumbsumArrayYourGoal[i].ExpectedLumpsumat + `</td>
      
    </tr>`
                        }
                    }

                }

            }



        }



        for (i = 0; i < financialCalculator.passiveArrayYourGoal.length; i++) {


            if (financialCalculator.passiveArrayYourGoal[i].startpayout <= rAge && rAge == RetireAge && financialCalculator.passiveArrayYourGoal[i].endpayout >= rAge) {
                if (rAge == RetireAge) {
                    expectedPersonalSaveMatureForYearYourGoal = expectedPersonalSaveMatureForYearYourGoal + ((financialCalculator.passiveArrayYourGoal[i].passiveincome * 12) * (rAge - financialCalculator.passiveArrayYourGoal[i].startpayout));
                }
                else if (rAge > RetireAge && financialCalculator.passiveArrayYourGoal[i].endpayout > rAge) {
                    expectedPersonalSaveMatureForYearYourGoal = expectedPersonalSaveMatureForYearYourGoal + ((financialCalculator.passiveArrayYourGoal[i].passiveincome * 12));
                }



            }

            else if (financialCalculator.passiveArrayYourGoal[i].startpayout <= rAge && rAge == RetireAge) {
                expectedPersonalSaveMatureCurrent = expectedPersonalSaveMatureCurrent + ((financialCalculator.passiveArrayYourGoal[i].passiveincome * 12) * (financialCalculator.passiveArrayYourGoal[i].endpayout - financialCalculator.passiveArrayYourGoal[i].startpayout));
            }


        }

        var passiveincomeTotal = 0;
        passiveincome = 0;
        for (i = 0; i < financialCalculator.passiveArrayYourGoal.length; i++) {
           

            if (financialCalculator.passiveArrayYourGoal[i].startpayout <= rAge && financialCalculator.passiveArrayYourGoal[i].endpayout >= rAge) {
                passiveincomeTotal = Number(financialCalculator.passiveArrayYourGoal[i].passiveincome) + Number(passiveincomeTotal);
                passiveincome = passiveincomeTotal;
            }
            // if (financialCalculator.passiveArrayYourGoal[i].endpayout < rAge) {
            //     passiveincome = passiveincome - Number(financialCalculator.passiveArrayYourGoal[i].passiveincome)
            //     passiveincomeTotal = passiveincome;

            // }

            if (counter == 0) {

                var currentinsurer = ''

                if (financialCalculator.passiveArrayYourGoal && financialCalculator.passiveArrayYourGoal[i].insuer != '')
                    currentinsurer = financialCalculator.passiveArrayYourGoal[i].insuer
                var currentstartendpayout = ''
                //var currentendpayout = ''
                if (financialCalculator.passiveArrayYourGoal[i].startpayout != 'Start of passive income payout' && financialCalculator.passiveArrayYourGoal[i].endpayout != 'End of passive income payout')
                    currentstartendpayout = financialCalculator.passiveArrayYourGoal[i].startpayout + `-` + financialCalculator.passiveArrayYourGoal[i].endpayout
                var curremtpassiveincome = ''
                if (financialCalculator.passiveArrayYourGoal[i].passiveincome != '')
                    curremtpassiveincome = parseFloat(financialCalculator.passiveArrayYourGoal[i].passiveincome).toFixed(2);

                if (financialCalculator.passiveArrayYourGoal && financialCalculator.passiveArrayYourGoal[i].isPage2 && financialCalculator.passiveArrayYourGoal[i].isPage2 == 'true') {


                    minisummaryhtml = minisummaryhtml + `   
         

                        
                    <tr>
                    <td  style="width: 50%; border: 1px solid black;border-collapse: collapse; background-color:white;color: "  >`+ currentinsurer + `</td>
                    <td style="width: 25%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black;  text-align: right"  >`+ curremtpassiveincome + `</td>
                    <td style="width: 25%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black; text-align: right "  >`+ currentstartendpayout + `</td>
                    
                      </tr>`
                }
                else {

                    currentminisummaryhtml = currentminisummaryhtml + `   
         

                            
                            <tr>
                            <td  style="width: 50%; border: 1px solid black;border-collapse: collapse; background-color:white;color: "  >`+ currentinsurer + `</td>
                            <td style="width: 25%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black; text-align :right "  >`+ curremtpassiveincome + `</td>
                            <td style="width: 25%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black; text-align: right "  >`+ currentstartendpayout + `</td>
                            
                            </tr>`


                }
            }
        }
        var cuurentAnnualExp = 0;

        for (i = 0; i < annualExpensesArray.length; i++) {
            if (annualExpensesArray[i][0] == rAge) {
                cuurentAnnualExp = annualExpensesArray[i][1];
            }
        }
        
        TotAnnAmtLeftYourGoal = (Number(lastYearLumpSumYourGoal) + Number(expectedPersonalSaveMatureForYearYourGoal) + (Number(passiveincome) * 12)) - Number(cuurentAnnualExp);
        TotAnnAmtLeftYourGoal_Display = (TotAnnAmtLeftYourGoal) + (cuurentAnnualExp);///Number(((monthlyexpnceCurrent * ((1 + 0.025) ** (rAge - currentAge)))) * 12) ;


        console.log("Annual check:" + TotAnnAmtLeftYourGoal + '  ' + (((monthlyexpnceCurrent * ((1 + 0.025) ** (rAge - currentAge)))) * 12) + ' ' + (Number(TotAnnAmtLeftYourGoal) + Number(((monthlyexpnceCurrent * ((1 + 0.025) ** (rAge - currentAge)))) * 12)))
        //TotAnnAmtLeftYourGoal = (Number(lastYearLumpSumYourGoal) + Number(partLumsum) + Number(expectedPersonalSaveMatureForYearYourGoal) + (Number(passiveincome) * 12)) - cuurentAnnualExp;
        //console.log("Check->" + Number(lastYearLumpSumYourGoal) + ' ' + Number(partLumsum) + ' ' + Number(expectedPersonalSaveMatureForYearYourGoal) + ' ' + (Number(passiveincome) * 12) + ' ' + cuurentAnnualExp)
        YourGoalLeft.push([rAge, TotAnnAmtLeftYourGoal_Display]);
        YourGoalLeft2.push([TotAnnAmtLeftYourGoal_Display, rAge]);
        lastYearLumpSumYourGoal = TotAnnAmtLeftYourGoal;

        passiveincomepayoutYourGoal = (monthlyexpnceYourGoal * (1 + 0.025) ** (rAge - currentAge)) - passiveincome;
        yearlyExpectedExpensesYourGoal = passiveincomepayoutYourGoal * 12;
        console.log(' 2)  ' + rAge + '   ' + TotAnnAmtLeftYourGoal_Display.toFixed(2) + '   ' + yearlyExpectedExpensesYourGoal.toFixed(2))
        YearlyExp.push([rAge, yearlyExpectedExpensesYourGoal]);
        YearlyExp2.push([yearlyExpectedExpensesYourGoal, rAge]);


        var val1 = ''
        if (annualExpensesArray[counter] && annualExpensesArray[counter] != undefined && annualExpensesArray[counter][1] && annualExpensesArray[counter][1] != '')
            val1 = parseFloat(annualExpensesArray[counter][1]).toFixed(2);

        var val2 = '0.00'
        if (CurrentLeft[counter] && CurrentLeft[counter] != undefined && CurrentLeft[counter][1] && CurrentLeft[counter][1] != '')
            val2 = parseFloat(CurrentLeft[counter][1]).toFixed(2);

        var val3 = '0.00'
        console.log("here==" + parseFloat(YourGoalLeft[counter][1]).toFixed(2))
        if (YourGoalLeft[counter] && YourGoalLeft[counter] != undefined && YourGoalLeft[counter][1] && YourGoalLeft[counter][1] != '')
            val3 = parseFloat(YourGoalLeft[counter][1]).toFixed(2);
        partLumsum = 0;

        html = html + `
     
     
         
         <tr>
           <td style="width: 10%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black; text-align: right" >`+ rAge + `</td>
           <td style="width: 30%;  border: 1px solid black;border-collapse: collapse;background-color:white;color: black; text-align: right"  >`+ val1 + `</td>
           <td style="width: 30%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black; text-align: right" >`+ val2 + `</td>
           <td style="width: 30%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black; text-align: right"  >`+ val3 + `</td>
         </tr>
   
`

        counter++;
    }
    html = html + `  </table>`


    console.log('YourGoalLeft')
    console.log(YourGoalLeft)
    console.log('CurrentLeft')
    console.log(CurrentLeft)
    console.log('annualExpensesArray')
    console.log(annualExpensesArray)









    const data = {
        labels: ageArray,
        datasets: [
            {
                label: 'Beginning Cash Flow',
                data: CurrentLeft,//Utils.numbers(NUMBER_CFG),
                borderColor: "rgba(255,215,0,0.5)",
                backgroundColor: "rgba(255,215,0,0.5)",
                fill: true
            },
            {
                label: 'NEW Beginning Cash Flow',
                data: YourGoalLeft,//Utils.numbers(NUMBER_CFG),

                //  borderColor:"#BE9E61",
                borderColor: "rgba(163, 148, 59, 0.5)",
                backgroundColor: "rgba(163, 148, 59, 0.5)",
                // backgroundColor: "#BE9E61",
                fill: true
            },
            {
                label: 'Annual Expenses',
                data: annualExpensesArray,//Utils.numbers(NUMBER_CFG),

                borderColor: "rgba(97, 233, 237, 0.5)",
                backgroundColor: "rgba(97, 233, 237, 0.5)",
                fill: true
            }

        ]
    };


    const config = {
        type: 'line',
        data: data,
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    //text: (ctx) => 'Chart.js Line Chart - stacked=' + ctx.chart.options.scales.y.stacked
                },
                tooltip: {
                    mode: 'index'
                },
            },
            interaction: {
                mode: 'nearest',
                axis: 'x',
                intersect: false
            },
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Age'
                    }
                },
                y: {
                    stacked: false,
                    title: {
                        display: true,
                        text: 'Retirement Income and balnce'
                    },
                    ticks: {
                        // forces step size to be 50 units
                        stepSize: 50000
                    },
                    min: -250000

                }
            }
        }
    };


    const myChart = new Chart(
        document.getElementById('pie2'),
        config
    );
    $("#chardatagrid").append(html)
    $("#minisummarycurrent").append(currentminisummaryhtml)
    $("#minisummarycurrent").append(lumpsumhtmlCurrentPolicies)

    $("#minisummary").append(minisummaryhtml)
    $("#minisummary").append(lumpsumhtmlproposed)



    $(document).on('click', '#backbtn', function (e) {


        try {
            var element = $(this);

            var rolename = localStorage.getItem('roleName');
            var nextPage = 'app_allfinancialservicesstepfinallist';

            if (rolename.toLowerCase() == "consultant") {
                nextPage = "app_consultantallfinancialsteplist";
            }

            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "update";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - backbutton1", error)
        }

    })

    $(document).on('click', '#changeorientation', function (e) {
        $("#pie2").toggleClass("vertical");

        if (isPie2 == true) {
            $("#chardatagrid").css("top", "330px");
            $("#minisummarycurrent").css("top", "180px");
            $("#minisummary").css("top", "280px");
            $("#backbtndiv").css("top", "475px");
            $(".bottominfo").css("top", "550px");

            isPie2 = false;

        }
        else {
            $("#chardatagrid").css("top", "230px");
            $("#minisummarycurrent").css("top", "80px");
            $("#minisummary").css("top", "180px");
            $(".bottominfo").css("top", "450px");
            $("#backbtndiv").css("top", "375px");
            isPie2 = true;

        }


    });
    $(document).on('click', '#download', function (e) {

        var imageSrc = $('#pie2')[0].toDataURL(); // this stores the base64 image url in imagesrc


        var html = `<html><head></head><body class="app-theme-background-primary-mk app-theme-foreground-primary-mk sgclsapp_retirementcalculateadd"
            style="display: contents;"><div><img  style="margin-left: 10px;"  src="`+ imageSrc + `"></div>`
        var chardivhtml = $("#detailsdiv")[0].innerHTML;
        chardivhtml = chardivhtml.trim();
        var chardivhtml = chardivhtml.replace(/\n|\r/g, "");
        html = html + chardivhtml + `</body></html>`


        var appJSON = {}
        appJSON.htmlPageData = html
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        if (isAndroid === -1) {
            setupWebViewJavascriptBridge(function (bridge) {
                bridge.callHandler("previewHtmlPage", appJSON, function (response) { });
                //   bridge.registerHandler("offlineMode", function (responseData, responseCallback) {
                //offlineMode(responseData);
                // });
            });
        } else {
            window.Android.previewHtmlPage(JSON.stringify(appJSON));
        }

        //  console.log(html);

        //  html.append
        //  window.open(html);
        //   $("#pie2").append(html);

    });
    $(document).on('click', '#backbutton1', function (e) {
        try {
            var element = $(this);
            var rolename = localStorage.getItem("roleName");
            // var nextPage = 'app_custmoreinfodetails';
            var nextPage = 'app_retirementgoalstep2';
            // if (rolename == "consultant") {
            //   nextPage = "app_consultantcustmoreinfodetails";
            // }

            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "update";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - backbutton1", error)
        }
    })
});