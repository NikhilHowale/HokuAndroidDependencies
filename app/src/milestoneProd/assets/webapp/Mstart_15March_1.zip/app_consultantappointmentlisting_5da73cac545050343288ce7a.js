
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
     var totaldcard_leftimage_collectioncontainer = 0;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];


  var queryMode = getParameterByName('queryMode');
      var isMobile = $('#isMobile').val();
      var isiPad = $('#isiPad').val();
      if(queryMode != ''){
          var tokenKey = $('#tokenKey').val();
          var objParamsList = {};
          objParamsList.queryMode = queryMode;
          var ajaXCallURL = $.trim($('#ajaXCallURL').val());
          objParamsList.tokenKey = getParameterByName('tokenKey');
          objParamsList.secretKey = getParameterByName('secretKey');
          objParamsList.ajaXCallURL = ajaXCallURL;
          objParamsList.isMobile = isMobile;
          objParamsList.isiPad = isiPad;
          objParamsList.applyFilter = false;
          getDataProcessBeforeCalldcard_leftimage_collectioncontainerOrders5da73cac545050343288ce7a(objParamsList,function(processBeforeRes){
 if(getParameterByName('rolename') && getParameterByName('rolename') != '' && getParameterByName('rolename') != null  && getParameterByName('rolename') != 'undefined' ){
 objParamsList.rolename =  getParameterByName('rolename');
 }
 if(getParameterByName('consultantid') && getParameterByName('consultantid') != '' && getParameterByName('consultantid') != null  && getParameterByName('consultantid') != 'undefined' ){
 objParamsList.consultantid =  getParameterByName('consultantid');
 }
 if(getParameterByName('status') && getParameterByName('status') != '' && getParameterByName('status') != null  && getParameterByName('status') != 'undefined' ){
 objParamsList.consultantstatus =  getParameterByName('status');
 }
          var dcard_leftimage_collectioncontainerapp_consultantappointmentlisting = localStorage.getItem('dcard_leftimage_collectioncontainerapp_consultantappointmentlisting');
          var  applyFilter = getParameterByName('applyFilter');
          $('#display_loading').removeClass('hideme');
          if (dcard_leftimage_collectioncontainerapp_consultantappointmentlisting && applyFilter != 'true' ) {
              response = JSON.parse(dcard_leftimage_collectioncontainerapp_consultantappointmentlisting);
              $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html('');
              getdcard_leftimage_collectioncontainerapp_consultantappointmentlistingMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
              dcard_leftimage_collectioncontainerapp_consultantappointmentlistingSync(response.timestamp);   
          } else {
         show_dcard_leftimage_collectioncontainerapp_consultantappointmentlisting_Details(objParamsList)
          }
          });//End of get data process before call.
  }
 $(document).on('click', '.dcard_leftimage_collectioncontainer', function () {
   if(dcardLoaded && !dcardLoaded['dcard_leftimage_collectioncontainer']) { return false;}; // added for use should not able to click until data loaded
   localStorage.setItem("headerPageName", 'app_consultantappointmentdetails') ;
   var recordID =  $(this).attr('recordID');// get record ID;
   var ordersid =  $(this).attr('recordID');// get record ID;
   var tokenKey = getParameterByName('tokenKey');
   var secretKey = getParameterByName('secretKey');
   var queryMode = 'update';
   var nextPage = 'app_consultantappointmentdetails';
   if(!nextPage){
      return false;
   }
   var pageurl =  nextPage + '_5da73cac545050343288ce7a.html?queryMode='+ queryMode+'&tokenKey='+tokenKey+ '&secretKey=' + secretKey+ '&ordersid=' + ordersid+ '&recordID=' + recordID+'&applyFilter=true';
   window.location.href = pageurl;
   return false;
 }); // to add New record

		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_consultantacceptappointmentslisting'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	}) 
                 $('#page_app_consultantappointmentlisting').addClass('lazyload'); 
                 $('body').addClass('overflowbody'); 
                             //dropdate  
                        var paramsType = {};  
                paramsType.tokenKey = getParameterByName("tokenKey"); 
                paramsType.secretKey = getParameterByName("secretKey"); 
                 var ajaXCallURL = $.trim($("#ajaXCallURL").val());  
                             $.ajax({  
                                 url: ajaXCallURL+'/milestone003/schedulerGetEvents_app_consultantappointmentlisting_Orders5da73cac545050343288ce7a',  
                                 data: paramsType,  
                                 type: 'POST',  
                                 success: function(response) {  
                                     if (response.status == 0) {  
                                         var assignedJobs = [];  
                                         $.each(response.data, function(keyList, objList) {  
                                             var colour = '#F44336' 
                                             var textColor = '#FFFFFF' 
  if(objList.type == 'webinar'){  
  	colour = '#F44336'   
  } 
  if(objList.type == 'meeting'){  
  	colour = '#FD9DDD'   
  } 
   var tempObj = {}; 
if( objList._id){
   tempObj.id= objList._id; 
} 
if( objList.startdate){
   tempObj.start= objList.startdate; 
} 
if( objList.enddate){
   tempObj.end= objList.enddate; 
} 
if( objList.agenda){
   tempObj.title= objList.agenda; 
} 
if( objList.type){
   tempObj.type= objList.type; 
}  
                                             	tempObj.textColor = textColor 
                                             	tempObj.color = colour 
   if(tempObj.end){ 
   		var end = moment.utc(tempObj.end); 
   		var end = end.local(); 
   		tempObj.end = end; 
   } 
   if(tempObj.start){ 
   		var start = moment.utc(tempObj.start); 
   		var start = start.local(); 
   		tempObj.start = start; 
   } 
   assignedJobs.push(tempObj);  
                                         });  
                                         var  fullCalendarDate = localStorage.getItem('fullCalendarDate'); 
                                         if(fullCalendarDate && fullCalendarDate != '' &&  fullCalendarDate != null && fullCalendarDate != 'undefined'){ 
                                         	fullCalendarDate = fullCalendarDate; 
                                         } else { 
                                         	fullCalendarDate = moment().format("YYYY-MM-DD"); 
                                         } 
                                         $('#calendar').fullCalendar({  
                                            schedulerLicenseKey: '0624711552-fcs-1562244290',  
                                             nowIndicator: true,  
                                             editable: true, // enable draggable events  
                                             droppable: true, // this allows things to be dropped onto the calendar  
                                             aspectRatio: 1.8,  
                                             slotDuration: '01:00', // undo default 6am scrollTime  
                                             scrollTime: '00:00', // undo default 6am scrollTime   
                                             header: {  
                                                 left: 'prev',  
                                                 center: 'title',  
                                                 right: 'month,agendaWeek,agendaDay,next'  
                                             },  
                                             defaultView: 'agendaWeek',  
                                             eventOverlap: true,  
                                             views: {  
                                                 timelineThreeDays: {  
                                                     type: 'timeline',  
                                                     duration: {  
                                                         days: 3  
                                                     }  
                                                 } 
   ,agendaWeek: { 
   		type: 'agendaWeek', 
   		duration: { 
   			days: 7 
   		}, 
   	} 
                                             },  
                                             resourceLabelText: 'Driver',  
                                             events: assignedJobs,  
                                             drop: function(date, jsEvent, ui, resourceId) {  
                                                 console.log('drop', date.format(), resourceId);  
                                                 // is the "remove after drop" checkbox checked?  
                                                 if ($('#drop-remove').is(':checked')) {  
                                                     // if so, remove the element from the "Draggable Events" list  
                                                     $(this).remove();  
                                                 }  
                                             },  
                                             eventReceive: function(event) { // called when a proper external event is dropped     
                                             		event.color = event.color;  
                                                 $('#calendar').fullCalendar('updateEvent', event);  
                                                 var params = {};  
                                                 updateOrder(params,function(eventRes){ 
                                                 }); 
                                                 $('.draggable').data('event', { 
                                                     title: 'my event'  
                                                 });  
                                                 console.log('eventReceive', event);  
                                             },  
                                             eventDrop: function(event) { // called when an event (already on the calendar) is moved  
                                                 console.log('eventDrop', event);  
                                                 var params = {};  
                                                 //params.pickupdate = event.start.format();  
                                                 //params.dropdate = event.end.format();  
                                                 params.recordID = event.id;  
                                                 updateOrder(params,function(eventRes){ 
                                                 }); 
                                             },  
                                             eventClick: function(info) { 
                                             	getSchedulerEventsClientAfterapp_consultantappointmentlisting(info, function (processAfterRes) { 
    							var queryMode = "mylist";  
    							var recordID = info.id;  
    							var tokenKey = getParameterByName('tokenKey'); 
    							var secretKey = getParameterByName('secretKey');  
    							var updatedObj = {}; 
    							for (var key in info) { 
    							    if (typeof(info[key]) == "string" || typeof(info[key]) == "boolean" || typeof(info[key]) == "number") { 
    							        updatedObj[key] = info[key]; 
    							    }; 
    							} 
    							var paramString = $.param(updatedObj);
     var nextPage = 'app_consultantappointmentlisting'; 
    							window.location.href = nextPage+'_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&recordID=' + recordID+ '&' + paramString;  
    							return false;  
                                              }); 
                                             }, 
                                             eventResize: function(event, delta, revertFunc) {  
                                                 var params = {};  
                                                 //params.pickupdate = event.start.format();  
                                                 //params.dropdate = event.end.format();  
                                                 params.recordID = event.id;  
                                                 //params.driver = event.resourceId;  
                                                 //params.status = "Assigned";  
                                                 updateOrder(params,function(eventRes){ 
                                                 }); 
                                                 //if (!confirm("is this okay?")) {  
                                                  //   revertFunc();  
                                                 //}  
                                             },  
                                             eventMouseover: function(calEvent, jsEvent) {  
                                            	$('.tooltipevent').remove(); 
                                               if(typeof(tooltip) != 'undefined' ){    
                                                 var $tooltip = $(tooltip).appendTo('body');  
                                                 $(this).mouseover(function(e) {  
                                                     $(this).css('z-index', 10000);  
                                                     $tooltip.fadeIn('500');  
                                                     $tooltip.fadeTo('10', 1.9);  
                                                 }).mousemove(function(e) {  
                                                     $tooltip.css('top', e.pageY + 30);  
                                                     $tooltip.css('left', e.pageX - 20);  
                                                 });  
                                               } 
                                             },  
                                             eventMouseout: function(calEvent, jsEvent) {  
                                                 $(this).css('z-index', 8);  
                                                 $('.tooltipevent').remove();  
                                             }  
                                         });  
                                     }  
                                 },  
                                 error: function(xhr, status, error) {  
                                 },  
                             });  
                             $(document).on("change", ".schedulerfilter", function() { 
                                     var paramsType = {}; 
                paramsType.tokenKey = getParameterByName("tokenKey"); 
                paramsType.secretKey = getParameterByName("secretKey"); 
                 var ajaXCallURL = $.trim($("#ajaXCallURL").val());  
                                     $.ajax({ 
                                 		url: ajaXCallURL+'/milestone003/schedulerGetEvents_app_consultantappointmentlisting_Orders5da73cac545050343288ce7a',  
                                         data: paramsType, 
                                         type: 'POST', 
                                         success: function(response) { 
                                             if (response.status == 0) { 
                                                 var assignedJobs = []; 
                                         $.each(response.data, function(keyList, objList) {  
                                             var colour = '#F44336' 
                                             var textColor = '#FFFFFF' 
  if(objList.type == 'webinar'){  
  	colour = '#F44336'   
  } 
  if(objList.type == 'meeting'){  
  	colour = '#FD9DDD'   
  } 
   var tempObj = {}; 
if( objList._id){
   tempObj.id= objList._id; 
} 
if( objList.startdate){
   tempObj.start= objList.startdate; 
} 
if( objList.enddate){
   tempObj.end= objList.enddate; 
} 
if( objList.agenda){
   tempObj.title= objList.agenda; 
} 
if( objList.type){
   tempObj.type= objList.type; 
}  
                                             	tempObj.textColor = textColor 
                                             	tempObj.color = colour 
   if(tempObj.end){ 
   		var end = moment.utc(tempObj.end); 
   		var end = end.local(); 
   		tempObj.end = end; 
   } 
   if(tempObj.start){ 
   		var start = moment.utc(tempObj.start); 
   		var start = start.local(); 
   		tempObj.start = start; 
   } 
   assignedJobs.push(tempObj);  
                                         });  
                                                 }        
                                                 $('#calendar').fullCalendar('removeEventSources') 
                                                 $('#calendar').fullCalendar('removeEvents') 
                                                 $('#calendar').fullCalendar('addEventSource', assignedJobs); 
                              
                                         }, 
                                         error: function(xhr, status, error) {}, 
                                     }); 
                             });
});//end of ready
 function getDataProcessBeforeCalldcard_leftimage_collectioncontainerOrders5da73cac545050343288ce7a(objParamsList,callback){
      var response = objParamsList

 var data = {
 };
	functc5351080f0ca11e9b8cc058871cb4a77(response, function (responsefunctc5351080f0ca11e9b8cc058871cb4a77) {
	if(responsefunctc5351080f0ca11e9b8cc058871cb4a77.inValid) {
			callback();
 		} else {
			callback();
 		}
 });

 function functc5351080f0ca11e9b8cc058871cb4a77(response, callback) {
objParamsList.rolename='client';
objParamsList.consultantid=localStorage.userID;
objParamsList.consultantstatus='Accepted';
	callback({'inValid': 1});
 }
 }
 function dcard_leftimage_collectioncontainerapp_consultantappointmentlistingSync(timestamp) {
     try {
         var objParamsList = {};
         objParamsList.queryMode = 'mylist';
         var ajaXCallURL = $.trim($('#ajaXCallURL').val());
         objParamsList.tokenKey = getParameterByName('tokenKey');
         objParamsList.secretKey = getParameterByName('secretKey');
         objParamsList.ajaXCallURL = ajaXCallURL;
         objParamsList.isMobile = true;
         objParamsList.timestamp = timestamp;
         $.ajax({
             url: objParamsList.ajaXCallURL + '/milestone003/syncListDetails_Orders5da73cac545050343288ce7a_app_consultantappointmentlisting',
             data: objParamsList,
             type: 'POST',
             success: function (response) {
              $('#display_loading').addClass('hideme');
                 if (response.status != undefined && response.status == 1) {
                     localStorage.removeItem('dcard_leftimage_collectioncontainerapp_consultantappointmentlisting');
                     var objParamsList = {};
                     objParamsList.queryMode = 'mylist';
                     var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                     objParamsList.tokenKey = getParameterByName('tokenKey');
                     objParamsList.secretKey = getParameterByName('secretKey');
                     objParamsList.ajaXCallURL = ajaXCallURL;
                     objParamsList.isMobile = 'true';
                     objParamsList.isiPad = false;
                     objParamsList.timestamp = timestamp; 
 if(getParameterByName('rolename') && getParameterByName('rolename') != '' && getParameterByName('rolename') != null  && getParameterByName('rolename') != 'undefined' ){
 objParamsList.rolename =  getParameterByName('rolename');
 }
 if(getParameterByName('consultantid') && getParameterByName('consultantid') != '' && getParameterByName('consultantid') != null  && getParameterByName('consultantid') != 'undefined' ){
 objParamsList.consultantid =  getParameterByName('consultantid');
 }
 if(getParameterByName('status') && getParameterByName('status') != '' && getParameterByName('status') != null  && getParameterByName('status') != 'undefined' ){
 objParamsList.consultantstatus =  getParameterByName('status');
 }
         show_dcard_leftimage_collectioncontainerapp_consultantappointmentlisting_Details(objParamsList)
                 }
             },
             error: function (xhr, status, error) { 
                 handleError(xhr, status, error); 
             } 
         });
     } catch (err) {
        // console.log('Error in workingtoolsSync', err);
     }
 }
         function show_dcard_leftimage_collectioncontainerapp_consultantappointmentlisting_Details(objParamsList){ 
 if(getParameterByName('rolename') && getParameterByName('rolename') != '' && getParameterByName('rolename') != null  && getParameterByName('rolename') != 'undefined' ){
 objParamsList.rolename =  getParameterByName('rolename');
 }
 if(getParameterByName('consultantid') && getParameterByName('consultantid') != '' && getParameterByName('consultantid') != null  && getParameterByName('consultantid') != 'undefined' ){
 objParamsList.consultantid =  getParameterByName('consultantid');
 }
 if(getParameterByName('status') && getParameterByName('status') != '' && getParameterByName('status') != null  && getParameterByName('status') != 'undefined' ){
 objParamsList.consultantstatus =  getParameterByName('status');
 }
         localStorage.setItem('appconsultantappointmentlistingFilterBox','');
 
          $.ajax({
              url: objParamsList.ajaXCallURL+'/milestone003/getListDetails_Orders5da73cac545050343288ce7a_app_consultantappointmentlisting_dcard_leftimage_collectioncontainer',
              data: objParamsList,
              type: 'POST',
              success: function (response) {
                      getDataProcessAfterCalldcard_leftimage_collectioncontainerOrders5da73cac545050343288ce7a(response, function(){
                      if (response.status != undefined && response.status == 0) {
                     if (objParamsList.isMobile == 'true') {    
                             $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html('');
                             localStorage.removeItem('dcard_leftimage_collectioncontainerapp_consultantappointmentlisting');
                              getdcard_leftimage_collectioncontainerapp_consultantappointmentlistingMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
                          } else if (objParamsList.isiPad == 'true') {    
                              getdcard_leftimage_collectioncontainerapp_consultantappointmentlistingiPadView(response, objParamsList.tokenKey, objParamsList.queryMode);
                          } else {
                              getdcard_leftimage_collectioncontainerapp_consultantappointmentlistingWebView(response, objParamsList.tokenKey,objParamsList.queryMode);
                          }
                          $('#display_loading').addClass('hideme');
                     } else {   
                          $('#display_loading').addClass('hideme')
                     }   
                   });   
                  },        
                  error: function (xhr, status, error) {        
                          $('#display_loading').addClass('hideme')
                          handleError(xhr, status, error); 
                  },        
              });  
        } // end of function     
                  
 function getDataProcessAfterCalldcard_leftimage_collectioncontainerOrders5da73cac545050343288ce7a(response,callback){

      callback();
 }

        function getdcard_leftimage_collectioncontainerapp_consultantappointmentlistingMobileView(response, tokenKey, queryMode) {
              var html = '';
              if (response.data.length == 0) {
                  html += '<div class="nodatafound">';
                  html +=     '<img src="nodatafound.gif" width="100%">';
                  html +=         '<br>';
                  html +=     '<!-- span>No record found</span -->';
                  html += '</div>';
                  $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html); ;
             } else {
              html =       '';
              var radioGroups =       [];
              $.each(response.data, function (keyList, objList) {
                  
                  var ios = navigator.userAgent.toLowerCase().indexOf("iphone os"); 
                  var isAndroid = navigator.userAgent.toLowerCase().indexOf("android"); 
                  if(isAndroid > -1 || ios > -1){  // need to fix with native gyes.. images not getting download
                      var mediaID = '';
                      var fileName = '';
                      if(objList['imageupload'] && objList['imageupload'][0].mediaID){
                          mediaID = objList['imageupload'][0].mediaID;
                          fileName = objList['imageupload'][0].mediaID + '.png';
                      }
                      getLocalImagedcard_leftimage_collectioncontainer(objList, mediaID, fileName); 
                  }else {
               
 html += '      <div class="row plain-card search" search="'+ removeSpecialChars(  objList.imageupload  + objList.clientname  + objList.policytype_name  + objList.date  + objList.fromtime  + objList.totime  + objList.address_name) +'">';
 html += '      		<div class="col s12 m12">';
 html += '               <div class="card-content">';
 html += '                  <div     status="'+ objList.status+ '"  recordID="'+objList._id+'" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
 html += '      <div class="row  element" style=""  >';
 html += '      <div class="col s3 cls_sg7449" style="">';
  var localFilePath = '';
  if(response && response.localFilePath){
     localFilePath = response.localFilePath;
  }
 html += '           <div class="col s12 clssg1549" style="">';
 var filetodisplay = ''; 
 if(objList.imageupload && objList.imageupload[0] && objList.imageupload[0].mediaID){
    filetodisplay = getuploadedfilepreview(objList.imageupload[0].fileNm);
 }
 if ( localFilePath && localFilePath != '' ) {
     html += '               <img recordID="'+objList._id+'"  id="imageupload12"   class=" clssg1549image imageupload12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ localFilePath+'" mediaid="'+ objList.mediaID +'" filenm="'+ objList.filenm +'" >';
 } else if(objList.imageupload && objList.imageupload[0] && objList.imageupload[0].mediaID){
    if(filetodisplay && filetodisplay != objList.imageupload[0].fileNm){
        html += '               <img recordID="'+objList._id+'"    id="imageupload12"   class=" clssg1549image imageupload12" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ filetodisplay + '">';
    } else {
        html += '               <img recordID="'+objList._id+'"    id="imageupload12"   class=" clssg1549image imageupload12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ CDN_PATH+objList.imageupload[0].mediaID+'_compressed.png">';
    }
 } else{
    // stage 6666666666666666
     html += '               <img recordID="'+objList._id+'"   id="imageupload12"   class=" clssg1549image imageupload12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
 }
 html += '           </div>';
 html += '     </div>';
 html += '      <div class="col s9 cls_sg9449 addshimmer" style="">';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg3549  '+adddbclass+' " style=" cursor: pointer;">';
 objList['clientname'] = objList['clientname'] ? objList['clientname'] : '';
 if(response.showShimmer){
    objList['clientname'] = '';
 }
 var clientname = objList['clientname'];
 html += '           <div recordID="' + objList._id +'"   id="clientname13" class="languagetranslation " style="" >'+ clientname+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg5549  '+adddbclass+' " style=" cursor: pointer;">';
 objList['policytype_name'] = objList['policytype_name'] ? objList['policytype_name'] : '';
 if(response.showShimmer){
    objList['policytype_name'] = '';
 }
 var policytype_name = objList['policytype_name'];
 html += '           <div recordID="' + objList._id +'"   id="policytype_name14" class="languagetranslation " style="" >'+ policytype_name+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s3 clssg7549  '+adddbclass+' " style=" cursor: pointer;">';
 objList['date'] = objList['date'] ? moment(new Date(objList['date'])).format('DD MMM YYYY') : '';
 var date = objList['date'];
 html += '           <div recordID="' + objList._id +'"   id="date15" class="languagetranslation " style="" >'+ date+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s5 clssg9549  '+adddbclass+' " style=" cursor: pointer;">';
 objList['fromtime'] = objList['fromtime'] ? objList['fromtime'] : '';
 if(response.showShimmer){
    objList['fromtime'] = '';
 }
 var fromtime = objList['fromtime'];
 html += '           <div recordID="' + objList._id +'"   id="fromtime16" class="languagetranslation " style="" >'+ fromtime+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s4 clssg1649  '+adddbclass+' " style=" cursor: pointer;">';
 objList['totime'] = objList['totime'] ? objList['totime'] : '';
 if(response.showShimmer){
    objList['totime'] = '';
 }
 var totime = objList['totime'];
 html += '           <div recordID="' + objList._id +'"   id="totime17" class="languagetranslation " style="" >'+ totime+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg3649  '+adddbclass+' " style=" cursor: pointer;">';
 objList['address_name'] = objList['address_name'] ? objList['address_name'] : '';
 if(response.showShimmer){
    objList['address_name'] = '';
 }
 var address_name = objList['address_name'];
 html += '           <div recordID="' + objList._id +'"   id="address_name18" class="languagetranslation " style="" >'+ address_name+'</div>';
 html += '     </div>';
 html += '     </div>';
 html += '     </div>';
 html += '      				</div>';
 html += '          </div>';
 html += '        </div>';
 html += '     </div>';
 html += '   </div>';
                  }
             });
                  var ios = navigator.userAgent.toLowerCase().indexOf("iphone os"); 
                  var isAndroid = navigator.userAgent.toLowerCase().indexOf("android"); 
                  if(1){ 
                          $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html)
                   $('#full-body-container').addClass('fadeInUp');
                  };
                  if(!response.showShimmer){
                      dcardLoaded['dcard_leftimage_collectioncontainer'] = true;
                      $('#collectioncontainerDivdcard_leftimage_collectioncontainer').find('.view_list_record').removeClass('shimmer');
                  }
                  $('.carddropdown').material_select();
                  $('<input>').attr({type: 'hidden',class: 'cardtoggleswitch',id: 'togleswitchvalue'}).appendTo('body')
                  if($('.js-candlestick').length) $('.js-candlestick').candlestick({afterSetting: function(input, wrapper, value) {$('#togleswitchvalue').val(value).attr('recordID', input.attr('id')).trigger('click');}});
                  if(radioGroups && radioGroups.length){
                      for(var key in radioGroups){
                          var groupName = radioGroups[key];
                          $('input:radio[name='+ groupName +']:first').prop('checked', true);
                          $('input:radio[name='+ groupName +']:first').trigger('change');
                      }
                  }
              };
            };
            function getLocalImagedcard_leftimage_collectioncontainer(objList, mediaID, fileName) {
                try {
                    var appJSON = {};
                    appJSON.nextButtonCallback = 'handleLocalImagedcard_leftimage_collectioncontainer';
                    appJSON.url = CDN_PATH + mediaID+ '_compressed.png';
                    appJSON.fileMimeType = 'image/png';
                    appJSON.fileName = fileName;
                    appJSON.objList = objList;
                    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
                    if (isAndroid > -1) {
                        window.Android.getLocalImage(JSON.stringify(appJSON))
                    } else {
                        setupWebViewJavascriptBridge(function (bridge) {
                            bridgeObj = bridge;
                            bridgeObj.callHandler('getLocalImage', appJSON, function (response) { });
                            bridgeObj.registerHandler('handleLocalImagedcard_leftimage_collectioncontainer', function (responseData, responseCallback) {
                                handleLocalImagedcard_leftimage_collectioncontainer(responseData)
                            });
                        });
                    }
                } catch (err) {
            
                }
            }
            function handleLocalImagedcard_leftimage_collectioncontainer(response) {
               var objList = response.dataDictionay.objList;
               var html = '';
               
 html += '      <div class="row plain-card search" search="'+ removeSpecialChars(  objList.imageupload  + objList.clientname  + objList.policytype_name  + objList.date  + objList.fromtime  + objList.totime  + objList.address_name) +'">';
 html += '      		<div class="col s12 m12">';
 html += '               <div class="card-content">';
 html += '                  <div     status="'+ objList.status+ '"  recordID="'+objList._id+'" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
 html += '      <div class="row  element" style=""  >';
 html += '      <div class="col s3 cls_sg7449" style="">';
  var localFilePath = '';
  if(response && response.localFilePath){
     localFilePath = response.localFilePath;
  }
 html += '           <div class="col s12 clssg1549" style="">';
 var filetodisplay = ''; 
 if(objList.imageupload && objList.imageupload[0] && objList.imageupload[0].mediaID){
    filetodisplay = getuploadedfilepreview(objList.imageupload[0].fileNm);
 }
 if ( localFilePath && localFilePath != '' ) {
     html += '               <img recordID="'+objList._id+'"  id="imageupload12"   class=" clssg1549image imageupload12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ localFilePath+'" mediaid="'+ objList.mediaID +'" filenm="'+ objList.filenm +'" >';
 } else if(objList.imageupload && objList.imageupload[0] && objList.imageupload[0].mediaID){
    if(filetodisplay && filetodisplay != objList.imageupload[0].fileNm){
        html += '               <img recordID="'+objList._id+'"    id="imageupload12"   class=" clssg1549image imageupload12" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ filetodisplay + '">';
    } else {
        html += '               <img recordID="'+objList._id+'"    id="imageupload12"   class=" clssg1549image imageupload12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ CDN_PATH+objList.imageupload[0].mediaID+'_compressed.png">';
    }
 } else{
    // stage 6666666666666666
     html += '               <img recordID="'+objList._id+'"   id="imageupload12"   class=" clssg1549image imageupload12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
 }
 html += '           </div>';
 html += '     </div>';
 html += '      <div class="col s9 cls_sg9449 addshimmer" style="">';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg3549  '+adddbclass+' " style=" cursor: pointer;">';
 objList['clientname'] = objList['clientname'] ? objList['clientname'] : '';
 if(response.showShimmer){
    objList['clientname'] = '';
 }
 var clientname = objList['clientname'];
 html += '           <div recordID="' + objList._id +'"   id="clientname13" class="languagetranslation " style="" >'+ clientname+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg5549  '+adddbclass+' " style=" cursor: pointer;">';
 objList['policytype_name'] = objList['policytype_name'] ? objList['policytype_name'] : '';
 if(response.showShimmer){
    objList['policytype_name'] = '';
 }
 var policytype_name = objList['policytype_name'];
 html += '           <div recordID="' + objList._id +'"   id="policytype_name14" class="languagetranslation " style="" >'+ policytype_name+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s3 clssg7549  '+adddbclass+' " style=" cursor: pointer;">';
 objList['date'] = objList['date'] ? moment(new Date(objList['date'])).format('DD MMM YYYY') : '';
 var date = objList['date'];
 html += '           <div recordID="' + objList._id +'"   id="date15" class="languagetranslation " style="" >'+ date+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s5 clssg9549  '+adddbclass+' " style=" cursor: pointer;">';
 objList['fromtime'] = objList['fromtime'] ? objList['fromtime'] : '';
 if(response.showShimmer){
    objList['fromtime'] = '';
 }
 var fromtime = objList['fromtime'];
 html += '           <div recordID="' + objList._id +'"   id="fromtime16" class="languagetranslation " style="" >'+ fromtime+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s4 clssg1649  '+adddbclass+' " style=" cursor: pointer;">';
 objList['totime'] = objList['totime'] ? objList['totime'] : '';
 if(response.showShimmer){
    objList['totime'] = '';
 }
 var totime = objList['totime'];
 html += '           <div recordID="' + objList._id +'"   id="totime17" class="languagetranslation " style="" >'+ totime+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg3649  '+adddbclass+' " style=" cursor: pointer;">';
 objList['address_name'] = objList['address_name'] ? objList['address_name'] : '';
 if(response.showShimmer){
    objList['address_name'] = '';
 }
 var address_name = objList['address_name'];
 html += '           <div recordID="' + objList._id +'"   id="address_name18" class="languagetranslation " style="" >'+ address_name+'</div>';
 html += '     </div>';
 html += '     </div>';
 html += '     </div>';
 html += '      				</div>';
 html += '          </div>';
 html += '        </div>';
 html += '     </div>';
 html += '   </div>';
               $('#collectioncontainerDivdcard_leftimage_collectioncontainer').append(html)
              $('#full-body-container').addClass('fadeInUp');
        dcardLoaded['dcard_leftimage_collectioncontainer'] = true;
        $('#collectioncontainerDivdcard_leftimage_collectioncontainer').find('.view_list_record').removeClass('shimmer');
        // after html bining code
        };

        function getdcard_leftimage_collectioncontainerapp_consultantappointmentlistingPadView(response, tokenKey, queryMode) {
              var html = '';
              if (response.data.length == 0) {
                              html += '<tr>';
                              html +=     '<td colspan="1" class="text_center first_row_table_td">';
                              html +=         'No record found';
                              html +=     '</td>';
                              html += '</tr>';
             } else {
              html =       '';
              $.each(response.data, function (keyList, objList) {
               
 html += '      <div class="row plain-card search" search="'+ removeSpecialChars(  objList.imageupload  + objList.clientname  + objList.policytype_name  + objList.date  + objList.fromtime  + objList.totime  + objList.address_name) +'">';
 html += '      		<div class="col s12 m12">';
 html += '               <div class="card-content">';
 html += '                  <div     status="'+ objList.status+ '"  recordID="'+objList._id+'" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
 html += '      <div class="row  element" style=""  >';
 html += '      <div class="col s3 cls_sg7449" style="">';
  var localFilePath = '';
  if(response && response.localFilePath){
     localFilePath = response.localFilePath;
  }
 html += '           <div class="col s12 clssg1549" style="">';
 var filetodisplay = ''; 
 if(objList.imageupload && objList.imageupload[0] && objList.imageupload[0].mediaID){
    filetodisplay = getuploadedfilepreview(objList.imageupload[0].fileNm);
 }
 if ( localFilePath && localFilePath != '' ) {
     html += '               <img recordID="'+objList._id+'"  id="imageupload12"   class=" clssg1549image imageupload12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ localFilePath+'" mediaid="'+ objList.mediaID +'" filenm="'+ objList.filenm +'" >';
 } else if(objList.imageupload && objList.imageupload[0] && objList.imageupload[0].mediaID){
    if(filetodisplay && filetodisplay != objList.imageupload[0].fileNm){
        html += '               <img recordID="'+objList._id+'"    id="imageupload12"   class=" clssg1549image imageupload12" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ filetodisplay + '">';
    } else {
        html += '               <img recordID="'+objList._id+'"    id="imageupload12"   class=" clssg1549image imageupload12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ CDN_PATH+objList.imageupload[0].mediaID+'_compressed.png">';
    }
 } else{
    // stage 6666666666666666
     html += '               <img recordID="'+objList._id+'"   id="imageupload12"   class=" clssg1549image imageupload12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
 }
 html += '           </div>';
 html += '     </div>';
 html += '      <div class="col s9 cls_sg9449 addshimmer" style="">';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg3549  '+adddbclass+' " style=" cursor: pointer;">';
 objList['clientname'] = objList['clientname'] ? objList['clientname'] : '';
 if(response.showShimmer){
    objList['clientname'] = '';
 }
 var clientname = objList['clientname'];
 html += '           <div recordID="' + objList._id +'"   id="clientname13" class="languagetranslation " style="" >'+ clientname+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg5549  '+adddbclass+' " style=" cursor: pointer;">';
 objList['policytype_name'] = objList['policytype_name'] ? objList['policytype_name'] : '';
 if(response.showShimmer){
    objList['policytype_name'] = '';
 }
 var policytype_name = objList['policytype_name'];
 html += '           <div recordID="' + objList._id +'"   id="policytype_name14" class="languagetranslation " style="" >'+ policytype_name+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s3 clssg7549  '+adddbclass+' " style=" cursor: pointer;">';
 objList['date'] = objList['date'] ? moment(new Date(objList['date'])).format('DD MMM YYYY') : '';
 var date = objList['date'];
 html += '           <div recordID="' + objList._id +'"   id="date15" class="languagetranslation " style="" >'+ date+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s5 clssg9549  '+adddbclass+' " style=" cursor: pointer;">';
 objList['fromtime'] = objList['fromtime'] ? objList['fromtime'] : '';
 if(response.showShimmer){
    objList['fromtime'] = '';
 }
 var fromtime = objList['fromtime'];
 html += '           <div recordID="' + objList._id +'"   id="fromtime16" class="languagetranslation " style="" >'+ fromtime+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s4 clssg1649  '+adddbclass+' " style=" cursor: pointer;">';
 objList['totime'] = objList['totime'] ? objList['totime'] : '';
 if(response.showShimmer){
    objList['totime'] = '';
 }
 var totime = objList['totime'];
 html += '           <div recordID="' + objList._id +'"   id="totime17" class="languagetranslation " style="" >'+ totime+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg3649  '+adddbclass+' " style=" cursor: pointer;">';
 objList['address_name'] = objList['address_name'] ? objList['address_name'] : '';
 if(response.showShimmer){
    objList['address_name'] = '';
 }
 var address_name = objList['address_name'];
 html += '           <div recordID="' + objList._id +'"   id="address_name18" class="languagetranslation " style="" >'+ address_name+'</div>';
 html += '     </div>';
 html += '     </div>';
 html += '     </div>';
 html += '      				</div>';
 html += '          </div>';
 html += '        </div>';
 html += '     </div>';
 html += '   </div>';
              }); // end of each loop
            };
              $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html)
        };

        function getdcard_leftimage_collectioncontainerapp_consultantappointmentlistingWebView(response, tokenKey, queryMode) {
              var html = '';
              if (response.data.length == 0) {
                              html += '<tr>';
                              html +=     '<td colspan="1" class="text_center first_row_table_td">';
                              html +=         'No record found';
                              html +=     '</td>';
                              html += '</tr>';
             } else {
              html =       '';
              $.each(response.data, function (keyList, objList) {
               
 html += '      <div class="row plain-card search" search="'+ removeSpecialChars(  objList.imageupload  + objList.clientname  + objList.policytype_name  + objList.date  + objList.fromtime  + objList.totime  + objList.address_name) +'">';
 html += '      		<div class="col s12 m12">';
 html += '               <div class="card-content">';
 html += '                  <div     status="'+ objList.status+ '"  recordID="'+objList._id+'" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
 html += '      <div class="row  element" style=""  >';
 html += '      <div class="col s3 cls_sg7449" style="">';
  var localFilePath = '';
  if(response && response.localFilePath){
     localFilePath = response.localFilePath;
  }
 html += '           <div class="col s12 clssg1549" style="">';
 var filetodisplay = ''; 
 if(objList.imageupload && objList.imageupload[0] && objList.imageupload[0].mediaID){
    filetodisplay = getuploadedfilepreview(objList.imageupload[0].fileNm);
 }
 if ( localFilePath && localFilePath != '' ) {
     html += '               <img recordID="'+objList._id+'"  id="imageupload12"   class=" clssg1549image imageupload12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ localFilePath+'" mediaid="'+ objList.mediaID +'" filenm="'+ objList.filenm +'" >';
 } else if(objList.imageupload && objList.imageupload[0] && objList.imageupload[0].mediaID){
    if(filetodisplay && filetodisplay != objList.imageupload[0].fileNm){
        html += '               <img recordID="'+objList._id+'"    id="imageupload12"   class=" clssg1549image imageupload12" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ filetodisplay + '">';
    } else {
        html += '               <img recordID="'+objList._id+'"    id="imageupload12"   class=" clssg1549image imageupload12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ CDN_PATH+objList.imageupload[0].mediaID+'_compressed.png">';
    }
 } else{
    // stage 6666666666666666
     html += '               <img recordID="'+objList._id+'"   id="imageupload12"   class=" clssg1549image imageupload12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
 }
 html += '           </div>';
 html += '     </div>';
 html += '      <div class="col s9 cls_sg9449 addshimmer" style="">';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg3549  '+adddbclass+' " style=" cursor: pointer;">';
 objList['clientname'] = objList['clientname'] ? objList['clientname'] : '';
 if(response.showShimmer){
    objList['clientname'] = '';
 }
 var clientname = objList['clientname'];
 html += '           <div recordID="' + objList._id +'"   id="clientname13" class="languagetranslation " style="" >'+ clientname+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg5549  '+adddbclass+' " style=" cursor: pointer;">';
 objList['policytype_name'] = objList['policytype_name'] ? objList['policytype_name'] : '';
 if(response.showShimmer){
    objList['policytype_name'] = '';
 }
 var policytype_name = objList['policytype_name'];
 html += '           <div recordID="' + objList._id +'"   id="policytype_name14" class="languagetranslation " style="" >'+ policytype_name+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s3 clssg7549  '+adddbclass+' " style=" cursor: pointer;">';
 objList['date'] = objList['date'] ? moment(new Date(objList['date'])).format('DD MMM YYYY') : '';
 var date = objList['date'];
 html += '           <div recordID="' + objList._id +'"   id="date15" class="languagetranslation " style="" >'+ date+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s5 clssg9549  '+adddbclass+' " style=" cursor: pointer;">';
 objList['fromtime'] = objList['fromtime'] ? objList['fromtime'] : '';
 if(response.showShimmer){
    objList['fromtime'] = '';
 }
 var fromtime = objList['fromtime'];
 html += '           <div recordID="' + objList._id +'"   id="fromtime16" class="languagetranslation " style="" >'+ fromtime+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s4 clssg1649  '+adddbclass+' " style=" cursor: pointer;">';
 objList['totime'] = objList['totime'] ? objList['totime'] : '';
 if(response.showShimmer){
    objList['totime'] = '';
 }
 var totime = objList['totime'];
 html += '           <div recordID="' + objList._id +'"   id="totime17" class="languagetranslation " style="" >'+ totime+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg3649  '+adddbclass+' " style=" cursor: pointer;">';
 objList['address_name'] = objList['address_name'] ? objList['address_name'] : '';
 if(response.showShimmer){
    objList['address_name'] = '';
 }
 var address_name = objList['address_name'];
 html += '           <div recordID="' + objList._id +'"   id="address_name18" class="languagetranslation " style="" >'+ address_name+'</div>';
 html += '     </div>';
 html += '     </div>';
 html += '     </div>';
 html += '      				</div>';
 html += '          </div>';
 html += '        </div>';
 html += '     </div>';
 html += '   </div>';
             }); // end of each loop 1
            };
              $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html)
        }; 
                 function updateOrder(params,callback) { 
                     $.ajax({  
                     	 url: '/milestone003/schedulerUpdateEvents_app_consultantappointmentlisting_',  
                         data: params,  
                         type: 'POST',  
                         success: function(response) {  
                             console.log("---response---- ", response);  
                             if (response.status == 0) {  
                  					callback({"response":response}) 
                             } else {  
                  				callback({"response":response}) 
                             }  
                         },  
                         error: function(xhr, status, error) {  
                   
                         },  
                     });  
                 }  
                 function getSchedulerEventsClientBeforeschedulerUpdateEvents_app_consultantappointmentlisting_(paramsType,callback) {
 	try{
 var response = paramsType;
 callback();
  } catch(error){
  	console.log('Error in getSchedulerEventsClientBeforeschedulerUpdateEvents_app_consultantappointmentlisting_', error);
  } 
                 } 
                 function getSchedulerEventsClientAfterapp_consultantappointmentlisting(response,callback) {
 	try{
 callback();
  } catch(error){
  	console.log('Error in getSchedulerEventsClientAfterapp_consultantappointmentlisting', error);
  } 
                 }
