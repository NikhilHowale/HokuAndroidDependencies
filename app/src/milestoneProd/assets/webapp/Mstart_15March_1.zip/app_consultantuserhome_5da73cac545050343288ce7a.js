
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var totaldcard_leftimage_collectioncontainer = 0;
var totallbl_orders_bannerimageupload = 0;
function makeSlidesuserphotoupload6(data) {
    var slide = '';
    var htmlString = '';
    if (data && data.length == 1) { data = data[0].userphotoupload ? data[0].userphotoupload : []; };
    if (data && data.length > 0) {
        for (let index = 0; index < data.length; index++) {
            const element = data[index];
            var mediaID;
            if (element && element.userphotoupload && element.userphotoupload[0]) {
                mediaID = element.userphotoupload[0].mediaID;
            } else if (element && element.mediaID) {
                mediaID = element.mediaID;
            }
            slide += ' <div class="swiper-slide" href="#one!" >'
            slide += '    <div class="row  col s12" style="padding: 0px" !important;>'
            slide += '       <div id="image6_div" style="text-align: center;">'
            slide += '          <img    src="' + CDN_PATH + mediaID + '_compressed.png" style="width:100%; height:192px">'
            slide += '       </div>'
            slide += '    </div>'
            slide += '        </div>'
        }
        if (slide) {
            $("#userphotoupload6").html(slide)
        }
        var swiper = new Swiper('.swiper-container', {
            autoplay: {
                delay: 2500,
                disableOnInteraction: false,
            },
            watchOverflow: true,
            pagination: {
                el: '.swiper-pagination'
            },
        });
        $('.dynamic-slider-view').removeClass('shimmer');
    }
}
$(document).ready(function () {

    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"))
    }

    var objParamsToken = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsToken.tokenKey = getParameterByName('tokenKey');
    objParamsToken.secretKey = getParameterByName('secretKey');

    var userRole = $('#userRole').val();
    var userID = $('#userID').val();
    var createrOfRecord = $('#createrOfRecord').val();
    var queryMode = getParameterByName('queryMode');
    var recordID = $.trim($('#recordID').val());
    var addSessionComments = [];

    getLatestCustomer();
    getVoucherRequest();


    var queryMode = getParameterByName('queryMode');
    var isMobile = $('#isMobile').val();
    var isiPad = $('#isiPad').val();
    if (queryMode != '') {
        var tokenKey = $('#tokenKey').val();
        var objParamsList = {};
        objParamsList.queryMode = queryMode;
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParamsList.tokenKey = getParameterByName('tokenKey');
        objParamsList.secretKey = getParameterByName('secretKey');
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = isMobile;
        objParamsList.isiPad = isiPad;
        objParamsList.applyFilter = false;
        getDataProcessBeforeCalldcard_leftimage_collectioncontainerOrders5da73cac545050343288ce7a(objParamsList, function (processBeforeRes) {
            if (getParameterByName('type') && getParameterByName('type') != '' && getParameterByName('type') != null && getParameterByName('type') != 'undefined') {
                objParamsList.type = getParameterByName('type');
            }
            if (getParameterByName('consultantid') && getParameterByName('consultantid') != '' && getParameterByName('consultantid') != null && getParameterByName('consultantid') != 'undefined') {
                objParamsList.consultantid = getParameterByName('consultantid');
            }
            if (getParameterByName('status') && getParameterByName('status') != '' && getParameterByName('status') != null && getParameterByName('status') != 'undefined') {
                objParamsList.status = getParameterByName('status');
            }
            var dcard_leftimage_collectioncontainerapp_consultantuserhome = false//localStorage.getItem('dcard_leftimage_collectioncontainerapp_consultantuserhome');
            var applyFilter = getParameterByName('applyFilter');
            $('#display_loading').removeClass('hideme');
            if (dcard_leftimage_collectioncontainerapp_consultantuserhome && applyFilter != 'true') {
                response = JSON.parse(dcard_leftimage_collectioncontainerapp_consultantuserhome);
                $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html('');
                //getdcard_leftimage_collectioncontainerapp_consultantuserhomeMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
                //dcard_leftimage_collectioncontainerapp_consultantuserhomeSync(response.timestamp);
                show_dcard_leftimage_collectioncontainerapp_consultantuserhome_Details(objParamsList)
            } else {
                show_dcard_leftimage_collectioncontainerapp_consultantuserhome_Details(objParamsList)
            }
        });//End of get data process before call.

        /// Bind Events  >>>


        var dcard_topimage2x2_collectioncontainerapp_userhome = false//localStorage.getItem('dcard_topimage2x2_collectioncontainerapp_userhome');
        var applyFilter = getParameterByName('applyFilter');
        $('#display_loading').removeClass('hideme');
        if (dcard_topimage2x2_collectioncontainerapp_userhome && applyFilter != 'true') {
            response = JSON.parse(dcard_topimage2x2_collectioncontainerapp_userhome);
            $('#dcard_topimage2x2_collectioncontainerapp_userhome').html('');
            getdcard_topimage2x2_collectioncontainerapp_userhomeMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
            dcard_topimage_collectioncontainerapp_consultantuserhomeSync(response.timestamp);
        } else {
            populateEvents()
        }

    }
    //  populateEvents();
    $(document).on('click', '.dcard_leftimage_collectioncontainer', function (e) {
        e.preventDefault();
        if (dcardLoaded && !dcardLoaded['dcard_leftimage_collectioncontainer']) { return false; }; // added for use should not able to click until data loaded
        localStorage.setItem("headerPageName", 'app_consultantappointmentdetails');
        var recordID = $(this).attr('recordID');// get record ID;
        var ordersid = $(this).attr('recordID');// get record ID;
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = 'update';
        var nextPage = 'app_consultantappointmentdetails';
        if (!nextPage) {
            return false;
        }
        var pageurl = nextPage + '_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&ordersid=' + ordersid + '&recordID=' + recordID + '&applyFilter=true';

        window.location.href = pageurl;
        return false;
    }); // to add New record

    $(document).on('click', '.rejectVoucher', function (e) {
        e.preventDefault();
        $('#yesReject12').attr('recordid', $(this).attr('recordid'))
        $('.modal').modal('open');
    })

    $(document).on('click', '#yesReject12', function (e) {
        let params = {};
        params.tokenKey = getParameterByName('tokenKey');
        params.secretKey = getParameterByName('secretKey');
        params.recordID = $(this).attr('recordid');
        
        params.status = 'Rejected'
        params.ajaXCallURL = ajaXCallURL + '/milestone003/updateAjaxredeemedvouchersapp_sacaner';
        $.ajax({
            url: params.ajaXCallURL,
            data: params,
            type: 'POST',
            success: function (response) {
                $('#display_loading').addClass('hideme');
                getVoucherRequest();
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            }
        });
        return false;
    }); // to add New record
    $(document).on('click', '.dcard_topimage2x2_collectioncontainer', function () {
        if (dcardLoaded && !dcardLoaded['dcard_topimage2x2_collectioncontainer']) { return false; }; // added for use should not able to click until data loaded
        localStorage.setItem("headerPageName", 'app_productadditionaldetails');
        var recordID = $(this).attr('recordID');// get record ID;
        var bazaarid = $(this).attr('recordID');// get record ID;
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = 'update';
        var nextPage = 'app_productadditionaldetails';
        if (!nextPage) {
            return false;
        }
        var parent = "app_consultantuserhome";
        var pageurl = nextPage + '_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&bazaarid=' + bazaarid + '&recordID=' + recordID + '&applyFilter=true' + "&parent=" + parent;
        window.location.href = pageurl;
        return false;
    }); // to add New record
    var addedRecords = [];
    localStorage.setItem('addedRecords', []);


    $(document).on('click', '#sg6318', function () {
        try {
            var element = $(this);
            var nextPage = 'app_customernotificationlisting';
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "mylist";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var parent = "app_consultantuserhome";
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString + "&parent=" + parent;
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - notifications27", error)
        }
    })

    $(document).on('click', '#viewall9', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_allupcomingeventslist';
            var queryParams = queryStringToJSON();
            localStorage.setItem("activeMenu", "Home")

            queryParams["queryMode"] = "mylist";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - viewall9", error)
        }
    })

    $(document).on('click', '#viewall19', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_consultantrequestappointmentslisting';
            var queryParams = queryStringToJSON();
            localStorage.setItem("activeMenu", "Home")

            queryParams["queryMode"] = "mylist";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - viewall9", error)
        }
    })

    $(document).on('click', '#viewall_latest19', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_consultantclientlisting';
            var queryParams = queryStringToJSON();
            // localStorage.setItem("activeMenu","Home")

            queryParams["queryMode"] = "mylist";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - viewall9", error)
        }
    })
    $(document).on('click', '.voucherdcard', function (e) {
        e.preventDefault();
        if(e.target.classList.contains('rejectVoucher')) {
            return false;
        }
        localStorage.setItem("headerPageName", 'app_consultantvoucherdetails');
        var recordID = $(this).attr('recordID');// get record ID;
        var redeemedvouchersid = $(this).attr('recordID');// get record ID;
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = 'update';
        var nextPage = 'app_consultantvoucherdetails';
        if (!nextPage) {
            return false;
        }
        var pageurl = nextPage + '_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&redeemedvouchersid=' + redeemedvouchersid + '&recordID=' + recordID + '&applyFilter=true';
        window.location.href = pageurl;
        return false;
    })

    $(document).on('click', '#viewall_voucher19', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_consultantrequestvoucherlisting';
            var queryParams = queryStringToJSON();
            // localStorage.setItem("activeMenu","Home")

            queryParams["queryMode"] = "mylist";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - viewall9", error)
        }
    })

    var consultantbannerimages = localStorage.getItem("consultantbannerimages")
    if (consultantbannerimages) {
        var response = JSON.parse(consultantbannerimages)
        makeSlidesuserphotoupload6(response.data)
        syncList_SLider(response.timestamp)
    }
    else {
        getSliderImages()
    }
    function syncList_SLider(timestamp) {
        var paramsType = {};
        paramsType.tokenKey = getParameterByName('tokenKey');
        paramsType.secretKey = getParameterByName('secretKey');
        paramsType.timestamp = timestamp
        // getCountProcessBeforeCalluserphotoupload6(paramsType, function (processBeforeRes) {
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        $.ajax({
            url: ajaXCallURL + '/milestone003/syncList_showslider_app_consultantuserhome_Consultantbanner5da73cac545050343288ce7alblordersbannerimageupload',
            data: paramsType,
            type: 'POST',
            success: function (response) {
                if (response.status == 1) {
                    localStorage.removeItem("consultantbannerimages")

                    getSliderImages()
                } else {
                    makeSlidesuserphotoupload6([])
                }
            },
            error: function (xhr, status, error) {
            },
        });
        // });
    }
    function getSliderImages() {
        var paramsType = {};
        paramsType.tokenKey = getParameterByName('tokenKey');
        paramsType.secretKey = getParameterByName('secretKey');
        getCountProcessBeforeCalluserphotoupload6(paramsType, function (processBeforeRes) {
            var ajaXCallURL = $.trim($('#ajaXCallURL').val());
            $.ajax({
                url: ajaXCallURL + '/milestone003/showslider_app_consultantuserhome_Consultantbanner5da73cac545050343288ce7alblordersbannerimageupload',
                data: paramsType,
                type: 'POST',
                success: function (response) {
                    if (response.status == 0) {
                        localStorage.setItem("consultantbannerimages", JSON.stringify(response))
                        makeSlidesuserphotoupload6(response.data)
                    } else {
                        makeSlidesuserphotoupload6([])
                    }
                },
                error: function (xhr, status, error) {
                },
            });
        });
    }
    function getCountProcessBeforeCalluserphotoupload6(paramsType, callback) {
        callback();
    }
    showBottomMenu();

    $('#togBtn').change(function() {
        var objParams = {}
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParams.tokenKey = getParameterByName('tokenKey');
        var recordID = localStorage.getItem("userID");
        objParams.secretKey = getParameterByName('secretKey');
        objParams.offlineDataID = localStorage.getItem("offlineDataID");
       
        objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxusermanagement7555updateapp_clientprofile';
        objParams.recordID =  recordID;
        $('#display_loading').removeClass('hideme');
        objParams.enableNotifications = $(this).is(':checked')
        $.ajax({
            url: objParams.callUrl,
            data: objParams,
            type: 'POST',
            success: function (response) {
                if (response.status == 0) {
                    $('#display_loading').addClass('hideme');
    
                    return false;
                } else {
                    $('#display_loading').addClass('hideme');
                    $('#update3_error').html(response.error);
                    $('#update3_error').show();
                }
                $('#391757').removeProp('disabled');
            },
            error: function (xhr, status, error) {
                $('#display_loading').addClass('hideme');
                $('#update3').removeProp('disabled');
            },
        });
    
    
    });
});//end of ready
function getDataProcessBeforeCalldcard_leftimage_collectioncontainerOrders5da73cac545050343288ce7a(objParamsList, callback) {
    var response = objParamsList
    objParamsList.type = 'appointments';

    objParamsList.consultantid = localStorage.userID;
    objParamsList.status = 'Requested';

    callback();
}



function getLatestCustomer() {

    try {
        var objParamsList = {};
        objParamsList.queryMode = 'mylist';
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParamsList.tokenKey = getParameterByName('tokenKey');
        objParamsList.secretKey = getParameterByName('secretKey');
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = true;
        objParamsList.customerLimit = 3;
        objParamsList.consultantid = localStorage.userID;
        $.ajax({
            url: objParamsList.ajaXCallURL + '/milestone003/getListDetails_Usermanagement5da73cac545050343288ce7a_app_consultantclientlisting_dcard_leftimage_collectioncontainer',
            data: objParamsList,
            type: 'POST',
            success: function (response) {
                $('#display_loading').addClass('hideme');
                showCustomerInDcard(response);
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            }
        });
    } catch (err) {
        console.log('Error in workingtoolsSync', err);
    }
}

function getVoucherRequest() {

    try {
        var objParamsList = {};
        objParamsList.queryMode = 'mylist';
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParamsList.tokenKey = getParameterByName('tokenKey');
        objParamsList.tokenKey = getParameterByName('tokenKey');
        objParamsList.secretKey = getParameterByName('secretKey');
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = true;
        objParamsList.consultantid = localStorage.userID;
        objParamsList.fetch = 3;
        objParamsList.status = 'Requested';
        $.ajax({
            url: objParamsList.ajaXCallURL + '/milestone003/getListDetails_Redeemedvouchers5da73cac545050343288ce7a_app_consultantrequestvoucherlisting_dcard_collectioncontainer',
            data: objParamsList,
            type: 'POST',
            success: function (response) {
                $('#display_loading').addClass('hideme');
                $('.modal').modal('close');
                getdcard_collectioncontainerapp_consultantrequestvoucherlistingMobileView(response);
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            }
        });
    } catch (err) {
        console.log('Error in workingtoolsSync', err);
    }
}

function showCustomerInDcard(response) {
    if (response.status == 0 && response.data && Array.isArray(response.data)) {
        var html = '';
        response.data.forEach(obj => {
            let src = '';
            html +=
                `<div class="row custCard">
                <div class="customercard">
                    <div class="col s3">`
            if (obj.userphotoupload && Array.isArray(obj.userphotoupload) && obj.userphotoupload[0]) {
                src = globalImgPath.replace('{{mediaID}}', obj.userphotoupload[0].mediaID)
                html += `<img src="${src}" onerror="this.src='https://appscdn-us.hokuapps.com/card.png'" class="customerImages">`
            } else {
                html += `<img src="default.png" onerror="this.src='https://appscdn-us.hokuapps.com/card.png'" class="customerImages">`
            }

            html += `</div>
                    <div class="col s8">
                        <div class="customerName"> ${obj.name}</div>
                        <div class="joinedat"> Joined on ${moment(new Date(obj.createdOn)).format('DD/MM/YYYY')}</div>
                    </div>
                    <div class="col s1"><img src="FinancialServices-GetInTouch-White.svg" style="width: 40px; float: right;padding-top: 22px;"></div>
                </div>
            </div>`
        });
        $('#latestcustomerdcard123').html(html);
    }
}

function getdcard_collectioncontainerapp_consultantrequestvoucherlistingMobileView(response) {
    var html = '';
    if(response.data)
    {
if (response.data.length == 0) {
        html += '<div class="nodatafound">';
        html += '<img src="nodatafound.gif" width="100%">';
        html += '<br>';
        html += '<!-- span>No record found</span -->';
        html += '</div>';
        $('#collectioncontainerDivdcard_collectioncontainer').html(html);;
    } else {
        html = '';
        var radioGroups = [];
        $.each(response.data, function (keyList, objList) {
            html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.vouchername + objList.clientname + objList.createdon) + '">';
            html += '             <div class="col s12 m12 bgwhite">';
            html += '               <div class="card-content">';
            html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_collectioncontainer voucherdcard" style="" >';
            html += '      <div class="row  element" style=""  >';
            html += '      <div class="col s8 element" style=""  >';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg0411  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['createdOn'] = objList['createdOn'] ? moment(new Date(objList['createdOn'])).format('DD MMMM YYYY hh:mm A') : '';
            var createdOn = objList['createdOn'];
            html += '           <div recordID="' + objList._id + '"   id="createdOn14" class="languagetranslation " style="" >' + createdOn + '</div>';
            html += '     </div>';

            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg6311  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['vouchername'] = objList['vouchername'] ? objList['vouchername'] : '';
            if (response.showShimmer) {
                objList['vouchername'] = '';
            }
            var vouchername = objList['vouchername'];
            html += '           <div recordID="' + objList._id + '"   id="vouchername12" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Voucher :</span>' + vouchername + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg8311  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['name'] = objList['name'] ? objList['name'] : '';
            if (response.showShimmer) {
                objList['name'] = '';
            }
            var name = objList['name'];
            html += '           <div recordID="' + objList._id + '"   id="name13" class="languagetranslation " style="" >' + name + '</div>';
            html += '     </div>';

            html += '     </div>';
            html += '      <div class="col s2" style=""  > <img recordID="' + objList._id + '" src="check.png"  class="iconcrossncheck" /> </div>';
            html += '      <div class="col s2" style=""  > <img recordID="' + objList._id + '" src="cross.svg"  class="iconcrossncheck rejectVoucher" /> </div>';
            html += '                     </div>';
            html += '              </div>';
            html += '          </div>';
            html += '        </div>';
            html += '     </div>';
            html += '   </div>';
        });
        $('#collectioncontainerDivdcard_collectioncontainer').html(html)
        $('#full-body-container').addClass('fadeInUp');
        if (!response.showShimmer) {
            dcardLoaded['dcard_collectioncontainer'] = true;
            $('#collectioncontainerDivdcard_collectioncontainer').find('.view_list_record').removeClass('shimmer');
        }
        $('.carddropdown').material_select();
        $('<input>').attr({ type: 'hidden', class: 'cardtoggleswitch', id: 'togleswitchvalue' }).appendTo('body')
        if ($('.js-candlestick').length) $('.js-candlestick').candlestick({ afterSetting: function (input, wrapper, value) { $('#togleswitchvalue').val(value).attr('recordID', input.attr('id')).trigger('click'); } });
        if (radioGroups && radioGroups.length) {
            for (var key in radioGroups) {
                var groupName = radioGroups[key];
                $('input:radio[name=' + groupName + ']:first').prop('checked', true);
                $('input:radio[name=' + groupName + ']:first').trigger('change');
            }
        }
    };
};
    }
    

function dcard_topimage_collectioncontainerapp_consultantuserhomeSync(timestamp) {
    try {
        var objParamsList = {};
        objParamsList.queryMode = 'mylist';
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParamsList.tokenKey = getParameterByName('tokenKey');
        objParamsList.secretKey = getParameterByName('secretKey');
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = true;
        objParamsList.timestamp = timestamp;
        $.ajax({
            url: objParamsList.ajaXCallURL + '/milestone003/syncListDetails_Bazaar5da73cac545050343288ce7a_app_userhome',
            data: objParamsList,
            type: 'POST',
            success: function (response) {
                $('#display_loading').addClass('hideme');
                if (response.status != undefined && response.status == 1) {
                    localStorage.removeItem('dcard_topimage2x2_collectioncontainerapp_userhome');
                    var objParamsList = {};
                    objParamsList.queryMode = 'mylist';
                    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                    objParamsList.tokenKey = getParameterByName('tokenKey');
                    objParamsList.secretKey = getParameterByName('secretKey');
                    objParamsList.ajaXCallURL = ajaXCallURL;
                    objParamsList.isMobile = 'true';
                    objParamsList.isiPad = false;
                    objParamsList.timestamp = timestamp;
                    if (getParameterByName('type') && getParameterByName('type') != '' && getParameterByName('type') != null && getParameterByName('type') != 'undefined') {
                        objParamsList.type = getParameterByName('type');
                    }
                    if (getParameterByName('consultantid') && getParameterByName('consultantid') != '' && getParameterByName('consultantid') != null && getParameterByName('consultantid') != 'undefined') {
                        objParamsList.consultantid = getParameterByName('consultantid');
                    }
                    if (getParameterByName('status') && getParameterByName('status') != '' && getParameterByName('status') != null && getParameterByName('status') != 'undefined') {
                        objParamsList.status = getParameterByName('status');
                    }
                    populateEvents();
                    //  show_dcard_leftimage_collectioncontainerapp_consultantuserhome_Details(objParamsList)
                } else {
                    populateEvents();
                }
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            }
        });
    } catch (err) {
        // console.log('Error in workingtoolsSync', err);
    }
}
function dcard_leftimage_collectioncontainerapp_consultantuserhomeSync(timestamp) {
    try {
        var objParamsList = {};
        objParamsList.queryMode = 'mylist';
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParamsList.tokenKey = getParameterByName('tokenKey');
        objParamsList.secretKey = getParameterByName('secretKey');
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = true;
        objParamsList.timestamp = timestamp;
        $.ajax({
            url: objParamsList.ajaXCallURL + '/milestone003/syncListDetails_Orders5da73cac545050343288ce7a_app_consultantuserhome',
            data: objParamsList,
            type: 'POST',
            success: function (response) {
                $('#display_loading').addClass('hideme');
                if (response.status != undefined && response.status == 1) {
                    localStorage.removeItem('dcard_leftimage_collectioncontainerapp_consultantuserhome');
                    var objParamsList = {};
                    objParamsList.queryMode = 'mylist';
                    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                    objParamsList.tokenKey = getParameterByName('tokenKey');
                    objParamsList.secretKey = getParameterByName('secretKey');
                    objParamsList.ajaXCallURL = ajaXCallURL;
                    objParamsList.isMobile = 'true';
                    objParamsList.isiPad = false;
                    objParamsList.timestamp = timestamp;
                    if (getParameterByName('type') && getParameterByName('type') != '' && getParameterByName('type') != null && getParameterByName('type') != 'undefined') {
                        objParamsList.type = getParameterByName('type');
                    }
                    if (getParameterByName('consultantid') && getParameterByName('consultantid') != '' && getParameterByName('consultantid') != null && getParameterByName('consultantid') != 'undefined') {
                        objParamsList.consultantid = getParameterByName('consultantid');
                    }
                    if (getParameterByName('status') && getParameterByName('status') != '' && getParameterByName('status') != null && getParameterByName('status') != 'undefined') {
                        objParamsList.status = getParameterByName('status');
                    }
                    show_dcard_leftimage_collectioncontainerapp_consultantuserhome_Details(objParamsList)
                }
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            }
        });
    } catch (err) {
        console.log('Error in workingtoolsSync', err);
    }
}
function show_dcard_leftimage_collectioncontainerapp_consultantuserhome_Details(objParamsList) {
    if (getParameterByName('type') && getParameterByName('type') != '' && getParameterByName('type') != null && getParameterByName('type') != 'undefined') {
        objParamsList.type = getParameterByName('type');
    }
    if (getParameterByName('consultantid') && getParameterByName('consultantid') != '' && getParameterByName('consultantid') != null && getParameterByName('consultantid') != 'undefined') {
        objParamsList.consultantid = getParameterByName('consultantid');
    }
    if (getParameterByName('status') && getParameterByName('status') != '' && getParameterByName('status') != null && getParameterByName('status') != 'undefined') {
        objParamsList.status = getParameterByName('status');
    }
    localStorage.setItem('appconsultantuserhomeFilterBox', '');
    // objParamsList.isMobile = false;
    // objParamsList.queryMode = 'adminList';
    // delete objParamsList.isMobile;
    // delete objParamsList.isiPad;
    // delete objParamsList.applyFilter;
    // delete objParamsList.type;
    // delete objParamsList.consultantid;
    // delete objParamsList.status;
    $.ajax({
        url: objParamsList.ajaXCallURL + '/milestone003/getListDetails_Orders5da73cac545050343288ce7a_app_consultantuserhome_dcard_leftimage_collectioncontainer',
        // url: objParamsList.ajaXCallURL + '/milestone003/getListDetails_Orders5da73cac545050343288ce7a_jobmarketweb_jobmarketwebKendoList',
        data: objParamsList,
        type: 'POST',
        success: function (response) {
            getDataProcessAfterCalldcard_leftimage_collectioncontainerOrders5da73cac545050343288ce7a(response, function () {
                if (response.status != undefined && response.status == 0) {
                    // response.data = response.data.slice(0, 5);
                    // console.log('response.data ',response.data )
                    if (objParamsList.isMobile == 'true' || true) {
                        $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html('');
                        localStorage.setItem('dcard_leftimage_collectioncontainerapp_consultantuserhome', JSON.stringify(response));
                        getdcard_leftimage_collectioncontainerapp_consultantuserhomeMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    } else if (objParamsList.isiPad == 'true') {
                        getdcard_leftimage_collectioncontainerapp_consultantuserhomeiPadView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    } else {
                        getdcard_leftimage_collectioncontainerapp_consultantuserhomeWebView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    }
                    $('#display_loading').addClass('hideme');
                } else {
                    $('#display_loading').addClass('hideme')
                }
            });
        },
        error: function (xhr, status, error) {
            $('#display_loading').addClass('hideme')
            handleError(xhr, status, error);
        },
    });
} // end of function     

function getDataProcessAfterCalldcard_leftimage_collectioncontainerOrders5da73cac545050343288ce7a(response, callback) {

    callback();
}

function getdcard_leftimage_collectioncontainerapp_consultantuserhomeMobileView(response, tokenKey, queryMode) {
    var html = '';
    if (response.data.length == 0) {
        html += '<div class="nodatafound">';
        html += '<img src="nodatafound.gif" width="100%">';
        html += '<br>';
        html += '<!-- span>No record found</span -->';
        html += '</div>';
        $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html);;
    } else {
        html = '';
        var radioGroups = [];
        $.each(response.data, function (keyList, objList) {

            // var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
            // var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            // if (isAndroid > -1 || ios > -1) {  // need to fix with native gyes.. images not getting download
            //     var mediaID = '';
            //     var fileName = '';
            //     if (objList['userphotoupload'] && objList['userphotoupload'][0].mediaID) {
            //         mediaID = objList['userphotoupload'][0].mediaID;
            //         fileName = objList['userphotoupload'][0].mediaID + '.png';
            //     }
            //     getLocalImagedcard_leftimage_collectioncontainer(objList, mediaID, fileName);
            // } else {


            // }

            html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.imageupload + objList.clientname + objList.policytype_name + objList.date + objList.fromtime + objList.totime + objList.address_name) + '">';
            html += '      		<div class="col s12 m12 ">';
            html += '               <div class="card-content">';
            html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
            html += '      <div class="row  element" style=""  >';

            html += '      <div class="col s12 cls_sg1451 addshimmer" style="">';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg7451  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['policytype_name'] = objList['policytype_name'] ? objList['policytype_name'] : '';
            if (response.showShimmer) {
                objList['policytype_name'] = '';
            }
            var date = objList.slotdate ? new moment(new Date(objList.slotdate)).format('dddd, DD MMMM YYYY') : '';
            html += '           <div recordID="' + objList._id + '"   id="policytype_name17" class="languagetranslation " style="" >' + date + ' ' + (objList.starttime ? objList.starttime : '') + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s10 clssg5551  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['note'] = objList['note'] ? objList['note'] : '';
            if (response.showShimmer) {
                objList['address_name'] = '';
            }
            var note = objList['note'];
            html += '           <div recordID="' + objList._id + '"   id="address_name21" class="languagetranslation " style="" >' + note + '</div>';
            html += '     </div>';
            html += '     <div class="col s2"><img class="calendar" src="calendar.svg" />';
            html += '     </div>';
            html += '     </div>';
            html += '     </div>';
            html += '      				</div>';
            html += '          </div>';
            html += '        </div>';
            html += '     </div>';
            html += '   </div>';
        });
        var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        //  if (1) {
        $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html)
        $('#full-body-container').addClass('fadeInUp');
        //   };
        if (!response.showShimmer) {
            dcardLoaded['dcard_leftimage_collectioncontainer'] = true;
            $('#collectioncontainerDivdcard_leftimage_collectioncontainer').find('.view_list_record').removeClass('shimmer');
        }
        // $('.carddropdown').material_select();
        // $('<input>').attr({ type: 'hidden', class: 'cardtoggleswitch', id: 'togleswitchvalue' }).appendTo('body')
        // if ($('.js-candlestick').length) $('.js-candlestick').candlestick({ afterSetting: function (input, wrapper, value) { $('#togleswitchvalue').val(value).attr('recordID', input.attr('id')).trigger('click'); } });
        // if (radioGroups && radioGroups.length) {
        //     for (var key in radioGroups) {
        //         var groupName = radioGroups[key];
        //         $('input:radio[name=' + groupName + ']:first').prop('checked', true);
        //         $('input:radio[name=' + groupName + ']:first').trigger('change');
        //     }
        // }
    };
};
function getLocalImagedcard_leftimage_collectioncontainer(objList, mediaID, fileName) {
    try {
        var appJSON = {};
        appJSON.nextButtonCallback = 'handleLocalImagedcard_leftimage_collectioncontainer';
        appJSON.url = CDN_PATH + mediaID + '_compressed.png';
        appJSON.fileMimeType = 'image/png';
        appJSON.fileName = fileName;
        appJSON.objList = objList;
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        if (isAndroid > -1) {
            window.Android.getLocalImage(JSON.stringify(appJSON))
        } else {
            setupWebViewJavascriptBridge(function (bridge) {
                bridgeObj = bridge;
                bridgeObj.callHandler('getLocalImage', appJSON, function (response) { });
                bridgeObj.registerHandler('handleLocalImagedcard_leftimage_collectioncontainer', function (responseData, responseCallback) {
                    handleLocalImagedcard_leftimage_collectioncontainer(responseData)
                });
            });
        }
    } catch (err) {

    }
}
function handleLocalImagedcard_leftimage_collectioncontainer(response) {
    var objList = response.dataDictionay.objList;
    var html = '';

    html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.imageupload + objList.clientname + objList.policytype_name + objList.date + objList.fromtime + objList.totime + objList.address_name) + '">';
    html += '      		<div class="col s12 m12">';
    html += '               <div class="card-content">';
    html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
    html += '      <div class="row  element" style=""  >';
    html += '      <div class="col s3 cls_sg9351" style="">';
    var localFilePath = '';
    if (response && response.localFilePath) {
        localFilePath = response.localFilePath;
    }
    html += '           <div class="col s12 clssg3451" style="">';
    var filetodisplay = '';
    if (objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID) {
        filetodisplay = getuploadedfilepreview(objList.userphotoupload[0].fileNm);
    }
    if (localFilePath && localFilePath != '') {
        html += '               <img recordID="' + objList._id + '"   id="userphotoupload15"   class=" clssg3451image userphotoupload15" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
    } else if (objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID) {
        if (filetodisplay && filetodisplay != objList.userphotoupload[0].fileNm) {
            html += '               <img recordID="' + objList._id + '"    id="userphotoupload15"   class=" clssg3451image userphotoupload15" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
        } else {
            html += '               <img recordID="' + objList._id + '"    id="userphotoupload15"   class=" clssg3451image userphotoupload15" style="" onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + CDN_PATH + objList.userphotoupload[0].mediaID + '_compressed.png">';
        }
    } else {
        // stage 22222222222222
        html += '               <img recordID="' + objList._id + '"    id="userphotoupload15"   class=" clssg3451image userphotoupload15" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
    }
    html += '           </div>';
    html += '     </div>';
    html += '      <div class="col s9 cls_sg1451 addshimmer" style="">';
    var adddbclass = ''

    html += '           <div recordID="' + objList._id + '" class="col s12 clssg7451  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['policytype_name'] = objList['policytype_name'] ? objList['policytype_name'] : '';
    if (response.showShimmer) {
        objList['policytype_name'] = '';
    }
    var policytype_name = objList['policytype_name'];
    html += '           <div recordID="' + objList._id + '"   id="policytype_name17" class="languagetranslation " style="" >' + policytype_name + '</div>';
    html += '     </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s3 clssg9451  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['slotdate'] = objList['slotdate'] ? moment(new Date(objList['slotdate'])).format('DD MMM YYYY') : '';
    var slotdate = objList['slotdate'];
    html += '           <div recordID="' + objList._id + '"   id="slotdate18" class="languagetranslation " style="" >' + slotdate + '</div>';
    html += '     </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s5 clssg1551  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['starttime'] = objList['starttime'] ? objList['starttime'] : '';
    if (response.showShimmer) {
        objList['starttime'] = '';
    }
    var starttime = objList['starttime'];
    html += '           <div recordID="' + objList._id + '"   id="starttime19" class="languagetranslation " style="" >' + starttime + '</div>';
    html += '     </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s4 clssg3551  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['endtime'] = objList['endtime'] ? objList['endtime'] : '';
    if (response.showShimmer) {
        objList['endtime'] = '';
    }
    var endtime = objList['endtime'];
    html += '           <div recordID="' + objList._id + '"   id="endtime20" class="languagetranslation " style="" >' + endtime + '</div>';
    html += '     </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s12 clssg5551  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['address_name'] = objList['address_name'] ? objList['address_name'] : '';
    if (response.showShimmer) {
        objList['address_name'] = '';
    }
    var address_name = objList['address_name'];
    html += '           <div recordID="' + objList._id + '"   id="address_name21" class="languagetranslation " style="" >' + address_name + '</div>';
    html += '     </div>';
    html += '     </div>';
    html += '     </div>';
    html += '      				</div>';
    html += '          </div>';
    html += '        </div>';
    html += '     </div>';
    html += '   </div>';
    $('#collectioncontainerDivdcard_leftimage_collectioncontainer').append(html)
    $('#full-body-container').addClass('fadeInUp');
    dcardLoaded['dcard_leftimage_collectioncontainer'] = true;
    $('#collectioncontainerDivdcard_leftimage_collectioncontainer').find('.view_list_record').removeClass('shimmer');
    // after html bining code
};

function getdcard_leftimage_collectioncontainerapp_consultantuserhomePadView(response, tokenKey, queryMode) {
    var html = '';
    if (response.data.length == 0) {
        html += '<tr>';
        html += '<td colspan="1" class="text_center first_row_table_td">';
        html += 'No record found';
        html += '</td>';
        html += '</tr>';
    } else {
        html = '';
        $.each(response.data, function (keyList, objList) {

            html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.imageupload + objList.clientname + objList.policytype_name + objList.date + objList.fromtime + objList.totime + objList.address_name) + '">';
            html += '      		<div class="col s12 m12">';
            html += '               <div class="card-content">';
            html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
            html += '      <div class="row  element" style=""  >';
            html += '      <div class="col s3 cls_sg9351" style="">';
            var localFilePath = '';
            if (response && response.localFilePath) {
                localFilePath = response.localFilePath;
            }
            html += '           <div class="col s12 clssg3451" style="">';
            var filetodisplay = '';
            if (objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID) {
                filetodisplay = getuploadedfilepreview(objList.userphotoupload[0].fileNm);
            }
            if (localFilePath && localFilePath != '') {
                html += '               <img recordID="' + objList._id + '"   id="userphotoupload15"   class=" clssg3451image userphotoupload15" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
            } else if (objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID) {
                if (filetodisplay && filetodisplay != objList.userphotoupload[0].fileNm) {
                    html += '               <img recordID="' + objList._id + '"    id="userphotoupload15"   class=" clssg3451image userphotoupload15" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
                } else {
                    html += '               <img recordID="' + objList._id + '"    id="userphotoupload15"   class=" clssg3451image userphotoupload15" style="" onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + CDN_PATH + objList.userphotoupload[0].mediaID + '_compressed.png">';
                }
            } else {
                // stage 22222222222222
                html += '               <img recordID="' + objList._id + '"    id="userphotoupload15"   class=" clssg3451image userphotoupload15" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
            }
            html += '           </div>';
            html += '     </div>';
            html += '      <div class="col s9 cls_sg1451 addshimmer" style="">';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg7451  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['policytype_name'] = objList['policytype_name'] ? objList['policytype_name'] : '';
            if (response.showShimmer) {
                objList['policytype_name'] = '';
            }
            var policytype_name = objList['policytype_name'];
            html += '           <div recordID="' + objList._id + '"   id="policytype_name17" class="languagetranslation " style="" >' + policytype_name + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s3 clssg9451  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['slotdate'] = objList['slotdate'] ? moment(new Date(objList['slotdate'])).format('DD MMM YYYY') : '';
            var slotdate = objList['slotdate'];
            html += '           <div recordID="' + objList._id + '"   id="slotdate18" class="languagetranslation " style="" >' + slotdate + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s5 clssg1551  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['starttime'] = objList['starttime'] ? objList['starttime'] : '';
            if (response.showShimmer) {
                objList['starttime'] = '';
            }
            var starttime = objList['starttime'];
            html += '           <div recordID="' + objList._id + '"   id="starttime19" class="languagetranslation " style="" >' + starttime + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s4 clssg3551  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['endtime'] = objList['endtime'] ? objList['endtime'] : '';
            if (response.showShimmer) {
                objList['endtime'] = '';
            }
            var endtime = objList['endtime'];
            html += '           <div recordID="' + objList._id + '"   id="endtime20" class="languagetranslation " style="" >' + endtime + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg5551  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['address_name'] = objList['address_name'] ? objList['address_name'] : '';
            if (response.showShimmer) {
                objList['address_name'] = '';
            }
            var address_name = objList['address_name'];
            html += '           <div recordID="' + objList._id + '"   id="address_name21" class="languagetranslation " style="" >' + address_name + '</div>';
            html += '     </div>';
            html += '     </div>';
            html += '     </div>';
            html += '      				</div>';
            html += '          </div>';
            html += '        </div>';
            html += '     </div>';
            html += '   </div>';
        }); // end of each loop
    };
    $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html)
};

function populateEvents() {
    var objParamsList = {};
    objParamsList.queryMode = 'mylist';
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsList.tokenKey = getParameterByName('tokenKey');
    objParamsList.secretKey = getParameterByName('secretKey');
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.isMobile = 'true';
    objParamsList.isiPad = false;
    //    objParamsList.timestamp = timestamp;
    var applyFilter = getParameterByName('applyFilter');
    // if (applyFilter == null && objParamsList.applyFilter == false) {
    objParamsList.type = 'events';
    objParamsList.applystaticfilter = true;
    //}

    show_dcard_topimage2x2_collectioncontainerapp_userhome_Details(objParamsList)
}
function show_dcard_topimage2x2_collectioncontainerapp_userhome_Details(objParamsList) {
    var applyFilter = getParameterByName('applyFilter');
    if (applyFilter == null && objParamsList.applyFilter == false) {
        objParamsList.type = 'events';
        objParamsList.applystaticfilter = true;
    }
    if (getParameterByName('eventdate') && getParameterByName('eventdate') != '' && getParameterByName('eventdate') != null && getParameterByName('eventdate') != 'undefined') {
        objParamsList.eventdate = getParameterByName('eventdate');
    }
    if (getParameterByName('eventenddate') && getParameterByName('eventenddate') != '' && getParameterByName('eventenddate') != null && getParameterByName('eventenddate') != 'undefined') {
        objParamsList.eventenddate = getParameterByName('eventenddate');
    }
    localStorage.setItem('appuserhomeFilterBox', '');
    if (false)
        $.ajax({
            url: objParamsList.ajaXCallURL + '/milestone003/getListDetails_Bazaar5da73cac545050343288ce7a_app_userhome_dcard_topimage2x2_collectioncontainer',
            data: objParamsList,
            type: 'POST',
            success: function (response) {
                // getDataProcessAfterCalldcard_topimage2x2_collectioncontainerBazaar5da73cac545050343288ce7a(response, function () {
                if (response.status != undefined && response.status == 0) {
                    //if (objParamsList.isMobile == 'true') {
                    $('#collectioncontainerDivdcard_topimage2x2_collectioncontainer').html('');
                    localStorage.setItem('dcard_topimage2x2_collectioncontainerapp_userhome', JSON.stringify(response));
                    getdcard_topimage2x2_collectioncontainerapp_userhomeMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    // } else if (objParamsList.isiPad == 'true') {
                    //     getdcard_topimage2x2_collectioncontainerapp_userhomeiPadView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    // } else {
                    //     getdcard_topimage2x2_collectioncontainerapp_userhomeWebView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    // }
                    $('#display_loading').addClass('hideme');
                } else {
                    $('#display_loading').addClass('hideme')
                }
                // });
            },
            error: function (xhr, status, error) {
                $('#display_loading').addClass('hideme')
                handleError(xhr, status, error);
            },
        });
}
function getLocalImagedcard_topimage2x2_collectioncontainer(objList, mediaID, fileName) {
    try {
        var appJSON = {};
        appJSON.nextButtonCallback = 'handleLocalImagedcard_topimage2x2_collectioncontainer';
        appJSON.url = CDN_PATH + mediaID + '_compressed.png';
        appJSON.fileMimeType = 'image/png';
        appJSON.fileName = fileName;
        appJSON.objList = objList;
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        if (isAndroid > -1) {
            window.Android.getLocalImage(JSON.stringify(appJSON))
        } else {
            setupWebViewJavascriptBridge(function (bridge) {
                bridgeObj = bridge;
                bridgeObj.callHandler('getLocalImage', appJSON, function (response) { });
                bridgeObj.registerHandler('handleLocalImagedcard_topimage2x2_collectioncontainer', function (responseData, responseCallback) {
                    handleLocalImagedcard_topimage2x2_collectioncontainer(responseData)
                });
            });
        }
    } catch (err) {

    }
}
function handleLocalImagedcard_topimage2x2_collectioncontainer(response) {
    var objList = response.dataDictionay.objList;
    var html = '';

    html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.eventimage + objList.eventname + objList.eventdate) + '">';
    html += '              <div class="col s12 m12">';
    html += '               <div class="card-content">';
    html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_topimage2x2_collectioncontainer" style="" >';
    html += '      <div class="row  element" style=""  >';
    var localFilePath = '';
    if (response && response.localFilePath) {
        localFilePath = response.localFilePath;
    }
    html += '           <div class="col s12 clssg6069" style="">';
    var filetodisplay = '';
    if (objList.eventimage && objList.eventimage[0] && objList.eventimage[0].mediaID) {
        filetodisplay = getuploadedfilepreview(objList.eventimage[0].fileNm);
    }
    if (localFilePath && localFilePath != '') {
        html += '               <img recordID="' + objList._id + '"  id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
    } else if (objList.eventimage && objList.eventimage[0] && objList.eventimage[0].mediaID) {
        if (filetodisplay && filetodisplay != objList.eventimage[0].fileNm) {
            html += '               <img recordID="' + objList._id + '"    id="eventimage13"   class=" clssg6069image eventimage13" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
        } else {
            html += '               <img recordID="' + objList._id + '"    id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + objList.eventimage[0].mediaID + '_compressed.png">';
        }
    } else {
        // stage 6666666666666666
        html += '               <img recordID="' + objList._id + '"   id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
    }
    html += '           </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s12 clssg8069  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['eventname'] = objList['eventname'] ? objList['eventname'] : '';
    if (response.showShimmer) {
        objList['eventname'] = '';
    }
    var eventname = objList['eventname'];
    html += '           <div recordID="' + objList._id + '"   id="eventname14" class="languagetranslation " style="" >' + eventname + '</div>';
    html += '     </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s12 clssg0169  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['eventdate'] = objList['eventdate'] ? moment(new Date(objList['eventdate'])).format('DD MMM YYYY') : '';
    var eventdate = objList['eventdate'];
    html += '           <div recordID="' + objList._id + '"   id="eventdate15" class="languagetranslation " style="" >' + eventdate + '</div>';
    html += '     </div>';
    html += '     </div>';
    html += '                      </div>';
    html += '          </div>';
    html += '        </div>';
    html += '     </div>';
    html += '   </div>';
    $('#collectioncontainerDivdcard_topimage2x2_collectioncontainer').append(html)
    $('#full-body-container').addClass('fadeInUp');
    dcardLoaded['dcard_topimage2x2_collectioncontainer'] = true;
    $('#collectioncontainerDivdcard_topimage2x2_collectioncontainer').find('.view_list_record').removeClass('shimmer');
    // after html bining code
};
function getdcard_topimage2x2_collectioncontainerapp_userhomeMobileView(response, tokenKey, queryMode) {
    var html = '';
    if (response.data.length == 0) {
        html += '<div class="nodatafound">';
        html += '<img src="nodatafound.gif" width="100%">';
        html += '<br>';
        html += '<!-- span>No record found</span -->';
        html += '</div>';
        $('#collectioncontainerDivdcard_topimage2x2_collectioncontainer').html(html);;
    } else {
        html = '';
        var radioGroups = [];
        $.each(response.data, function (keyList, objList) {

            var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (isAndroid > -1 || ios > -1) {  // need to fix with native gyes.. images not getting download
                var mediaID = '';
                var fileName = '';
                if (objList['eventimage'] && objList['eventimage'][0].mediaID) {
                    mediaID = objList['eventimage'][0].mediaID;
                    fileName = objList['eventimage'][0].mediaID + '.png';
                }
                getLocalImagedcard_topimage2x2_collectioncontainer(objList, mediaID, fileName);
            } else {

                html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.eventimage + objList.eventname + objList.eventdate) + '">';
                html += '      		<div class="col s12 m12">';
                html += '               <div class="card-content">';
                html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_topimage2x2_collectioncontainer" style="" >';
                html += '      <div class="row  element" style=""  >';
                var localFilePath = '';
                if (response && response.localFilePath) {
                    localFilePath = response.localFilePath;
                }
                html += '           <div class="col s12 clssg6069" style="">';
                var filetodisplay = '';
                if (objList.eventimage && objList.eventimage[0] && objList.eventimage[0].mediaID) {
                    filetodisplay = getuploadedfilepreview(objList.eventimage[0].fileNm);
                }
                if (localFilePath && localFilePath != '') {
                    html += '               <img recordID="' + objList._id + '"  id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
                } else if (objList.eventimage && objList.eventimage[0] && objList.eventimage[0].mediaID) {
                    if (filetodisplay && filetodisplay != objList.eventimage[0].fileNm) {
                        html += '               <img recordID="' + objList._id + '"    id="eventimage13"   class=" clssg6069image eventimage13" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
                    } else {
                        html += '               <img recordID="' + objList._id + '"    id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + objList.eventimage[0].mediaID + '_compressed.png">';
                    }
                } else {
                    // stage 6666666666666666
                    html += '               <img recordID="' + objList._id + '"   id="eventimage13"   class=" clssg6069image eventimage13" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
                }
                html += '           </div>';
                var adddbclass = ''
                html += '           <div recordID="' + objList._id + '" class="col s12 clssg8069  ' + adddbclass + ' " style=" cursor: pointer;">';
                objList['eventname'] = objList['eventname'] ? objList['eventname'] : '';
                if (response.showShimmer) {
                    objList['eventname'] = '';
                }
                var eventname = objList['eventname'];
                html += '           <div recordID="' + objList._id + '"   id="eventname14" class="languagetranslation " style="" >' + eventname + '</div>';
                html += '     </div>';
                var adddbclass = ''
                html += '           <div recordID="' + objList._id + '" class="col s12 clssg0169  ' + adddbclass + ' " style=" cursor: pointer;">';
                objList['eventdate'] = objList['eventdate'] ? moment(new Date(objList['eventdate'])).format('DD MMM YYYY') : '';
                var eventdate = objList['eventdate'];
                html += '           <div recordID="' + objList._id + '"   id="eventdate15" class="languagetranslation " style="" >' + eventdate + '</div>';
                html += '     </div>';
                html += '     </div>';
                html += '      				</div>';
                html += '          </div>';
                html += '        </div>';
                html += '     </div>';
                html += '   </div>';
            }
        });
        var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        if (1) {
            $('#collectioncontainerDivdcard_topimage2x2_collectioncontainer').html(html)
            $('#full-body-container').addClass('fadeInUp');
        };
        if (!response.showShimmer) {
            dcardLoaded['dcard_topimage2x2_collectioncontainer'] = true;
            $('#collectioncontainerDivdcard_topimage2x2_collectioncontainer').find('.view_list_record').removeClass('shimmer');
        }
        $('.carddropdown').material_select();
        $('<input>').attr({ type: 'hidden', class: 'cardtoggleswitch', id: 'togleswitchvalue' }).appendTo('body')
        if ($('.js-candlestick').length) $('.js-candlestick').candlestick({ afterSetting: function (input, wrapper, value) { $('#togleswitchvalue').val(value).attr('recordID', input.attr('id')).trigger('click'); } });
        if (radioGroups && radioGroups.length) {
            for (var key in radioGroups) {
                var groupName = radioGroups[key];
                $('input:radio[name=' + groupName + ']:first').prop('checked', true);
                $('input:radio[name=' + groupName + ']:first').trigger('change');
            }
        }
    };
};
function getdcard_leftimage_collectioncontainerapp_consultantuserhomeWebView(response, tokenKey, queryMode) {
    var html = '';
    if (response.data.length == 0) {
        html += '<tr>';
        html += '<td colspan="1" class="text_center first_row_table_td">';
        html += 'No record found';
        html += '</td>';
        html += '</tr>';
    } else {
        html = '';
        $.each(response.data, function (keyList, objList) {

            html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.imageupload + objList.clientname + objList.policytype_name + objList.date + objList.fromtime + objList.totime + objList.address_name) + '">';
            html += '      		<div class="col s12 m12">';
            html += '               <div class="card-content">';
            html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
            html += '      <div class="row  element" style=""  >';
            html += '      <div class="col s3 cls_sg9351" style="">';
            var localFilePath = '';
            if (response && response.localFilePath) {
                localFilePath = response.localFilePath;
            }
            html += '           <div class="col s12 clssg3451" style="">';
            var filetodisplay = '';
            if (objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID) {
                filetodisplay = getuploadedfilepreview(objList.userphotoupload[0].fileNm);
            }
            if (localFilePath && localFilePath != '') {
                html += '               <img recordID="' + objList._id + '"   id="userphotoupload15"   class=" clssg3451image userphotoupload15" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
            } else if (objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID) {
                if (filetodisplay && filetodisplay != objList.userphotoupload[0].fileNm) {
                    html += '               <img recordID="' + objList._id + '"    id="userphotoupload15"   class=" clssg3451image userphotoupload15" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
                } else {
                    html += '               <img recordID="' + objList._id + '"    id="userphotoupload15"   class=" clssg3451image userphotoupload15" style="" onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + CDN_PATH + objList.userphotoupload[0].mediaID + '_compressed.png">';
                }
            } else {
                // stage 22222222222222
                html += '               <img recordID="' + objList._id + '"    id="userphotoupload15"   class=" clssg3451image userphotoupload15" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
            }
            html += '           </div>';
            html += '     </div>';
            html += '      <div class="col s9 cls_sg1451 addshimmer" style="">';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg7451  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['policytype_name'] = objList['policytype_name'] ? objList['policytype_name'] : '';
            if (response.showShimmer) {
                objList['policytype_name'] = '';
            }
            var policytype_name = objList['policytype_name'];
            html += '           <div recordID="' + objList._id + '"   id="policytype_name17" class="languagetranslation " style="" >' + policytype_name + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s3 clssg9451  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['slotdate'] = objList['slotdate'] ? moment(new Date(objList['slotdate'])).format('DD MMM YYYY') : '';
            var slotdate = objList['slotdate'];
            html += '           <div recordID="' + objList._id + '"   id="slotdate18" class="languagetranslation " style="" >' + slotdate + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s5 clssg1551  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['starttime'] = objList['starttime'] ? objList['starttime'] : '';
            if (response.showShimmer) {
                objList['starttime'] = '';
            }
            var starttime = objList['starttime'];
            html += '           <div recordID="' + objList._id + '"   id="starttime19" class="languagetranslation " style="" >' + starttime + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s4 clssg3551  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['endtime'] = objList['endtime'] ? objList['endtime'] : '';
            if (response.showShimmer) {
                objList['endtime'] = '';
            }
            var endtime = objList['endtime'];
            html += '           <div recordID="' + objList._id + '"   id="endtime20" class="languagetranslation " style="" >' + endtime + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg5551  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['address_name'] = objList['address_name'] ? objList['address_name'] : '';
            if (response.showShimmer) {
                objList['address_name'] = '';
            }
            var address_name = objList['address_name'];
            html += '           <div recordID="' + objList._id + '"   id="address_name21" class="languagetranslation " style="" >' + address_name + '</div>';
            html += '     </div>';
            html += '     </div>';
            html += '     </div>';
            html += '      				</div>';
            html += '          </div>';
            html += '        </div>';
            html += '     </div>';
            html += '   </div>';
        }); // end of each loop 1
    };
    $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html)
};
function showBottomMenu() {
    var menuObj = localStorage.getItem('objGetUserDetailsWithmenu');
    if (menuObj) {
        menuObj = JSON.parse(menuObj);
        if (menuObj.data && menuObj.data.roleName) {
            var roleName = menuObj.data.roleName;
        }
    }
    try {
        var appUser = JSON.parse(localStorage.getItem("appUser"));
        var notificationCount = 0
        if (appUser.notificationunreadcount) {
            notificationCount = appUser.notificationunreadcount
        }
        $("#notificationcount5").html(notificationCount)
        var appointmentunreadcount = 0
        if (appUser.appointmentunreadcount) {
            appointmentunreadcount = appUser.appointmentunreadcount
        }
        var roleName = localStorage.getItem('roleName');
        var clientIcon = "icon_client.svg"
        var notificationicon = "icon_notification.svg"

        if (roleName == "consultant") {
            clientIcon = "icon_team.png";
            notificationicon = "icon_calendar.svg"

        }
        var bottommenu = '';
        bottommenu += '<div class="mobilebottommenu">'
        bottommenu += '    <div class="row">'
        bottommenu += '    <div class="menuwrapper " style="width: 16% !important;"><a class="redirecttopage" nativeredirect="" id="Home" fileName="app_consultantuserhome_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_homeactive.svg"><span>Home</span></a></div>'
        bottommenu += '    <div class="menuwrapper " style="width: 15% !important;"><a class="redirecttopage" nativeredirect="" id="Client" fileName="app_consultantclientlisting_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="' + clientIcon + '"><span>Clients</span></a></div>'
        bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Appointments" fileName="app_consultantrequestappointmentslisting_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="AppointmentWhite.svg"><span>Appointments</span></a><div  id="appointmentCount"  class="chatunreadcount active">0</div></div>'
        bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Chat" fileName="undefined_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_chat.svg"><span>Messages</span></a><div id="chatCount" style="display:none !important"   class="chatunreadcount active">0</div></div>'
        bottommenu += '    <div class="menuwrapper " style="width: 18% !important;"><a class="redirecttopage" nativeredirect="" id="More" fileName="app_consultantcustmoreinfodetails_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_more.svg"><span>Account</span></a></div>'
        bottommenu += '    </div>'
        bottommenu += '</div>'
        $('#bottommenu22').html(bottommenu)
    } catch (err) {
        // console.log('Error in showBottomMenu', err);
    }
}
