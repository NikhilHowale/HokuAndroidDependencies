
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var totaldcard_topimage2_collectioncontainer = 0;
$(document).ready(function () {
    showBottomMenu();
    getCategoryDetails();
    localStorage.removeItem('discountbackpage');
    $(".bodytabs").scrollLeft(100);
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"))
    }
    var roleName = localStorage.getItem('roleName');
    if (roleName == "consultant") {

        $("#sg1907").hide()
    }
    var objParamsToken = {};

    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsToken.tokenKey = getParameterByName('tokenKey');
    objParamsToken.secretKey = getParameterByName('secretKey');

    var userRole = $('#userRole').val();
    var userID = $('#userID').val();
    var createrOfRecord = $('#createrOfRecord').val();
    var queryMode = getParameterByName('queryMode');
    var recordID = $.trim($('#recordID').val());
    var addSessionComments = [];



    var queryMode = getParameterByName('queryMode');
    var isMobile = $('#isMobile').val();
    var isiPad = $('#isiPad').val();
    if (queryMode != '') {
        var tokenKey = $('#tokenKey').val();
        var objParamsList = {};
        objParamsList.queryMode = queryMode;
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParamsList.tokenKey = getParameterByName('tokenKey');
        objParamsList.secretKey = getParameterByName('secretKey');
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = isMobile;
        objParamsList.isiPad = isiPad;
        objParamsList.applyFilter = false;
        getDataProcessBeforeCalldcard_topimage2_collectioncontainerBazaar5da73cac545050343288ce7a(objParamsList, function (processBeforeRes) {
            var applyFilter = getParameterByName('applyFilter');
            if (applyFilter == null && objParamsList.applyFilter == false) {
                objParamsList.type = 'events';
                objParamsList.applystaticfilter = true;
            }
            if (getParameterByName('eventdate') && getParameterByName('eventdate') != '' && getParameterByName('eventdate') != null && getParameterByName('eventdate') != 'undefined') {
                objParamsList.eventdate = getParameterByName('eventdate');
            }
            if (getParameterByName('eventenddate') && getParameterByName('eventenddate') != '' && getParameterByName('eventenddate') != null && getParameterByName('eventenddate') != 'undefined') {
                objParamsList.eventenddate = getParameterByName('eventenddate');
            }
            var dcard_topimage2_collectioncontainerapp_allupcomingeventslist = localStorage.getItem('dcard_topimage2_collectioncontainerapp_allupcomingeventslist');
            var applyFilter = getParameterByName('applyFilter');
            $('#display_loading').removeClass('hideme');
            if (dcard_topimage2_collectioncontainerapp_allupcomingeventslist && applyFilter != 'true') {
                response = JSON.parse(dcard_topimage2_collectioncontainerapp_allupcomingeventslist);
                $('#collectioncontainerDivdcard_topimage2_collectioncontainer').html('');
                $('#collectioncontainerDivdcard_topimage2x2_collectioncontainer__discount').html('');
                getdcard_topimage2_collectioncontainerapp_allupcomingeventslistMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
                dcard_topimage2_collectioncontainerapp_allupcomingeventslistSync(response.timestamp);
            } else {
                show_dcard_topimage2_collectioncontainerapp_allupcomingeventslist_Details(objParamsList)
                show_dcard_topimage2_collectioncontainerapp_allupcomingeventslist_Details_discount(objParamsList)
            }
        });//End of get data process before call.
    }

    $(document).on('click', '.dcard_topimage2_collectioncontainer', function () {
        if (dcardLoaded && !dcardLoaded['dcard_topimage2_collectioncontainer']) { return false; }; // added for use should not able to click until data loaded
        localStorage.setItem("headerPageName", 'app_myeventdetails');
        var recordID = $(this).attr('recordID');// get record ID;
        var bazaarid = $(this).attr('recordID');// get record ID;
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = 'update';
        var parent = "app_allupcomingeventslist"
        var nextPage = 'app_discountdetails';
        if (!nextPage) {
            return false;
        }
        localStorage.setItem('discountbackpage', 'app_allmerchantdiscountslist');
        var pageurl = nextPage + '_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&bazaarid=' + bazaarid + '&recordID=' + recordID + '&applyFilter=true' + "&parent=" + parent;
        window.location.href = pageurl;
        return false;
    }); // to add New record

    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#backbutton1', function (e) {
        try {
            var element = $(this);
            var parent = getParameterByName('parent');
            var nextPage = 'app_userhome';
            var activemenu = localStorage.getItem("activeMenu")
            if (activemenu == "Home") {
                var roleName = localStorage.getItem('roleName');
                if (roleName == "consultant") {
                    nextPage = "app_consultantuserhome";

                }
                else {
                    nextPage = "app_userhome";
                }


            }
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "mylist";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - backbutton1", error)
        }
    })
    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    // $(document).on('click', '#myevents7', function (e) {
    //     try {
    //         var element = $(this);
    //         var nextPage = 'app_myupcomingeventslist';
    //         var queryParams = queryStringToJSON();
    //         queryParams["queryMode"] = "mylist";
    //         var recordID = $(this).attr("recordID");
    //         if (recordID) {
    //             queryParams["recordID"] = recordID;
    //         }
    //         var queryString = $.param(queryParams);
    //         queryString = queryString.replace(/\+/g, "%20");
    //         queryString = decodeURIComponent(queryString);
    //         window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
    //         return false;
    //     } catch (error) {
    //         console.log("Error in pageredirect workflow - myevents7", error)
    //     }
    // })

    $(document).on('keyup','#customerlistB18B580C23E84CB1ACF372E307F44D35copy',function() {
        var objParamsList = {};
        let search = $(this).val();  
        objParamsList.tokenKey = getParameterByName('tokenKey');
        objParamsList.secretKey = getParameterByName('secretKey');
        objParamsList.ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParamsList.queryMode = 'mylist'
        objParamsList.globalsearchvalue = search     
        show_dcard_topimage2_collectioncontainerapp_allupcomingeventslist_Details_discount(objParamsList);
        getAllDealsOfTheDay(search)
    });

    $(document).on('click', '.btmcolormerchantdiscountfliter', function () {
        $('#card_bottompopup141_row').modal('open');
    }); 
    $(document).on('click', '.sortbydistance', function () {
        $('#filtebyoptions_seconddiv').addClass('hide');
        $(`.sortbydistance`).css("background-color", "repeating-linear-gradient(to left, rgb(172, 136, 74), rgb(195, 164, 100));");
        $(`.sortbydistance`).css("color", "#fff");
        $(`.sortbycategory`).css("background-color", "#fff");
        $(`.sortbycategory`).css("color", "#b18d4f");
        $('#filtebyoptions_firstdiv').removeClass('hide');
    }); // to add New record
    $(document).on('click', '.sortbycategory', function () {
        $('#filtebyoptions_firstdiv').addClass('hide');
        $(`.sortbydistance`).css("background", "#ffffff");
        $(`.sortbydistance`).css("color", "#b18d4f");
        $(`.sortbycategory`).css("background-color", "repeating-linear-gradient(to left, rgb(172, 136, 74), rgb(195, 164, 100));");
        $(`.sortbycategory`).css("color", "#fff");
        $('#filtebyoptions_seconddiv').removeClass('hide');
    });

    $(document).on('click', '.resetandapply_apply', function () {
        var objParamsList = {};
        // var category = $('.category_checkbox').val();
        selectedCategoryForFilter = [];
        $('.categoryoptions input:checked').each(function () {
            selectedCategoryForFilter.push($(this).attr('value'));
        });
        objParamsList.queryMode = 'mylist';
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParamsList.tokenKey = getParameterByName('tokenKey');
        objParamsList.secretKey = getParameterByName('secretKey');
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = 'true';
        objParamsList.isiPad = false;
        if (selectedCategoryForFilter) {
            objParamsList.eventcategory_name = selectedCategoryForFilter;
        }
        console.log("here 1")
        console.log(objParamsList)
        show_dcard_topimage2_collectioncontainerapp_allupcomingeventslist_Details_discount(objParamsList)
        $('#card_bottompopup141_row').modal('close');
        // $('.category_checkbox').prop('checked', false);
    });
    $(document).on('click', '.resetandapply_reset', function () {
        $('input:checkbox').removeAttr('checked');
        var objParamsList = {};
        // var category = $('.category_checkbox').val();
        selectedCategoryForFilter = [];
        $('.categoryoptions input:checked').each(function () {
            selectedCategoryForFilter.push($(this).attr('value'));
        });
        objParamsList.queryMode = 'mylist';
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParamsList.tokenKey = getParameterByName('tokenKey');
        objParamsList.secretKey = getParameterByName('secretKey');
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = 'true';
        objParamsList.isiPad = false;
        if (selectedCategoryForFilter) {
            objParamsList.eventcategory_name = selectedCategoryForFilter;
        }
        show_dcard_topimage2_collectioncontainerapp_allupcomingeventslist_Details_discount(objParamsList)
        $('#card_bottompopup141_row').modal('close');
        // $('.category_checkbox').prop('checked', false);
    });
});//end of ready
function getDataProcessBeforeCalldcard_topimage2_collectioncontainerBazaar5da73cac545050343288ce7a(objParamsList, callback) {
    var response = objParamsList
    objParamsList.eventdate = new Date();
    objParamsList.eventenddate = new Date();
    objParamsList.type = 'events';
    callback();
}
function dcard_topimage2_collectioncontainerapp_allupcomingeventslistSync(timestamp) {
    try {
        var objParamsList = {};
        objParamsList.queryMode = 'mylist';
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParamsList.tokenKey = getParameterByName('tokenKey');
        objParamsList.secretKey = getParameterByName('secretKey');
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = true;
        objParamsList.timestamp = timestamp;
        $.ajax({
            url: objParamsList.ajaXCallURL + '/milestone003/syncListDetails_Bazaar5da73cac545050343288ce7a_app_allupcomingeventslist',
            data: objParamsList,
            type: 'POST',
            success: function (response) {
                $('#display_loading').addClass('hideme');
                if (response.status != undefined && response.status == 1) {
                    localStorage.removeItem('dcard_topimage2_collectioncontainerapp_allupcomingeventslist');
                    var objParamsList = {};
                    objParamsList.queryMode = 'mylist';
                    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                    objParamsList.tokenKey = getParameterByName('tokenKey');
                    objParamsList.secretKey = getParameterByName('secretKey');
                    objParamsList.ajaXCallURL = ajaXCallURL;
                    objParamsList.isMobile = 'true';
                    objParamsList.isiPad = false;
                    objParamsList.timestamp = timestamp;
                    var applyFilter = getParameterByName('applyFilter');
                    if (applyFilter == null && objParamsList.applyFilter == false) {
                        objParamsList.type = 'events';
                        objParamsList.applystaticfilter = true;
                    }
                    if (getParameterByName('eventdate') && getParameterByName('eventdate') != '' && getParameterByName('eventdate') != null && getParameterByName('eventdate') != 'undefined') {
                        objParamsList.eventdate = getParameterByName('eventdate');
                    }
                    if (getParameterByName('eventenddate') && getParameterByName('eventenddate') != '' && getParameterByName('eventenddate') != null && getParameterByName('eventenddate') != 'undefined') {
                        objParamsList.eventenddate = getParameterByName('eventenddate');
                    }
                    show_dcard_topimage2_collectioncontainerapp_allupcomingeventslist_Details(objParamsList)
                    show_dcard_topimage2_collectioncontainerapp_allupcomingeventslist_Details_discount(objParamsList)
                }
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            }
        });
    } catch (err) {
        // console.log('Error in workingtoolsSync', err);
    }
}
function show_dcard_topimage2_collectioncontainerapp_allupcomingeventslist_Details(objParamsList) {
    var applyFilter = getParameterByName('applyFilter');
    $('#display_loading').removeClass('hideme');
    if (applyFilter == null && objParamsList.applyFilter == false) {
        objParamsList.type = 'events';
        objParamsList.applystaticfilter = true;
    }
    if (getParameterByName('eventdate') && getParameterByName('eventdate') != '' && getParameterByName('eventdate') != null && getParameterByName('eventdate') != 'undefined') {
        objParamsList.eventdate = getParameterByName('eventdate');
    }
    if (getParameterByName('eventenddate') && getParameterByName('eventenddate') != '' && getParameterByName('eventenddate') != null && getParameterByName('eventenddate') != 'undefined') {
        objParamsList.eventenddate = getParameterByName('eventenddate');
    }
    localStorage.setItem('appallupcomingeventslistFilterBox', '');
    objParamsList.type = 'dealsoftheday';
    $.ajax({
        url: objParamsList.ajaXCallURL + '/milestone003/getListDetails_Bazaar5da73cac545050343288ce7a_app_userhome_dcard_topimage3_collectioncontainer__discount',
        data: objParamsList,
        type: 'POST',
        success: function (response) {
            getDataProcessAfterCalldcard_topimage2_collectioncontainerBazaar5da73cac545050343288ce7a(response, function () {
                $('#display_loading').addClass('hideme');
                if (response.status != undefined && response.status == 0) {
                    if (objParamsList.isMobile == 'true') {
                        $('#collectioncontainerDivdcard_topimage2_collectioncontainer').html('');
                        // $('#collectioncontainerDivdcard_topimage2x2_collectioncontainer__discount').html('');
                        // localStorage.setItem('dcard_topimage2_collectioncontainerapp_allupcomingeventslist', JSON.stringify(response));
                        getdcard_topimage2_collectioncontainerapp_allupcomingeventslistMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    } else if (objParamsList.isiPad == 'true') {
                        getdcard_topimage2_collectioncontainerapp_allupcomingeventslistiPadView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    } else {
                        getdcard_topimage2_collectioncontainerapp_allupcomingeventslistWebView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    }
                    $('#display_loading').addClass('hideme');
                } else {
                    $('#display_loading').addClass('hideme')
                }
            });
        },
        error: function (xhr, status, error) {
            $('#display_loading').addClass('hideme')
            handleError(xhr, status, error);
        },
    });
} // end of function     

function getDataProcessAfterCalldcard_topimage2_collectioncontainerBazaar5da73cac545050343288ce7a(response, callback) {

    callback();
}

function show_dcard_topimage2_collectioncontainerapp_allupcomingeventslist_Details_discount(objParamsList) {
    var applyFilter = getParameterByName('applyFilter');
    if (applyFilter == null && objParamsList.applyFilter == false) {
        objParamsList.type = 'events';
        objParamsList.applystaticfilter = true;
    }
    if (getParameterByName('eventdate') && getParameterByName('eventdate') != '' && getParameterByName('eventdate') != null && getParameterByName('eventdate') != 'undefined') {
        objParamsList.eventdate = getParameterByName('eventdate');
    }
    if (getParameterByName('eventenddate') && getParameterByName('eventenddate') != '' && getParameterByName('eventenddate') != null && getParameterByName('eventenddate') != 'undefined') {
        objParamsList.eventenddate = getParameterByName('eventenddate');
    }
    localStorage.setItem('appallupcomingeventslistFilterBox', '');

    console.log("Here 3")
    console.log(objParamsList)
    $.ajax({
        url: objParamsList.ajaXCallURL + '/milestone003/getListDetails_Bazaar5da73cac545050343288ce7a_app_userhome_dcard_topimage3_collectioncontainer__discount',
        data: objParamsList,
        type: 'POST',
        success: function (response) {
            console.log("Here 4")
            console.log(response)
            getDataProcessAfterCalldcard_topimage2_collectioncontainerBazaar_discount5da73cac545050343288ce7a(response, function () {
                if (response.status != undefined && response.status == 0) {
                    if (objParamsList.isMobile == 'true') {
                        // $('#collectioncontainerDivdcard_topimage2_collectioncontainer').html('');
                        // localStorage.setItem('dcard_topimage2_collectioncontainerapp_allupcomingeventslist', JSON.stringify(response));
                        getdcard_topimage2_collectioncontainerapp_allupcomingeventslistMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    } else if (objParamsList.isiPad == 'true') {
                        getdcard_topimage2_collectioncontainerapp_allupcomingeventslistiPadView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    } else {
                        getdcard_topimage2_collectioncontainerapp_allupcomingeventslistWebView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    }
                    $('#display_loading').addClass('hideme');
                } else {
                    $('#display_loading').addClass('hideme')
                }
            });
        },
        error: function (xhr, status, error) {
            $('#display_loading').addClass('hideme')
            handleError(xhr, status, error);
        },
    });

} // end of function     

function getDataProcessAfterCalldcard_topimage2_collectioncontainerBazaar_discount5da73cac545050343288ce7a(response, callback) {

    callback();
}

function getdcard_topimage2_collectioncontainerapp_allupcomingeventslistMobileView(response, tokenKey, queryMode) {
    console.log(response)
    var html = '';
    if (response.data.length == 0) {
        html += '<div class="nodatafound">';
        html += '<img src="nodatafound.gif" width="100%">';
        html += '<br>';
        html += '<!-- span>No record found</span -->';
        html += '</div>';
        $('#collectioncontainerDivdcard_topimage2_collectioncontainer').html(html);;
        $('#collectioncontainerDivdcard_topimage2x2_collectioncontainer__discount').html(html);;

    } else {
        html = '';
        var radioGroups = [];
        $.each(response.data, function (keyList, objList) {

            var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (isAndroid > -1 || ios > -1) {  // need to fix with native gyes.. images not getting download
                var mediaID = '';
                var fileName = '';
                if (objList['merchantimage'] && objList['merchantimage'][0].mediaID) {
                    mediaID = objList['merchantimage'][0].mediaID;
                    fileName = objList['merchantimage'][0].mediaID + '.png';
                }
                getLocalImagedcard_topimage2_collectioncontainer(objList, mediaID, fileName);
            } else {

                html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.merchantimage + objList.code + objList.eventdate) + '">';
                html += '      		<div class="col s12 m12">';
                html += '               <div class="card-content">';
                html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_topimage2_collectioncontainer" style="" >';
                html += '      <div class="row  element" style=""  >';
                var localFilePath = '';
                if (response && response.localFilePath) {
                    localFilePath = response.localFilePath;
                }
                html += '<div class="row">';
                html += '<div class="col s4">';
                html += '           <div class="col s12 clssg3017" style="">';
                var filetodisplay = '';
                if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
                    filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
                }
                if (localFilePath && localFilePath != '') {
                    html += '               <img recordID="' + objList._id + '"  id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
                } else if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
                    if (filetodisplay && filetodisplay != objList.merchantimage[0].fileNm) {
                        html += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
                    } else {
                        html += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + objList.merchantimage[0].mediaID + '_compressed.png">';
                    }
                } else {
                    // stage 6666666666666666
                    html += '               <img recordID="' + objList._id + '"   id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
                }
                html += '           </div>';
                var adddbclass = ''
                html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017__merchanttype' + adddbclass + ' " style=" cursor: pointer;">';
                objList['merchanttype'] = objList['merchanttype'] ? objList['merchanttype'] : '';
                if (response.showShimmer) {
                    objList['merchanttype'] = '';
                }
                var merchanttype = objList['merchanttype'];
                html += '           <div recordID="' + objList._id + '"   id="merchanttype13" class="languagetranslation " style="" >' + merchanttype + '</div>'; // <img onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="Merchant-Location-White.svg" width=15%; style=""> &nbsp
                html += '     </div>';
                html += '           </div>';
                html += '<div class="col s8 leftcards">';
                var adddbclass = ''
                html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017__name  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
                objList['merchantname'] = objList['merchantname'] ? objList['merchantname'] : '';
                if (response.showShimmer) {
                    objList['merchantname'] = '';
                }
                var merchantname = objList['merchantname'];
                html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + merchantname + '</div>';
                html += '     </div>';

                var adddbclass = ''
                html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
                objList['code'] = objList['code'] ? objList['code'] : '';
                if (response.showShimmer) {
                    objList['code'] = '';
                }
                var code = objList['code'];
                html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + code + '</div>';
                html += '     </div>';
                var adddbclass = ''
                html += '           <div recordID="' + objList._id + '" class="col s12 clssg7017  ' + adddbclass + ' " style=" cursor: pointer;">';
                objList['eventdate'] = objList['eventdate'] ? moment(new Date(objList['eventdate'])).format('DD MMM YYYY') : '';
                var eventdate = objList['eventdate'];
                var description = objList["description"] || '';
                description = description.replace(/<[^>]*>?/gm, '');
                if (description.length > 75) {
                    // description = description.slice(0, 69);
                    // description = `${description}...`;
                  }
                html += '           <div recordID="' + objList._id + '"   id="eventdate14" class="languagetranslation " style="width: 100% !important; text-overflow: ellipsis !important; white-space: nowrap !important; overflow: hidden !important;" >' + description + '</div>';
                html += '     </div>';
                var adddbclass = ''
                html += '           <div recordID="' + objList._id + '" class="col s9 clssg5017  codeclssg5017__getdiscount' + adddbclass + ' " style=" cursor: pointer;">';
                html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >Get Discount</div>';
                html += '     </div>';
                html += '           <div recordID="' + objList._id + '" class="col s3 clssg5017  codeclssg5017__getdiscountimg' + adddbclass + ' " style=" cursor: pointer;">';
                html += '         <img recordid="c79eca6544feb547f994edec" id="merchantimage12" class=" clssg3017image__discount merchantimage12" style="" onerror="this.src="https://appscdn-us.hokuapps.com/card.png" src="Merchant-Stamp-White.svg">';
                html += '     </div>';
                html += '     </div>';
                html += '     </div>';
                html += '     </div>';
                html += '      				</div>';
                html += '          </div>';
                html += '        </div>';
                html += '     </div>';
                html += '   </div>';
            }
        });
        var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        if (1) {
            $('#collectioncontainerDivdcard_topimage2_collectioncontainer').html(html)
            $('#collectioncontainerDivdcard_topimage2x2_collectioncontainer__discount').html(html)

            $('#full-body-container').addClass('fadeInUp');
        };
        if (!response.showShimmer) {
            dcardLoaded['dcard_topimage2_collectioncontainer'] = true;
            $('#collectioncontainerDivdcard_topimage2_collectioncontainer').find('.view_list_record').removeClass('shimmer');
            $('#collectioncontainerDivdcard_topimage2x2_collectioncontainer__discount').find('.view_list_record').removeClass('shimmer');

        }
        $('.carddropdown').material_select();
        $('<input>').attr({ type: 'hidden', class: 'cardtoggleswitch', id: 'togleswitchvalue' }).appendTo('body')
        if ($('.js-candlestick').length) $('.js-candlestick').candlestick({ afterSetting: function (input, wrapper, value) { $('#togleswitchvalue').val(value).attr('recordID', input.attr('id')).trigger('click'); } });
        if (radioGroups && radioGroups.length) {
            for (var key in radioGroups) {
                var groupName = radioGroups[key];
                $('input:radio[name=' + groupName + ']:first').prop('checked', true);
                $('input:radio[name=' + groupName + ']:first').trigger('change');
            }
        }
    };
};
function getLocalImagedcard_topimage2_collectioncontainer(objList, mediaID, fileName) {
    try {
        var appJSON = {};
        appJSON.nextButtonCallback = 'handleLocalImagedcard_topimage2_collectioncontainer';
        appJSON.url = CDN_PATH + mediaID + '_compressed.png';
        appJSON.fileMimeType = 'image/png';
        appJSON.fileName = fileName;
        appJSON.objList = objList;
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        if (isAndroid > -1) {
            window.Android.getLocalImage(JSON.stringify(appJSON))
        } else {
            setupWebViewJavascriptBridge(function (bridge) {
                bridgeObj = bridge;
                bridgeObj.callHandler('getLocalImage', appJSON, function (response) { });
                bridgeObj.registerHandler('handleLocalImagedcard_topimage2_collectioncontainer', function (responseData, responseCallback) {
                    handleLocalImagedcard_topimage2_collectioncontainer(responseData)
                });
            });
        }
    } catch (err) {

    }
}
function handleLocalImagedcard_topimage2_collectioncontainer(response) {
    var objList = response.dataDictionay.objList;
    var html = '';

    html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.merchantimage + objList.code + objList.eventdate) + '">';
    html += '      		<div class="col s12 m12">';
    html += '               <div class="card-content">';
    html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_topimage2_collectioncontainer" style="" >';
    html += '      <div class="row  element" style=""  >';
    var localFilePath = '';
    if (response && response.localFilePath) {
        localFilePath = response.localFilePath;
    }
    html += '<div class="row">';
    html += '<div class="col s4">';
    html += '           <div class="col s12 clssg3017" style="">';
    var filetodisplay = '';
    if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
        filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
    }
    if (localFilePath && localFilePath != '') {
        html += '               <img recordID="' + objList._id + '"  id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
    } else if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
        if (filetodisplay && filetodisplay != objList.merchantimage[0].fileNm) {
            html += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
        } else {
            html += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + objList.merchantimage[0].mediaID + '_compressed.png">';
        }
    } else {
        // stage 6666666666666666
        html += '               <img recordID="' + objList._id + '"   id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
    }
    html += '           </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017__merchanttype' + adddbclass + ' " style=" cursor: pointer;">';
    objList['merchanttype'] = objList['merchanttype'] ? objList['merchanttype'] : '';
    if (response.showShimmer) {
        objList['merchanttype'] = '';
    }
    var merchanttype = objList['merchanttype'];
    html += '           <div recordID="' + objList._id + '"   id="merchanttype13" class="languagetranslation " style="" >' + merchanttype + '</div>'; //<img onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="Merchant-Location-White.svg" width=15%; style=""> &nbsp
    html += '     </div>';
    html += '           </div>';
    html += '<div class="col s8 leftcards">';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017__name  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
    objList['merchantname'] = objList['merchantname'] ? objList['merchantname'] : '';
    if (response.showShimmer) {
        objList['merchantname'] = '';
    }
    var merchantname = objList['merchantname'];
    html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + merchantname + '</div>';
    html += '     </div>';

    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
    objList['code'] = objList['code'] ? objList['code'] : '';
    if (response.showShimmer) {
        objList['code'] = '';
    }
    var code = objList['code'];
    html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + code + '</div>';
    html += '     </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s12 clssg7017  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['eventdate'] = objList['eventdate'] ? moment(new Date(objList['eventdate'])).format('DD MMM YYYY') : '';
    var eventdate = objList['eventdate'];
    var description = objList["description"] || '';
    description = description.replace(/<[^>]*>?/gm, '');
    if (description.length > 75) {
        description = description.slice(0, 69);
        description = `${description}...`;
      }
    html += '           <div recordID="' + objList._id + '"   id="eventdate14" class="languagetranslation " style="" >' + description + '</div>';
    html += '     </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s9 clssg5017  codeclssg5017__getdiscount' + adddbclass + ' " style=" cursor: pointer;">';
    html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >Get Discount</div>';
    html += '     </div>';
    html += '           <div recordID="' + objList._id + '" class="col s3 clssg5017  codeclssg5017__getdiscountimg' + adddbclass + ' " style=" cursor: pointer;">';
    html += '         <img recordid="c79eca6544feb547f994edec" id="merchantimage12" class=" clssg3017image__discount merchantimage12" style="" onerror="this.src="https://appscdn-us.hokuapps.com/card.png" src="Merchant-Stamp-White.svg">';
    html += '     </div>';
    html += '     </div>';
    html += '     </div>';
    html += '     </div>';
    html += '      				</div>';
    html += '          </div>';
    html += '        </div>';
    html += '     </div>';
    html += '   </div>';
    $('#collectioncontainerDivdcard_topimage2_collectioncontainer').append(html)
    $('#collectioncontainerDivdcard_topimage2x2_collectioncontainer__discount').append(html)

    $('#full-body-container').addClass('fadeInUp');
    dcardLoaded['dcard_topimage2_collectioncontainer'] = true;
    $('#collectioncontainerDivdcard_topimage2_collectioncontainer').find('.view_list_record').removeClass('shimmer');
    $('#collectioncontainerDivdcard_topimage2x2_collectioncontainer__discount').find('.view_list_record').removeClass('shimmer');
    // after html bining code
};

function getdcard_topimage2_collectioncontainerapp_allupcomingeventslistPadView(response, tokenKey, queryMode) {
    var html = '';
    if (response.data.length == 0) {
        html += '<tr>';
        html += '<td colspan="1" class="text_center first_row_table_td">';
        html += 'No record found';
        html += '</td>';
        html += '</tr>';
    } else {
        html = '';
        $.each(response.data, function (keyList, objList) {

            html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.merchantimage + objList.code + objList.eventdate) + '">';
            html += '      		<div class="col s12 m12">';
            html += '               <div class="card-content">';
            html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_topimage2_collectioncontainer" style="" >';
            html += '      <div class="row  element" style=""  >';
            var localFilePath = '';
            if (response && response.localFilePath) {
                localFilePath = response.localFilePath;
            }
            html += '<div class="row">';
            html += '<div class="col s4">';
            html += '           <div class="col s12 clssg3017" style="">';
            var filetodisplay = '';
            if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
                filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
            }
            if (localFilePath && localFilePath != '') {
                html += '               <img recordID="' + objList._id + '"  id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
            } else if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
                if (filetodisplay && filetodisplay != objList.merchantimage[0].fileNm) {
                    html += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
                } else {
                    html += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + objList.merchantimage[0].mediaID + '_compressed.png">';
                }
            } else {
                // stage 6666666666666666
                html += '               <img recordID="' + objList._id + '"   id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
            }
            html += '           </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017__merchanttype' + adddbclass + ' " style=" cursor: pointer;">';
            objList['merchanttype'] = objList['merchanttype'] ? objList['merchanttype'] : '';
            if (response.showShimmer) {
                objList['merchanttype'] = '';
            }
            var merchanttype = objList['merchanttype'];
            html += '           <div recordID="' + objList._id + '"   id="merchanttype13" class="languagetranslation " style="" >' + merchanttype + '</div>'; // <img onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="Merchant-Location-White.svg" width=15%; style=""> &nbsp
            html += '     </div>';
            html += '           </div>';
            html += '<div class="col s8 leftcards">';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017__name  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
            objList['merchantname'] = objList['merchantname'] ? objList['merchantname'] : '';
            if (response.showShimmer) {
                objList['merchantname'] = '';
            }
            var merchantname = objList['merchantname'];
            html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + merchantname + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
            objList['code'] = objList['code'] ? objList['code'] : '';
            if (response.showShimmer) {
                objList['code'] = '';
            }
            var code = objList['code'];
            html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + code + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg7017  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['eventdate'] = objList['eventdate'] ? moment(new Date(objList['eventdate'])).format('DD MMM YYYY') : '';
            var eventdate = objList['eventdate'];
            var description = objList["description"] || '';
            description = description.replace(/<[^>]*>?/gm, '');
            if (description.length > 75) {
                description = description.slice(0, 69);
                description = `${description}...`;
              }
            html += '           <div recordID="' + objList._id + '"   id="eventdate14" class="languagetranslation " style="" >' + description + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s9 clssg5017  codeclssg5017__getdiscount' + adddbclass + ' " style=" cursor: pointer;">';
            html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >Get Discount</div>';
            html += '     </div>';
            html += '           <div recordID="' + objList._id + '" class="col s3 clssg5017  codeclssg5017__getdiscountimg' + adddbclass + ' " style=" cursor: pointer;">';
            html += '         <img recordid="c79eca6544feb547f994edec" id="merchantimage12" class=" clssg3017image__discount merchantimage12" style="" onerror="this.src="https://appscdn-us.hokuapps.com/card.png" src="Merchant-Stamp-White.svg">';
            html += '     </div>';
            html += '     </div>';
            html += '     </div>';
            html += '     </div>';
            html += '      				</div>';
            html += '          </div>';
            html += '        </div>';
            html += '     </div>';
            html += '   </div>';
        }); // end of each loop
    };
    $('#collectioncontainerDivdcard_topimage2_collectioncontainer').html(html)
    $('#collectioncontainerDivdcard_topimage2x2_collectioncontainer__discount').html(html)

};

function getdcard_topimage2_collectioncontainerapp_allupcomingeventslistWebView(response, tokenKey, queryMode) {
    var html = '';
    if (response.data.length == 0) {
        html += '<tr>';
        html += '<td colspan="1" class="text_center first_row_table_td">';
        html += 'No record found';
        html += '</td>';
        html += '</tr>';
    } else {
        html = '';
        $.each(response.data, function (keyList, objList) {

            html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.merchantimage + objList.code + objList.eventdate) + '">';
            html += '      		<div class="col s12 m12">';
            html += '               <div class="card-content">';
            html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_topimage2_collectioncontainer" style="" >';
            html += '      <div class="row  element" style=""  >';
            var localFilePath = '';
            if (response && response.localFilePath) {
                localFilePath = response.localFilePath;
            }
            html += '<div class="row">';
            html += '<div class="col s4">';
            html += '           <div class="col s12 clssg3017" style="">';
            var filetodisplay = '';
            if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
                filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
            }
            if (localFilePath && localFilePath != '') {
                html += '               <img recordID="' + objList._id + '"  id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
            } else if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID) {
                if (filetodisplay && filetodisplay != objList.merchantimage[0].fileNm) {
                    html += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
                } else {
                    html += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + objList.merchantimage[0].mediaID + '_compressed.png">';
                }
            } else {
                // stage 6666666666666666
                html += '               <img recordID="' + objList._id + '"   id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
            }
            html += '           </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017__merchanttype' + adddbclass + ' " style=" cursor: pointer;">';
            objList['merchanttype'] = objList['merchanttype'] ? objList['merchanttype'] : '';
            if (response.showShimmer) {
                objList['merchanttype'] = '';
            }
            var merchanttype = objList['merchanttype'];
            html += '           <div recordID="' + objList._id + '"   id="merchanttype13" class="languagetranslation " style="" >' + merchanttype + '</div>';// <img onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="Merchant-Location-White.svg" width=15%; style=""> &nbsp
            html += '     </div>';
            html += '           </div>';
            html += '<div class="col s8 leftcards">';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017__name  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
            objList['merchantname'] = objList['merchantname'] ? objList['merchantname'] : '';
            if (response.showShimmer) {
                objList['merchantname'] = '';
            }
            var merchantname = objList['merchantname'];
            html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + merchantname + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
            objList['code'] = objList['code'] ? objList['code'] : '';
            if (response.showShimmer) {
                objList['code'] = '';
            }
            var code = objList['code'];
            html += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + code + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg7017  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['eventdate'] = objList['eventdate'] ? moment(new Date(objList['eventdate'])).format('DD MMM YYYY') : '';
            var eventdate = objList['eventdate'];
            var description = objList["description"] || '';
            description = description.replace(/<[^>]*>?/gm, '');
            if (description.length > 75) {
                description = description.slice(0, 69);
                description = `${description}...`;
              }
            html += '           <div recordID="' + objList._id + '"   id="eventdate14" class="languagetranslation " style="" >' + description + '</div>';
            html += '     </div>';
            html += '     </div>';
            html += '     </div>';
            html += '     </div>';
            html += '      				</div>';
            html += '          </div>';
            html += '        </div>';
            html += '     </div>';
            html += '   </div>';
        }); // end of each loop 1
    };
    $('#collectioncontainerDivdcard_topimage2_collectioncontainer').html(html)
};
$(document).on('click', '#myevents7', function (e) {
    try {
        var element = $(this);
        var nextPage = 'app_allmerchantdiscountslist';
        var queryParams = queryStringToJSON();
        queryParams["queryMode"] = "mylist";
        var recordID = $(this).attr("recordID");
        if (recordID) {
            queryParams["recordID"] = recordID;
        }
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
        return false;
    } catch (error) {
        console.log("Error in pageredirect workflow - myevents7", error)
    }
});


$(document).on('click', '#allevents8', function (e) {
    try {
        var element = $(this);
        var nextPage = 'app_alleventpromotionslist';
        var queryParams = queryStringToJSON();
        queryParams["queryMode"] = "mylist";
        var recordID = $(this).attr("recordID");
        if (recordID) {
            queryParams["recordID"] = recordID;
        }
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
        return false;
    } catch (error) {
        console.log("Error in pageredirect workflow - myevents7", error)
    }
});

$(document).on('click', '#financeevents7', function (e) {
    try {
        var element = $(this);
        var nextPage = 'app_allfinancialserviceslist';
        var queryParams = queryStringToJSON();
        queryParams["queryMode"] = "mylist";
        var recordID = $(this).attr("recordID");
        if (recordID) {
            queryParams["recordID"] = recordID;
        }
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
        return false;
    } catch (error) {
        console.log("Error in pageredirect workflow - myevents7", error)
    }
});
function showBottomMenu() {
    //    var  appUser = JSON.parse(localStorage.getItem("appUser"));
    var notificationCount = 0;
    //    if(appUser.notificationunreadcount)
    //    {
    //        notificationCount = appUser.notificationunreadcount
    //    }
    //    $("#notificationcount5").html(notificationCount)
    var appointmentunreadcount = 0;
    //    if(appUser.appointmentunreadcount)
    //    {
    //        appointmentunreadcount = appUser.appointmentunreadcount
    //    }
    var menuObj = localStorage.getItem("objGetUserDetailsWithmenu");
    if (menuObj) {
        menuObj = JSON.parse(menuObj);
        if (menuObj.data && menuObj.data.roleName) {
            var roleName = menuObj.data.roleName;
        }
    }
    try {
        var bottommenu = "";
        bottommenu += '<div class="mobilebottommenu">';
        bottommenu += '    <div class="row">';
        bottommenu +=
            '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Home" fileName="app_userhome_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_home.svg"><span>Home</span></a></div>';
        bottommenu +=
            '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Appointment" fileName="app_alleventpromotionslist_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_calendar.svg"><span >Discover</span></a></a><div id="appointmentCount" class="chatunreadcount active hide">' +
            appointmentunreadcount +
            "</div></div>";
        bottommenu +=
            '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Scan" fileName="app_sacaner_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_barcode.svg" class="scannerbottommenu"><span>Scan</span></a></div>';
        bottommenu +=
            '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Chat" fileName="undefined_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_chat.svg"><span>Messages</span></a><div id="chatCount" style="display:none !important"  class="chatunreadcount active">0</div></div>';
        bottommenu +=
            '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="More" fileName="app_custmoreinfodetails_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_more.svg"><span>Account</span></a></div>';
        bottommenu += "    </div>";
        bottommenu += "</div>";
        $("#bottommenu35").html(bottommenu);
    } catch (err) {
        // console.log('Error in showBottomMenu', err);
    }
}
function getAllDealsOfTheDay(search = '') {
    var objParamsList = {};
    objParamsList.queryMode = 'mylist';
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsList.tokenKey = getParameterByName('tokenKey');
    objParamsList.secretKey = getParameterByName('secretKey');
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.isMobile = true;
    objParamsList.type = "dealsoftheday";
    objParamsList.eventdate = new Date();
    objParamsList.eventenddate = new Date();
    if (search && search != '') {
       objParamsList.globalsearchvalue = search;
    }
    $.ajax({
            url: ajaXCallURL + '/milestone003/getListDetails_Bazaar5da73cac545050343288ce7a_app_userhome_dcard_topimage3_collectioncontainer__discount',
            data: objParamsList,
            type: 'POST',
            success: function (response) {
                $('#display_loading').addClass('hideme');
                renderDealsOfTheDay(response);
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            }
        });
}


function  renderDealsOfTheDay(response) {
    console.log(response)
    var html = '';
    if (response.data.length == 0) {
        html += '<div class="nodatafound">';
        html += '<img src="nodatafound.gif" width="100%">';
        html += '<br>';
        html += '<!-- span>No record found</span -->';
        html += '</div>';
        $('#collectioncontainerDivdcard_topimage2x2_collectioncontainer__discount').html(html);;

    } else {
        html = '';
        squareHtml = '';
        var radioGroups = [];
        $.each(response.data, function (keyList, objList) {

            var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (isAndroid > -1 || ios > -1) {  // need to fix with native gyes.. images not getting download
                var mediaID = '';
                var fileName = '';
                if (objList['merchantimage'] && objList['merchantimage'][0].mediaID) {
                    mediaID = objList['merchantimage'][0].mediaID;
                    fileName = objList['merchantimage'][0].mediaID + '.png';
                }
                getLocalImagedcard_topimage2_collectioncontainer(objList, mediaID, fileName);
            } else {

                squareHtml += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.merchantimage + objList.code + objList.eventdate) + '">';
                squareHtml += '             <div class="col s12 m12">';
                squareHtml += '               <div class="card-content">';
                squareHtml += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_topimage2_collectioncontainer" style="" >';
                squareHtml += '      <div class="row  element" style=""  >';
                var localFilePath = '';
                if (response && response.localFilePath) {
                    localFilePath = response.localFilePath;
                }
                squareHtml += '<div class="row">';
                squareHtml += '<div class="col s4">';
                squareHtml += '           <div class="col s12 clssg3017" style="">';
                var filetodisplay = '';
                // objList.merchantimage = objList.squaremerchantimage ? objList.squaremerchantimage : objList.merchantimage;
                if (objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[objList.merchantimage.length -1].mediaID) {
                    filetodisplay = getuploadedfilepreview(objList.merchantimage[objList.merchantimage.length -1].fileNm);
                }
                if (localFilePath && localFilePath != '') {
                    squareHtml += '               <img recordID="' + objList._id + '"  id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
                } else if (objList.merchantimage && objList.merchantimage[objList.merchantimage.length -1] && objList.merchantimage[objList.merchantimage.length -1].mediaID) {
                    if (filetodisplay && filetodisplay != objList.merchantimage[objList.merchantimage.length -1].fileNm) {
                        squareHtml += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
                    } else {
                        squareHtml += '               <img recordID="' + objList._id + '"    id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + objList.merchantimage[objList.merchantimage.length -1].mediaID + '_compressed.png">';
                    }
                } else {
                    // stage 6666666666666666
                    squareHtml += '               <img recordID="' + objList._id + '"   id="merchantimage12"   class=" clssg3017image merchantimage12" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
                }
                squareHtml += '           </div>';
                var adddbclass = ''
                squareHtml += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017__merchanttype' + adddbclass + ' " style=" cursor: pointer;">';
                objList['merchanttype'] = objList['merchanttype'] ? objList['merchanttype'] : '';
                if (response.showShimmer) {
                    objList['merchanttype'] = '';
                }
                var merchanttype = objList['merchanttype'];
                squareHtml += '           <div recordID="' + objList._id + '"   id="merchanttype13" class="languagetranslation " style="" >' + merchanttype + '</div>'; // <img onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="Merchant-Location-White.svg" width=15%; style=""> &nbsp
                squareHtml += '     </div>';
                squareHtml += '           </div>';
                squareHtml += '<div class="col s8 leftcards">';
                var adddbclass = ''
                squareHtml += '           <div recordID="' + objList._id + '" class="col s12 clssg5017__name  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
                objList['merchantname'] = objList['merchantname'] ? objList['merchantname'] : '';
                if (response.showShimmer) {
                    objList['merchantname'] = '';
                }
                var merchantname = objList['merchantname'];
                squareHtml += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + merchantname + '</div>';
                squareHtml += '     </div>';

                var adddbclass = ''
                squareHtml += '           <div recordID="' + objList._id + '" class="col s12 clssg5017  codeclssg5017' + adddbclass + ' " style=" cursor: pointer;">';
                objList['code'] = objList['code'] ? objList['code'] : '';
                if (response.showShimmer) {
                    objList['code'] = '';
                }
                var code = objList['code'];
                squareHtml += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >' + code + '</div>';
                squareHtml += '     </div>';
                var adddbclass = ''
                squareHtml += '           <div recordID="' + objList._id + '" class="col s12 clssg7017  ' + adddbclass + ' " style=" cursor: pointer;">';
                objList['eventdate'] = objList['eventdate'] ? moment(new Date(objList['eventdate'])).format('DD MMM YYYY') : '';
                var eventdate = objList['eventdate'];
                var description = objList["description"] || '';
                description = description.replace(/<[^>]*>?/gm, '');
                if (description.length > 75) {
                    // description = description.slice(0, 69);
                    // description = `${description}...`;
                    }
                squareHtml += '           <div recordID="' + objList._id + '"   id="eventdate14" class="languagetranslation " style="width: 100% !important; text-overflow: ellipsis !important; white-space: nowrap !important; overflow: hidden !important;" >' + description + '</div>';
                squareHtml += '     </div>';
                var adddbclass = ''
                squareHtml += '           <div recordID="' + objList._id + '" class="col s9 clssg5017  codeclssg5017__getdiscount' + adddbclass + ' " style=" cursor: pointer;">';
                squareHtml += '           <div recordID="' + objList._id + '"   id="code13" class="languagetranslation " style="" >Get Discount</div>';
                squareHtml += '     </div>';
                squareHtml += '           <div recordID="' + objList._id + '" class="col s3 clssg5017  codeclssg5017__getdiscountimg' + adddbclass + ' " style=" cursor: pointer;">';
                squareHtml += '         <img recordid="c79eca6544feb547f994edec" id="merchantimage12" class=" clssg3017image__discount merchantimage12" style="" onerror="this.src="https://appscdn-us.hokuapps.com/card.png" src="Merchant-Stamp-White.svg">';
                squareHtml += '     </div>';
                squareHtml += '     </div>';
                squareHtml += '     </div>';
                squareHtml += '     </div>';
                squareHtml += '                     </div>';
                squareHtml += '          </div>';
                squareHtml += '        </div>';
                squareHtml += '     </div>';
                squareHtml += '   </div>';
            }
        });
        var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        if (1) {
            $('#collectioncontainerDivdcard_topimage2_collectioncontainer').html(squareHtml);
            $('#full-body-container').addClass('fadeInUp');
        };
        if (!response.showShimmer) {
            dcardLoaded['dcard_topimage2_collectioncontainer'] = true;
            $('#collectioncontainerDivdcard_topimage2_collectioncontainer').find('.view_list_record').removeClass('shimmer');

        }
        $('.carddropdown').material_select();
        $('<input>').attr({ type: 'hidden', class: 'cardtoggleswitch', id: 'togleswitchvalue' }).appendTo('body')
        if ($('.js-candlestick').length) $('.js-candlestick').candlestick({ afterSetting: function (input, wrapper, value) { $('#togleswitchvalue').val(value).attr('recordID', input.attr('id')).trigger('click'); } });
        if (radioGroups && radioGroups.length) {
            for (var key in radioGroups) {
                var groupName = radioGroups[key];
                $('input:radio[name=' + groupName + ']:first').prop('checked', true);
                $('input:radio[name=' + groupName + ']:first').trigger('change');
            }
        }
    };
}
function getCategoryDetails() {
    var objParamsList = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsList.tokenKey = getParameterByName('tokenKey');
    objParamsList.secretKey = getParameterByName('secretKey');
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.categorytype = 'Merchant';
    $.ajax({
        url: objParamsList.ajaXCallURL + '/milestone003/getListDetails_Category5da73cac545050343288ce7a_eventcategoryweb_eventcategorywebKendoList',
        data: objParamsList,
        type: 'POST',
        success: function (response) {
            if (response.status != undefined && response.status == 0) {
                let html = ''

                $.each(response.data, function (keyList, objList) {
                    html += `<div id="sgcol0482" class="col s12">
                        <div id="education_div" class="input-field  element " style="margin-top:0px;" >
                        <input iamowner='${objList.categoryname}' class="category_checkbox" value="${objList.categoryname}" name="" class="chkstatus filled-in" type="checkbox" id="${objList.categoryname}" />
                        <label style ="" for="${objList.categoryname}">${objList.categoryname}</label>
                        <div id=${objList.categoryname}_error" status="0" class="error_message" style="display: none; color: red;padding-top: 10px;position: relative;top: 10px;">Required </div>
                        </div>
                     </div>`;
                });
                $('.categoryoptions').html(html)
                $('#display_loading').addClass('hideme');
            } else {
                $('#display_loading').addClass('hideme')
            }
        },
        error: function (xhr, status, error) {
            $('#display_loading').addClass('hideme')
            handleError(xhr, status, error);
        },
    });
}