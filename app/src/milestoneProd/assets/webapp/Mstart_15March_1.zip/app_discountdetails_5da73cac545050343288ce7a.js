var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = "";
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
  $("#recordID").val(getParameterByName("recordID"));
  var queryMode = getParameterByName("queryMode");
  var authKey = $("#authKey").val();
  var appID = $("#hdnAppID").val();
  if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
    $("#headerPageName").html(localStorage.getItem("headerPageName"));
  }

  var objParamsToken = {};
  var ajaXCallURL = $.trim($("#ajaXCallURL").val());
  objParamsToken.tokenKey = getParameterByName("tokenKey");
  objParamsToken.secretKey = getParameterByName("secretKey");

  var userRole = $("#userRole").val();
  var userID = $("#userID").val();
  var createrOfRecord = $("#createrOfRecord").val();
  var queryMode = getParameterByName("queryMode");
  var recordID = $.trim($("#recordID").val());
  var addSessionComments = [];
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on("click", "#redeem24", function () {
    var objParams = {};
    var discountid = $.trim($("#discountid31").val());
    if ($("#discountid31_div").is(":visible")) {
      objParams.discountid = discountid;
    }
    var discountid = $.trim($("#discountid31").val());
    if ($("#discountid31_div").is(":visible")) {
      objParams.discountid = discountid;
    }
    var tempobjParams = getParams(window.location.href);
    function extend(obj, src) {
      for (var key in src) {
        if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
      }
      return obj;
    }
    objParams = extend(objParams, tempobjParams);
    if (!objParams["discountid"]) {
      delete objParams["discountid"];
    }
    if (!objParams["discountid"]) {
      delete objParams["discountid"];
    }
    var recordID = $("#recordID").val();
    objParams.isDelete = 0;
    var ajaXCallURL = $.trim($("#ajaXCallURL").val());
    objParams.tokenKey = getParameterByName("tokenKey");
    objParams.secretKey = getParameterByName("secretKey");
    objParams.offlineDataID = localStorage.getItem("offlineDataID");
    objParams.merchantID = getParameterByName("merchantID");
    var queryMode = getParameterByName("queryMode");
    if (queryMode == "mylist") {
      objParams.callUrl =
        ajaXCallURL +
        "/milestone003/saveAjaxredeemeddiscountapp_discountdetails";
    } else {
      objParams.callUrl =
        ajaXCallURL +
        "/milestone003/updateAjaxredeemeddiscountapp_discountdetails";
      objParams.recordID = recordID;
    }
    if (errorFields && Object.keys(errorFields).length) {
      $("#display_loading1").addClass("hideme");
      for (var firstErrorField in errorFields) {
        var controlType = errorFields[firstErrorField];
        errorFields = [];
        var errField = $("#" + firstErrorField);
        if (controlType == "dropdown") {
          errField.prev().prev().focus();
        } else {
          errField.focus();
        }
        validAll = true;
        return false;
      }
    }
    if (!validAll) {
      validAll = true;
      return false;
    }
    $("#redeem24").prop("disabled", true);
    $("#display_loading1").removeClass("hideme");
    if (addSessionComments.length > 0) {
      objParams.addSessionComments = addSessionComments;
    } else {
      objParams.addSessionComments = [];
    }
    var parentID = $("#parentID").val();
    var parentName = $("#parentName").val();
    if (parentID != "") {
      objParams.parentID = parentID;
      objParams.parentName = parentName;
    }
    if (
      typeof addedFiles != "undefined" &&
      addedFiles &&
      addedFiles.length > 0
    ) {
      objParams.addedFiles = addedFiles;
    }
    objParams.ajaXCallURL = $("#ajaXCallURL").val();
    objParams.organizationID = $("#organizationID").val();
    objParams.ajaXCallURL = $("#ajaXCallURL").val();
    objParams.organizationID = $("#organizationID").val();
    var tokenKey = getParameterByName("tokenKey");
    var secretKey = getParameterByName("secretKey");
    var queryMode = getParameterByName("queryMode");
    queryMode = queryMode.replace("edit", "");
    localStorage.setItem("headerPageName", "app_userhome");
    var queryString = window.location.search.slice(1);
    var newQuery =
      queryString +
      "&queryMode=mylist&tokenKey=" +
      tokenKey +
      "&secretKey=" +
      secretKey;
    var queryParams = queryStringToJSON(newQuery);
    queryString = $.param(queryParams);
    queryString = queryString.replace(/\+/g, "%20");
    queryString = decodeURIComponent(queryString);
    var nextPage = 'app_merchantdiscountlist'
    if (recordID == "") {
      window.location.href =
        nextPage +
        "_5da73cac545050343288ce7a.html?" +
        queryString;
    } else {
      window.location.href =
        nextPage +
        "_5da73cac545050343288ce7a.html?" +
        queryString;
    }
    return false;
    // processBeforeCallForSaveredeemeddiscount(objParams, {}, function (
    //   processBeforeRes
    // ) {
    //   $.ajax({
    //     url: objParams.callUrl,
    //     data: objParams,
    //     type: "POST",
    //     success: function (response) {
    //       if (response.status == 0) {
    //         $("#display_loading1").addClass("hideme");
    //         var roleName = localStorage.getItem("roleName");
    //         if (roleName == "consultant") {
    //           response.nextPage = "app_consultantuserhome";
    //         } else {
    //           response.nextPage = "app_userhome";
    //         }
    //         processAfterCallForSaveredeemeddiscount(response, function (
    //           processAfterRes
    //         ) {
    //           var tokenKey = getParameterByName("tokenKey");
    //           var secretKey = getParameterByName("secretKey");
    //           var queryMode = getParameterByName("queryMode");
    //           queryMode = queryMode.replace("edit", "");
    //           localStorage.setItem("headerPageName", "app_userhome");
    //           var queryString = window.location.search.slice(1);
    //           var newQuery =
    //             queryString +
    //             "&queryMode=mylist&tokenKey=" +
    //             tokenKey +
    //             "&secretKey=" +
    //             secretKey;
    //           var queryParams = queryStringToJSON(newQuery);
    //           queryString = $.param(queryParams);
    //           queryString = queryString.replace(/\+/g, "%20");
    //           queryString = decodeURIComponent(queryString);
    //           if (recordID == "") {
    //             window.location.href =
    //               response.nextPage +
    //               "_5da73cac545050343288ce7a.html?" +
    //               queryString;
    //           } else {
    //             window.location.href =
    //               response.nextPage +
    //               "_5da73cac545050343288ce7a.html?" +
    //               queryString;
    //           }
    //           return false;
    //         }); // End of After Process
    //       } else {
    //         $("#display_loading1").addClass("hideme");
    //         $("#2656d_error").html(response.error);
    //         $("#2656d_error").show();
    //       }
    //       $("#redeem24").removeProp("disabled");
    //     },
    //     error: function (xhr, status, error) {
    //       $("#display_loading1").addClass("hideme");
    //       $("#redeem24").removeProp("disabled");
    //     },
    //   });
    //   return false;
    // }); // End of Before Process
  }); //end of Event Redeem_is_click
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};
  $(document).on("click", "#backbutton1", function (e) {
    window.history.back();
    return false;
  });

  var addedRecords = [];
  localStorage.setItem("addedRecords", []);
  $(document).on("click", "#backbutton1", function (e) {
    try {
      var element = $(this);
      var nextPage = "app_merchantdetails";
      nextPage = "app_allmerchantdiscountslist";
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "update";
      // var recordID = $(this).attr("recordID");
      // if (recordID) {
      //   queryParams["recordID"] = recordID;
      // }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href =
        nextPage + "_5da73cac545050343288ce7a.html?" + queryString;
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error);
    }
  });


  var paramsEdit = {};
  paramsEdit.tokenKey = getParameterByName("tokenKey");
  paramsEdit.secretKey = getParameterByName("secretKey");
  getRecordByIDProcessBeforeCall367715(paramsEdit, function (processBeforeRes) {
    $.ajax({
      url:
        ajaXCallURL +
        "/milestone003/getRecordByCustomeQuery_app_discountdetails_Bazaar5da73cac545050343288ce7a",
      data: paramsEdit,
      type: "POST",
      jsonpCallback: "callback",
      success: function (response) {
        getRecordByIDProcessAfterCall367715(response, function (
          processBeforeRes
        ) {
          if (
            response.status != undefined &&
            response.status == 0 &&
            response.recordDetails != undefined
          ) {
            var objParamsList = {};
            var queryMode = $("#queryMode").val();
            objParamsList.queryMode = queryMode;
            var tokenKey = $("#tokenKey").val();
            objParamsList.tokenKey = tokenKey;
            if (response.recordDetails.accumalatedstampcard != undefined)
              $("#accumalatedstampcard29").val(
                response.recordDetails.accumalatedstampcard
              );
            if (!$("#backbutton1").html()) {
              $("#backbutton1").append(response.recordDetails.undefined);
            }
            response.recordDetails["createdOn_preserved"] =
              response.recordDetails["createdOn"];
            response.recordDetails["createdOn"] = response.recordDetails[
              "createdOn"
            ]
              ? moment(new Date(response.recordDetails["createdOn"])).format(
                "DD MMMM YYYY hh:mm A"
              )
              : "";
            if (!$("#createdOn11").html()) {
              $("#createdOn11").append(response.recordDetails.createdOn);
            }
            response.recordDetails["createdOn"] =
              response.recordDetails["createdOn_preserved"];
            if (!$("#description17").html()) {
              $("#description17").append(
                unescape(response.recordDetails.description)
              );
            }
            if (!$("#discountid8").html()) {
              $("#discountid8").append(response.recordDetails.discountid);
            }
            if (!$("#name10").html()) {
              $("#name10").append(response.recordDetails.name);
            }
            if (!$("#code9").html()) {
              $("#code9").append(response.recordDetails.code);
            }
            if (!$("#description16").html()) {
              $("#description16").append(
                unescape(response.recordDetails.undefined)
              );
            }
            if (!$("#discountdetails2").html()) {
              $("#discountdetails2").append(response.recordDetails.undefined);
            }
            if (response.recordDetails.droplocation != undefined)
              $("#droplocation26").val(response.recordDetails.droplocation);
            if (
              response.recordDetails.droplocation &&
              response.recordDetails.droplocation["coordinates"]
            ) {
              var coordinates =
                response.recordDetails.droplocation["coordinates"];
              if (coordinates && coordinates.length) {
                localStorage.setItem("droplocationLatitude", coordinates[1]);
                localStorage.setItem("droplocationLongitute", coordinates[0]);
              }
            }
            if (response.recordDetails.droplocation_name != undefined)
              $("#droplocation_name28").val(
                response.recordDetails.droplocation_name
              );
            if (response.recordDetails.pickuplocation != undefined)
              $("#pickuplocation25").val(response.recordDetails.pickuplocation);
            if (
              response.recordDetails.pickuplocation &&
              response.recordDetails.pickuplocation["coordinates"]
            ) {
              var coordinates =
                response.recordDetails.pickuplocation["coordinates"];
              if (coordinates && coordinates.length) {
                localStorage.setItem("pickuplocationLatitude", coordinates[1]);
                localStorage.setItem("pickuplocationLongitute", coordinates[0]);
              }
            }
            if (response.recordDetails.pickuplocation_name != undefined)
              $("#pickuplocation_name27").val(
                response.recordDetails.pickuplocation_name
              );
            var url = "icon_next.png";
            $("#iconnext22").attr("src", url);
            var url = "icon_next4.png";
            $("#iconnext414").attr("src", url);
            // getrecordbycustomquery - Stage - 111111111111
            if (
              response.recordDetails["merchantimage"] &&
              response.recordDetails["merchantimage"].length > 0
            ) {
              if (
                (response.recordDetails["merchantimage"][0].displayType =
                  "html")
              ) {
                var eleParent = $("#merchantimage6").parent();
              response.recordDetails["merchantimage"] = [ response.recordDetails["merchantimage"][ response.recordDetails["merchantimage"].length - 1] ]
                for (var key in response.recordDetails["merchantimage"]) {
                  var objImage = response.recordDetails["merchantimage"][key];
                  if (
                    response.recordDetails["merchantimage"][key].name == "Audio"
                  ) {
                    var token = $("#tokenKey").val();
                    if (token && token != "") {
                      token = $("#tokenKey").val();
                    } else {
                      token = getParameterByName("tokenKey");
                    }
                    var mediaIDa =
                      response.recordDetails["merchantimage"][0].mediaID;
                    var filenamea =
                      response.recordDetails["merchantimage"][0].fileName;
                    var CDN_PATH2 =
                      "https://devfiles.hokuapps.com/downloadOriginal?f=" +
                      mediaIDa +
                      "&fn=" +
                      filenamea +
                      "&t=" +
                      token;
                    var url = CDN_PATH2;
                  } else {
                    var filetodisplay = getuploadedfilepreview(objImage.fileNm);
                    if (filetodisplay && filetodisplay != objImage.fileNm) {
                      var url = filetodisplay;
                    } else {
                      var url = CDN_PATH + objImage.mediaID + "_compressed.png";
                    }
                  }
                  if (
                    response.recordDetails["merchantimage"][key].name == "Audio"
                  ) {
                    var html = "";
                    html += '<div class="col s12" style="float: right;">';
                    html +=
                      '<audio class="" src="' + url + '" controls></audio>';
                    html += "</div>";
                  } else {
                    var html =
                      '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' +
                      url +
                      '" />';
                  }
                  if (!key || key == "0") {
                    eleParent.html(html);
                  } else {
                    eleParent.append(html);
                  }
                }
              } else {
                if (
                  response.recordDetails["merchantimage"][key].name == "Audio"
                ) {
                  var url =
                    CDN_PATH +
                    response.recordDetails["merchantimage"][0].mediaID;
                } else {
                  var url =
                    CDN_PATH +
                    response.recordDetails["merchantimage"][0].mediaID +
                    "_compressed.png";
                }
                $("#merchantimage6").attr("src", url);
              }
            }
            if (response.recordDetails.tested != undefined)
              $("#tested30").val(response.recordDetails.tested);
            if (response.recordDetails.discountid != undefined)
              $("#discountid31").val(response.recordDetails.discountid);
            if (!$("#shopdetails13").html()) {
              $("#shopdetails13").append(response.recordDetails.undefined);
            }
            if (!$("#stampcards21").html()) {
              $("#stampcards21").append(response.recordDetails.undefined);
            }
            if (!$("#youhavealreadyredeemedthisdiscount19").html()) {
              $("#youhavealreadyredeemedthisdiscount19").append(
                response.recordDetails.undefined
              );
            }

            if (response.recordDetails.merchantname) {
              $('#merchantcategory_name8').html(response.recordDetails.merchantname);
            }
            if (response.recordDetails.aboutmerchant) {

              var html = "";
              var description18Edit = response.recordDetails.aboutmerchant.replace(/<[^>]*>?/gm, '');
              var charLength = description18Edit.length;
              var firstLine = description18Edit.slice(0, 100);
              var secondLine = description18Edit.slice(100, charLength);
              if (charLength > 100) {
                html += `<div>${firstLine}<span id="dots">...</span><span id="more">${secondLine}</span><p  onclick="showMoreLess()" class="showMoreBtm" id="myBtn"> Show more</p></div>`;
              } else {
                html = description18Edit;
              }

              $('#merchantdescription13').html(html);
            }
            if (response.recordDetails.expirationdate) {
              let expirationdate = moment(response.recordDetails.expirationdate).format('ddd, MMMM DD, YYYY');
              $('#expirydate17').html(expirationdate);
            }
            if (response.recordDetails.outletaddress_name) {
              $('#location17').html(response.recordDetails.outletaddress_name);
            }
            if (response.recordDetails.outletcontactnumber) {
              $('#contactno17').html(`<a style="color: #b18d4f !important;" href="tel:${response.recordDetails.outletcontactnumber}">${response.recordDetails.outletcontactnumber}</a>`);
            }
            Materialize.updateTextFields();
            $(".languagetranslation.fieldshimmer")
              .removeClass("fieldshimmer")
              .fadeOut(0)
              .fadeIn(100);
          }
        }); // end of getRecord By ID
      },
      error: function (xhr, status, error) {
        handleError(xhr, status, error);
      },
    });
  }); // end of getRecord By ID

  var paramsEdit = {};
  paramsEdit.tokenKey = getParameterByName("tokenKey");
  paramsEdit.secretKey = getParameterByName("secretKey");
  if (
    getParameterByName("discountid") &&
    getParameterByName("discountid") != null &&
    getParameterByName("discountid") != ""
  ) {
    paramsEdit.discountid = getParameterByName("discountid");
  }
  if (
    getParameterByName("userId") &&
    getParameterByName("userId") != null &&
    getParameterByName("userId") != ""
  ) {
    paramsEdit.userId = getParameterByName("userId");
  }
  getRecordByIDProcessBeforeCallgroup113row7(paramsEdit, function (
    processBeforeRes
  ) {
    $.ajax({
      url:
        ajaXCallURL +
        "/milestone003/getRecordByCustomeQuery_app_discountdetails_Redeemeddiscount5da73cac545050343288ce7a",
      data: paramsEdit,
      type: "POST",
      jsonpCallback: "callback",
      success: function (response) {
        getRecordByIDProcessAfterCallgroup113row7(response, function (
          processBeforeRes
        ) {
          if (
            response.status != undefined &&
            response.status == 0 &&
            response.recordDetails != undefined
          ) {
            var objParamsList = {};
            var queryMode = $("#queryMode").val();
            objParamsList.queryMode = queryMode;
            var tokenKey = $("#tokenKey").val();
            objParamsList.tokenKey = tokenKey;
            if (response.recordDetails.accumalatedstampcard != undefined)
              $("#accumalatedstampcard29").val(
                response.recordDetails.accumalatedstampcard
              );
            if (!$("#backbutton1").html()) {
              $("#backbutton1").append(response.recordDetails.undefined);
            }
            response.recordDetails["createdOn_preserved"] =
              response.recordDetails["createdOn"];
            response.recordDetails["createdOn"] = response.recordDetails[
              "createdOn"
            ]
              ? moment(new Date(response.recordDetails["createdOn"])).format(
                "DD MMMM YYYY hh:mm A"
              )
              : "";
            if (!$("#createdOn11").html()) {
              $("#createdOn11").append(response.recordDetails.createdOn);
            }
            response.recordDetails["createdOn"] =
              response.recordDetails["createdOn_preserved"];
            if (!$("#description17").html()) {
              $("#description17").append(
                unescape(response.recordDetails.description)
              );
            }
            if (!$("#discountid8").html()) {
              $("#discountid8").append(response.recordDetails.discountid);
            }
            if (!$("#name10").html()) {
              $("#name10").append(response.recordDetails.name);
            }
            if (!$("#code9").html()) {
              $("#code9").append(response.recordDetails.code);
            }
            if (!$("#description16").html()) {
              $("#description16").append(
                unescape(response.recordDetails.undefined)
              );
            }
            if (!$("#discountdetails2").html()) {
              $("#discountdetails2").append(response.recordDetails.undefined);
            }
            if (response.recordDetails.droplocation != undefined)
              $("#droplocation26").val(response.recordDetails.droplocation);
            if (
              response.recordDetails.droplocation &&
              response.recordDetails.droplocation["coordinates"]
            ) {
              var coordinates =
                response.recordDetails.droplocation["coordinates"];
              if (coordinates && coordinates.length) {
                localStorage.setItem("droplocationLatitude", coordinates[1]);
                localStorage.setItem("droplocationLongitute", coordinates[0]);
              }
            }
            if (response.recordDetails.droplocation_name != undefined)
              $("#droplocation_name28").val(
                response.recordDetails.droplocation_name
              );
            if (response.recordDetails.pickuplocation != undefined)
              $("#pickuplocation25").val(response.recordDetails.pickuplocation);
            if (
              response.recordDetails.pickuplocation &&
              response.recordDetails.pickuplocation["coordinates"]
            ) {
              var coordinates =
                response.recordDetails.pickuplocation["coordinates"];
              if (coordinates && coordinates.length) {
                localStorage.setItem("pickuplocationLatitude", coordinates[1]);
                localStorage.setItem("pickuplocationLongitute", coordinates[0]);
              }
            }
            if (response.recordDetails.pickuplocation_name != undefined)
              $("#pickuplocation_name27").val(
                response.recordDetails.pickuplocation_name
              );
            var url = "icon_next.png";
            $("#iconnext22").attr("src", url);
            var url = "icon_next4.png";
            $("#iconnext414").attr("src", url);
            // getrecordbycustomquery - Stage - 111111111111
            if (
              response.recordDetails["merchantimage"] &&
              response.recordDetails["merchantimage"].length > 0
            ) {
              if (
                (response.recordDetails["merchantimage"][0].displayType =
                  "html")
              ) {
                var eleParent = $("#merchantimage6").parent();
                for (var key in response.recordDetails["merchantimage"]) {
                  var objImage = response.recordDetails["merchantimage"][key];
                  if (
                    response.recordDetails["merchantimage"][key].name == "Audio"
                  ) {
                    var token = $("#tokenKey").val();
                    if (token && token != "") {
                      token = $("#tokenKey").val();
                    } else {
                      token = getParameterByName("tokenKey");
                    }
                    var mediaIDa =
                      response.recordDetails["merchantimage"][0].mediaID;
                    var filenamea =
                      response.recordDetails["merchantimage"][0].fileName;
                    var CDN_PATH2 =
                      "https://devfiles.hokuapps.com/downloadOriginal?f=" +
                      mediaIDa +
                      "&fn=" +
                      filenamea +
                      "&t=" +
                      token;
                    var url = CDN_PATH2;
                  } else {
                    var filetodisplay = getuploadedfilepreview(objImage.fileNm);
                    if (filetodisplay && filetodisplay != objImage.fileNm) {
                      var url = filetodisplay;
                    } else {
                      var url = CDN_PATH + objImage.mediaID + "_compressed.png";
                    }
                  }
                  if (
                    response.recordDetails["merchantimage"][key].name == "Audio"
                  ) {
                    var html = "";
                    html += '<div class="col s12" style="float: right;">';
                    html +=
                      '<audio class="" src="' + url + '" controls></audio>';
                    html += "</div>";
                  } else {
                    var html =
                      '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' +
                      url +
                      '" />';
                  }
                  if (!key || key == "0") {
                    eleParent.html(html);
                  } else {
                    eleParent.append(html);
                  }
                }
              } else {
                if (
                  response.recordDetails["merchantimage"][key].name == "Audio"
                ) {
                  var url =
                    CDN_PATH +
                    response.recordDetails["merchantimage"][0].mediaID;
                } else {
                  var url =
                    CDN_PATH +
                    response.recordDetails["merchantimage"][0].mediaID +
                    "_compressed.png";
                }
                $("#merchantimage6").attr("src", url);
              }
            }
            if (response.recordDetails.tested != undefined)
              $("#tested30").val(response.recordDetails.tested);
            if (response.recordDetails.discountid != undefined)
              $("#discountid31").val(response.recordDetails.discountid);
            if (!$("#shopdetails13").html()) {
              $("#shopdetails13").append(response.recordDetails.undefined);
            }
            if (!$("#stampcards21").html()) {
              $("#stampcards21").append(response.recordDetails.undefined);
            }
            if (!$("#youhavealreadyredeemedthisdiscount19").html()) {
              $("#youhavealreadyredeemedthisdiscount19").append(
                response.recordDetails.undefined
              );
            }

            Materialize.updateTextFields();
            $(".languagetranslation.fieldshimmer")
              .removeClass("fieldshimmer")
              .fadeOut(0)
              .fadeIn(100);
          }
        }); // end of getRecord By ID
      },
      error: function (xhr, status, error) {
        handleError(xhr, status, error);
      },
    });
  }); // end of getRecord By ID

  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on("click", "#merchantimage12", function () {
    var tokenKey = getParameterByName("tokenKey");
    var secretKey = getParameterByName("secretKey");
    var queryMode = getParameterByName("queryMode");
    var ajaXCallURL = $.trim($("#ajaXCallURL").val());
    loadNativescanqrcodeControl(tokenKey, queryMode, secretKey, ajaXCallURL);
  }); //end of Event Scan QR Code_is_click

  $(document).on('click', '#share12', function () {
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var queryMode = getParameterByName('queryMode');
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    loadNativesendinvitesControl(tokenKey, queryMode, secretKey, ajaXCallURL);
  });//end of Event Send invites_is_click 

}); //end of ready
function getParams(url) {
  var urlParams = {};
  url.replace(new RegExp("([^?=&]+)(=([^&]*))?", "g"), function (
    $0,
    $1,
    $2,
    $3
  ) {
    if ($3 && $3 != "undefined") urlParams[$1] = $3;
  });
  return urlParams;
}
function processBeforeCallForSaveredeemeddiscount(objParams,response,callback
) {
  objParams.type = "Stamp Card";

  objParams.referralAmount = 1;
  objParams.displayAmount = 1;
  objParams.status = "Approved";
  if (
    getParameterByName("bazaarid") &&
    getParameterByName("bazaarid") != "undefined"
  ) {
    objParams.discountid = getParameterByName("bazaarid");
  }

  callback();
}
function processAfterCallForSaveredeemeddiscount(response, callback) {
  shareAppData("You have successfully availed discount.", "toast");

  callback();
}
function getRecordByIDProcessBeforeCall367715(paramsType, callback) {
  var response = paramsType;

  if (
    getParameterByName("bazaarid") &&
    getParameterByName("bazaarid") != "undefined"
  ) {
    paramsType.recordID = getParameterByName("bazaarid");
  } else if (
    getParameterByName("recordID") &&
    getParameterByName("recordID") != "undefined"
  ) {
    paramsType.recordID = getParameterByName("recordID");
  }
  callback();
}
function getRecordByIDProcessAfterCall367715(response, callback) {
  callback();
}
function getRecordByIDProcessBeforeCallgroup113row7(paramsType, callback) {
  var response = paramsType;

  if (
    getParameterByName("bazaarid") &&
    getParameterByName("bazaarid") != "undefined"
  ) {
    paramsType.discountid = getParameterByName("bazaarid");
  }

  paramsType.userId = localStorage.getItem("userID");
  paramsType.todaydate = new Date();
  callback();
}
function getRecordByIDProcessAfterCallgroup113row7(response, callback) {
  if (response && response.recordDetails) {
    $("#sg3704").show();
    $("#groupcopy28row23").hide();
    $("#youhavealreadyredeemedthisdiscount19").removeClass("hide");
  } else {
    $("#groupcopy28row23").show();
    $("#sg3704").hide();
  }

  return false;
}

function showMoreLess() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");

  if (dots.style.display === "none") {
    dots.style.display = "inline";
    btnText.innerHTML = " Show more";
    moreText.style.display = "none";
  } else {
    dots.style.display = "none";
    btnText.innerHTML = " Show less";
    moreText.style.display = "inline";
  }
}


function loadNativescanqrcodeControl(
  tokenKey,
  queryMode,
  secretKey,
  ajaXCallURL
) {
  try {
    var appJSON = {};
    appJSON.tokenKey = tokenKey;
    appJSON.secretKey = secretKey;
    appJSON.queryMode = queryMode;
    appJSON.action = queryMode;
    appJSON.ajaXCallURL = ajaXCallURL;
    var AWSCredentials = localStorage.getItem("AWSCredentials");
    if (localStorage.IDENTITY_TOKEN) {
      var token = localStorage.IDENTITY_TOKEN;
      var playload = JSON.parse(atob(token.split(".")[1]));
      appJSON.Authorization = token;
      appJSON.Expiration = playload.exp;
    } else if (AWSCredentials) {
      AWSCredentials = JSON.parse(AWSCredentials);
      appJSON.accessKeyId = AWSCredentials.accessKeyId;
      appJSON.secretAccessKey = AWSCredentials.secretAccessKey;
      appJSON.sessionToken = AWSCredentials.sessionToken;
      appJSON.Expiration = AWSCredentials.Expiration;
    }
    appJSON.msgText =
      "<b><b><b><b><b><b><b><b><b>undefined</b></b></b></b></b></b></b></b></b>";
    appJSON.organizationID = $("#organizationID").val();
    appJSON.userID = $("#userID").val();
    appJSON.callbackFunction = "setNativescanqrcodeControl";
    appJSON.nextButtonCallback = "setNativescanqrcodeControl";
    appJSON.appID = $("#appID").val();
    var element = element ? element : null;
    clientbeforeNativescanqrcode(appJSON, element, function (pbcRes) {
      if (DEVICE_TYPE == "ios") {
        setupWebViewJavascriptBridge(function (bridgeObj) {
          bridgeObj.callHandler(
            "loadNativeQRCodeScannerUpload",
            appJSON,
            function (response) {}
          );
          bridgeObj.registerHandler("setNativescanqrcodeControl", function (
            responseData,
            responseCallback
          ) {
            setNativescanqrcodeControl(responseData);
          });
        });
      } else {
        window.Android.loadNativeQRCodeScannerUpload(JSON.stringify(appJSON));
      }
    }); // end of process before call
  } catch (err) {}
}

function setNativescanqrcodeControl(responseData) {
  try {
    if (responseData) {
      // Add Custome function Call here
      clientafterNativescanqrcode(responseData, function (pbcRes) {
        // handle client after call
      });
    }
  } catch (err) {}
}

function clientafterNativescanqrcode(response, callback) {
  if (response) {
    // Add Custome function Call here
    var barcode = response.data.split("&&");
    if (barcode != "") {
      var objParams = {};
      var recordID = barcode[0];
      objParams.isDelete = 0;
      var ajaXCallURL = $.trim($("#ajaXCallURL").val());
      objParams.tokenKey = getParameterByName("tokenKey");
      objParams.secretKey = getParameterByName("secretKey");
      objParams.offlineDataID = localStorage.getItem("offlineDataID");
      var merchantID = getParameterByName("merchantID");
      if (recordID == merchantID) {
        objParams.clientid = localStorage.getItem("userID");

        objParams.merchantid = recordID;

        var queryMode = getParameterByName("queryMode");
        // localStorage.setItem("eventID", recordID);
        objParams.callUrl =
          ajaXCallURL + "/milestone003/saveAjaxordersclientstampweb";
        objParams.recordID = recordID;
        $.ajax({
          url: objParams.callUrl,
          data: objParams,
          type: "POST",
          success: function (response) {
            if (response.status == 0) {
              $("#display_loading").addClass("hideme");
              shareAppData(
                "Congratulations! You have earned a stamp. Redeem Stamp from My Reward Points to get exciting offers.",
                "toast"
              );
              var objParams = {};
              //                        if (response.recordDetails && response.recordDetails[0]) {
              //                            $("#addstampcards28").trigger("click");
              //
              //                        } else {
              //                            shareAppData("Invalid QR Code.", "toast");
              //                        }
            } else {
              $("#display_loading").addClass("hideme");
              shareAppData(response.error, "toast");
            }
          },
          error: function (xhr, status, error) {
            $("#display_loading").addClass("hideme");
            shareAppData("Invalid QR Code.", "toast");
          },
        });
      } else {
        shareAppData("Invalid QR Code.", "toast");
      }

      //    return false;
    } else {
      shareAppData("Invalid QR Code.", "toast");
    }
  }
  console.log("last one");
}

function clientbeforeNativescanqrcode(appJSON, element, callback) {
  var response = appJSON;
  callback();
}

function loadNativesendinvitesControl(tokenKey, queryMode, secretKey, ajaXCallURL) {
  try {
    var appJSON = {};
    appJSON.tokenKey = tokenKey;
    appJSON.secretKey = secretKey;
    appJSON.queryMode = queryMode;
    appJSON.action = queryMode;
    appJSON.ajaXCallURL = ajaXCallURL;
    var AWSCredentials = localStorage.getItem("AWSCredentials");
    if (localStorage.IDENTITY_TOKEN) {
      var token = localStorage.IDENTITY_TOKEN;
      var playload = JSON.parse(atob(token.split(".")[1]));
      appJSON.Authorization = token;
      appJSON.Expiration = playload.exp;
    } else if (AWSCredentials) {
      AWSCredentials = JSON.parse(AWSCredentials);
      appJSON.accessKeyId = AWSCredentials.accessKeyId;
      appJSON.secretAccessKey = AWSCredentials.secretAccessKey;
      appJSON.sessionToken = AWSCredentials.sessionToken;
      appJSON.Expiration = AWSCredentials.Expiration;
    }
    var storeurl = localStorage.getItem("storeurl");
    var appuser = JSON.parse(localStorage.getItem("appUser"))
    var queryParams = queryStringToJSON();
    let url = `https://milestone.hokuapps.com/?pageName=app_discountdetails_5da73cac545050343288ce7a&bazaarid=${queryParams.bazaarid}&recordID=${queryParams.recordID}&applyFilter=${queryParams.applyFilter}&parent=${queryParams.parent}`;
    appJSON.title = "Message on Share Discount:";
    appJSON.msgText = `Hi, check this discount on MSTAR Application ${url}\n\n Don't have MSTAR Application.? Please use http://onelink.to/jabqrj to download it. \n\n Apply the referral code below during sign-up.\n ${appuser.userreferralcode}`;
  
    appJSON.organizationID = $('#organizationID').val();
    appJSON.userID = $('#userID').val();
    appJSON.appID = $('#appID').val();
    var element = element ? element : null;
  //   clientbeforeNativesendinvites(appJSON, element, function (pbcRes) {
      if (DEVICE_TYPE == 'ios') {
        setupWebViewJavascriptBridge(function (bridgeObj) {
          bridgeObj.callHandler('shareTextToApps', appJSON, function (response) {
          });
        });
      } else {
        window.Android.shareTextToApps(JSON.stringify(appJSON));
      }
  //   }); // end of process before call 
  } catch (err) {

  }
}

function clientbeforeNativesendinvites(appJSON, element, callback) {
  callback();
}