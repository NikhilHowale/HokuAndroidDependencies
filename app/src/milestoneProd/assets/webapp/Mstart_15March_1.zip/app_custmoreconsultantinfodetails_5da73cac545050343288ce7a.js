
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
	var recordID = localStorage.getItem('userID');
	if (recordID != '') {
		$('#display_loading').removeClass('hideme');
		var paramsEdit = {};
		paramsEdit.recordID = recordID;
		getRecordByIdUsermanagement5da73cac545050343288ce7a(paramsEdit);
	}
	$('#recordID').val(getParameterByName('recordID'));
	var queryMode = getParameterByName('queryMode');
	var authKey = $('#authKey').val();
	var appID = $('#hdnAppID').val();
	if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
		$("#headerPageName").html(localStorage.getItem("headerPageName"))
	}

	var objParamsToken = {};
	var ajaXCallURL = $.trim($('#ajaXCallURL').val());
	objParamsToken.tokenKey = getParameterByName('tokenKey');
	objParamsToken.secretKey = getParameterByName('secretKey');

	var userRole = $('#userRole').val();
	var userID = $('#userID').val();
	var createrOfRecord = $('#createrOfRecord').val();
	var queryMode = getParameterByName('queryMode');
	var recordID = $.trim($('#recordID').val());
	var addSessionComments = [];
	$(document).on('click', '#logout44', function (e) {
		try {
			var element = $(this);
			var objParams = {};
			objParams.recordID = getParameterByName('recordID');
			if ($(this).attr('recordID')) {
				objParams.recordID = $(this).attr('recordID');
			}

			customcodeLogout(objParams, element, {}, function (processCustomcode) {
				return false;
			});
		} catch (error) {
			console.log('Error in customcode click', error);
		}
	});
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#myfinancialcalculator6', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_retirementcalculateadd';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "add";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - myfinancialcalculator6", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext17', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_retirementcalculateadd';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "add";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext17", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#sg2622', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_myupcomingeventslist';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - myevents9", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext210', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_myupcomingeventslist';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext210", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#sg8622', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_allvoucherlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - myvouchers12", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext413', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_allvoucherlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext413", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#sg4722', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_rewardsdetails';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "update";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - mymembership15", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext516', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_rewardsdetails';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "update";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext516", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#sg0822', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_merchantlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - merchants18", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext619', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_merchantlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext619", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#sg682299', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_allofferlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - stampcardsoffers21", error)
		}
	});


	$(document).on('click', '#sg68224', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_promotioncardlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - merchants18", error)
		}
	});

	$(document).on('click', '#promotioniconnext722', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_promotioncardlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - merchants18", error)
		}
	});

	$(document).on('click', '#sg6822', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_mystampcardlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - mystampcards21", error)
		}
	})

	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext722', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_allofferlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext722", error)
		}
	});

	$(document).on('click', '#mystampiconnext722', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_mystampcardlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - mystampiconnext722", error)
		}
	})

	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#sg2922', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_referafrienddetails';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "update";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - referafriend24", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext825', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_referafrienddetails';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "update";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext825", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#sg8922', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_customernotificationlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			queryParams["applyFilter"] = false;
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - notifications27", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext928', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_customernotificationlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext928", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#sg4032', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_contactuslisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - contactsupport30", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext1031', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_contactuslisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext1031", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#sg0132', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_customeraboutapplisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - aboutapp33", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext1134', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_customeraboutapplisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext1134", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#sg6132', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_clientprofile';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - profile36", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext1237', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_clientprofile';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext1237", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#sg2232', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_appointmentslisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - myappointnments39", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext1340', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_appointmentslisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext1340", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#mystampcards42', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_mystampcardlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - mystampcards42", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext1443', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_mystampcardlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext1443", error)
		}
	})
	var paramsEdit = {};
	paramsEdit.tokenKey = getParameterByName('tokenKey');
	paramsEdit.secretKey = getParameterByName('secretKey')
	getRecordByIDProcessBeforeCall722377(paramsEdit, function (processBeforeRes) {
		$.ajax({
			url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_custmoreinfodetails_Bazaar5da73cac545050343288ce7a',
			data: paramsEdit,
			type: 'POST',
			jsonpCallback: 'callback',
			success: function (response) {
				getRecordByIDProcessAfterCall722377(response, function (processBeforeRes) {
					if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
						var objParamsList = {};
						var queryMode = $('#queryMode').val();
						objParamsList.queryMode = queryMode;;
						var tokenKey = $('#tokenKey').val();;
						objParamsList.tokenKey = tokenKey;;
						if (!$('#aboutapp33').html()) {
							$('#aboutapp33').append(response.recordDetails.undefined);
						}
						if (!$('#bottommenu45').html()) {
							$('#bottommenu45').append(response.recordDetails.undefined);
						}
						if (!$('#contactsupport30').html()) {
							$('#contactsupport30').append(response.recordDetails.undefined);
						}
						var url = 'icon_next1.png'
						$('#iconnext17').attr("src", url);
						var url = 'icon_next10.png'
						$('#iconnext1031').attr("src", url);
						var url = 'icon_next11.png'
						$('#iconnext1134').attr("src", url);
						var url = 'icon_next12.png'
						$('#iconnext1237').attr("src", url);
						var url = 'icon_next13.png'
						$('#iconnext1340').attr("src", url);
						var url = 'icon_next14.png'
						$('#iconnext1443').attr("src", url);
						var url = 'icon_next2.png'
						$('#iconnext210').attr("src", url);
						var url = 'icon_next4.png'
						$('#iconnext413').attr("src", url);
						var url = 'icon_next5.png'
						$('#iconnext516').attr("src", url);
						var url = 'icon_next6.png'
						$('#iconnext619').attr("src", url);
						var url = 'icon_next7.png'
						$('#iconnext722').attr("src", url);
						var url = 'icon_next8.png'
						$('#iconnext825').attr("src", url);
						var url = 'icon_next9.png'
						$('#iconnext928').attr("src", url);
						if (!$('#merchants18').html()) {
							$('#merchants18').append(response.recordDetails.undefined);
						}
						if (!$('#more1').html()) {
							$('#more1').append(response.recordDetails.undefined);
						}
						if (!$('#myappointnments39').html()) {
							$('#myappointnments39').append(response.recordDetails.undefined);
						}
						if (!$('#myevents9').html()) {
							$('#myevents9').append(response.recordDetails.undefined);
						}
						if (!$('#myfinancialcalculator6').html()) {
							$('#myfinancialcalculator6').append(response.recordDetails.undefined);
						}
						if (!$('#mymembership15').html()) {
							$('#mymembership15').append(response.recordDetails.undefined);
						}
						if (!$('#mystampcards42').html()) {
							$('#mystampcards42').append(response.recordDetails.undefined);
						}
						if (!$('#myvouchers12').html()) {
							$('#myvouchers12').append(response.recordDetails.undefined);
						}
						if (!$('#notifications27').html()) {
							$('#notifications27').append(response.recordDetails.undefined);
						}
						if (!$('#profile36').html()) {
							$('#profile36').append(response.recordDetails.undefined);
						}
						if (!$('#referafriend24').html()) {
							$('#referafriend24').append(response.recordDetails.undefined);
						}
						if (!$('#stampcardsoffers21').html()) {
							$('#stampcardsoffers21').append(response.recordDetails.undefined);
						}

						Materialize.updateTextFields();
						$('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

					}
				}); // end of getRecord By ID
			},
			error: function (xhr, status, error) {
				handleError(xhr, status, error);
			},
		});
	}); // end of getRecord By ID



	$(document).on('click', '#groupchatwithconsutlatnt44', function (e) {
		try {
		  var appJSON = {};
		  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
	
		  appJSON.tokenKey = getParameterByName('tokenKey');;
		  appJSON.secretKey = getParameterByName('secretKey');
		  appJSON.queryMode = "mylist";
		  appJSON.action = "mylist";;
		  appJSON.ajaXCallURL = ajaXCallURL;
		  appJSON.organizationID = $('#organizationID').val();
		  appJSON.appID = $('#appID').val();
	
		  //var userid = getParameterByName('usermanagementid');
		  var userid = localStorage.getItem("selectedClient");
	
		  // if (menuID != "groupchat") {
		  appJSON.userID = userid;
		  appJSON.recordID = userid;
	
		  //  }
		  appJSON.chatTabType = 10;
	
		  if (DEVICE_TYPE == 'ios') {
			setupWebViewJavascriptBridge(function (bridgeObj) {
			  bridgeObj.callHandler('loadNativeChatIndivisualWindow', appJSON, function (response) { });
			});
		  } else {
			window.Android.loadNativeChatIndivisualWindow(JSON.stringify(appJSON));
		  }
	
		} catch (err) {
	
		}
	  })


	showBottomMenu();
});//end of ready
function customcodeLogout(objParams, element, response, callback) {
	try {
		var queryMode = 'add';
		var ajaXCallURL = getParameterByName('ajaXCallURL');
		var tokenKey = getParameterByName('tokenKey');
		var secretKey = getParameterByName('secretKey');
		logoutNativeCall(tokenKey, queryMode, secretKey, ajaXCallURL);
		return false;
		callback();
	} catch (err) {
		callback();
		// console.log('Error in customcode', err);
	}
}
function getRecordByIDProcessBeforeCall722377(paramsType, callback) {
	var response = paramsType;

	if (getParameterByName('bazaarid') && getParameterByName('bazaarid') != 'undefined') { paramsType.recordID = getParameterByName('bazaarid') } else if (getParameterByName('recordID') && getParameterByName('recordID') != 'undefined') { paramsType.recordID = getParameterByName('recordID') }; callback();
}
function getRecordByIDProcessAfterCall722377(response, callback) {
	callback();
}
function showBottomMenu() {
	var appUser = JSON.parse(localStorage.getItem("appUser"));
	var notificationCount = 0
	if (appUser.notificationunreadcount) {
		notificationCount = appUser.notificationunreadcount
	}
	var appointmentunreadcount = 0
	if (appUser.appointmentunreadcount) {
		appointmentunreadcount = appUser.appointmentunreadcount
	}
	var menuObj = localStorage.getItem('objGetUserDetailsWithmenu');
	if (menuObj) {
		menuObj = JSON.parse(menuObj);
		if (menuObj.data && menuObj.data.roleName) {
			var roleName = menuObj.data.roleName;
		}
	}
	try {
		var bottommenu = '';
		bottommenu += '<div class="mobilebottommenu">'
		bottommenu += '    <div class="row">'
		bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Home" fileName="app_userhome_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_home.svg"><span>Home</span></a></div>'
		bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Appointment" fileName="app_alleventpromotionslist_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_calendar.svg"><span>Discover</span></a></a><div id="appointmentCount" class="chatunreadcount active hide">' + appointmentunreadcount + '</div></div>'
		bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Scan" fileName="app_sacaner_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_barcode.svg"><span>Scan</span></a></div>'
		bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Chat" fileName="undefined_5da73cac545050343288ce7a.html"  queryMode="mylist"  href="javascript:void(0);"><img src="icon_chat.svg"><span>Chat</span></a><div id="chatCount" style="display:none !important"  class="chatunreadcount active">0</div></div>'
		bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="More" fileName="app_custmoreinfodetails_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_moreactive.svg"><span>More</span></a></div>'
		bottommenu += '    </div>'
		bottommenu += '</div>'
		$('#bottommenu45').html(bottommenu)
	} catch (err) {
		// console.log('Error in showBottomMenu', err);
	}
}






function getRecordByIDProcessBeforeCallusermanagement(paramsType, callback) {
	callback();
}
function getRecordByIDProcessAfterCallusermanagement(response, callback) {
	callback();
}
function getRecordByIdUsermanagement5da73cac545050343288ce7a(paramsEdit) {
	var ajaXCallURL = $('#ajaXCallURL').val();
	getRecordByIDProcessBeforeCallusermanagement(paramsEdit, function (processBeforeRes) {
		paramsEdit.tokenKey = getParameterByName('tokenKey');
		paramsEdit.secretKey = getParameterByName('secretKey');
		// var isMobile = $('#isMobile').val();
		$.ajax({
			url: ajaXCallURL + '/milestone003/get_data_by_record_Usermanagement5da73cac545050343288ce7aapp_clientprofile',
			data: paramsEdit,
			type: 'POST',
			jsonpCallback: 'callback',
			success: function (response) {
				$('#display_loading').addClass('hideme');
				if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
					var objParamsList = {};
					objParamsList.queryMode = queryMode;
					var tokenKey = getParameterByName('tokenKey');
					objParamsList.tokenKey = tokenKey;
					objParamsList.isMobile = isMobile;
					var tempobj = response.recordDetails[0];
					response.recordDetails = tempobj;
					getRecordByIDProcessAfterCallusermanagement(response.recordDetails, function (processBeforeRes) {
						if (response.recordDetails.consultantname != undefined) $('#username14').html(response.recordDetails.consultantname);
						if (response.recordDetails.consultantemail != undefined) $('#EmailAddress140').html('<a style="color: rgb(175, 147, 93)" href="mailto:' + response.recordDetails.consultantemail + '">' + response.recordDetails.consultantemail + '</a>');
						if (response.recordDetails.consultatntcontactnumber != undefined) $('#Contactno141').html('<a style="color: rgb(175, 147, 93)" href="tel:' + response.recordDetails.consultatntcontactnumber + '">' + response.recordDetails.consultatntcontactnumber + '</a>');
						// if(response.recordDetails.password != undefined) $('#password16').val(response.recordDetails.password);
						if (response.recordDetails.consultantphotoupload && response.recordDetails.consultantphotoupload[0] && response.recordDetails.consultantphotoupload[0].mediaID) {
							var url = CDN_PATH + response.recordDetails.consultantphotoupload[0].mediaID + '_compressed.png';
						} else {
							var url = 'image_logo.png';
						}
						response.recordDetails.earnedpoints = response.recordDetails.earnedpoints || 0;
						if (response.recordDetails.earnedpoints != undefined) {
							$('#earnpoints15').html(`<span class="earnpointspan">${response.recordDetails.earnedpoints}</span> Available Reward Points`);
						}
						$('#userphotoupload8').attr('src', url).attr('onerror', "this.src='https://appscdn-us.hokuapps.com/card.png'");
						if (response.recordDetails.offlineDataID) {
							localStorage.setItem('offlineDataID', response.recordDetails.offlineDataID);
						}
						if (response.recordDetails.consultantid) {

						localStorage.setItem("selectedClient", response.recordDetails.consultantid)
						}
					}); // end of process after call
					$('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

					Materialize.updateTextFields();
				}
			},
			error: function (xhr, status, error) { },
		});
	}); // end of getRecord By ID
}



$(document).on('click', '#backbutton1', function (e) {
	try {
		var element = $(this);
		var nextPage = 'app_custmoreinfodetails';
		var queryParams = queryStringToJSON();
		queryParams["queryMode"] = "update";
		var recordID = $(this).attr("recordID");
		if (recordID) {
			queryParams["recordID"] = recordID;
		}
		var queryString = $.param(queryParams);
		queryString = queryString.replace(/\+/g, "%20");
		queryString = decodeURIComponent(queryString);
		window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
		return false;
	} catch (error) {
		console.log("Error in pageredirect workflow - backbutton1", error)
	}
})
