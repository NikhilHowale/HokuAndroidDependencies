
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"))
    }

    var objParamsToken = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsToken.tokenKey = getParameterByName('tokenKey');
    objParamsToken.secretKey = getParameterByName('secretKey');

    var userRole = $('#userRole').val();
    var userID = $('#userID').val();
    var createrOfRecord = $('#createrOfRecord').val();
    var queryMode = getParameterByName('queryMode');
    var recordID = $.trim($('#recordID').val());
    var addSessionComments = [];
    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#backbutton1', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_consultantclientlisting';
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "mylist";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - backbutton1", error)
        }
    })
    $(document).on('click', '#backbutton1', function (e) {
        window.history.back();
        return false;
    })
    $(document).on('click', '#chat3', function (e) {
        try {
            var appJSON = {};
            var ajaXCallURL = $.trim($('#ajaXCallURL').val());

            appJSON.tokenKey = getParameterByName('tokenKey');;
            appJSON.secretKey = getParameterByName('secretKey');
            appJSON.queryMode = "mylist";
            appJSON.action = "mylist";;
            appJSON.ajaXCallURL = ajaXCallURL;
            appJSON.organizationID = $('#organizationID').val();
            appJSON.appID = $('#appID').val();

            var userid = getParameterByName('usermanagementid');


            // if (menuID != "groupchat") {
            appJSON.userID = userid;
            appJSON.recordID = userid;

            //  }
            appJSON.chatTabType = 10;

            if (DEVICE_TYPE == 'ios') {
                setupWebViewJavascriptBridge(function (bridgeObj) {
                    bridgeObj.callHandler('loadNativeChatIndivisualWindow', appJSON, function (response) { });
                });
            } else {
                window.Android.loadNativeChatIndivisualWindow(JSON.stringify(appJSON));
            }

        } catch (err) {

        }
    })

    var paramsEdit = {};
    paramsEdit.tokenKey = getParameterByName('tokenKey');
    paramsEdit.secretKey = getParameterByName('secretKey');

    var roleName = localStorage.getItem('roleName');
    if (roleName == "customer") {
        $(".referredbycls").addClass('hide');
    }

    getRecordByIDProcessBeforeCall459953(paramsEdit, function (processBeforeRes) {
        $.ajax({
            url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_consultantclientdetails_Usermanagement5da73cac545050343288ce7a',
            data: paramsEdit,
            type: 'POST',
            jsonpCallback: 'callback',
            success: function (response) {
                getRecordByIDProcessAfterCall459953(response, function (processBeforeRes) {
                    if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                        var objParamsList = {};
                        var queryMode = $('#queryMode').val();
                        objParamsList.queryMode = queryMode;;
                        var tokenKey = $('#tokenKey').val();;
                        objParamsList.tokenKey = tokenKey;;
                        if (!$('#accumalatedpoints15').html()) {
                            $('#accumalatedpoints15').append(response.recordDetails.undefined);
                        }
                        if (!$('#backbutton1').html()) {
                            $('#backbutton1').append(response.recordDetails.undefined);
                        }
                        if (!$('#chat3').html()) {
                            $('#chat3').append(response.recordDetails.undefined);
                        }
                        if (!$('#clientdetails2').html()) {
                            $('#clientdetails2').append(response.recordDetails.undefined);
                        }
                        if (!$('#contact13').html()) {
                            $('#contact13').append(response.recordDetails.undefined);
                        }
                        if (!$('#dateofbirth17').html()) {
                            $('#dateofbirth17').append(response.recordDetails.undefined);
                        }
                        if (response.recordDetails.referedby && response.recordDetails.referedby !== undefined) {
                            $('#referredby18').append(response.recordDetails.referedby);
                        } else {
                            $('.referredbycls').hide();
                        }
                        $('#accumalatedpoints16').html(response.recordDetails.accumalatedpoints);
                        $('#contactnumber14').html(response.recordDetails.contactnumber);
                        $('#dateofbirth18').html(response.recordDetails.dateofbirth);
                        $('#name12').html(response.recordDetails.name);
                        $('#email').html(response.recordDetails.email);
                        $('#membershiptype').html(response.recordDetails.membership ? response.recordDetails.membership + " Customer" : '');
                        $('#customertype').html(response.recordDetails.customertype);
                        if (response.recordDetails.customertype && response.recordDetails.customertype == 'Referred Customer') {
                            $('#sg907904').removeClass('hide');
                            $('#referredby').html(response.recordDetails.referredby);
                        }
                        if (!$('#name11').html()) {
                            $('#name11').append(response.recordDetails.undefined);
                        }
                        if (!$('#name9').html()) {
                            $('#name9').append(response.recordDetails.name);
                        }
                        // getrecordbycustomquery - Stage - 111111111111
                        if (response.recordDetails['userphotoupload'] && response.recordDetails['userphotoupload'].length > 0) {
                            if (response.recordDetails['userphotoupload'][0].displayType = 'html') {
                                var eleParent = $('#userphotoupload8').parent();
                                for (var key in response.recordDetails['userphotoupload']) {
                                    var objImage = response.recordDetails['userphotoupload'][key];
                                    if (response.recordDetails['userphotoupload'][key].name == 'Audio') {
                                        var token = $('#tokenKey').val();
                                        if (token && token != '') {
                                            token = $('#tokenKey').val();
                                        } else {
                                            token = getParameterByName('tokenKey');
                                        }
                                        var mediaIDa = response.recordDetails['userphotoupload'][0].mediaID
                                        var filenamea = response.recordDetails['userphotoupload'][0].fileName
                                        var CDN_PATH2 = 'https://devfiles.hokuapps.com/downloadOriginal?f=' + mediaIDa + '&fn=' + filenamea + '&t=' + token
                                        var url = CDN_PATH2
                                    } else {
                                        var filetodisplay = getuploadedfilepreview(objImage.fileNm);
                                        if (filetodisplay && filetodisplay != objImage.fileNm) {
                                            var url = filetodisplay;
                                        } else {
                                            var url = CDN_PATH + objImage.mediaID + '_compressed.png';
                                        }
                                    }
                                    if (response.recordDetails['userphotoupload'][key].name == 'Audio') {
                                        var html = '';
                                        html += '<div class="col s12" style="float: right;">'
                                        html += '<audio class="" src="' + url + '" controls></audio>'
                                        html += '</div>'
                                    } else {
                                        var html = '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + url + '" />';
                                    }
                                    if (!key || key == '0') {
                                        eleParent.html(html);
                                    } else {
                                        eleParent.append(html);
                                    }
                                }
                            } else {
                                if (response.recordDetails['userphotoupload'][key].name == 'Audio') {
                                    var url = CDN_PATH + response.recordDetails['userphotoupload'][0].mediaID;
                                } else {
                                    var url = CDN_PATH + response.recordDetails['userphotoupload'][0].mediaID + '_compressed.png';
                                }
                                $('#userphotoupload8').attr("src", url);
                            }
                        }

                        Materialize.updateTextFields();
                        $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

                    }
                }); // end of getRecord By ID
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            },
        });
    }); // end of getRecord By ID
    $(document).on('click', '#email', function () {
        var email = $('#email').html();
        if (email)
            window.location.href = "mailto:" + email;
    });
    $(document).on('click', '#contactnumber14', function () {
        var contactNumber = $('#contactnumber14').html();
        if (contactNumber)
            window.location.href = "tel:" + contactNumber;
    });


});//end of ready 
function getRecordByIDProcessBeforeCall459953(paramsType, callback) {
    var response = paramsType;

    if (getParameterByName('usermanagementid') && getParameterByName('usermanagementid') != 'undefined') { paramsType.recordID = getParameterByName('usermanagementid') } else if (getParameterByName('recordID') && getParameterByName('recordID') != 'undefined') { paramsType.recordID = getParameterByName('recordID') }; callback();
}
function getRecordByIDProcessAfterCall459953(response, callback) {
    callback();
}
