
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
	$(document).on('click', '#add3', function(e) {
		try {
			e.preventDefault();
			var objParams = {};
			var element = $(this);
			objParams.recordID = getParameterByName('recordID');
			if ($(this).attr('recordID')) {
				objParams.recordID = $(this).attr('recordID');
			}
		
			objParams.quantity = 1;
			if ($(this).val()) {
				objParams.quantity = $(this).val();
			} else if($('input[name=quantity]').val()){
				objParams.quantity = $('input[name=quantity]').val();
			}
			addtocartv2Cartitems5da73cac545050343288ce7aadd3(objParams, element);
			return false;
		} catch (error) {
			console.log('Error in addtocart click', error);
		}
	});
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_productpickertopitemslisting'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
});//end of ready
	function addtocartv2Cartitems5da73cac545050343288ce7aadd3(objParams, element) {
		try {
			objParams.userId = localStorage.getItem('userID');
			var ajaXCallURL = $.trim($('#ajaXCallURL').val());
			objParams.tokenKey = getParameterByName('tokenKey');
			objParams.secretKey = getParameterByName('secretKey');
		objParams.updatequantity = true;
			var callUrl = ajaXCallURL + '/milestone003/addtocartv2_Cartitems5da73cac545050343288ce7a_app_productpickeradd';
			$('#display_loading').removeClass('hideme');
 			addToCartV2ProcessBeforeCallCartitems5da73cac545050343288ce7aAdd(element, objParams, function(){
			$.ajax({
				url: callUrl,
				data: objParams,
				type: 'POST',
				success: function (response) {
					$('#display_loading').addClass('hideme');
 					addToCartV2ProcessAfterCallCartitems5da73cac545050343288ce7aAdd(response, function(){
					if (response.status == 0) {
						if(response.carttotal){
						    response.carttotal = Math.round(response.carttotal * 100) / 100
						}
					    if(objParams.quantity == 0){ // remove div no record found
					        $('[recordID="'+ objParams.recordID +'"]').closest('.plain-card').remove()
					    }
					    if(response.cartcount && $('#cartcountid').length){ 
					    	$('#cartcountid').html(response.cartcount); 
					    } else if(response.cartcount && $('.clsshowcartcount').length){ 
						    var cls = 'clscartcount1';
						    if(response.cartcount > 9 ) { cls = 'clscartcount2';}
						    $('.clsshowcartcount').append('<span id="cartcountid" class="'+ cls +'">'+ response.cartcount +'</span>');
						    $('#cartcountid').on('click', function(){ $('#cartcountid').parent().find('img').trigger('click'); })
					    }
	
  var tokenKey = getParameterByName('tokenKey');
 var secretKey = getParameterByName('secretKey');
 var queryMode = getParameterByName('queryMode');
  window.location.href = 'app_productpickerlist_5da73cac545050343288ce7a.html?queryMode='+ queryMode+'&tokenKey='+tokenKey+ '&secretKey=' + secretKey
	
						return;
					} else {
 	var quantityTotal = $('#'+objParams.recordID+'_quantity').val();
 	if(quantityTotal){
		quantityTotal =  parseInt(quantityTotal)-1;
		$('#'+objParams.recordID+'_quantity').val(quantityTotal);
 	}else {
		$('#'+objParams.recordID+'_quantity').val(1);
 	}
						var errorMessage = '';
						if( response.error &&  response.error.trim() != ''){
							errorMessage = response.error;
						}
						if(errorMessage){
							shareAppData(errorMessage, 'toast');
						}
						return;
					 }
					}); //close client after call
				},
				error: function (xhr, status, error) {
					$('#display_loading').addClass('hideme');
				},
			});
			}); // close precessbeforecall
		} catch (error) {
			$('#display_loading').addClass('hideme');
			console.log('Error in addtocartv2_fieldname', error);
		}
	} 
 function addToCartV2ProcessBeforeCallCartitems5da73cac545050343288ce7aAdd(element, objParams, callback) { 	var response = objParams;
objParams.quantity = $("input[id^=productqty]").val();
if(!objParams.quantity || objParams.quantity == ''){
   $('.error_message').show();$('#display_loading').addClass('hideme');
   return false;
}
objParams.byinput = 1;
objParams.updatequantity = true;
objParams.userId = localStorage.userID;
callback(); 
 } 
 function addToCartV2ProcessAfterCallCartitems5da73cac545050343288ce7aAdd(response, callback) {
 callback(); 
 }