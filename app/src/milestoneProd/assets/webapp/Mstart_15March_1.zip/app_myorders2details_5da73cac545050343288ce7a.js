
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorderdetails'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "update"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
      var paramsEdit = {};
      paramsEdit.tokenKey = getParameterByName('tokenKey');
      paramsEdit.secretKey = getParameterByName('secretKey') 
                       getRecordByIDProcessBeforeCall297339(paramsEdit, function (processBeforeRes) {
      $.ajax({
          url: ajaXCallURL+'/milestone003/getRecordByCustomeQuery_app_myorders2details_Orders5da73cac545050343288ce7a',
          data: paramsEdit,
          type: 'POST',
          jsonpCallback: 'callback',
          success: function (response) { 
                       getRecordByIDProcessAfterCall297339(response, function (processBeforeRes) {
              if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                  var objParamsList = {};
                  var queryMode = $('#queryMode').val(); 
                  objParamsList.queryMode = queryMode;;
                  var tokenKey = $('#tokenKey').val();;
                  objParamsList.tokenKey = tokenKey;;
  if(!$('#backbutton1').html()){
            $('#backbutton1').append(response.recordDetails.undefined);
 }
  if(!$('#billingsummary32').html()){
            $('#billingsummary32').append(response.recordDetails.undefined);
 }
  if(!$('#deliverydetails49').html()){
            $('#deliverydetails49').append(response.recordDetails.undefined);
 }
  if(!$('#deliverystatus63').html()){
            $('#deliverystatus63').append(response.recordDetails.undefined);
 }
  if(!$('#drivercontact54').html()){
            $('#drivercontact54').append(response.recordDetails.undefined);
 }
  if(!$('#drivername51').html()){
            $('#drivername51').append(response.recordDetails.undefined);
 }
  if(!$('#estimateddeliverydate21').html()){
            $('#estimateddeliverydate21').append(response.recordDetails.undefined);
 }
  if(!$('#estimateddeliverytime24').html()){
            $('#estimateddeliverytime24').append(response.recordDetails.undefined);
 }
  if(!$('#handling38').html()){
            $('#handling38').append(response.recordDetails.undefined);
 }
  if(!$('#labourcharges40').html()){
            $('#labourcharges40').append(response.recordDetails.undefined);
 }
  if(!$('#orderdate9').html()){
            $('#orderdate9').append(response.recordDetails.undefined);
 }
  if(!$('#orderdetails2').html()){
            $('#orderdetails2').append(response.recordDetails.undefined);
 }
  if(!$('#orderid12').html()){
            $('#orderid12').append(response.recordDetails.undefined);
 }
  if(!$('#orderstatus18').html()){
            $('#orderstatus18').append(response.recordDetails.undefined);
 }
  if(!$('#ordersummary7').html()){
            $('#ordersummary7').append(response.recordDetails.undefined);
 }
  if(!$('#ordertotal15').html()){
            $('#ordertotal15').append(response.recordDetails.undefined);
 }
  if(!$('#addressstring30').html()){
            $('#addressstring30').append(response.recordDetails.addressstring);
 }
  if(!$('#contactnumber55').html()){
            $('#contactnumber55').append('<a id="contactnumberImg" class="tellink" href="tel:'+ response.recordDetails.contactnumber+'">'+ response.recordDetails.contactnumber+'</a>');
 }
 response.recordDetails['createdOn_preserved'] = response.recordDetails['createdOn'] ;
 response.recordDetails['createdOn'] = response.recordDetails['createdOn']  ? moment(new Date(response.recordDetails['createdOn'])).format('DD MMM YYYY') : '';
  if(!$('#createdOn10').html()){
            $('#createdOn10').append(response.recordDetails.createdOn);
 }
 response.recordDetails['createdOn'] =  response.recordDetails['createdOn_preserved'];
  if(!$('#driverid_name52').html()){
            $('#driverid_name52').append(response.recordDetails.driverid_name);
 }
  if(!$('#fullname58').html()){
            $('#fullname58').append(response.recordDetails.fullname);
 }
              response.recordDetails.handlingcost = getCurrancy(response.recordDetails.handlingcost, 'USD','$'); 
  if(!$('#handlingcost39').html()){
            $('#handlingcost39').append(response.recordDetails.handlingcost);
 }
              response.recordDetails.labourcharges = getCurrancy(response.recordDetails.labourcharges, 'USD','$'); 
  if(!$('#labourcharges41').html()){
            $('#labourcharges41').append(response.recordDetails.labourcharges);
 }
  if(!$('#mobilenumber61').html()){
            $('#mobilenumber61').append('<a id="mobilenumberImg" class="tellink" href="tel:'+ response.recordDetails.mobilenumber+'">'+ response.recordDetails.mobilenumber+'</a>');
 }
  if(!$('#name29').html()){
            $('#name29').append(response.recordDetails.name);
 }
  if(!$('#ordersnumber13').html()){
            if(!response.recordDetails.ordersnumber){
            	response.recordDetails.ordersnumber = '0';
            }
            $('#ordersnumber13').append(response.recordDetails.ordersnumber);
 }
              response.recordDetails.productprice = getCurrancy(response.recordDetails.productprice, 'USD','$'); 
  if(!$('#productprice35').html()){
            $('#productprice35').append(response.recordDetails.productprice);
 }
 response.recordDetails['slotdate_preserved'] = response.recordDetails['slotdate'] ;
 response.recordDetails['slotdate'] = response.recordDetails['slotdate']  ? moment(new Date(response.recordDetails['slotdate'])).format('DD MMM YYYY') : '';
  if(!$('#slotdate22').html()){
            $('#slotdate22').append(response.recordDetails.slotdate);
 }
 response.recordDetails['slotdate'] =  response.recordDetails['slotdate_preserved'];
  if(!$('#starttime25').html()){
            $('#starttime25').append(response.recordDetails.starttime);
 }
  if(!$('#status19').html()){
            $('#status19').append(response.recordDetails.status);
 }
  if(!$('#status64').html()){
            $('#status64').append(response.recordDetails.status);
 }
              response.recordDetails.subtotal = getCurrancy(response.recordDetails.subtotal, 'USD','$'); 
  if(!$('#subtotal43').html()){
            $('#subtotal43').append(response.recordDetails.subtotal);
 }
              response.recordDetails.taxes = getCurrancy(response.recordDetails.taxes, 'USD','$'); 
  if(!$('#taxes45').html()){
            $('#taxes45').append(response.recordDetails.taxes);
 }
              response.recordDetails.totalamount = getCurrancy(response.recordDetails.totalamount, 'USD','$'); 
  if(!$('#totalamount16').html()){
            $('#totalamount16').append(response.recordDetails.totalamount);
 }
              response.recordDetails.totalamount = getCurrancy(response.recordDetails.totalamount, 'USD','$'); 
  if(!$('#totalamount47').html()){
            $('#totalamount47').append(response.recordDetails.totalamount);
 }
              response.recordDetails.transportationcost = getCurrancy(response.recordDetails.transportationcost, 'USD','$'); 
  if(!$('#transportationcost37').html()){
            $('#transportationcost37').append(response.recordDetails.transportationcost);
 }
  if(!$('#price34').html()){
            $('#price34').append(response.recordDetails.undefined);
 }
  if(!$('#receivercontact60').html()){
            $('#receivercontact60').append(response.recordDetails.undefined);
 }
  if(!$('#receivername57').html()){
            $('#receivername57').append(response.recordDetails.undefined);
 }
  if(!$('#shippingaddress27').html()){
            $('#shippingaddress27').append(response.recordDetails.undefined);
 }
  if(!$('#subtotal42').html()){
            $('#subtotal42').append(response.recordDetails.undefined);
 }
  if(!$('#taxes44').html()){
            $('#taxes44').append(response.recordDetails.undefined);
 }
  if(!$('#totalamount46').html()){
            $('#totalamount46').append(response.recordDetails.undefined);
 }
  if(!$('#transportation36').html()){
            $('#transportation36').append(response.recordDetails.undefined);
 }

              Materialize.updateTextFields();
                $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);
  
              } 
              }); // end of getRecord By ID
          },
          error: function (xhr, status, error) {
              handleError(xhr, status, error); 
          },
      }); 
              }); // end of getRecord By ID
   
});//end of ready 
                 function getRecordByIDProcessBeforeCall297339(paramsType,callback) { 
                 var response = paramsType;
 
if(getParameterByName('ordersid') && getParameterByName('ordersid') != 'undefined'){paramsType.recordID = getParameterByName('ordersid')} else if(getParameterByName('recordID') && getParameterByName('recordID') != 'undefined'){paramsType.recordID = getParameterByName('recordID')};callback(); 
                 } 
                 function getRecordByIDProcessAfterCall297339(response,callback) {
 callback(); 
                 }