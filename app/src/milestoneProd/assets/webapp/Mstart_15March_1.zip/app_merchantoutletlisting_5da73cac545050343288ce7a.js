
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
     var totaldcard_leftimage_collectioncontainer = 0;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];


  var queryMode = getParameterByName('queryMode');
      var isMobile = $('#isMobile').val();
      var isiPad = $('#isiPad').val();
      if(queryMode != ''){
          var tokenKey = $('#tokenKey').val();
          var objParamsList = {};
          objParamsList.queryMode = queryMode;
          var ajaXCallURL = $.trim($('#ajaXCallURL').val());
          objParamsList.tokenKey = getParameterByName('tokenKey');
          objParamsList.secretKey = getParameterByName('secretKey');
          objParamsList.ajaXCallURL = ajaXCallURL;
          objParamsList.isMobile = isMobile;
          objParamsList.isiPad = isiPad;
          objParamsList.applyFilter = false;
          getDataProcessBeforeCalldcard_leftimage_collectioncontainerBazaar5da73cac545050343288ce7a(objParamsList,function(processBeforeRes){
 var  applyFilter = getParameterByName('applyFilter');
 if(applyFilter == null && objParamsList.applyFilter == false ){
 objParamsList.type =  'merchantoutlets';
    objParamsList.applystaticfilter = true;
 }
 if(getParameterByName('bazaarid') && getParameterByName('bazaarid') != '' && getParameterByName('bazaarid') != null  && getParameterByName('bazaarid') != 'undefined' ){
 objParamsList.merchantid =  getParameterByName('bazaarid');
 }
          var dcard_leftimage_collectioncontainerapp_merchantoutletlisting = localStorage.getItem('dcard_leftimage_collectioncontainerapp_merchantoutletlisting');
          var  applyFilter = getParameterByName('applyFilter');
          $('#display_loading').removeClass('hideme');
        //  if (dcard_leftimage_collectioncontainerapp_merchantoutletlisting && applyFilter != 'true' ) {
           //   response = JSON.parse(dcard_leftimage_collectioncontainerapp_merchantoutletlisting);
            //  $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html('');
            //  getdcard_leftimage_collectioncontainerapp_merchantoutletlistingMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
            //  dcard_leftimage_collectioncontainerapp_merchantoutletlistingSync(response.timestamp);   
         // } else {
         show_dcard_leftimage_collectioncontainerapp_merchantoutletlisting_Details(objParamsList)
         // }
          });//End of get data process before call.
  }
 $(document).on('click', '.dcard_leftimage_collectioncontainer', function () {
   if(dcardLoaded && !dcardLoaded['dcard_leftimage_collectioncontainer']) { return false;}; // added for use should not able to click until data loaded
   
  if(localStorage.getItem('activeMenu') != "More" || localStorage.getItem('isFromStampCard') != 'true')
    localStorage.setItem("headerPageName", 'app_merchantdetails') ;
  else
    localStorage.setItem("headerPageName", 'app_offerdetails') ;
   
  var recordID =  $(this).attr('recordID');// get record ID;
   var bazaarid =  $(this).attr('recordID');// get record ID;
   var merchantID =  getParameterByName('recordID');// get record ID;
   var stampcardoffersid =  getParameterByName('stampcardoffersid');// get record ID;
   var stampofferid =  getParameterByName('stampofferid');// get record ID;

   var tokenKey = getParameterByName('tokenKey');
   var secretKey = getParameterByName('secretKey');
   var queryMode = 'update';
  
   if(localStorage.getItem('activeMenu') != "More" || localStorage.getItem('isFromStampCard') != 'true'){
         var nextPage = 'app_merchantdetails'; //old
        var pageurl =  nextPage + '_5da73cac545050343288ce7a.html?queryMode='+ queryMode+'&tokenKey='+tokenKey+ '&secretKey=' + secretKey+ '&bazaarid=' + bazaarid+'&merchantID=' + merchantID+ '&recordID=' + recordID+'&applyFilter=true';
   }else{
        var nextPage = 'app_offerdetails'; //new
        var pageurl =  nextPage + '_5da73cac545050343288ce7a.html?queryMode='+ queryMode+'&tokenKey='+tokenKey+ '&secretKey=' + secretKey+ '&stampcardoffersid=' + stampcardoffersid+ '&stampofferid=' + stampofferid+'&applyFilter=true&outletId='+recordID;
   }
   if(!nextPage){
    return false;
 }
   window.location.href = pageurl;
   return false;
 }); // to add New record

		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
                var nextPage =  'app_merchantlisting'; 
                if(localStorage.getItem('isFromStampCard') == 'true'){
                    nextPage =  'app_allofferlisting'; 
                }
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
});//end of ready
 function getDataProcessBeforeCalldcard_leftimage_collectioncontainerBazaar5da73cac545050343288ce7a(objParamsList,callback){
      var response = objParamsList

      callback();
 }
 function dcard_leftimage_collectioncontainerapp_merchantoutletlistingSync(timestamp) {
     try {
         var objParamsList = {};
         objParamsList.queryMode = 'mylist';
         var ajaXCallURL = $.trim($('#ajaXCallURL').val());
         objParamsList.tokenKey = getParameterByName('tokenKey');
         objParamsList.secretKey = getParameterByName('secretKey');
         objParamsList.ajaXCallURL = ajaXCallURL;
         objParamsList.isMobile = true;
         objParamsList.timestamp = timestamp;
         $.ajax({
             url: objParamsList.ajaXCallURL + '/milestone003/syncListDetails_Bazaar5da73cac545050343288ce7a_app_merchantoutletlisting',
             data: objParamsList,
             type: 'POST',
             success: function (response) {
              $('#display_loading').addClass('hideme');
                 if (response.status != undefined && response.status == 1) {
                     localStorage.removeItem('dcard_leftimage_collectioncontainerapp_merchantoutletlisting');
                     var objParamsList = {};
                     objParamsList.queryMode = 'mylist';
                     var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                     objParamsList.tokenKey = getParameterByName('tokenKey');
                     objParamsList.secretKey = getParameterByName('secretKey');
                     objParamsList.ajaXCallURL = ajaXCallURL;
                     objParamsList.isMobile = 'true';
                     objParamsList.isiPad = false;
                     objParamsList.timestamp = timestamp; 
 var  applyFilter = getParameterByName('applyFilter');
 if(applyFilter == null && objParamsList.applyFilter == false ){
 objParamsList.type =  'merchantoutlets';
    objParamsList.applystaticfilter = true;
 }
 if(getParameterByName('bazaarid') && getParameterByName('bazaarid') != '' && getParameterByName('bazaarid') != null  && getParameterByName('bazaarid') != 'undefined' ){
 objParamsList.merchantid =  getParameterByName('bazaarid');
 }
         show_dcard_leftimage_collectioncontainerapp_merchantoutletlisting_Details(objParamsList)
                 }
             },
             error: function (xhr, status, error) { 
                 handleError(xhr, status, error); 
             } 
         });
     } catch (err) {
        // console.log('Error in workingtoolsSync', err);
     }
 }
         function show_dcard_leftimage_collectioncontainerapp_merchantoutletlisting_Details(objParamsList){ 
 var  applyFilter = getParameterByName('applyFilter');
 if(applyFilter == null && objParamsList.applyFilter == false ){
 objParamsList.type =  'merchantoutlets';
    objParamsList.applystaticfilter = true;
 }
 if(getParameterByName('bazaarid') && getParameterByName('bazaarid') != '' && getParameterByName('bazaarid') != null  && getParameterByName('bazaarid') != 'undefined' ){
 objParamsList.merchantid =  getParameterByName('bazaarid');
 }
         localStorage.setItem('appmerchantoutletlistingFilterBox','');
         objParamsList.status = 'Active';
          $.ajax({
              url: objParamsList.ajaXCallURL+'/milestone003/getListDetails_Bazaar5da73cac545050343288ce7a_app_merchantoutletlisting_dcard_leftimage_collectioncontainer',
              data: objParamsList,
              type: 'POST',
              success: function (response) {
                      getDataProcessAfterCalldcard_leftimage_collectioncontainerBazaar5da73cac545050343288ce7a(response, function(){
                      if (response.status != undefined && response.status == 0) {
                     if (objParamsList.isMobile == 'true') {    
                             $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html('');
                             //localStorage.removeItem('dcard_leftimage_collectioncontainerapp_merchantoutletlisting');
                             localStorage.setItem('dcard_leftimage_collectioncontainerapp_merchantoutletlisting',JSON.stringify(response));
                              getdcard_leftimage_collectioncontainerapp_merchantoutletlistingMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
                          } else if (objParamsList.isiPad == 'true') {    
                              getdcard_leftimage_collectioncontainerapp_merchantoutletlistingiPadView(response, objParamsList.tokenKey, objParamsList.queryMode);
                          } else {
                              getdcard_leftimage_collectioncontainerapp_merchantoutletlistingWebView(response, objParamsList.tokenKey,objParamsList.queryMode);
                          }
                          $('#display_loading').addClass('hideme');
                     } else {   
                          $('#display_loading').addClass('hideme')
                     }   
                   });   
                  },        
                  error: function (xhr, status, error) {        
                          $('#display_loading').addClass('hideme')
                          handleError(xhr, status, error); 
                  },        
              });  
        } // end of function     
                  
 function getDataProcessAfterCalldcard_leftimage_collectioncontainerBazaar5da73cac545050343288ce7a(response,callback){

      callback();
 }

        function getdcard_leftimage_collectioncontainerapp_merchantoutletlistingMobileView(response, tokenKey, queryMode) {
              var html = '';
              if (response.data.length == 0) {
                  html += '<div class="nodatafound">';
                  html +=     '<img src="nodatafound.gif" width="100%">';
                  html +=         '<br>';
                  html +=     '<!-- span>No record found</span -->';
                  html += '</div>';
                  $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html); ;
             } else {
              html =       '';
              var radioGroups =       [];
              $.each(response.data, function (keyList, objList) {
                  var ios = navigator.userAgent.toLowerCase().indexOf("iphone os"); 
                  var isAndroid = navigator.userAgent.toLowerCase().indexOf("android"); 
                  if(isAndroid > -1 || ios > -1){  // need to fix with native gyes.. images not getting download
                      var mediaID = '';
                      var fileName = '';
                      if(objList['merchantimage'] && objList['merchantimage'][0].mediaID){
                          mediaID = objList['merchantimage'][0].mediaID;
                          fileName = objList['merchantimage'][0].mediaID + '.png';
                      }
                      getLocalImagedcard_leftimage_collectioncontainer(objList, mediaID, fileName); 
                  }else {
               
 html += '      <div class="row plain-card search" search="'+ removeSpecialChars(  objList.merchantimage  + objList.name  + objList.stampcardcount  + objList.outletaddress_name  + objList.description) +'">';
 html += '      		<div class="col s12 m12">';
 html += '               <div class="card-content">';
 html += '                  <div     status="'+ objList.status+ '"  recordID="'+objList._id+'" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
 html += '      <div class="row  element" style=""  >';
 html += '      <div class="col s3 cls_sg3964" style="">';
  var localFilePath = '';
  if(response && response.localFilePath){
     localFilePath = response.localFilePath;
  }
 html += '           <div class="col s12 clssg7964" style="">';
 var filetodisplay = ''; 
 if(objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID){
    filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
 }
 if ( localFilePath && localFilePath != '' ) {
     html += '               <img recordID="'+objList._id+'"  id="merchantimage11"   class=" clssg7964image merchantimage11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ localFilePath+'" mediaid="'+ objList.mediaID +'" filenm="'+ objList.filenm +'" >';
 } else if(objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID){
    if(filetodisplay && filetodisplay != objList.merchantimage[0].fileNm){
        html += '               <img recordID="'+objList._id+'"    id="merchantimage11"   class=" clssg7964image merchantimage11" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ filetodisplay + '">';
    } else {
        html += '               <img recordID="'+objList._id+'"    id="merchantimage11"   class=" clssg7964image merchantimage11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ CDN_PATH+objList.merchantimage[0].mediaID+'_compressed.png">';
    }
 } else{
    // stage 6666666666666666
     html += '               <img recordID="'+objList._id+'"   id="merchantimage11"   class=" clssg7964image merchantimage11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
 }
 html += '           </div>';
 html += '     </div>';
 html += '      <div class="col s9 cls_sg5964 addshimmer" style="">';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg9964  '+adddbclass+' " style=" cursor: pointer;">';
 objList['name'] = objList['name'] ? objList['name'] : '';
 if(response.showShimmer){
    objList['name'] = '';
 }
 var name = objList['name'];
 html += '           <div recordID="' + objList._id +'"   id="name12" class="languagetranslation " style="" >'+ name+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s6 clssg1074  '+adddbclass+' " style=" cursor: pointer;">';
 objList['stampcardcount'] = objList['stampcardcount'] ? objList['stampcardcount'] : '0';
 if(response.showShimmer){
    objList['stampcardcount'] = '';
 }
 var stampcardcount = objList['stampcardcount'];
 html += '           <div recordID="' + objList._id +'"   id="stampcardcount13" class="languagetranslation " style="" >'+ stampcardcount+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s6 clssg3074  '+adddbclass+' " style=" cursor: pointer;">';
 html += '           <div recordID="'+objList._id+'"  id="loyaltystampcardsavailable14" class="languagetranslation "style="" >Loyalty Stamp Cards Available </div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg5074  '+adddbclass+' " style=" cursor: pointer;">';
 objList['outletaddress_name'] = objList['outletaddress_name'] ? objList['outletaddress_name'] : '';
 if(response.showShimmer){
    objList['outletaddress_name'] = '';
 }
 var outletaddress_name = objList['outletaddress_name'];
 html += '           <div recordID="' + objList._id +'"   id="outletaddress_name15" class="languagetranslation " style="" >'+ outletaddress_name+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg7074  '+adddbclass+' " style=" cursor: pointer;">';
 objList['description'] = objList['description'] ? objList['description'] : '';
 if(response.showShimmer){
    objList['description'] = '';
 }
 var description = objList['description'];
 html += '           <div recordID="' + objList._id +'"   id="description16" class="languagetranslation " style="" >'+ description+'</div>';
 html += '     </div>';
 html += '     </div>';
 html += '     </div>';
 html += '      				</div>';
 html += '          </div>';
 html += '        </div>';
 html += '     </div>';
 html += '   </div>';
                  }
             });
                  var ios = navigator.userAgent.toLowerCase().indexOf("iphone os"); 
                  var isAndroid = navigator.userAgent.toLowerCase().indexOf("android"); 
                  if(1){ 
                          $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html)
                   $('#full-body-container').addClass('fadeInUp');
                  };
                  if(!response.showShimmer){
                      dcardLoaded['dcard_leftimage_collectioncontainer'] = true;
                      $('#collectioncontainerDivdcard_leftimage_collectioncontainer').find('.view_list_record').removeClass('shimmer');
                  }
                  $('.carddropdown').material_select();
                  $('<input>').attr({type: 'hidden',class: 'cardtoggleswitch',id: 'togleswitchvalue'}).appendTo('body')
                  if($('.js-candlestick').length) $('.js-candlestick').candlestick({afterSetting: function(input, wrapper, value) {$('#togleswitchvalue').val(value).attr('recordID', input.attr('id')).trigger('click');}});
                  if(radioGroups && radioGroups.length){
                      for(var key in radioGroups){
                          var groupName = radioGroups[key];
                          $('input:radio[name='+ groupName +']:first').prop('checked', true);
                          $('input:radio[name='+ groupName +']:first').trigger('change');
                      }
                  }
              };
            };
            function getLocalImagedcard_leftimage_collectioncontainer(objList, mediaID, fileName) {
                try {
                    var appJSON = {};
                    appJSON.nextButtonCallback = 'handleLocalImagedcard_leftimage_collectioncontainer';
                    appJSON.url = CDN_PATH + mediaID+ '_compressed.png';
                    appJSON.fileMimeType = 'image/png';
                    appJSON.fileName = fileName;
                    appJSON.objList = objList;
                    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
                    if (isAndroid > -1) {
                        window.Android.getLocalImage(JSON.stringify(appJSON))
                    } else {
                        setupWebViewJavascriptBridge(function (bridge) {
                            bridgeObj = bridge;
                            bridgeObj.callHandler('getLocalImage', appJSON, function (response) { });
                            bridgeObj.registerHandler('handleLocalImagedcard_leftimage_collectioncontainer', function (responseData, responseCallback) {
                                handleLocalImagedcard_leftimage_collectioncontainer(responseData)
                            });
                        });
                    }
                } catch (err) {
            
                }
            }
            function handleLocalImagedcard_leftimage_collectioncontainer(response) {
               var objList = response.dataDictionay.objList;
               var html = '';
               
 html += '      <div class="row plain-card search" search="'+ removeSpecialChars(  objList.merchantimage  + objList.name  + objList.stampcardcount  + objList.outletaddress_name  + objList.description) +'">';
 html += '      		<div class="col s12 m12">';
 html += '               <div class="card-content">';
 html += '                  <div     status="'+ objList.status+ '"  recordID="'+objList._id+'" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
 html += '      <div class="row  element" style=""  >';
 html += '      <div class="col s3 cls_sg3964" style="">';
  var localFilePath = '';
  if(response && response.localFilePath){
     localFilePath = response.localFilePath;
  }
 html += '           <div class="col s12 clssg7964" style="">';
 var filetodisplay = ''; 
 if(objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID){
    filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
 }
 if ( localFilePath && localFilePath != '' ) {
     html += '               <img recordID="'+objList._id+'"  id="merchantimage11"   class=" clssg7964image merchantimage11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ localFilePath+'" mediaid="'+ objList.mediaID +'" filenm="'+ objList.filenm +'" >';
 } else if(objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID){
    if(filetodisplay && filetodisplay != objList.merchantimage[0].fileNm){
        html += '               <img recordID="'+objList._id+'"    id="merchantimage11"   class=" clssg7964image merchantimage11" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ filetodisplay + '">';
    } else {
        html += '               <img recordID="'+objList._id+'"    id="merchantimage11"   class=" clssg7964image merchantimage11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ CDN_PATH+objList.merchantimage[0].mediaID+'_compressed.png">';
    }
 } else{
    // stage 6666666666666666
     html += '               <img recordID="'+objList._id+'"   id="merchantimage11"   class=" clssg7964image merchantimage11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
 }
 html += '           </div>';
 html += '     </div>';
 html += '      <div class="col s9 cls_sg5964 addshimmer" style="">';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg9964  '+adddbclass+' " style=" cursor: pointer;">';
 objList['name'] = objList['name'] ? objList['name'] : '';
 if(response.showShimmer){
    objList['name'] = '';
 }
 var name = objList['name'];
 html += '           <div recordID="' + objList._id +'"   id="name12" class="languagetranslation " style="" >'+ name+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s6 clssg1074  '+adddbclass+' " style=" cursor: pointer;">';
 objList['stampcardcount'] = objList['stampcardcount'] ? objList['stampcardcount'] : '0';
 if(response.showShimmer){
    objList['stampcardcount'] = '';
 }
 var stampcardcount = objList['stampcardcount'];
 html += '           <div recordID="' + objList._id +'"   id="stampcardcount13" class="languagetranslation " style="" >'+ stampcardcount+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s6 clssg3074  '+adddbclass+' " style=" cursor: pointer;">';
 html += '           <div recordID="'+objList._id+'"  id="loyaltystampcardsavailable14" class="languagetranslation "style="" >Loyalty Stamp Cards Available </div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg5074  '+adddbclass+' " style=" cursor: pointer;">';
 objList['outletaddress_name'] = objList['outletaddress_name'] ? objList['outletaddress_name'] : '';
 if(response.showShimmer){
    objList['outletaddress_name'] = '';
 }
 var outletaddress_name = objList['outletaddress_name'];
 html += '           <div recordID="' + objList._id +'"   id="outletaddress_name15" class="languagetranslation " style="" >'+ outletaddress_name+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg7074  '+adddbclass+' " style=" cursor: pointer;">';
 objList['description'] = objList['description'] ? objList['description'] : '';
 if(response.showShimmer){
    objList['description'] = '';
 }
 var description = objList['description'];
 html += '           <div recordID="' + objList._id +'"   id="description16" class="languagetranslation " style="" >'+ description+'</div>';
 html += '     </div>';
 html += '     </div>';
 html += '     </div>';
 html += '      				</div>';
 html += '          </div>';
 html += '        </div>';
 html += '     </div>';
 html += '   </div>';
               $('#collectioncontainerDivdcard_leftimage_collectioncontainer').append(html)
              $('#full-body-container').addClass('fadeInUp');
        dcardLoaded['dcard_leftimage_collectioncontainer'] = true;
        $('#collectioncontainerDivdcard_leftimage_collectioncontainer').find('.view_list_record').removeClass('shimmer');
        // after html bining code
        };

        function getdcard_leftimage_collectioncontainerapp_merchantoutletlistingPadView(response, tokenKey, queryMode) {
              var html = '';
              if (response.data.length == 0) {
                              html += '<tr>';
                              html +=     '<td colspan="1" class="text_center first_row_table_td">';
                              html +=         'No record found';
                              html +=     '</td>';
                              html += '</tr>';
             } else {
              html =       '';
              $.each(response.data, function (keyList, objList) {
               
 html += '      <div class="row plain-card search" search="'+ removeSpecialChars(  objList.merchantimage  + objList.name  + objList.stampcardcount  + objList.outletaddress_name  + objList.description) +'">';
 html += '      		<div class="col s12 m12">';
 html += '               <div class="card-content">';
 html += '                  <div     status="'+ objList.status+ '"  recordID="'+objList._id+'" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
 html += '      <div class="row  element" style=""  >';
 html += '      <div class="col s3 cls_sg3964" style="">';
  var localFilePath = '';
  if(response && response.localFilePath){
     localFilePath = response.localFilePath;
  }
 html += '           <div class="col s12 clssg7964" style="">';
 var filetodisplay = ''; 
 if(objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID){
    filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
 }
 if ( localFilePath && localFilePath != '' ) {
     html += '               <img recordID="'+objList._id+'"  id="merchantimage11"   class=" clssg7964image merchantimage11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ localFilePath+'" mediaid="'+ objList.mediaID +'" filenm="'+ objList.filenm +'" >';
 } else if(objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID){
    if(filetodisplay && filetodisplay != objList.merchantimage[0].fileNm){
        html += '               <img recordID="'+objList._id+'"    id="merchantimage11"   class=" clssg7964image merchantimage11" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ filetodisplay + '">';
    } else {
        html += '               <img recordID="'+objList._id+'"    id="merchantimage11"   class=" clssg7964image merchantimage11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ CDN_PATH+objList.merchantimage[0].mediaID+'_compressed.png">';
    }
 } else{
    // stage 6666666666666666
     html += '               <img recordID="'+objList._id+'"   id="merchantimage11"   class=" clssg7964image merchantimage11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
 }
 html += '           </div>';
 html += '     </div>';
 html += '      <div class="col s9 cls_sg5964 addshimmer" style="">';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg9964  '+adddbclass+' " style=" cursor: pointer;">';
 objList['name'] = objList['name'] ? objList['name'] : '';
 if(response.showShimmer){
    objList['name'] = '';
 }
 var name = objList['name'];
 html += '           <div recordID="' + objList._id +'"   id="name12" class="languagetranslation " style="" >'+ name+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s6 clssg1074  '+adddbclass+' " style=" cursor: pointer;">';
 objList['stampcardcount'] = objList['stampcardcount'] ? objList['stampcardcount'] : '0';
 if(response.showShimmer){
    objList['stampcardcount'] = '';
 }
 var stampcardcount = objList['stampcardcount'];
 html += '           <div recordID="' + objList._id +'"   id="stampcardcount13" class="languagetranslation " style="" >'+ stampcardcount+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s6 clssg3074  '+adddbclass+' " style=" cursor: pointer;">';
 html += '           <div recordID="'+objList._id+'"  id="loyaltystampcardsavailable14" class="languagetranslation "style="" >Loyalty Stamp Cards Available </div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg5074  '+adddbclass+' " style=" cursor: pointer;">';
 objList['outletaddress_name'] = objList['outletaddress_name'] ? objList['outletaddress_name'] : '';
 if(response.showShimmer){
    objList['outletaddress_name'] = '';
 }
 var outletaddress_name = objList['outletaddress_name'];
 html += '           <div recordID="' + objList._id +'"   id="outletaddress_name15" class="languagetranslation " style="" >'+ outletaddress_name+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg7074  '+adddbclass+' " style=" cursor: pointer;">';
 objList['description'] = objList['description'] ? objList['description'] : '';
 if(response.showShimmer){
    objList['description'] = '';
 }
 var description = objList['description'];
 html += '           <div recordID="' + objList._id +'"   id="description16" class="languagetranslation " style="" >'+ description+'</div>';
 html += '     </div>';
 html += '     </div>';
 html += '     </div>';
 html += '      				</div>';
 html += '          </div>';
 html += '        </div>';
 html += '     </div>';
 html += '   </div>';
              }); // end of each loop
            };
              $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html)
        };

        function getdcard_leftimage_collectioncontainerapp_merchantoutletlistingWebView(response, tokenKey, queryMode) {
              var html = '';
              if (response.data.length == 0) {
                              html += '<tr>';
                              html +=     '<td colspan="1" class="text_center first_row_table_td">';
                              html +=         'No record found';
                              html +=     '</td>';
                              html += '</tr>';
             } else {
              html =       '';
              $.each(response.data, function (keyList, objList) {
               
 html += '      <div class="row plain-card search" search="'+ removeSpecialChars(  objList.merchantimage  + objList.name  + objList.stampcardcount  + objList.outletaddress_name  + objList.description) +'">';
 html += '      		<div class="col s12 m12">';
 html += '               <div class="card-content">';
 html += '                  <div     status="'+ objList.status+ '"  recordID="'+objList._id+'" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
 html += '      <div class="row  element" style=""  >';
 html += '      <div class="col s3 cls_sg3964" style="">';
  var localFilePath = '';
  if(response && response.localFilePath){
     localFilePath = response.localFilePath;
  }
 html += '           <div class="col s12 clssg7964" style="">';
 var filetodisplay = ''; 
 if(objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID){
    filetodisplay = getuploadedfilepreview(objList.merchantimage[0].fileNm);
 }
 if ( localFilePath && localFilePath != '' ) {
     html += '               <img recordID="'+objList._id+'"  id="merchantimage11"   class=" clssg7964image merchantimage11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ localFilePath+'" mediaid="'+ objList.mediaID +'" filenm="'+ objList.filenm +'" >';
 } else if(objList.merchantimage && objList.merchantimage[0] && objList.merchantimage[0].mediaID){
    if(filetodisplay && filetodisplay != objList.merchantimage[0].fileNm){
        html += '               <img recordID="'+objList._id+'"    id="merchantimage11"   class=" clssg7964image merchantimage11" style=""   onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ filetodisplay + '">';
    } else {
        html += '               <img recordID="'+objList._id+'"    id="merchantimage11"   class=" clssg7964image merchantimage11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="'+ CDN_PATH+objList.merchantimage[0].mediaID+'_compressed.png">';
    }
 } else{
    // stage 6666666666666666
     html += '               <img recordID="'+objList._id+'"   id="merchantimage11"   class=" clssg7964image merchantimage11" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
 }
 html += '           </div>';
 html += '     </div>';
 html += '      <div class="col s9 cls_sg5964 addshimmer" style="">';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg9964  '+adddbclass+' " style=" cursor: pointer;">';
 objList['name'] = objList['name'] ? objList['name'] : '';
 if(response.showShimmer){
    objList['name'] = '';
 }
 var name = objList['name'];
 html += '           <div recordID="' + objList._id +'"   id="name12" class="languagetranslation " style="" >'+ name+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s6 clssg1074  '+adddbclass+' " style=" cursor: pointer;">';
 objList['stampcardcount'] = objList['stampcardcount'] ? objList['stampcardcount'] : '0';
 if(response.showShimmer){
    objList['stampcardcount'] = '';
 }
 var stampcardcount = objList['stampcardcount'];
 html += '           <div recordID="' + objList._id +'"   id="stampcardcount13" class="languagetranslation " style="" >'+ stampcardcount+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s6 clssg3074  '+adddbclass+' " style=" cursor: pointer;">';
 html += '           <div recordID="'+objList._id+'"  id="loyaltystampcardsavailable14" class="languagetranslation "style="" >Loyalty Stamp Cards Available </div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg5074  '+adddbclass+' " style=" cursor: pointer;">';
 objList['outletaddress_name'] = objList['outletaddress_name'] ? objList['outletaddress_name'] : '';
 if(response.showShimmer){
    objList['outletaddress_name'] = '';
 }
 var outletaddress_name = objList['outletaddress_name'];
 html += '           <div recordID="' + objList._id +'"   id="outletaddress_name15" class="languagetranslation " style="" >'+ outletaddress_name+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg7074  '+adddbclass+' " style=" cursor: pointer;">';
 objList['description'] = objList['description'] ? objList['description'] : '';
 if(response.showShimmer){
    objList['description'] = '';
 }
 var description = objList['description'];
 html += '           <div recordID="' + objList._id +'"   id="description16" class="languagetranslation " style="" >'+ description+'</div>';
 html += '     </div>';
 html += '     </div>';
 html += '     </div>';
 html += '      				</div>';
 html += '          </div>';
 html += '        </div>';
 html += '     </div>';
 html += '   </div>';
             }); // end of each loop 1
            };
              $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html)
        };