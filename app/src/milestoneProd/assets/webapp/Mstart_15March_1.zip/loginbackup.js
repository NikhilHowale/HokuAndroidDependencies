
var offlineDataID = randomString();
var arrAllMedia = [];
var count = 0;
var otpCode = 0;
var passwordchanged = 0;
var errorFields = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var loginInfo = null;
var signupInfo = null;
var forgotEmail = null;
var changePassword = null;
var deviceInfo = {};
var forgotEmailOtp = 0;

var dropdownvalues = {};
var isFetch = true;
var isLock = false;
localStorage.setItem('objGetUserDetailsWithmenu', '');
$(document).ready(function () {

    getbannerImage();
    getbannerImage_signup();


    $('#sg4075').removeClass('hide')

    $(".cognitoError").hide();
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"))
    }

    var objParamsToken = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsToken.tokenKey = getParameterByName('tokenKey');
    objParamsToken.secretKey = getParameterByName('secretKey');

    var userRole = $('#userRole').val();
    var userID = $('#userID').val();
    var createrOfRecord = $('#createrOfRecord').val();
    var queryMode = getParameterByName('queryMode');
    var recordID = $.trim($('#recordID').val());
    var addSessionComments = [];
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('click', '#otpbackbutton1', function (e) {
        $(".cognitoError").hide();
        e.preventDefault();
        resetFormInputs();
        $('.outer_starcontainer').addClass('hide');
        if (signupInfo) {
            $('#page_usersignup').removeClass('hide');
        } else {
            $('#page_login').removeClass('hide');
        }
    });//end of Event 


    $(document).on('focus', '#newpassword7', function () {
        $('.sgstrongpasswordmessage').fadeIn('300');
    });
    $(document).on('focusout', '#newpassword7', function () {
        $('.sgstrongpasswordmessage').hide();
        $('#confirmnewpassword8').focus();
    });

    $(document).on('focus', '#password10', function () {
        $('.sgstrongpasswordmessage').fadeIn('300');
    });
    $(document).on('focusout', '#password10', function () {
        $('.sgstrongpasswordmessage').hide();
        $('#confirmpassword11').focus();
    });

    $(document).on('keyup', '#newpassword7', function () {
        var password = $(this).val();
        showPasswordStrength(password)
    });

    $(document).on('click', '#signup5', function (e) {
        $(".cognitoError").hide();
        e.preventDefault();
        resetFormInputs();
        $('.outer_starcontainer').addClass('hide');
        $('#page_login').removeClass('hide');
    });
    $(document).on('click', '#didntreceiveotp9', function (e) {
        $(".cognitoError").hide();
        $('#display_loading').removeClass('hideme');
        $('.otp-input').val("");
        if (loginInfo) {
            authenticateUser(loginInfo);
        } else if (signupInfo) {
            resendConfirmationCode(signupInfo);
        } else if (forgotEmail) {
            forgotPassword(forgotEmail);
        } else {
            $('#display_loading').addClass('hideme');
            $(".cognitoError").html('Error in sending OTP. Please try later.').addClass('error_message').removeClass('success_message');
            $(".cognitoError").show();
        }
    });
    $(document).on('click', '#terms_condition', function () {
        var appJSON = {
            url: 'https://appcdn.hokuapps.com/msa/terms.html',
            title: 'Terms & Conditions',
            isLocal: false
        };
        var isAndroid = navigator.userAgent.toLowerCase().indexOf('android');
        if (isAndroid > -1) {
            window.Android.showTermsAndConditions(JSON.stringify(appJSON));
        } else {
            setupWebViewJavascriptBridge(function (bridge) {
                bridgeObj = bridge;
                bridgeObj.callHandler('showTermsAndConditions', appJSON, function (response) { });
            });
        }
    });

    $(document).on('click', '#launchmilestoneprivaacy', function () {
        var appJSON = {
            url: 'http://milestones-group.com/privacy-policy.html',
            title: 'Privacy Policy',
            isLocal: false


        };
        var isAndroid = navigator.userAgent.toLowerCase().indexOf('android');
        if (isAndroid > -1) {
            window.Android.showTermsAndConditions(JSON.stringify(appJSON));
        } else {
            setupWebViewJavascriptBridge(function (bridge) {
                bridgeObj = bridge;
                bridgeObj.callHandler('showTermsAndConditions', appJSON, function (response) { });
            });
        }
    });
    $(document).on("keyup", '.otp-input', function (e) {
        $(".cognitoError").hide();
        var val = $(this).val();
        // if (val) {
        //     $(this).attr('type', 'password');
        // } else {
        //     $(this).attr('type', 'tel');
        // }

        var currentTarget = $(e.target);
        var srno = currentTarget.attr('srno');
        if (e.keyCode == 8) {
        }
        var otp = isAllFill();
        $(".cognitoError").hide();
        if (otp) {
            var responseData = JSON.parse(localStorage.getItem('responseData'));
            validateOTPWrapper(otp, CognitoConfig.APPID);
            return false;
        } else if (val) {
            srno = parseInt(srno);
            srno = srno + 1;
            $("#hkotp" + srno).focus();
        } else {
            srno = parseInt(srno);
            srno = srno - 1;
            if (srno >= 1) {
                $("#hkotp" + srno).focus();
            }
        }
    });

    function isAllFill() {
        try {
            if ($.trim($('#hkotp1').val()) != '' && $.trim($('#hkotp2').val()) != '' && $.trim($('#hkotp3').val()) != '' && $.trim($('#hkotp4').val()) != '' && $.trim($('#hkotp5').val()) != '' && $.trim($('#hkotp6').val()) != '') {
                var otp = $.trim($('#hkotp1').val()) + $.trim($('#hkotp2').val()) + $.trim($('#hkotp3').val()) + $.trim($('#hkotp4').val()) + $.trim($('#hkotp5').val()) + $.trim($('#hkotp6').val());
                return otp;
            }
            return false;
        } catch (err) {
            console.log('Error in isAllFill', err);
        }
    }

    function validateOTPWrapper(otp, appID) {
        try {
            $('#display_loading').removeClass('hideme');
            if (signupInfo) {
                confirmRegistration(signupInfo, otp)
                return;
            }
            otpCode = otp;
            $('#display_loading').addClass('hideme');
            $('.outer_starcontainer').addClass('hide');
            $('#page_changepassword').removeClass('hide');
        } catch (err) {
            console.log('Error in validateOTPWrapper', err);
        }
    }

    $(document).on('click', '#resetpassword8', function () {
        //var tokenKey = getParameterByName('tokenKey');
        //var secretKey = getParameterByName('secretKey');
        //var queryMode = getParameterByName('queryMode');
        //var recordID = getParameterByName('recordID');
        //queryMode = 'add'
        //window.location.href = 'forgotpassword_5c0ba42d6b9ef012db2b6518.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey
        $('.outer_starcontainer').addClass('hide');
        $('#page_forgotpassword').removeClass('hide');
        $('.strongpass').removeClass('valid');
        resetAllInputs();
        return false;
    });//end of Event Reset Password_is_click 

    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('click', '#createone14', function () {
        $(".error_message").hide();
        $('.outer_starcontainer').addClass('hide');
        $('#page_signup').removeClass('hide');
        $('.strongpass').removeClass('valid');
        swiper2 = new Swiper('.swiper-container .swiper2', {
            autoplay: {
                delay: 2500,
                disableOnInteraction: false,
            },
            watchOverflow: true,
            pagination: {
                el: '.swiper-pagination2',
            },
        });
        return false;
    });//end of Event Create One_is_click 
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};
    Materialize.updateTextFields();
    var gBrnach = [];
    $(document).on('click', '#login7', function (e) {
        e.preventDefault();
        $('#display_loading').removeClass('hideme');
        $('#forgotPass_status').hide();
        $('#invalid_details_error').hide();
        var objParams = {};
        var contactnumber = $.trim($('#contactnumber4').val());
        if ($('#contactnumber4_div').is(':visible')) {
            if (contactnumber == '') {
                $('#display_loading').addClass('hideme');
                $('#contactnumber4_error').show();
                $('#contactnumber4').focus();
                return false;
            } else {
                $('#contactnumber4_error').hide();
            }
        }


        var email = $.trim($('#email5').val());
        if ($('#email5_div').is(':visible')) {
            if (email == '') {
                $('#display_loading').addClass('hideme');
                $('#email5_error').show();
                $('#email5').focus();
                return false;
            } else {
                $('#email5_error').hide();
            }
        }

        var password = $.trim($('#password6').val());

        if ($('#password6_div').is(':visible')) {
            if (password == '') {
                $('#display_loading').addClass('hideme');
                $('#password6_error').show();
                $('#password6').focus();
                return false;
            } else {
                $('#password6_error').hide();
            }
        }

        localStorage.clear();
        objParams.email = email.trim().toLowerCase();
        objParams.username = email.trim().toLowerCase();
        objParams.password = password.trim();
        objParams.subdomain = CognitoConfig.SUBhokuapps;
        objParams['custom:subdomain'] = CognitoConfig.SUBhokuapps;
        objParams['custom:appId'] = CognitoConfig.APPID;
        signupInfo = null;
        loginInfo = objParams;

        $('#display_loading').removeClass('hideme');
        authenticateUser(loginInfo);
        return false

        //getAppLogin(email, password);
    }); //end of Event
    $(document).on('click', '#updatePassword9', function () {

        $(".error_message").hide();
        $(".cognitoError").hide();
        var errorFields = [];
        var objParams = {};
        objParams.isDelete = 0;

        var enterotp = $.trim($('#enterotp').val());
        if ($('#enterotp_div').is(':visible')) {
            if (enterotp == '') {
                $('#enterotp_error').show();
                $('#enterotp').fadeIn(1000);
                errorFields.push('enterotp');
            }
            else {
                $('#enterotp_error').hide();
            }
        }
        // if ($('#enterotp_div').is(':visible')) {
        //     objParams.password = password;
        // }

        var password = $.trim($('#newpassword7').val());
        if ($('#newpassword7_div').is(':visible')) {
            if (password == '') {
                $('#newpassword7_error').show();
                $('#newpassword7').fadeIn(1000);
                errorFields.push('newpassword7');
            }
            else {
                $('#newpassword7_error').hide();
            }
        }
        if ($('#newpassword7_div').is(':visible')) {
            objParams.password = password;
        }
        var confirmpassword = $.trim($('#confirmnewpassword8').val());
        if ($('#confirmnewpassword8_div').is(':visible')) {
            if (confirmpassword == '') {
                $('#confirmnewpassword8_error').show();
                $('#confirmnewpassword8').fadeIn(1000);
                errorFields.push('confirmnewpassword8');
            }
            else {
                $('#confirmnewpassword8_error').hide();
            }
        }
        if ($('#confirmnewpassword8_div').is(':visible')) {
            objParams.confirmpassword = confirmpassword;
        }

        if (errorFields && errorFields.length) {
            return false;
        }

        if (password != confirmpassword) {
            $('#confirmnewpassword8_error').html('Password and Confirm password should be same.');
            $('#confirmnewpassword8_error').show();
            $('#confirmnewpassword8').focus();
            return false;
        } else {
            $('#confirmnewpassword8_error').html('Confirm Password is required');
        }

        // check strong password before save
        var strongRegex = new RegExp("^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[!@#\$%\^&\*?])(?=.{6,})");
        if (strongRegex.test(password)) {

        } else {
            $('#newpasswordisnotstrong_error').show();
            $('#newpassword7').focus();
            return false;
        }

        var changePassParams = {};
        changePassParams.otp = enterotp;
        changePassParams.username = forgotEmail ? forgotEmail : (signupInfo ? signupInfo.username : loginInfo.username);
        changePassParams.password = objParams.password;

        //loginInfo = null;
        //signupInfo = null;
        forgotEmailOtp = 0;
        if (changePassword) {
            changePassword = null;
            completeNewPasswordChallenge(password);
        } else {
            $('#display_loading').removeClass('hideme');
            confirmForgotPassword(changePassParams);
            return false
        }
    });//end of Event 

    $(document).on('click', '#forgotpassword5', function () {
        //window.location.href = 'passwordmail_5aba2abef201fa2438796905.html';
        $('.outer_starcontainer').addClass('hide');
        $('#page_forgotpassword').removeClass('hide');
        resetAllInputs();
        return false;
        return false;
    });
    $(document).on('click', '#sendemail8', function () {
        var email = $("#email5forgotpass").val();
        if (!email) {
            $("#email5forgotpass_error").show();
            $("#email5forgotpass").focus();
            return;
        }
        forgotEmailOtp = 1;
        forgotEmail = email.toLowerCase();
        $('.enterotpdivmain').removeClass('hide');
        forgotPassword(email.toLowerCase());
    })

    $(document).on('click', '#loginasguestuser8', function (e) {
        var objParams = {};
        objParams.email = "webuser1@hokuapps.com";
        objParams.username = "webuser1@hokuapps.com";
        objParams.password = "Hoku@123";
        objParams.subdomain = CognitoConfig.SUBhokuapps;
        objParams['custom:subdomain'] = CognitoConfig.SUBhokuapps;
        objParams['custom:appId'] = CognitoConfig.APPID;
        signupInfo = null;
        loginInfo = objParams;

        $('#display_loading').removeClass('hideme');
        authenticateUser(loginInfo);
        return false;
    });


    $('#contactnumber9').intlTelInput({
        initialCountry: 'sg',
        preferredCountries: ['sg', 'us', 'in'],
        separateDialCode: true,
        utilsScript: 'countrycodes/js/utils.js'
    });
    var mask1 = '000-000-0000';
    $('#contactnumber9').attr('placeholder', mask1)
    $('#contactnumber9').mask(mask1);
    $('#contactnumber9').attr('dialCode', '65').attr('countryCode', 'sg');

    // $("#contactnumber9").intlTelInput({
    //     initialCountry: 'us',
    //     preferredCountries: ['us', 'sg', 'in'],
    //     separateDialCode: true,
    //     utilsScript: "countrycodes/js/utils.js"
    // });
    // var mask1 = '000-000-0000';
    // //var mask1 = $("#contactnumber9").attr('placeholder').replace(/[0-9]/g, 0);
    // $("#contactnumber9").attr('placeholder', mask1)
    // $('#contactnumber9').mask(mask1);
    // $('#contactnumber9').attr('dialCode', '1').attr('countryCode', 'us');

    $("#contactnumber9").on("countrychange", function (e, countryData) {
        $('#contactnumber9').val('');
        var dialCode = '+' + countryData.dialCode + ' ';
        var iso2 = countryData.iso2;
        var sampleNumber = intlTelInputUtils.getExampleNumber(iso2, false, 1);
        var placeholder = sampleNumber.replace(dialCode, '');
        var mask1 = placeholder.replace(/[0-9]/g, 0);
        $('#contactnumber9').attr('placeholder', mask1).attr('dialCode', countryData.dialCode).attr('countryCode', iso2);
        $('#contactnumber9').mask(mask1);
    });


    $(document).on('click', '#facicon12', function () {

        $('#display_loading').removeClass('hideme');
        localStorage.setItem('objGetUserDetailsWithmenu', '');

        if (!navigator.onLine) {
            shareAppData('It looks like your internet connection is not working. Please try again later.', 'toast');
        } else {
            var appJSON = {};
            appJSON.nextButtonCallback = 'loginWithFacebookCallBack';
            appJSON.colorCode = '#3c3c3c';
            appJSON.launchNative = false;
            appJSON.roleName = "customer";

            // appJSON.isFromSocialMedia = true;
            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (isAndroid > -1) {
                window.Android.loginWithFB(JSON.stringify(appJSON))
            } else {
                setupWebViewJavascriptBridge(function (bridge) {
                    bridgeObj.callHandler('loginWithFB', appJSON, function (response) { });
                    bridgeObj.registerHandler('loginWithFacebookCallBack', function (responseData, responseCallback) {
                        loginWithFacebookCallBack(responseData)
                    });
                });
            }
            return false;
        }
    });

    $(document).on('click', '#goicon13', function () {
        $('#display_loading').removeClass('hideme');
        localStorage.setItem('objGetUserDetailsWithmenu', '');

        if (!navigator.onLine) {
            shareAppData('It looks like your internet connection is not working. Please try again later.', 'toast');
        } else {
            var appJSON = {};
            appJSON.nextButtonCallback = 'loginWithGoogleCallBack';
            appJSON.colorCode = '#3c3c3c';
            appJSON.launchNative = false;
            appJSON.roleName = localStorage.getItem('roleName');
            appJSON.launchNextpage = 'app_home.html';
            appJSON.isFromSocialMedia = true;

            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (isAndroid > -1) {
                window.Android.loginWithGoogle(JSON.stringify(appJSON))
            } else {
                setupWebViewJavascriptBridge(function (bridge) {
                    bridgeObj.callHandler('loginWithGoogle', appJSON, function (response) { });
                    bridgeObj.registerHandler('loginWithGoogleCallBack', function (responseData, responseCallback) {
                        loginWithGoogleCallBack(responseData)
                    });
                });
            }
            $('#display_loading').addClass('hideme');
            return false;
        }
    });

});//end of ready

function loginWithGoogleCallBack(reseponseData) {
    try {
        CognitoConfig.GATEWAY_URL = 'https://securegateway.beepup.com/5da73cac545050343288ce7aIAM';
        AWS.config.region = CognitoConfig.AWS_REGION;

        AWS.config.credentials = new AWS.CognitoIdentityCredentials({
            IdentityPoolId: CognitoConfig.AWS_IDENTITY_POOLID,
            Logins: {
                'accounts.google.com': reseponseData.googleIdToken
            }
        });
        AWS.config.credentials.get(function () {

            var AWSCredentials = {};
            // Credentials will be available when this function is called.
            AWSCredentials.accessKeyId = AWS.config.credentials.accessKeyId;
            AWSCredentials.secretAccessKey = AWS.config.credentials.secretAccessKey;
            AWSCredentials.sessionToken = AWS.config.credentials.sessionToken;
            AWSCredentials.Expiration = AWS.config.credentials.expireTime.getTime();
            AWSCredentials.identityProvider = 'google';
            AWSCredentials.accessToken = reseponseData.googleIdToken;

            localStorage.removeItem('AWSCredentials');
            localStorage.setItem('IS_IAMUSER', true);
            $("#ajaXCallURL").val("https://securegateway.beepup.com/5da73cac545050343288ce7aIAM");
            localStorage.setItem('AWSCredentials', JSON.stringify(AWSCredentials));

            var appID = 'APPID';
            var queryMode = 'mylist';
            var id = reseponseData.googleIdToken;
            var email = reseponseData.email;
            var name = reseponseData.name;
            var role = getParameterByName('roleName');

            // var objParams = {};
            // objParams.name = name;
            // objParams.email = email ? email : id + '@google.com';
            // objParams.email = objParams.email.toLowerCase();
            // objParams.password = 'password';
            // objParams.tokenKey = getParameterByName('tokenKey');
            // objParams.secretKey = getParameterByName('secretKey');
            // objParams.organizationID = '5da73d1167a1b6026c1c0bc3';
            // objParams.appID = appID;
            // objParams.integrationName = "milestone003org";
            // objParams.roleName = "customer";
            // objParams.subdomain = CognitoConfig.SUBhokuapps;

            // loginInfo = objParams;
            // var ajaXCallURL = 'https://milestone.hokuapps.com';
            // var signupURL = 'https://securegateway.beepup.com/createAppUser5da73cac545050343288ce7a';
            // CognitoConfig.GATEWAY_URL = 'https://securegateway.beepup.com/5da73cac545050343288ce7aIAM';

            var objParams = {};
            objParams.appID = CognitoConfig.APPID;
            var id = reseponseData.fbIdToken;
            objParams.email = email ? email : id + '@google.com';
            objParams.emailid = objParams.email.toLowerCase();
            objParams.name = reseponseData.name;

            objParams.rolename = "customer";
            objParams.subdomain = CognitoConfig.SUBhokuapps;
            //objParams.cit = body.idToken;

            loginInfo = objParams;
            var ajaXCallURL = 'https://milestone.hokuapps.com';
            var signupURL = 'https://securegateway.beepup.com/createAppUser5da73cac545050343288ce7a';
            CognitoConfig.GATEWAY_URL = 'https://securegateway.beepup.com/5da73cac545050343288ce7aIAM';

            var apigClient = apigClientFactory.newClient(signupURL);
            var params = {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            };
            var additionalParams = {};
            apigClient.rootPost(params, objParams, additionalParams).then(function (response) {

                //doAppLogin(IDENTITY_TOKEN, true)
                doAppLogin('');
            }).catch(function (result) {
                ;
                $('#display_loading').addClass('hideme');
                $('#didntreceiveotp9').removeProp('disabled');
            });
        });
    } catch (error) {
        ;
        console.log(error);
    }


}

function loginWithFacebookCallBack(reseponseData) {
    try {
        CognitoConfig.GATEWAY_URL = 'https://securegateway.beepup.com/5da73cac545050343288ce7aIAM';
        AWS.config.region = CognitoConfig.AWS_REGION;

        AWS.config.credentials = new AWS.CognitoIdentityCredentials({
            IdentityPoolId: CognitoConfig.AWS_IDENTITY_POOLID,
            Logins: {
                'graph.facebook.com': reseponseData.token
            }
        });
        localStorage.setItem('accessToken', reseponseData.token);
        localStorage.setItem('identityProvider', 'facebook');

        AWS.config.credentials.get(function () {

            var AWSCredentials = {};
            // Credentials will be available when this function is called.
            AWSCredentials.accessKeyId = AWS.config.credentials.accessKeyId;
            AWSCredentials.secretAccessKey = AWS.config.credentials.secretAccessKey;
            AWSCredentials.sessionToken = AWS.config.credentials.sessionToken;
            AWSCredentials.Expiration = AWS.config.credentials.expireTime.getTime();
            AWSCredentials.identityProvider = 'facebook';
            AWSCredentials.accessToken = reseponseData.token;

            localStorage.removeItem('AWSCredentials');
            localStorage.setItem('IS_IAMUSER', true);

            $("#ajaXCallURL").val("https://securegateway.beepup.com/5da73cac545050343288ce7aIAM");

            localStorage.setItem('AWSCredentials', JSON.stringify(AWSCredentials));
            var objParams = {};
            objParams.appID = CognitoConfig.APPID;
            var id = reseponseData.fbIdToken;
            objParams.email = id + 'f@hokuapps.com';
            objParams.emailid = id + '@f.com';
            objParams.name = reseponseData.name;


            objParams.rolename = "customer";
            objParams.subdomain = CognitoConfig.SUBhokuapps;
            //objParams.cit = body.idToken;

            loginInfo = objParams;
            var ajaXCallURL = 'https://milestone.hokuapps.com';
            var signupURL = 'https://securegateway.beepup.com/5da73cac545050343288ce7aIAM/createAppUser5da73cac545050343288ce7a';
            CognitoConfig.GATEWAY_URL = 'https://securegateway.beepup.com/5da73cac545050343288ce7aIAM';
            var apigClient = apigClientFactory.newClient(signupURL);
            var params = {
                'Content-Type': 'application/json',
                'Access-Control-Allow-Origin': '*'
            };
            var additionalParams = {};
            apigClient.rootPost(params, objParams, additionalParams).then(function (response) {
                ;
                //doAppLogin(IDENTITY_TOKEN, true)
                doAppLogin('');
            }).catch(function (result) {
                ;
                $('#display_loading').addClass('hideme');
                $('#didntreceiveotp9').removeProp('disabled');
            });
        });
    } catch (error) {
        ;
        console.log(error);
    }
}

(function (global) {
    try {
        if (typeof (global) === "undefined") {
            throw new Error("window is undefined");
        }
        var _hash = "!";
        var noBackPlease = function () {
            global.location.href += "#";
            // making sure we have the fruit available for juice (^__^)
            global.setTimeout(function () {
                global.location.href += "!";
            }, 50);
        };

        global.onhashchange = function () {
            if (global.location.hash !== _hash) {
                global.location.hash = _hash;
            }
        };

        global.onload = function () {
            noBackPlease();
            // disables backspace on page except on input fields and textarea..
            document.body.onkeydown = function (e) {
                var elm = e.target.nodeName.toLowerCase();
                if (e.which === 8 && (elm !== 'input' && elm !== 'textarea')) {
                    e.preventDefault();
                }
                // stopping event bubbling up the DOM tree..
                e.stopPropagation();
            };
        }
    } catch (err) {
        // console.log('Error in global call', err);
    }

})(window);
function getAppLogin(username, password, callback) {
    try {
        var ajaXCallURL = $('#ajaXCallURL').val();
        var objParams = {};
        objParams.username = username;
        objParams.password = password;
        objParams.subdomain = CognitoConfig.SUBhokuapps;
        objParams.appID = CognitoConfig.APPID;
        $.ajax({
            url: ajaXCallURL + '/incorv56/hokuexternallogin5c5bfb8d5cdfed047d18806f',
            data: objParams,
            type: 'POST',
            success: function (response) {
                if (response.status != undefined && response.status == 0) {
                    localStorage.setItem('userID', response.user.userId);
                    if (response.isUpdatePassword) {
                        var tokenKey = response.appTokenDetails.authToken;
                        var secretKey = response.appTokenDetails.authSecretKey;
                        window.location.href = 'updatepassword_5c5bfb8d5cdfed047d18806f.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&userID=' + response.user.userId;
                        return false
                    } else {
                        localStorage.setItem('objGetUserDetailsWithmenu', JSON.stringify(response.objGetUserDetailsWithmenu));
                        localStorage.setItem('perms', JSON.stringify(response.perms));
                        localStorage.setItem('user', JSON.stringify(response.user));
                        localStorage.setItem('appUser', JSON.stringify(response.appUser));
                        localStorage.setItem('organizationID', response.user.organizationId);
                        localStorage.setItem('CDN_THUMB', 'https://dxrq26z7a1rw3.cloudfront.net');
                        localStorage.setItem('CDN_THUMB', response.CDN_THUMB);
                        if (response.appUser && response.appUser.userphotoupload && response.appUser.userphotoupload[0]) {
                            localStorage.setItem('profileThumb', response.appUser.userphotoupload[0].mediaID + '_compressed.png');
                        } else {
                            localStorage.removeItem('profileThumb');
                        }
                        var tokenKey = response.tokenData.authToken;
                        var secretKey = response.tokenData.authSecretKey;
                        localStorage.setItem('tokenData', JSON.stringify(response.tokenData));
                        loginNativeCallWrapper(response, '5c5bfb8d5cdfed047d18806f');
                        return false;
                    }
                } else {
                    $('#display_loading').addClass('hideme');
                    $('#contactnumber4_error').html("Please enter correct details.");
                    $('#contactnumber4_error').show();
                    $('#contactnumber4').focus();
                    // return false;
                    $('#display_loading').addClass('hideme');
                    $('#email5_error').html("Please enter correct details.");
                    $('#email5_error').show();
                    $('#email5').focus();
                    return false;
                }
            },
            error: function (xhr, status, error) {
                $('#display_loading').addClass('hideme');
                $('#contactnumber4_error').html("Please enter correct details.");
                $('#contactnumber4_error').show();
                $('#contactnumber4').focus();
                return false;
                $('#display_loading').addClass('hideme');
                $('#email5_error').html("Please enter correct details.");
                $('#email5_error').show();
                $('#email5').focus();
                return false;
            },
        });
    } catch (err) {
        console.log('Error in getAppLogin', err);
        $('#display_loading').addClass('hideme');
        $('#contactnumber4_error').html("Please enter correct details.");
        $('#contactnumber4_error').show();
        $('#contactnumber4').focus();
        return false;
        $('#display_loading').addClass('hideme');
        $('#email5_error').html("Please enter correct details.");
        $('#email5_error').show();
        $('#email5').focus();
        return false;
    }
}

// function loginNativeCallWrapper(response, appID) {
//     try {
//         var queryMode = $('#queryMode').val();
//         var appJSON = {};
//         appJSON.organizationID = response.user.organizationId;
//         appJSON.userID = response.user._id;
//         appJSON.appID = $('#appID').val();
//         appJSON.nextButtonCallback = 'setloginNativeCallBack';
//         appJSON.action = queryMode;
//         appJSON.colorCode = '#3c3c3c';
//         appJSON.response = response;
//         appJSON.launchNative = false;
//         appJSON.authToken = response.appTokenDetails.authToken;
//         appJSON.authSecretKey = response.appTokenDetails.authSecretKey;
//         appJSON.roleName = response.appTokenDetails.roleName;
//         appJSON.expiredTime = response.appTokenDetails.expiredTime;
//         appJSON.launchNextpage = 'listing5c5bfb8d5cdfed047d18806f.html'

//         var roleName = response.appTokenDetails.roleName;
//         localStorage.setItem('roleName', roleName);
//         var tokenKey = response.appTokenDetails.authToken;
//         var secretKey = response.appTokenDetails.authSecretKey;
//         var ISDEV_MODE = localStorage.getItem("ISDEV_MODE");
//         var DEV_MODE = getParameterByName('devmode');
//         if (ISDEV_MODE == "true" || DEV_MODE) {
//             var queryMode = 'mylist';

//             if (roleName == "user") {
//                 window.location.href = 'app_homemydashboardlisting1_5ce2e616f9039e46f12edc4d.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
//                 return false
//             }
//             return false;
//         } else {
//             var objParams = {};
//             objParams.organizationID = appJSON.organizationID;
//             objParams.userID = appJSON.userID;
//             objParams.appID = appJSON.appID;
//             objParams.roleName = roleName;
//             objParams.isLogin = true;
//             var ajaXCallURL = 'https://petstation.hokuapps.com';
//             appJSON.apiName = ajaXCallURL + '/api/addUserDeviceForApp_5da73cac545050343288ce7a_5c5bfb8d5cdfed047d18806f';
//             appJSON.addDeviceObject = objParams;
//             var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
//             if (isAndroid > -1) {
//                 window.Android.loginNativeCallV2(JSON.stringify(appJSON))
//             } else {
//                 bridgeObj.callHandler('loginNativeCall', appJSON, function (response) { });
//             }
//             var appJSON = {};
//             appJSON.tokenKey = response.appTokenDetails.authToken;
//             appJSON.secretKey = response.appTokenDetails.authSecretKey;
//             appJSON.queryMode = "mylist";
//             appJSON.action = "mylist";
//             appJSON.ajaXCallURL = ajaXCallURL;
//             appJSON.organizationID = response.user.organizationId;
//             appJSON.userID = response.user._id;
//             appJSON.callbackFunction = 'setCurrentLocationOfUser';
//             appJSON.nextButtonCallback = 'setCurrentLocationOfUser';
//             appJSON.appID = $('#appID').val();
//             appJSON.sendAddress = true;
//             if (DEVICE_TYPE == 'ios') {
//                 setupWebViewJavascriptBridge(function (bridge) {
//                     bridgeObj.callHandler('getCurrentLatLong', appJSON, function (response) {
//                     });
//                     bridgeObj.registerHandler('setCurrentLocationOfUser', function (responseData, responseCallback) {
//                         setCurrentLocationOfUser(responseData, response);
//                     });
//                 });
//             } else {
//                 window.Android.getCurrentLatLong(JSON.stringify(appJSON));
//             }
//         }
//     } catch (err) {
//         $('#display_loading').addClass('hideme');
//     }
// }

function loginNativeCallWrapper(response, appID) {
    try {
        var queryMode = $('#queryMode').val();
        var appJSON = {};
        appJSON.organizationID = response.user.organizationId;
        appJSON.userID = response.user._id;
        appJSON.appID = $('#appID').val();
        appJSON.nextButtonCallback = 'setloginNativeCallBack';
        appJSON.action = queryMode;
        appJSON.colorCode = '#3c3c3c';
        appJSON.response = response;
        appJSON.launchNative = false;
        appJSON.authToken = response.appTokenDetails.authToken;
        appJSON.authSecretKey = response.appTokenDetails.authSecretKey;
        appJSON.roleName = response.appTokenDetails.roleName;
        appJSON.expiredTime = response.appTokenDetails.expiredTime;
        appJSON.launchNextpage = 'userhome5c5bfb8d5cdfed047d18806f.html'

        var roleName = response.appTokenDetails.roleName;
        localStorage.setItem('roleName', roleName);
        var tokenKey = response.appTokenDetails.authToken;
        var secretKey = response.appTokenDetails.authSecretKey;
        var ISDEV_MODE = localStorage.getItem("ISDEV_MODE");
        var DEV_MODE = getParameterByName('devmode');

        if (roleName == 'customer' && response.appUser.consultantid) {
            localStorage.setItem('userconsultantid', response.appUser.consultantid);
        } else {
            localStorage.setItem('userconsultantid', "");
        }

        if (ISDEV_MODE == "true" || DEV_MODE) {
            var queryMode = 'mylist';

            var isredeemdisplay = response.appUser.isredeemdisplay;
            var membership = response.appUser.membership;

            if (roleName == 'customer' && isredeemdisplay == 0 && membership == "Silver") {
                var welcomevoucherid = response.appUser.welcomevoucherid;
                localStorage.setItem('welcomevoucherid', welcomevoucherid);
                var ajaXCallURL = CognitoConfig.GATEWAY_URL;

                if (response.appUser !== undefined && response.redeemstatus === "Requested") {
                    window.location.href = 'app_userhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&bazaarid=' + welcomevoucherid + '&recordID=' + welcomevoucherid + '&applyFilter=true'; return false
                } else {
                    window.location.href = 'app_welcomevoucherdetails_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&bazaarid=' + welcomevoucherid + '&recordID=' + welcomevoucherid + '&applyFilter=true'; return false
                }
            }

            if (roleName == 'customer' && isredeemdisplay == 0 && membership == "Gold") {
                var welcomevoucherid = response.appUser.welcomevoucherid;

                localStorage.setItem('welcomevoucherid', welcomevoucherid);
                if (response.appUser !== undefined && response.redeemstatus === "Requested") {
                    window.location.href = 'app_userhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&bazaarid=' + welcomevoucherid + '&recordID=' + welcomevoucherid + '&applyFilter=true'; return false
                } else {
                    window.location.href = 'app_welcomevouchergolddetails_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&bazaarid=' + welcomevoucherid + '&recordID=' + welcomevoucherid + '&applyFilter=true'; return false
                }
                //   window.location.href = 'app_welcomevouchergolddetails_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&bazaarid=' + welcomevoucherid + '&recordID=' + welcomevoucherid + '&applyFilter=true'; return false
            }

            if (roleName == 'customer') {
                window.location.href = 'app_userhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false
            }

            if (roleName == 'consultant') {
                window.location.href = 'app_consultantuserhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false
            }

            return false;
        } else {
            var objParams = {};
            objParams.organizationID = appJSON.organizationID;
            objParams.userID = appJSON.userID;
            objParams.appID = appJSON.appID;
            objParams.roleName = roleName;
            objParams.isLogin = true;
            var ajaXCallURL = CognitoConfig.GATEWAY_URL;
            appJSON.apiName = ajaXCallURL + '/api/addUserDeviceForApp_5da73cac545050343288ce7a';
            objParams.Authorization = localStorage.getItem('IDENTITY_TOKEN');

            appJSON.Authorization = localStorage.getItem('IDENTITY_TOKEN');

            appJSON.addDeviceObject = objParams;
            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
            if (isAndroid > -1) {
                window.Android.loginNativeCallV2(JSON.stringify(appJSON))
            } else {
                bridgeObj.callHandler('loginNativeCall', appJSON, function (response) { });
                bridgeObj.registerHandler('setloginNativeCallBack', function (responseData, responseCallback) {
                    setloginNativeCallBack(responseData)
                });
            }
            var isredeemdisplay = response.appUser.isredeemdisplay;
            var membership = response.appUser.membership;

            if (roleName == 'customer' && isredeemdisplay == 0 && membership == "Silver") {
                var welcomevoucherid = response.appUser.welcomevoucherid;
                localStorage.setItem('welcomevoucherid', welcomevoucherid);
                var ajaXCallURL = CognitoConfig.GATEWAY_URL;

                if (response.appUser !== undefined && response.redeemstatus === "Requested") {
                    window.location.href = 'app_userhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&bazaarid=' + welcomevoucherid + '&recordID=' + welcomevoucherid + '&applyFilter=true'; return false
                } else {
                    window.location.href = 'app_welcomevoucherdetails_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&bazaarid=' + welcomevoucherid + '&recordID=' + welcomevoucherid + '&applyFilter=true'; return false
                }
            }

            if (roleName == 'customer' && isredeemdisplay == 0 && membership == "Gold") {
                var welcomevoucherid = response.appUser.welcomevoucherid;

                localStorage.setItem('welcomevoucherid', welcomevoucherid);
                if (response.appUser !== undefined && response.redeemstatus === "Requested") {
                    window.location.href = 'app_userhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&bazaarid=' + welcomevoucherid + '&recordID=' + welcomevoucherid + '&applyFilter=true'; return false
                } else {
                    window.location.href = 'app_welcomevouchergolddetails_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&bazaarid=' + welcomevoucherid + '&recordID=' + welcomevoucherid + '&applyFilter=true'; return false
                }
            }
            // if (roleName == 'customer' && isredeemdisplay == 0 && membership == "Silver") {
            //     var welcomevoucherid = response.appUser.welcomevoucherid;

            //     localStorage.setItem('welcomevoucherid', welcomevoucherid);

            //     window.location.href = 'app_welcomevoucherdetails_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&bazaarid=' + welcomevoucherid + '&recordID=' + welcomevoucherid + '&applyFilter=true'; return false
            // }

            // if (roleName == 'customer' && isredeemdisplay == 0 && membership == "Gold") {
            //     var welcomevoucherid = response.appUser.welcomevoucherid;

            //     localStorage.setItem('welcomevoucherid', welcomevoucherid);

            //     window.location.href = 'app_welcomevouchergolddetails_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&bazaarid=' + welcomevoucherid + '&recordID=' + welcomevoucherid + '&applyFilter=true'; return false
            // }

            if (roleName == 'customer') {

                window.location.href = 'app_userhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false
            }

            if (roleName == 'consultant') {

                window.location.href = 'app_consultantuserhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false
            }



            return false;
        }
    } catch (err) {
        $('#display_loading').addClass('hideme');
    }
}

function setCurrentLocationOfUser(responseData, response) {
    try {
        var apiParams = {};
        if (responseData) {
            $('#display_loading').addClass('hideme');
            // Add Custome function Call here
            localStorage.setItem('locationPingJson', JSON.stringify(responseData));
            var userDeviceObj = responseData.userDeviceObj;
            if (responseData.data) {
                responseData = responseData.data;
            }
            var tokenKey = response.appTokenDetails.authToken;
            var secretKey = response.appTokenDetails.authSecretKey;
            var queryMode = 'mylist';
            var roleName = localStorage.getItem('roleName');

            if (roleName == 'customer') { window.location.href = 'app_userhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey; return false }
        }
    } catch (err) {
    }
}


function apiCall(params, callback) {
    try {
        var https = new XMLHttpRequest();
        var URL = params.URL;
        https.open("POST", URL, true);
        https.setRequestHeader('content-type', 'application/json');
        https.setRequestHeader("token", params.token);
        if (params.token) delete params.token;

        https.onreadystatechange = function () {
            if (https.readyState == 4 && https.status == 200) {
                var response = https.responseText;
                if (typeof response != 'object') {
                    response = JSON.parse(response);
                }
                callback(response);
            }
        }
        params = JSON.stringify(params);
        https.send(params);
    } catch (err) {

    }
}

function setloginNativeCallBack(responseData) {
    // try {
    //     if (responseData) {
    //         var userDeviceObj = responseData.userDeviceObj;
    //         if (responseData.data) {
    //             responseData = responseData.data;
    //         }
    //         var tokenKey = responseData.authToken;
    //         var secretKey = responseData.authSecretKey;
    //         var queryMode = 'mylist';
    //         var roleName = localStorage.getItem('roleName');

    //         if (roleName == "user") {
    //             window.location.href = 'customerhome_5c5bfb8d5cdfed047d18806f.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
    //             return false
    //         }
    //     };
    // } catch (err) { };
}
// function on login MFA Required
function authOtpReceived(codeDeliveryDetails) {
    try {
        resetFormInputs();
        if (forgotEmail) {
            $('#newPasswordDiv').removeClass('hide');

            //$('.otp-input').attr('type', 'tel');
            $('.outer_starcontainer').addClass('hide');
            $('#page_changepassword').removeClass('hide');
            $('#display_loading').addClass('hideme');
            // $(".cognitoError").html('OTP has sent to your email').addClass('success_message').removeClass('error_message');
            // $(".cognitoError").show();
            $('#display_loading').addClass('hideme');

        } else {
            $('#newPasswordDiv').addClass('hide');

            //$('.otp-input').attr('type', 'tel');
            $('.outer_starcontainer').addClass('hide');
            $('#page_otpverify').removeClass('hide');
            $('#display_loading').addClass('hideme');
            $(".cognitoError").html('OTP has sent to your email').addClass('success_message').removeClass('error_message');
            $(".cognitoError").show();
            $('#display_loading').addClass('hideme');

        }


    } catch (error) {
        console.log('Error in authOtpReceived', error);
    }
}

// function on auth Failure
function onAuthFailure(err, ERROR_CODE) {
    try {
        $('#sgstrongpasswordmessage').addClass('hide');
        console.log('----------------err.code--------------------', err.code);
        if (err && err.code && err.code == 'InvalidParameterException') {
            $('#display_loading').addClass('hideme');
            objCognitoUser = null;
            $('#sgstrongpasswordmessage').removeClass('hide');
            return;
        } else if (err && err.code && err.code == 'PasswordResetRequiredException') {
            objCognitoUser = null;
            $('#forogtPassword').trigger('click');
            return;
        } else if (err && err.code && err.code == 'CodeMismatchException') {
            $('.outer_starcontainer').addClass('hide');
            $('#page_otpverify').removeClass('hide');
            $('#display_loading').addClass('hideme');
            if (ERROR_CODE[err.code]) {
                message = ERROR_CODE[err.code];
            }
            $(".cognitoError").html(message).addClass('error_message').removeClass('success_message');
            $(".cognitoError").show();
        }
        else if (err && err.code && err.code == "UserNotConfirmedException") {
            signupInfo = loginInfo;
            changePassword = true;
            //signupInfo.username = loginInfo.username;
            resendConfirmationCode(signupInfo);
            $(".cognitoError").html(message).addClass('error_message').removeClass('success_message');
            $(".cognitoError").show();
            //$('.outer_starcontainer').addClass('hide');
            //$('#page_otpverify').removeClass('hide');
            //$('#display_loading').addClass('hideme');
        } else if (err && err.code && err.code == "ExpiredCodeException") {
            $('.outer_starcontainer').addClass('hide');
            $('#page_otpverify').removeClass('hide');
            $('#display_loading').addClass('hideme');
            $(".cognitoError").html(message).addClass('error_message').removeClass('success_message');
            $(".cognitoError").show();
        } else if (err && err.message == "User password cannot be reset in the current state.") {
            $(".cognitoError").html("Please contact administrator to reset the password. ").addClass('error_message').removeClass('success_message');
            $(".cognitoError").show();
            $('#display_loading').addClass('hideme');
        } else {
            $('#display_loading').addClass('hideme');
            var message = 'Processing error. Please try again';
            if (!(err.message.indexOf("registered/verified") > 0) && err.message.indexOf("password") > 0 && err.code != "NotAuthorizedException") {
                err.code = "InvalidPasswordException"
            }

            if (ERROR_CODE[err.code]) {
                message = ERROR_CODE[err.code];
            }
            if (err.code == "UsernameExistsException" && err.message.indexOf("email already exists")) {
                message = err.message;
            }
            if (err.message) {
                message = err.message;
            }
            $(".cognitoError").html(message).addClass('error_message').removeClass('success_message');
            $(".cognitoError").show();
        }
    } catch (error) {
        console.log('Error in authOtpReceived', error);
    }
}

// function on change password
function updateUserPassword() {
    try {
        changePassword = true;
        $('#display_loading').addClass('hideme');
        $('.outer_starcontainer').addClass('hide');
        $('#page_changepassword').removeClass('hide');
    } catch (error) {
        console.log('Error in authOtpReceived', error);
    }
}

// function on change password
function updateUserPasswordV2() {
    try {
        completeNewPasswordChallenge('Alh$' + CognitoConfig.APPID);
    } catch (error) {
        console.log('Error in authOtpReceived', error);
    }
}

// function on password chnaged
function onPasswordChanged(data) {
    try {
        $('#display_loading').addClass('hideme');
        resetFormInputs();
        $('.outer_starcontainer').addClass('hide');
        $('#page_login').removeClass('hide');
    } catch (error) {
        console.log('Error in onPasswordChanged', error);
    }
}

// function on signup done
function signupCompleted(data) {
    try {
        $('#display_loading').addClass('hideme');
        resetFormInputs();
        $('.outer_starcontainer').addClass('hide');
        $('#page_login').removeClass('hide');
    } catch (error) {
        console.log('Error in onPasswordChanged', error);
    }
}

// get mobile device info
function getDeviceInfo() {
    try {
        var appJSON = {};
        appJSON.nextButtonCallback = 'setDeviceInfo';
        var isAndroid = navigator.userAgent.toLowerCase().indexOf('android');
        if (isAndroid > -1) {
            window.Android.getDeviceInfo(JSON.stringify(appJSON));
        } else {
            setupWebViewJavascriptBridge(function (bridge) {
                bridgeObj = bridge;
                bridgeObj.callHandler('getDeviceInfo', JSON.stringify(appJSON), function (response) { });
                bridgeObj.registerHandler('setDeviceInfo', function (responseData, responseCallback) {
                    setDeviceInfo(responseData)
                });
            });
        }
    } catch (err) {
        console.log('Error in getDeviceInfo', err);
    }
}

// reset all inputs
function resetFormInputs() {
    try {
        $('.error_message').hide();
        $('.success_message').hide();
        $('input').val('');
        Materialize.updateTextFields();
    } catch (error) {
        console.log('Error in resetFormInputs', error)
    }
}

function resetHokuPassword(email, tokenKey, IDENTITY_TOKEN) {
    var objParamsList = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsList.email = email;
    objParamsList.subdomain = CognitoConfig.SUBhokuapps;
    objParamsList.ajaXCallURL = ajaXCallURL;
    objParamsList.tokenKey = tokenKey;

    $.ajax({
        url: CognitoConfig.GATEWAY_URL + '/milestone003/resethokuPassword',
        data: objParamsList,
        type: 'POST',
        success: function (response) {
            if (response.status != undefined && response.status == 0) {
                doAppLogin(IDENTITY_TOKEN)
            } else {
                $('#display_loading').addClass('hideme')
            }
        },
        error: function (xhr, status, error) {
            $('#display_loading').addClass('hideme')
        },
    });
}

// do app login
function doAppLogin(IDENTITY_TOKEN) {
    try {
        writeLog("weblog : doAppLogin --- " + IDENTITY_TOKEN + "  login_cognito.js");
        if (IDENTITY_TOKEN) {
            //Need to set authorization token in all gatway api calls
            $.ajaxSetup({
                headers: { Authorization: IDENTITY_TOKEN },
            });
            var apigClient = apigClientFactory.newClient(CognitoConfig.GATEWAY_URL);
            var params = {
                "Content-Type": "application/json",
                Authorization: IDENTITY_TOKEN,
            };
        } else {
            var apigClient = apigClientFactory.newClient(CognitoConfig.GATEWAY_URL);
            //Need to set authorization token in all gatway api calls
            var params = {
                "Content-Type": "application/json",
            };
        }

        var additionalParams = {};
        var objParams = deviceInfo ? deviceInfo : {};
        objParams.email = loginInfo.email;
        objParams.username = loginInfo.email;
        objParams.subdomain = 'milestone003org';

        if (IDENTITY_TOKEN) {
            objParams.cit = IDENTITY_TOKEN;
        } else {
            objParams.password = "Hoku@123";
            objParams.roleName = "customer";
        }

        objParams.appID = CognitoConfig.APPID;
        objParams.appUrl = CognitoConfig.APP_URL;
        objParams.POOLID = CognitoConfig.USER_POOL_ID;
        $('#display_loading').removeClass('hideme');
        $('#inactiveuser_error').hide();
        writeLog("weblog : rootPost ---  login_cognito.js");
        apigClient.rootPost(params, objParams, additionalParams)
            .then(function (response) {
                //This is where you would put a success callback
                response = response.data ? response.data : response;
                if (response.status == 0 && response.user) {

                    if (response.appUser && response.appUser.status && response.appUser.status == 'Pending') {
                        $('#display_loading').addClass('hideme');
                        $('#inactiveuser_error').html("Your account is wating for approval.");
                        $('#inactiveuser_error').show();
                        $('#email5').focus();
                        return false;
                    }

                    if (response.appUser && response.appUser.status && response.appUser.status == 'Inactive') {
                        $('#display_loading').addClass('hideme');
                        $('#inactiveuser_error').html("Your account is deactivated.");
                        $('#inactiveuser_error').show();
                        $('#email5').focus();
                        return false;
                    }

                    if (response.appUser && response.appUser.status && response.appUser.status == 'Rejected') {
                        $('#display_loading').addClass('hideme');
                        $('#inactiveuser_error').html("Your account is rejected.");
                        $('#inactiveuser_error').show();
                        $('#email5').focus();
                        return false;
                    }

                    if (response.appUser && JSON.stringify(response.appUser) != "{}" && response.objGetUserDetailsWithmenu) {
                        response.objGetUserDetailsWithmenu.userEmailDetails = response.appUser.email;
                    }
                    else {
                        resetHokuPassword(objParams.username, response.appTokenDetails.authToken, IDENTITY_TOKEN);
                        return;
                    }

                    // //response.objGetUserDetailsWithmenu.menuList = menuList;
                    // localStorage.setItem('roleName', response.appTokenDetails.roleName);
                    localStorage.setItem('IDENTITY_TOKEN', IDENTITY_TOKEN);
                    // localStorage.setItem('userID', response.user.userId);
                    // localStorage.setItem('objGetUserDetailsWithmenu', JSON.stringify(response.objGetUserDetailsWithmenu));
                    // localStorage.setItem('perms', JSON.stringify(response.perms));
                    // localStorage.setItem('user', JSON.stringify(response.user));
                    // localStorage.setItem('organizationID', response.user.organizationId);
                    // localStorage.setItem('country', response.appUser.country);
                    // localStorage.setItem('CDN_THUMB', 'https://dxrq26z7a1rw3.cloudfront.net');
                    // localStorage.setItem('CDN_THUMB', response.CDN_THUMB);
                    // if (response.appUser && response.appUser.userphotoupload && response.appUser.userphotoupload[0]) {
                    //     localStorage.setItem('profileThumb', response.appUser.userphotoupload[0].mediaID);
                    // } else {
                    //     localStorage.removeItem('profileThumb');
                    // }
                    // var roleName = response.appTokenDetails.roleName;
                    // if (response.appUser && response.appUser.status && response.appUser.status == 'Inactive') {
                    //     $('#display_loading').addClass('hideme');
                    //     $('#email4_error').html("Your account is deactivated.");
                    //     $('#email4_error').show();
                    //     $('#email4').focus();
                    //     return false;
                    // } else if (roleName == "resident") {
                    //     localStorage.setItem('objGetUserDetailsWithmenu', JSON.stringify(response.objGetUserDetailsWithmenu));
                    //     localStorage.setItem('perms', JSON.stringify(response.perms));
                    //     localStorage.setItem('user', JSON.stringify(response.user));
                    //     localStorage.setItem('appUser', JSON.stringify(response.appUser));
                    //     localStorage.setItem('organizationID', response.user.organizationId);
                    //     localStorage.setItem('CDN_THUMB', 'https://dxrq26z7a1rw3.cloudfront.net');
                    //     localStorage.setItem('CDN_THUMB', response.CDN_THUMB);
                    //     if (response.appUser && response.appUser.userphotoupload && response.appUser.userphotoupload[0]) {
                    //         localStorage.setItem('profileThumb', response.appUser.userphotoupload[0].mediaID + '_compressed.png');
                    //     } else {
                    //         localStorage.removeItem('profileThumb');
                    //     }
                    //     localStorage.setItem('tokenData', JSON.stringify(response.tokenData));

                    //     var tokenKey = response.tokenData.token;
                    //     var secretKey = response.tokenData.secretKey;
                    //     localStorage.setItem('tokenData', JSON.stringify(response.tokenData));
                    //      loginNativeCallWrapper(response, '5c5bfb8d5cdfed047d18806f');

                    //     window.location.href = 'residenthome_5c5bfb8d5cdfed047d18806f.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                    //     return false
                    // } else {
                    //     $('#display_loading').addClass('hideme');
                    //     $('#email4_error').html("Please enter correct details.");
                    //     $('#email4_error').show();
                    //     $('#email4').focus();
                    //     return false;
                    // }

                    localStorage.setItem('roleName', response.appTokenDetails.roleName);
                    localStorage.setItem('userID', response.user.userId);

                    localStorage.setItem('objGetUserDetailsWithmenu', JSON.stringify(response.objGetUserDetailsWithmenu));
                    localStorage.setItem('perms', JSON.stringify(response.perms));
                    localStorage.setItem('user', JSON.stringify(response.user));
                    localStorage.setItem('appUser', JSON.stringify(response.appUser));
                    localStorage.setItem('organizationID', response.user.organizationId);
                    // localStorage.setItem('CDN_THUMB', response.CDN_THUMB);
                    // localStorage.setItem('CDN_THUMB', response.CDN_THUMB);

                    localStorage.setItem('CDN_PATH', response.CDN_PATH);
                    localStorage.setItem('CDN_THUMB', response.CDN_THUMB);

                    //localStorage.setItem('CDN_PATH', "https://d1hlq0tvec6h4x.cloudfront.net");
                    //localStorage.setItem('CDN_THUMB', "https://d1hlq0tvec6h4x.cloudfront.net"); 

                    // localStorage.setItem('CDN_PATH', 'https://dxrq26z7a1rw3.cloudfront.net');
                    // localStorage.setItem('CDN_THUMB', 'https://d1hlq0tvec6h4x.cloudfront.net');

                    if (response.appUser && response.appUser.userphotoupload && response.appUser.userphotoupload[0]) {
                        localStorage.setItem('profileThumb', response.appUser.userphotoupload[0].mediaID);
                    } else {
                        localStorage.removeItem('profileThumb');
                    }
                    localStorage.setItem('tokenData', JSON.stringify(response.tokenData));
                    loginNativeCallWrapper(response, '5c5bfb8d5cdfed047d18806f');
                    return false;

                } else if (response && response.status == 2) {
                    shareAppData('Your account is disable. Please contact admin.')
                    return false;
                } else {
                    $(".cognitoError").html('').addClass('error_message').removeClass('success_message');
                    $(".cognitoError").show();
                }
                $('#display_loading').addClass('hideme');
            }).catch(function (result) {
                //This is where you would put an error callback
                $('#display_loading').addClass('hideme');
                $('#didntreceiveotp9').removeProp('disabled');
            });
    } catch (error) {
        console.log('Error in doAppLogin', error)
    }
}

function setDeviceInfo(response) {
    try {
        if (response) {
            deviceInfo = response;
        }
    } catch (err) {
        console.log('Error in setDeviceInfo', err);
    }
}

function refreshGoogleToken() {
    $('#display_loading').removeClass('hideme');
    localStorage.removeItem('objGetUserDetailsWithmenu');
    var appJSON = {};
    appJSON.nextButtonCallback = 'processGoogleToken';
    appJSON.colorCode = '#3c3c3c';
    appJSON.launchNative = false;
    appJSON.roleName = "customer";
    localStorage.setItem("activeMenu", "NewsFeed");
    appJSON.launchNextpage = 'timeline_5b8e725c4d16975f407c97c9.html';
    // appJSON.isFromSocialMedia = true;
    var ISDEV_MODE = localStorage.getItem("ISDEV_MODE");
    if (ISDEV_MODE == "false" || ISDEV_MODE == false) {
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        if (isAndroid > -1) {
            window.Android.refreshGoogleToken(JSON.stringify(appJSON))
        } else {
            setupWebViewJavascriptBridge(function (bridge) {
                var bridgeObj = bridge;
                bridgeObj.callHandler('refreshGoogleToken', appJSON, function (response) { });
                bridgeObj.registerHandler('processGoogleToken', function (responseData, responseCallback) {
                    processGoogleToken(responseData);
                }
                );
            });
        }
    }
}


// function refreshCognitoToken(IDENTITY_TOKEN,callback) {
//     try {

//         isTokenRefreshed = false;
//         var URL = window.location.href;
//         if (IDENTITY_TOKEN && URL.indexOf('login') == -1) {
//             var playload = JSON.parse(atob(IDENTITY_TOKEN.split('.')[1]));
//             var currentTime = new Date().getTime() / 1000;
//             if (currentTime > playload.exp) {
//                 refreshToken(function (IDENTITY_TOKEN) {
//                     if (IDENTITY_TOKEN) {
//                         $.ajaxSetup({
//                             headers: { 'Authorization': IDENTITY_TOKEN }
//                         });
//                         // refresh hoku token
//                         // refreshHokuToken();

//                     }
//                     isTokenRefreshed = true;
//                              callback(true);
//                 });
//             }
//             else {
//                 isTokenRefreshed = true;
//                 callback(true);
//             }
//         }
//         else {
//             isTokenRefreshed = true;
//             callback(true);
//         }
//     } catch (error) {
//         isTokenRefreshed = true;
//         console.log('Error in refreshCognitoToken', error)
//         callback(false);
//     }
// }
function getbannerImage() {
    var paramsType = {};
    //   paramsType.tokenKey = getParameterByName('tokenKey');
    //   paramsType.secretKey = getParameterByName('secretKey');
    //getCountProcessBeforeCallbannerimageupload6(paramsType, function (processBeforeRes) {
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    ajaXCallURL = 'https://milestone.hokuapps.com';
    $.ajax({
        url: ajaXCallURL + '/api/showslider_app_login_Loginbanner5da73cac545050343288ce7alblbannerbannerimageupload',
        data: paramsType,
        type: 'POST',
        success: function (response) {
            localStorage.setItem('bannerimages', JSON.stringify(response));

            if (response.status == 0) {
                makeSlidesbannerimageupload6(response.data);
            } else {
                makeSlidesbannerimageupload6([]);
            }
        },
        error: function (xhr, status, error) { },
    });
    // });
}

function makeSlidesbannerimageupload6(data) {
    var slide = '';
    var htmlString = '';
    var CDN_PATH = 'https://dp5sk5vkj97qs.cloudfront.net/5da73d1167a1b6026c1c0bc3/5da73cac545050343288ce7a/';
    let title = '';
    let description = '';
    if (data && data.length == 1) {
        title = data[0].title || '';
        description = data[0].description || '';
        data = data[0].userphotoupload ? data[0].userphotoupload : [];

    }
    if (data && data.length > 0) {
        for (let index = 0; index < data.length; index++) {
            const element = data[index];
            var mediaID;
            if (element && element.userphotoupload && element.userphotoupload[0]) {
                mediaID = element.userphotoupload[0].mediaID;
            } else if (element && element.mediaID) {
                mediaID = element.mediaID;
            }
            if (data[index] && data.length != 1) {
                title = data[index].title || '';
                description = data[index].description || '';
            }
            slide += ' <div class="swiper-slide" href="#one!" >';
            slide += '    <div class="row  col s12" style="padding: 0px" !important;>';
            slide += '       <div id="image6_div" style="text-align: center;">';
            slide += '          <img  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + mediaID + '_compressed.png" style="width:100%; height:192px">';
            slide += '       </div>';
            slide += '    </div>';
            slide += '    <div class="row  col s12" style="padding: 0px;font-size:22px;font-weight:bold;color:#af935d; text-align:center !important; font-family: \'Roboto\', sans-serif;"> ' + title + '';
            slide += '    </div>';
            slide += '    <div class="row  col s12" style="padding: 0px;font-size:16px;color:#000000; text-align:center !important; font-family: \'Roboto\', sans-serif;"> ' + description + '';
            slide += '    </div>';
            slide += '        </div>';
        }
        if (slide) {
            $('#bannerimageupload6').html(slide);
        }
        swiper = new Swiper('.swiper-container .swiper1', {
            autoplay: {
                delay: 2500,
                disableOnInteraction: false,
            },
            watchOverflow: true,
            pagination: {
                el: '.swiper-pagination ',
            },
        });
        $('.dynamic-slider-view').removeClass('shimmer');
    }
}






function getbannerImage_signup() {
    var paramsType = {};
    //   paramsType.tokenKey = getParameterByName('tokenKey');
    //   paramsType.secretKey = getParameterByName('secretKey');
    //getCountProcessBeforeCallbannerimageupload6(paramsType, function (processBeforeRes) {
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    ajaXCallURL = 'https://milestone.hokuapps.com';
    $.ajax({
        url: ajaXCallURL + '/api/showslider_app_signup_Signupbanner5da73cac545050343288ce7alblbannerbannerimageupload',
        data: paramsType,
        type: 'POST',
        success: function (response) {
            localStorage.setItem('bannerimages', JSON.stringify(response));

            if (response.status == 0) {
                makeSlidesbannerimageupload6_signup(response.data);
            } else {
                makeSlidesbannerimageupload6_signup([]);
            }
        },
        error: function (xhr, status, error) { },
    });
    // });
}

function makeSlidesbannerimageupload6_signup(data) {
    var signupslide = '';
    var htmlString = '';
    var CDN_PATH = 'https://dp5sk5vkj97qs.cloudfront.net/5da73d1167a1b6026c1c0bc3/5da73cac545050343288ce7a/';
    let title = '';
    let description = '';
    if (data && data.length == 1) {
        title = data[0].title || '';
        description = data[0].description || '';
        data = data[0].userphotoupload ? data[0].userphotoupload : [];
    }
    if (data && data.length > 0) {
        for (let index = 0; index < data.length; index++) {
            const element = data[index];
            var mediaID;
            if (element && element.userphotoupload && element.userphotoupload[0]) {
                mediaID = element.userphotoupload[0].mediaID;
            } else if (element && element.mediaID) {
                mediaID = element.mediaID;
            }
            if (data[index] && data.length != 1) {
                title = data[index].title || '';
                description = data[index].description || '';
            }
            signupslide += ' <div class="swiper-slide" href="#one!" >';
            signupslide += '    <div class="row  col s12" style="padding: 0px" !important;>';
            signupslide += '       <div id="image6__signup_div" style="text-align: center;">';
            signupslide += '          <img  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + mediaID + '_compressed.png" style="width:100%; height:150px">';
            signupslide += '       </div>';
            signupslide += '    </div>';
            signupslide += '    <div class="row  col s12 hide" style="padding: 0px;font-size:22px;font-weight:bold;color:#af935d; text-align:center !important; font-family: \'Roboto\', sans-serif;"> ' + title + '';
            signupslide += '    </div>';
            signupslide += '    <div class="row  col s12 hide" style="padding: 0px;font-size:16px;color:#000000; text-align:center !important; font-family: \'Roboto\', sans-serif;"> ' + description + '';
            signupslide += '    </div>';
            signupslide += '        </div>';
        }
        if (signupslide) {
            $('#bannerimageupload6__signup').html(signupslide);
        }
        swiper2 = new Swiper('.swiper-container .swiper2', {
            autoplay: {
                delay: 2500,
                disableOnInteraction: false,
            },
            watchOverflow: true,
            pagination: {
                el: '.swiper-pagination2',
            },
        });
        $('.dynamic-slider-view').removeClass('shimmer');
    }
}
