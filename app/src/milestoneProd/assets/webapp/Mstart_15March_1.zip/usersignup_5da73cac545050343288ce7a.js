
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
 var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on('click', '#signup14', function () {
  var objParams = {};
  objParams.isDelete = 0;
  var confirmpassword = $.trim($('#confirmpassword11').val());
 if($('#confirmpassword11_div').is(':visible')){
  if(confirmpassword == ''){
    $('#confirmpassword11_error').show();
    $('#confirmpassword11').fadeIn(1000);
    errorFields.push('confirmpassword11');
  }
  else{
    $('#confirmpassword11_error').hide();
  }
  }
 if($('#confirmpassword11_div').is(':visible')){
  objParams.confirmpassword = confirmpassword;
 }
  var customerid = $.trim($('#customerid13').val());
 if($('#customerid13_div').is(':visible')){
  if(customerid == ''){
    $('#customerid13_error').show();
    $('#customerid13').fadeIn(1000);
    errorFields.push('customerid13');
  }
  else{
    $('#customerid13_error').hide();
  }
  }
 if($('#customerid13_div').is(':visible')){
  objParams.customerid = customerid;
 }
  var email = $.trim($('#email7').val());
 if($('#email7_div').is(':visible')){
  if(email == ''){
    $('#email7_error').show();
    $('#email7').fadeIn(1000);
    errorFields.push('email7');
    } else if (typeof EMAIL_REGEX !== 'undefined' && EMAIL_REGEX && !EMAIL_REGEX.test(email)){
        $('#email7_error').html('Incorrect email format').show();
        $('#email7').focus();
        return false;
  }
  else{
    $('#email7_error').hide();
  }
  }
 if($('#email7_div').is(':visible')){
  objParams.email = email;
 }
  var contactnumber = $.trim($('#contactnumber9').val());
 if($('#contactnumber9_div').is(':visible')){
  if(contactnumber == ''){
    $('#contactnumber9_error').show();
    $('#contactnumber9').fadeIn(1000);
    errorFields.push('contactnumber9');
  }
  else{
    $('#contactnumber9_error').hide();
  }
  }
 if($('#contactnumber9_div').is(':visible')){
  objParams.contactnumber = contactnumber;
 }
  var name = $.trim($('#name6').val());
 if($('#name6_div').is(':visible')){
  if(name == ''){
    $('#name6_error').show();
    $('#name6').fadeIn(1000);
    errorFields.push('name6');
  }
  else{
    $('#name6_error').hide();
  }
  }
 if($('#name6_div').is(':visible')){
  objParams.name = name;
 }
  var password = $.trim($('#password10').val());
 if($('#password10_div').is(':visible')){
  if(password == ''){
    $('#password10_error').show();
    $('#password10').fadeIn(1000);
    errorFields.push('password10');
  }
  else{
    $('#password10_error').hide();
  }
  }
 if($('#password10_div').is(':visible')){
  objParams.password = password;
 }
  var referalcode = $.trim($('#referalcode8').val());
 if($('#referalcode8_div').is(':visible')){
  objParams.referalcode = referalcode;
 }
  
 if(password != confirmpassword){
    $('#confirmpassword11_error').html('Password and Confirm password should be same.');
    $('#confirmpassword11_error').show();
    $('#confirmpassword11').focus();
    return false;
 } else {
    $('#confirmpassword11_error').html('Confirm Password is required');
 }
  if(errorFields && errorFields.length){
      $('#display_loading').addClass('hideme');
      var firstErrorField = errorFields[0];
      errorFields = []
      $('#'+ firstErrorField).focus();
      $('#'+ firstErrorField).focus();
      return false;
  }
   objParams.offlineDataID =  localStorage.getItem("offlineDataID");
  $('#undefined').prop('disabled', true);
  $('#display_loading').removeClass('hideme');
   var recordID = $('#recordID').val();
  if (addSessionComments.length > 0) {
      objParams.addSessionComments = addSessionComments;
  } else {
      objParams.addSessionComments = [];
  }
  if (typeof(addedFiles) != 'undefined' && addedFiles.length > 0) {
      objParams.addedFiles = addedFiles;
  } else {
      objParams.addedFiles = [];
  }
   var parentID = $('#parentID').val();
   var parentName = $('#parentName').val();
   objParams.isDelete = 0;
   if(parentID != ''){
      objParams.parentID = parentID;
      objParams.parentName = parentName
   }
   objParams.lastpage = 'usersignup'
   localStorage.setItem('usersignup',JSON.stringify(objParams))
   var dataObj = {};
    var tokenKey = $('#tokenKey').val();
    var queryMode = $('#queryMode').val();
    var secretKey = $('#secretKey').val();
    objParams.subdomain = 'milestone003'
      if(dataObj && Object.keys(dataObj).length > 0) {
          objParams = dataObj;
      }
      objParams.subdomain = 'milestone003org'
      objParams.IsAdmin = "No";
     var ajaXCallURL = $('#ajaXCallURL').val();
      objParams.rolename = 'customer';
      objParams.appID = '5da73cac545050343288ce7a';
      objParams.integrationName = 'milestone003';
      localStorage.clear(); 
                       createNewThingINProcessBeforeCallsignup14(objParams, function (processBeforeRes) {
      $.ajax({
      url: ajaXCallURL + '/milestone003/hokuexternalsignup5da73cac545050343288ce7a',
      data: objParams,
      type: 'POST',
      success: function(response) {
        if (response.status != undefined && response.status == 0) {
 			localStorage.setItem('objGetUserDetailsWithmenu', JSON.stringify(response.objGetUserDetailsWithmenu));
 			localStorage.setItem('perms', JSON.stringify(response.perms));
 			localStorage.setItem('user', JSON.stringify(response.user));
 			localStorage.setItem('appUser', JSON.stringify(response.appUser));
 			localStorage.setItem('organizationID', response.user.organizationId);
 			localStorage.setItem('userID', response.user.userId);
 			localStorage.setItem('CDN_PATH', response.CDN_PATH);
 			localStorage.setItem('CDN_THUMB', response.CDN_THUMB);
 	  	    if(response.appUser){
 			    localStorage.setItem('appUser', JSON.stringify(response.appUser));
          }
 	  	    if(response.appUser && response.appUser.userphotoupload && response.appUser.userphotoupload[0]){
 			    localStorage.setItem('profileThumb', response.appUser.userphotoupload[0].mediaID);
          } else {
              localStorage.removeItem('profileThumb');
 			} 
 			localStorage.setItem('tokenData', JSON.stringify(response.tokenData));
 			loginNativeCallWrappersignup14(response, '5da73cac545050343288ce7a');
 			return false;
        } else if(response.errorMessage){
            $('#display_loading').addClass('hideme');
            $('#confirmpassword_error').html(response.errorMessage).show();
            return false;
        } else {
            $('#display_loading').addClass('hideme');
            return false;
        }
     },
     error: function(xhr, status, error) {}
   });
                         }); // end of CreateNewThingin Session ID Process Before Call 
  });//end of Event SIGN UP_is_click 
 var forwardChekbox = [];
 var isOpenForwardPopup = 0;
 var objParams = {};
 var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on('click', '#login5', function () {
  var tokenKey = getParameterByName('tokenKey');
 var secretKey = getParameterByName('secretKey');
 var queryMode = getParameterByName('queryMode');
 var recordID = getParameterByName('recordID');
 queryMode = 'mylist'
  window.location.href = 'login_5da73cac545050343288ce7a.html?queryMode='+ queryMode+'&tokenKey='+tokenKey+ '&secretKey=' + secretKey
  return false;
  });//end of Event Log In_is_click 
 var forwardChekbox = [];
 var isOpenForwardPopup = 0;
 var objParams = {};
 var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on('click', '#backbutton1', function () {
  var tokenKey = getParameterByName('tokenKey');
 var secretKey = getParameterByName('secretKey');
 var queryMode = getParameterByName('queryMode');
 var recordID = getParameterByName('recordID');
 queryMode = 'add'
  window.location.href = 'login_5da73cac545050343288ce7a.html?queryMode='+ queryMode+'&tokenKey='+tokenKey+ '&secretKey=' + secretKey
  return false;
  });//end of Event backbutton_is_click 
 var forwardChekbox = [];
 var isOpenForwardPopup = 0;
 var objParams = {};
  $(document).on('focusout', '#referalcode8', function () {
 	var objParams = {};
 	$('#display_loading').removeClass('hideme');
 	objParams.referralCode = $('#referalcode8').val();
 	var ajaXCallURL = $.trim($('#ajaXCallURL').val());
 	$.ajax({
 		url: ajaXCallURL + '/milestone003/verifyUserReferralCode5da73cac545050343288ce7a',
 		data: objParams,
 		type: 'POST',
 		success: function (response) {
 				$('#display_loading').addClass('hideme');
          verifyUserReferralCodeAfterCallReferraldetails5da73cac545050343288ce7a(response, function(){
 				if (response.status != undefined && response.status == 0) {
 			    	$('#display_loading').addClass('hideme');
 			    	$('#referalcode8_error').addClass('correct').removeClass('incorrect');
 			    	$('#referalcode8_error').html(response.error).show();
 			    	return false;
 				} else {
 			    	$('#display_loading').addClass('hideme');
 			    	$('#referalcode8_error').addClass('incorrect').removeClass('correct');
 			    	$('#referalcode8_error').html(response.error).show();
 			    	return false;
 				}
		    });
 		},
 		error: function (xhr, status, error) {
 			$('#display_loading1').addClass('hideme');
 			$('#referalcode8').removeProp('disabled');
 		},
 	});
 	return false;
 });
});//end of ready 
                 function createNewThingINProcessBeforeCallsignup14(objParams,callback) {
 callback();
       }
       function loginNativeCallWrappersignup14(response, appID) {
           try {
               var queryMode = $('#queryMode').val();
               var appJSON = {};
               appJSON.organizationID = response.user.organizationId;
               appJSON.userID = response.user.userId;
               appJSON.appID = $('#appID').val();
               appJSON.nextButtonCallback = 'setloginNativeCallBacksignup14';
               appJSON.action = queryMode;
               appJSON.colorCode = '#3c3c3c';
               appJSON.response = response;
               appJSON.launchNative = false;
               appJSON.authToken = response.appTokenDetails.authToken;
               appJSON.authSecretKey = response.appTokenDetails.authSecretKey;
               appJSON.roleName = response.appTokenDetails.roleName;
               appJSON.expiredTime = response.appTokenDetails.expiredTime;
               appJSON.launchNextpage = 'app_userhome_5da73cac545050343288ce7a.html'
       
               var roleName = response.appTokenDetails.roleName;
               localStorage.setItem('roleName', roleName);
               var ISDEV_MODE = localStorage.getItem('ISDEV_MODE'); 
           	  var DEV_MODE  = getParameterByName('devmode');
               if (ISDEV_MODE == 'true' || DEV_MODE) {
                   var tokenKey = response.appTokenDetails.authToken;
                   var secretKey = response.appTokenDetails.authSecretKey;
                   var queryMode = 'mylist';
                   window.location.href = 'app_userhome_5da73cac545050343288ce7a.html?queryMode=add&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                       return false
               } else {
                   var isAndroid = navigator.userAgent.toLowerCase().indexOf('android');
                   if (isAndroid > -1) {
                       window.Android.loginNativeCallV2(JSON.stringify(appJSON))
                   } else {
                       bridgeObj.callHandler('loginNativeCall', appJSON, function(response) {});
                       bridgeObj.registerHandler('setloginNativeCallBacksignup14', function(responseData, responseCallback) {
                           setloginNativeCallBacksignup14(responseData)
                       });
                   }
                }
             } catch (err) {
                 $('#display_loading').addClass('hideme');
             }
         }
      function setloginNativeCallBacksignup14(responseData) {
          try {
              if (responseData) {
                  var userDeviceObj = responseData.userDeviceObj;
                  if (responseData.data) {
                      responseData = responseData.data;
                  }
                  var tokenKey = responseData.authToken;
                  var secretKey = responseData.authSecretKey;
                  var queryMode = 'mylist';
                  var domainName = $('#domainName').val();
                  var ajaXCallURL=  CognitoConfig.GATEWAY_URL;
                  var objParams = {};
                  objParams.organizationID = responseData.organizationID;
                  objParams.userID = responseData.userID;
                  objParams.appID = responseData.appID;
                  objParams.tokenKey = tokenKey;
                  objParams.secretKey = secretKey;
                  objParams.userDeviceObj = userDeviceObj;
                  appJSON.Authorization =  localStorage.getItem('IDENTITY_TOKEN');

                  objParams.isLogin = true;
                  if(responseData.roleName){
                        objParams.roleName = responseData.roleName;
                  }
                  $.ajax({
                      url: ajaXCallURL + '/api/addUserDeviceForApp_5da73cac545050343288ce7a',
                      data: objParams,
                      type: 'POST',
                      success: function(response) {
                          if (response.status == 0) {
                              var roleName = localStorage.getItem('roleName');
                   window.location.href = 'app_userhome_5da73cac545050343288ce7a.html?queryMode=add&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                                  return false
                              }
                      },
                      error: function(xhr, status, error) {},
                  });
              };
          } catch (err) {};
      } 
 function verifyUserReferralCodeAfterCallReferraldetails5da73cac545050343288ce7a(response,callback) {
 callback(); 
 }
