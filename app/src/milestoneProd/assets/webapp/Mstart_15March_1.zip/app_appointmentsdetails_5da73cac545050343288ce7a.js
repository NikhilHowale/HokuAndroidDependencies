
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
  $('#display_loading1').removeClass('hideme');
  $('#display_loading').removeClass('hideme');
  $('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
    $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

  var objParamsToken = {};
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  objParamsToken.tokenKey = getParameterByName('tokenKey');
  objParamsToken.secretKey = getParameterByName('secretKey');

  var userRole = $('#userRole').val();
  var userID = $('#userID').val();
  var createrOfRecord = $('#createrOfRecord').val();
  var queryMode = getParameterByName('queryMode');
  var recordID = $.trim($('#recordID').val());
  var addSessionComments = [];
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on('click', '#confirmappointment29', function () {
    var objParams = {};
    var clientname = $.trim($('#clientname10').val());
    var obj = {}
    if ($('#clientname10_div').is(':visible')) {
      if (clientname == '') {
        $('#clientname10_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientname10'] = 'divtag';
        validAll = false;
      } else {
        $('#clientname10_error').hide();
      }
    }
    if ($('#clientname10_div').is(':visible')) {
      objParams.clientname = clientname;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var note = $.trim($('#note28').val());
    var obj = {}
    if ($('#note28_div').is(':visible')) {
      if (note == '') {
        $('#note28_error').show();
        if (!Object.keys(errorFields).length) errorFields['note28'] = 'divtag';
        validAll = false;
      } else {
        $('#note28_error').hide();
      }
    }
    if ($('#note28_div').is(':visible')) {
      objParams.note = note;
    }
    var slotdate = $.trim($('#slotdate7').val());
    var obj = {}
    if ($('#slotdate7_div').is(':visible')) {
      if (slotdate == '') {
        $('#slotdate7_error').show();
        if (!Object.keys(errorFields).length) errorFields['slotdate7'] = 'divtag';
        validAll = false;
      } else {
        $('#slotdate7_error').hide();
      }
    }
    if ($('#slotdate7_div').is(':visible')) {
      objParams.slotdate = slotdate;
    }
    var clientname = $.trim($('#clientname10').val());
    var obj = {}
    if ($('#clientname10_div').is(':visible')) {
      if (clientname == '') {
        $('#clientname10_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientname10'] = 'divtag';
        validAll = false;
      } else {
        $('#clientname10_error').hide();
      }
    }
    if ($('#clientname10_div').is(':visible')) {
      objParams.clientname = clientname;
    }
    var policytype_name = $.trim($('#policytype_name12').val());
    var obj = {}
    if ($('#policytype_name12_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name12_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name12'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name12_error').hide();
      }
    }
    if ($('#policytype_name12_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var clientname = $.trim($('#clientname10').val());
    var obj = {}
    if ($('#clientname10_div').is(':visible')) {
      if (clientname == '') {
        $('#clientname10_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientname10'] = 'divtag';
        validAll = false;
      } else {
        $('#clientname10_error').hide();
      }
    }
    if ($('#clientname10_div').is(':visible')) {
      objParams.clientname = clientname;
    }
    var policytype_name = $.trim($('#policytype_name12').val());
    var obj = {}
    if ($('#policytype_name12_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name12_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name12'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name12_error').hide();
      }
    }
    if ($('#policytype_name12_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var slotdate = $.trim($('#slotdate7').val());
    var obj = {}
    if ($('#slotdate7_div').is(':visible')) {
      if (slotdate == '') {
        $('#slotdate7_error').show();
        if (!Object.keys(errorFields).length) errorFields['slotdate7'] = 'divtag';
        validAll = false;
      } else {
        $('#slotdate7_error').hide();
      }
    }
    if ($('#slotdate7_div').is(':visible')) {
      objParams.slotdate = slotdate;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var clientname = $.trim($('#clientname10').val());
    var obj = {}
    if ($('#clientname10_div').is(':visible')) {
      if (clientname == '') {
        $('#clientname10_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientname10'] = 'divtag';
        validAll = false;
      } else {
        $('#clientname10_error').hide();
      }
    }
    if ($('#clientname10_div').is(':visible')) {
      objParams.clientname = clientname;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var policytype_name = $.trim($('#policytype_name12').val());
    var obj = {}
    if ($('#policytype_name12_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name12_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name12'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name12_error').hide();
      }
    }
    if ($('#policytype_name12_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var ordersnumber = $.trim($('#ordersnumber15').val());
    var obj = {}
    if ($('#ordersnumber15_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber15_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber15'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber15_error').hide();
      }
    }
    if ($('#ordersnumber15_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var name = $.trim($('#name18').val());
    var obj = {}
    if ($('#name18_div').is(':visible')) {
      if (name == '') {
        $('#name18_error').show();
        if (!Object.keys(errorFields).length) errorFields['name18'] = 'divtag';
        validAll = false;
      } else {
        $('#name18_error').hide();
      }
    }
    if ($('#name18_div').is(':visible')) {
      objParams.name = name;
    }
    var clientcontact = $.trim($('#clientcontact21').val());
    var obj = {}
    if ($('#clientcontact21_div').is(':visible')) {
      if (clientcontact == '') {
        $('#clientcontact21_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientcontact21'] = 'divtag';
        validAll = false;
      } else {
        $('#clientcontact21_error').hide();
      }
    }
    if ($('#clientcontact21_div').is(':visible')) {
      objParams.clientcontact = clientcontact;
    }
    var email = $.trim($('#email24').val());
    var obj = {}
    if ($('#email24_div').is(':visible')) {
      if (email == '') {
        $('#email24_error').html('Email is required');
        $('#email24_error').show();
        if (!Object.keys(errorFields).length) errorFields['email24'] = 'divtag';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email24_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email24'] = 'divtag';
        validAll = false;
      } else {
        $('#email24_error').hide();
      }
    }
    if ($('#email24_div').is(':visible')) {
      objParams.email = email;
    }
    var note = $.trim($('#note28').val());
    var obj = {}
    if ($('#note28_div').is(':visible')) {
      if (note == '') {
        $('#note28_error').show();
        if (!Object.keys(errorFields).length) errorFields['note28'] = 'divtag';
        validAll = false;
      } else {
        $('#note28_error').hide();
      }
    }
    if ($('#note28_div').is(':visible')) {
      objParams.note = note;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var policytype_name = $.trim($('#policytype_name12').val());
    var obj = {}
    if ($('#policytype_name12_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name12_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name12'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name12_error').hide();
      }
    }
    if ($('#policytype_name12_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var ordersnumber = $.trim($('#ordersnumber15').val());
    var obj = {}
    if ($('#ordersnumber15_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber15_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber15'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber15_error').hide();
      }
    }
    if ($('#ordersnumber15_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var name = $.trim($('#name18').val());
    var obj = {}
    if ($('#name18_div').is(':visible')) {
      if (name == '') {
        $('#name18_error').show();
        if (!Object.keys(errorFields).length) errorFields['name18'] = 'divtag';
        validAll = false;
      } else {
        $('#name18_error').hide();
      }
    }
    if ($('#name18_div').is(':visible')) {
      objParams.name = name;
    }
    var clientcontact = $.trim($('#clientcontact21').val());
    var obj = {}
    if ($('#clientcontact21_div').is(':visible')) {
      if (clientcontact == '') {
        $('#clientcontact21_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientcontact21'] = 'divtag';
        validAll = false;
      } else {
        $('#clientcontact21_error').hide();
      }
    }
    if ($('#clientcontact21_div').is(':visible')) {
      objParams.clientcontact = clientcontact;
    }
    var email = $.trim($('#email24').val());
    var obj = {}
    if ($('#email24_div').is(':visible')) {
      if (email == '') {
        $('#email24_error').html('Email is required');
        $('#email24_error').show();
        if (!Object.keys(errorFields).length) errorFields['email24'] = 'divtag';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email24_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email24'] = 'divtag';
        validAll = false;
      } else {
        $('#email24_error').hide();
      }
    }
    if ($('#email24_div').is(':visible')) {
      objParams.email = email;
    }
    var note = $.trim($('#note28').val());
    var obj = {}
    if ($('#note28_div').is(':visible')) {
      if (note == '') {
        $('#note28_error').show();
        if (!Object.keys(errorFields).length) errorFields['note28'] = 'divtag';
        validAll = false;
      } else {
        $('#note28_error').hide();
      }
    }
    if ($('#note28_div').is(':visible')) {
      objParams.note = note;
    }
    var ordersnumber = $.trim($('#ordersnumber30').val());
    if ($('#ordersnumber30_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber30').val());
    if ($('#ordersnumber30_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber30').val());
    if ($('#ordersnumber30_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var slotdate = $.trim($('#slotdate7').val());
    var obj = {}
    if ($('#slotdate7_div').is(':visible')) {
      if (slotdate == '') {
        $('#slotdate7_error').show();
        if (!Object.keys(errorFields).length) errorFields['slotdate7'] = 'divtag';
        validAll = false;
      } else {
        $('#slotdate7_error').hide();
      }
    }
    if ($('#slotdate7_div').is(':visible')) {
      objParams.slotdate = slotdate;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var clientname = $.trim($('#clientname10').val());
    var obj = {}
    if ($('#clientname10_div').is(':visible')) {
      if (clientname == '') {
        $('#clientname10_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientname10'] = 'divtag';
        validAll = false;
      } else {
        $('#clientname10_error').hide();
      }
    }
    if ($('#clientname10_div').is(':visible')) {
      objParams.clientname = clientname;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var policytype_name = $.trim($('#policytype_name12').val());
    var obj = {}
    if ($('#policytype_name12_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name12_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name12'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name12_error').hide();
      }
    }
    if ($('#policytype_name12_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var ordersnumber = $.trim($('#ordersnumber15').val());
    var obj = {}
    if ($('#ordersnumber15_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber15_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber15'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber15_error').hide();
      }
    }
    if ($('#ordersnumber15_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var name = $.trim($('#name18').val());
    var obj = {}
    if ($('#name18_div').is(':visible')) {
      if (name == '') {
        $('#name18_error').show();
        if (!Object.keys(errorFields).length) errorFields['name18'] = 'divtag';
        validAll = false;
      } else {
        $('#name18_error').hide();
      }
    }
    if ($('#name18_div').is(':visible')) {
      objParams.name = name;
    }
    var clientcontact = $.trim($('#clientcontact21').val());
    var obj = {}
    if ($('#clientcontact21_div').is(':visible')) {
      if (clientcontact == '') {
        $('#clientcontact21_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientcontact21'] = 'divtag';
        validAll = false;
      } else {
        $('#clientcontact21_error').hide();
      }
    }
    if ($('#clientcontact21_div').is(':visible')) {
      objParams.clientcontact = clientcontact;
    }
    var email = $.trim($('#email24').val());
    var obj = {}
    if ($('#email24_div').is(':visible')) {
      if (email == '') {
        $('#email24_error').html('Email is required');
        $('#email24_error').show();
        if (!Object.keys(errorFields).length) errorFields['email24'] = 'divtag';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email24_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email24'] = 'divtag';
        validAll = false;
      } else {
        $('#email24_error').hide();
      }
    }
    if ($('#email24_div').is(':visible')) {
      objParams.email = email;
    }
    var note = $.trim($('#note28').val());
    var obj = {}
    if ($('#note28_div').is(':visible')) {
      if (note == '') {
        $('#note28_error').show();
        if (!Object.keys(errorFields).length) errorFields['note28'] = 'divtag';
        validAll = false;
      } else {
        $('#note28_error').hide();
      }
    }
    if ($('#note28_div').is(':visible')) {
      objParams.note = note;
    }
    var ordersnumber = $.trim($('#ordersnumber30').val());
    if ($('#ordersnumber30_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber30').val());
    if ($('#ordersnumber30_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber30').val());
    if ($('#ordersnumber30_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber30').val());
    if ($('#ordersnumber30_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var clientname = $.trim($('#clientname10').val());
    var obj = {}
    if ($('#clientname10_div').is(':visible')) {
      if (clientname == '') {
        $('#clientname10_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientname10'] = 'divtag';
        validAll = false;
      } else {
        $('#clientname10_error').hide();
      }
    }
    if ($('#clientname10_div').is(':visible')) {
      objParams.clientname = clientname;
    }
    var policytype_name = $.trim($('#policytype_name12').val());
    var obj = {}
    if ($('#policytype_name12_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name12_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name12'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name12_error').hide();
      }
    }
    if ($('#policytype_name12_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var ordersnumber = $.trim($('#ordersnumber15').val());
    var obj = {}
    if ($('#ordersnumber15_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber15_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber15'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber15_error').hide();
      }
    }
    if ($('#ordersnumber15_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber15').val());
    var obj = {}
    if ($('#ordersnumber15_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber15_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber15'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber15_error').hide();
      }
    }
    if ($('#ordersnumber15_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var ordersnumber = $.trim($('#ordersnumber15').val());
    var obj = {}
    if ($('#ordersnumber15_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber15_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber15'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber15_error').hide();
      }
    }
    if ($('#ordersnumber15_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var policytype_name = $.trim($('#policytype_name12').val());
    var obj = {}
    if ($('#policytype_name12_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name12_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name12'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name12_error').hide();
      }
    }
    if ($('#policytype_name12_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var ordersnumber = $.trim($('#ordersnumber15').val());
    var obj = {}
    if ($('#ordersnumber15_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber15_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber15'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber15_error').hide();
      }
    }
    if ($('#ordersnumber15_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var name = $.trim($('#name18').val());
    var obj = {}
    if ($('#name18_div').is(':visible')) {
      if (name == '') {
        $('#name18_error').show();
        if (!Object.keys(errorFields).length) errorFields['name18'] = 'divtag';
        validAll = false;
      } else {
        $('#name18_error').hide();
      }
    }
    if ($('#name18_div').is(':visible')) {
      objParams.name = name;
    }
    var clientcontact = $.trim($('#clientcontact21').val());
    var obj = {}
    if ($('#clientcontact21_div').is(':visible')) {
      if (clientcontact == '') {
        $('#clientcontact21_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientcontact21'] = 'divtag';
        validAll = false;
      } else {
        $('#clientcontact21_error').hide();
      }
    }
    if ($('#clientcontact21_div').is(':visible')) {
      objParams.clientcontact = clientcontact;
    }
    var email = $.trim($('#email24').val());
    var obj = {}
    if ($('#email24_div').is(':visible')) {
      if (email == '') {
        $('#email24_error').html('Email is required');
        $('#email24_error').show();
        if (!Object.keys(errorFields).length) errorFields['email24'] = 'divtag';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email24_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email24'] = 'divtag';
        validAll = false;
      } else {
        $('#email24_error').hide();
      }
    }
    if ($('#email24_div').is(':visible')) {
      objParams.email = email;
    }
    var note = $.trim($('#note28').val());
    var obj = {}
    if ($('#note28_div').is(':visible')) {
      if (note == '') {
        $('#note28_error').show();
        if (!Object.keys(errorFields).length) errorFields['note28'] = 'divtag';
        validAll = false;
      } else {
        $('#note28_error').hide();
      }
    }
    if ($('#note28_div').is(':visible')) {
      objParams.note = note;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var clientname = $.trim($('#clientname10').val());
    var obj = {}
    if ($('#clientname10_div').is(':visible')) {
      if (clientname == '') {
        $('#clientname10_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientname10'] = 'divtag';
        validAll = false;
      } else {
        $('#clientname10_error').hide();
      }
    }
    if ($('#clientname10_div').is(':visible')) {
      objParams.clientname = clientname;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var policytype_name = $.trim($('#policytype_name12').val());
    var obj = {}
    if ($('#policytype_name12_div').is(':visible')) {
      if (policytype_name == '') {
        $('#policytype_name12_error').show();
        if (!Object.keys(errorFields).length) errorFields['policytype_name12'] = 'divtag';
        validAll = false;
      } else {
        $('#policytype_name12_error').hide();
      }
    }
    if ($('#policytype_name12_div').is(':visible')) {
      objParams.policytype_name = policytype_name;
    }
    var ordersnumber = $.trim($('#ordersnumber15').val());
    var obj = {}
    if ($('#ordersnumber15_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber15_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber15'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber15_error').hide();
      }
    }
    if ($('#ordersnumber15_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var name = $.trim($('#name18').val());
    var obj = {}
    if ($('#name18_div').is(':visible')) {
      if (name == '') {
        $('#name18_error').show();
        if (!Object.keys(errorFields).length) errorFields['name18'] = 'divtag';
        validAll = false;
      } else {
        $('#name18_error').hide();
      }
    }
    if ($('#name18_div').is(':visible')) {
      objParams.name = name;
    }
    var clientcontact = $.trim($('#clientcontact21').val());
    var obj = {}
    if ($('#clientcontact21_div').is(':visible')) {
      if (clientcontact == '') {
        $('#clientcontact21_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientcontact21'] = 'divtag';
        validAll = false;
      } else {
        $('#clientcontact21_error').hide();
      }
    }
    if ($('#clientcontact21_div').is(':visible')) {
      objParams.clientcontact = clientcontact;
    }
    var email = $.trim($('#email24').val());
    var obj = {}
    if ($('#email24_div').is(':visible')) {
      if (email == '') {
        $('#email24_error').html('Email is required');
        $('#email24_error').show();
        if (!Object.keys(errorFields).length) errorFields['email24'] = 'divtag';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email24_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email24'] = 'divtag';
        validAll = false;
      } else {
        $('#email24_error').hide();
      }
    }
    if ($('#email24_div').is(':visible')) {
      objParams.email = email;
    }
    var note = $.trim($('#note28').val());
    var obj = {}
    if ($('#note28_div').is(':visible')) {
      if (note == '') {
        $('#note28_error').show();
        if (!Object.keys(errorFields).length) errorFields['note28'] = 'divtag';
        validAll = false;
      } else {
        $('#note28_error').hide();
      }
    }
    if ($('#note28_div').is(':visible')) {
      objParams.note = note;
    }
    var ordersnumber = $.trim($('#ordersnumber30').val());
    if ($('#ordersnumber30_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber30').val());
    if ($('#ordersnumber30_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber15').val());
    var obj = {}
    if ($('#ordersnumber15_div').is(':visible')) {
      if (ordersnumber == '') {
        $('#ordersnumber15_error').show();
        if (!Object.keys(errorFields).length) errorFields['ordersnumber15'] = 'divtag';
        validAll = false;
      } else {
        $('#ordersnumber15_error').hide();
      }
    }
    if ($('#ordersnumber15_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var starttime = $.trim($('#starttime8').val());
    var obj = {}
    if ($('#starttime8_div').is(':visible')) {
      if (starttime == '') {
        $('#starttime8_error').show();
        if (!Object.keys(errorFields).length) errorFields['starttime8'] = 'divtag';
        validAll = false;
      } else {
        $('#starttime8_error').hide();
      }
    }
    if ($('#starttime8_div').is(':visible')) {
      objParams.starttime = starttime;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var note = $.trim($('#note28').val());
    var obj = {}
    if ($('#note28_div').is(':visible')) {
      if (note == '') {
        $('#note28_error').show();
        if (!Object.keys(errorFields).length) errorFields['note28'] = 'divtag';
        validAll = false;
      } else {
        $('#note28_error').hide();
      }
    }
    if ($('#note28_div').is(':visible')) {
      objParams.note = note;
    }
    var status = $.trim($('#status11').val());
    var obj = {}
    if ($('#status11_div').is(':visible')) {
      if (status == '') {
        $('#status11_error').show();
        if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
        validAll = false;
      } else {
        $('#status11_error').hide();
      }
    }
    if ($('#status11_div').is(':visible')) {
      objParams.status = status;
    }
    var ordersnumber = $.trim($('#ordersnumber30').val());
    if ($('#ordersnumber30_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber30').val());
    if ($('#ordersnumber30_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var tempobjParams = getParams(window.location.href)
    function extend(obj, src) {
      for (var key in src) {
        if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
      }
      return obj;
    }
    objParams = extend(objParams, tempobjParams);
    var recordID = $('#recordID').val();
    objParams.isDelete = 0;
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParams.tokenKey = getParameterByName('tokenKey');
    objParams.secretKey = getParameterByName('secretKey');
    objParams.offlineDataID = localStorage.getItem("offlineDataID");
    var queryMode = getParameterByName('queryMode')
    if (queryMode == 'mylist1') {
      objParams.callUrl = ajaXCallURL + '/milestone003/saveAjaxorders0830confirmappointmentapp_appointmentsdetails';
    } else {
      objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxorders0830confirmappointmentapp_appointmentsdetails';
      objParams.recordID = recordID;
    }
    if (errorFields && Object.keys(errorFields).length) {
      $('#display_loading1').addClass('hideme');
      for (var firstErrorField in errorFields) {
        var controlType = errorFields[firstErrorField];
        errorFields = []
        var errField = $('#' + firstErrorField);
        if (controlType == 'dropdown') {
          errField.prev().prev().focus();
        } else {
          errField.focus()
        }
        validAll = true;
        return false;
      }
    }
    if (!validAll) {
      validAll = true;
      return false;
    }
    $('#confirmappointment29').prop('disabled', true);
    $('#display_loading1').removeClass('hideme');
    if (addSessionComments.length > 0) {
      objParams.addSessionComments = addSessionComments;
    } else {
      objParams.addSessionComments = [];
    }
    var parentID = $('#parentID').val();
    var parentName = $('#parentName').val();
    if (parentID != '') {
      objParams.parentID = parentID;
      objParams.parentName = parentName
    }
    if (typeof (addedFiles) != "undefined" && addedFiles && addedFiles.length > 0) {
      objParams.addedFiles = addedFiles;
    }
    objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    objParams.organizationID = $("#organizationID").val();;
    objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    objParams.organizationID = $("#organizationID").val();;
    processBeforeCallForSave0830confirmappointment(objParams, {}, function (processBeforeRes) {
      $.ajax({
        url: objParams.callUrl,
        data: objParams,
        type: 'POST',
        success: function (response) {
          if (response.status == 0) {


            $('#display_loading1').addClass('hideme');
            $('.modal').modal('open');
            var top = $("#card_bottompopup1615829482016_row").position().top;
            var left = $("#card_bottompopup1615829482016_row").position().left;
            var width = $("#card_bottompopup1615829482016_row").width();
            var height = $("#card_bottompopup1615829482016_row").height();
            top = top + height + 21;
           var marginleft = left + (width/2) -60 ; 
           var leftvalue = marginleft +'px' ;
            //$("#done12").
            $("#done123")[0].style.setProperty('margin-left', leftvalue, 'important');

            
            $("#done123").css({ top: top});
           
            // response.nextPage = 'app_financialresultdetails';
            // processAfterCallForSave0830confirmappointment(response,function(processAfterRes){
            //   var tokenKey = getParameterByName('tokenKey');
            //   var secretKey = getParameterByName('secretKey');
            //   var queryMode = getParameterByName('queryMode');
            //   queryMode = queryMode.replace('edit', '');
            //   localStorage.setItem("headerPageName", 'app_financialresultdetails'); 
            //   var queryString = window.location.search.slice(1); 
            //   var newQuery = queryString +'&queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey+'&queryMode=mylist'+'&ordersid=' + response.data._id+'&recordID=' + response.data._id 
            //   var queryParams = queryStringToJSON(newQuery); 
            //   queryString = $.param(queryParams); 
            //   queryString = queryString.replace(/\+/g, "%20"); 
            //   queryString = decodeURIComponent(queryString);
            //   if (recordID == '') { 
            //   window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?'+ queryString
            //   }else{
            //   window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?'+ queryString
            //   }
            //   return false;
            // }); // End of After Process
          } else {
            $('#display_loading1').addClass('hideme');
            $('#2656d_error').html(response.error);
            $('#2656d_error').show();
          }
          $('#confirmappointment29').removeProp('disabled');
        },
        error: function (xhr, status, error) {
          $('#display_loading1').addClass('hideme');
          $('#confirmappointment29').removeProp('disabled');
        },
      });
      return false;
    }); // End of Before Process
  });//end of Event Confirm Appointment_is_click 

  $(document).on('click', '#done123', function () {
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var queryMode = getParameterByName('queryMode');
    var recordID = getParameterByName('recordID');
    queryMode = 'mylist'
    window.location.href = 'app_appointmentslisting_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey
    return false;
  });//end of Event Done_is_click 



  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#backbutton1', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_timeslot';
      var queryParams = queryStringToJSON();
     // queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error)
    }
  })
  var paramsEdit = {};
  paramsEdit.tokenKey = getParameterByName('tokenKey');
  paramsEdit.secretKey = getParameterByName('secretKey')
  getRecordByIDProcessBeforeCall210874(paramsEdit, function (processBeforeRes) {
    $.ajax({
      url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_appointmentsdetails_Orders5da73cac545050343288ce7a',
      data: paramsEdit,
      type: 'POST',
      jsonpCallback: 'callback',
      success: function (response) {
        $('#display_loading').addClass('hideme');
        getRecordByIDProcessAfterCall210874(response, function (processBeforeRes) {
          if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
            var objParamsList = {};
            var queryMode = $('#queryMode').val();
            objParamsList.queryMode = queryMode;;
            var tokenKey = $('#tokenKey').val();;
            objParamsList.tokenKey = tokenKey;;
            if (!$('#appointmentdetails2').html()) {
              $('#appointmentdetails2').append(response.recordDetails.undefined);
            }
            if (!$('#appointmentid14').html()) {
              $('#appointmentid14').append(response.recordDetails.undefined);
            }
            $('#ordersnumber30_value').html(response.recordDetails.ordersnumber);
            if (!$('#backbutton1').html()) {
              $('#backbutton1').append(response.recordDetails.undefined);
            }
            if (!$('#consultant17').html()) {
              $('#consultant17').append(response.recordDetails.undefined);
            }
            if (!$('#emailaddress23').html()) {
              $('#emailaddress23').append(response.recordDetails.undefined);
            }
            if (!$('#mobilenumber20').html()) {
              $('#mobilenumber20').append(response.recordDetails.undefined);
            }
            if (!$('#notes26').html()) {
              $('#notes26').append(response.recordDetails.undefined);
            }
            if (!$('#clientcontact21').html()) {
              $('#clientcontact21').append(response.recordDetails.clientcontact);
            }
            if (!$('#clientname10').html()) {
              $('#clientname10').append(response.recordDetails.clientname);
            }
            if (!$('#name18').html()) {
              $('#name18').append(response.recordDetails.name);
            }
            response.recordDetails['slotdate_preserved'] = response.recordDetails['slotdate'];
            response.recordDetails['slotdate'] = response.recordDetails['slotdate'] ? moment(new Date(response.recordDetails['slotdate'])).format('DD MMMM YYYY') : '';
            if (!$('#slotdate7').html()) {
              $('#slotdate7').append(response.recordDetails.slotdate);
            }
            response.recordDetails['slotdate'] = response.recordDetails['slotdate_preserved'];
            if (!$('#email24').html()) {
              $('#email24').append('<a id="emailImg" class="mailtolink" href="mailto:' + response.recordDetails.email + '">' + response.recordDetails.email + '</a>');
            }
            if (!$('#note28').html()) {
              $('#note28').append(response.recordDetails.note);
            }
            if (!$('#ordersnumber15').html()) {
              $('#ordersnumber15').append(response.recordDetails.ordersnumber);
            }
            if (!$('#policytype_name12').html()) {
              $('#policytype_name12').append(response.recordDetails.policytype_name);
            }
            if (!$('#starttime8').html()) {
              $('#starttime8').append('<span class="prefixlink">Time</span>' + response.recordDetails.starttime);
            }
            if (!$('#status11').html()) {
              $('#status11').append(response.recordDetails.status);
            }

            Materialize.updateTextFields();
            $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

          }
        }); // end of getRecord By ID
      },
      error: function (xhr, status, error) {
        handleError(xhr, status, error);
      },
    });
  }); // end of getRecord By ID

});//end of ready
function getParams(url) {
  var urlParams = {};
  url.replace(
    new RegExp("([^?=&]+)(=([^&]*))?", "g"),
    function ($0, $1, $2, $3) {
      if ($3 && $3 != 'undefined') urlParams[$1] = $3;
    }
  );
  return urlParams;
}
function processBeforeCallForSave0830confirmappointment(objParams, response, callback) {


  objParams.type = 'appointments';
  objParams.status = 'Requested';
  var appointmentID = localStorage.getItem("appointmentID");
  if (appointmentID && appointmentID != '' && appointmentID != null) {
    objParams.recordID = appointmentID;
  }

  callback();
}
function processAfterCallForSave0830confirmappointment(response, callback) {


  localStorage.removeItem("appointmentID");
  callback();
}
function getRecordByIDProcessBeforeCall210874(paramsType, callback) {
  var response = paramsType;

  var appointmentID = localStorage.getItem("appointmentID");
  if (appointmentID && appointmentID != '' && appointmentID != null) {
    paramsType.recordID = appointmentID;


  }
  if (!paramsType.recordID) {
    paramsType.recordID = getParameterByName('recordID');
  }

  callback();
}
function getRecordByIDProcessAfterCall210874(response, callback) {
  callback();
}
