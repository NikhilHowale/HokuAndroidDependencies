
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#track26', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_livetracking'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - track26", error) 
		} 
	})
      var paramsEdit = {};
      paramsEdit.tokenKey = getParameterByName('tokenKey');
      paramsEdit.secretKey = getParameterByName('secretKey') 
                       getRecordByIDProcessBeforeCall211357(paramsEdit, function (processBeforeRes) {
      $.ajax({
          url: ajaXCallURL+'/milestone003/getRecordByCustomeQuery_app_myorderdriverdetails_Orders5da73cac545050343288ce7a',
          data: paramsEdit,
          type: 'POST',
          jsonpCallback: 'callback',
          success: function (response) { 
                       getRecordByIDProcessAfterCall211357(response, function (processBeforeRes) {
              if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                  var objParamsList = {};
                  var queryMode = $('#queryMode').val(); 
                  objParamsList.queryMode = queryMode;;
                  var tokenKey = $('#tokenKey').val();;
                  objParamsList.tokenKey = tokenKey;;
  if(!$('#backbutton1').html()){
            $('#backbutton1').append(response.recordDetails.undefined);
 }
  if(!$('#call20').html()){
            $('#call20').append(response.recordDetails.undefined);
 }
  if(!$('#chat18').html()){
            $('#chat18').append(response.recordDetails.undefined);
 }
  if(!$('#driverdetails2').html()){
            $('#driverdetails2').append(response.recordDetails.undefined);
 }
  if(!$('#droplocation24').html()){
            $('#droplocation24').append(response.recordDetails.undefined);
 }
  if(!$('#eta14').html()){
            $('#eta14').append(response.recordDetails.undefined);
 }
  if(!$('#droplocation_name25').html()){
            $('#droplocation_name25').append(response.recordDetails.droplocation_name);
 }
  if(!$('#name12').html()){
            $('#name12').append(response.recordDetails.name);
 }
 response.recordDetails['pickupdate_preserved'] = response.recordDetails['pickupdate'] ;
 response.recordDetails['pickupdate'] = response.recordDetails['pickupdate']  ? moment(new Date(response.recordDetails['pickupdate'])).format('DD MMM YYYY') : '';
  if(!$('#pickupdate15').html()){
            $('#pickupdate15').append(response.recordDetails.pickupdate);
 }
 response.recordDetails['pickupdate'] =  response.recordDetails['pickupdate_preserved'];
  if(!$('#pickuplocation_name23').html()){
            $('#pickuplocation_name23').append(response.recordDetails.pickuplocation_name);
 }
    // getrecordbycustomquery - Stage - 111111111111
    if(response.recordDetails['userphotoupload'] && response.recordDetails['userphotoupload'].length > 0 ) {
    	if(response.recordDetails['userphotoupload'][0].displayType = 'html'){
    		var eleParent = $('#userphotoupload10').parent();
    	    for(var key in response.recordDetails['userphotoupload']){
    	        var objImage = response.recordDetails['userphotoupload'][key];
if(response.recordDetails['userphotoupload'][key].name=='Audio'){
         var token =  $('#tokenKey').val();
         if( token && token != '' ){
             token = $('#tokenKey').val();
         }else {
             token = getParameterByName('tokenKey');
         }
         var mediaIDa = response.recordDetails['userphotoupload'][0].mediaID
         var filenamea = response.recordDetails['userphotoupload'][0].fileName
          var CDN_PATH2 = 'https://devfiles.hokuapps.com/downloadOriginal?f='+mediaIDa+'&fn='+filenamea+'&t='+token
          var url = CDN_PATH2
}else{
 var filetodisplay = getuploadedfilepreview(objImage.fileNm); 
 if(filetodisplay && filetodisplay != objImage.fileNm){
          var url = filetodisplay ;
 } else {
          var url = CDN_PATH + objImage.mediaID+'_compressed.png';
 }
}
if(response.recordDetails['userphotoupload'][key].name=='Audio'){
    	        var html = '';
               html+='<div class="col s12" style="float: right;">'
               html+='<audio class="" src="' + url + '" controls></audio>'
               html+='</div>'
}else{
               var html = '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + url + '" />';
}
    	        if(!key || key == '0'){
    	        	eleParent.html(html);
    	        } else {
    	        	eleParent.append(html);
    	        } 
    	    }                
    	} else {
if(response.recordDetails['userphotoupload'][key].name=='Audio'){
    	    var url = CDN_PATH + response.recordDetails['userphotoupload'][0].mediaID;
}else{
    	    var url = CDN_PATH + response.recordDetails['userphotoupload'][0].mediaID+'_compressed.png';
}
    	    $('#userphotoupload10').attr("src", url);
    	}
    } 
  if(!$('#vehiclenumber13').html()){
            $('#vehiclenumber13').append('<span class="prefixlink">Vehicle Number:</span>'+response.recordDetails.vehiclenumber);
 }
  if(!$('#pickuplocation22').html()){
            $('#pickuplocation22').append(response.recordDetails.undefined);
 }
         if(response.recordDetails.pickuplocation && response.recordDetails.droplocation){ 
          var map = new google.maps.Map(document.getElementById('showdirection6'), {
              zoom: 10,
              center: {lat: response.recordDetails.pickuplocation.coordinates[1], lng: response.recordDetails.pickuplocation.coordinates[0]},
              mapTypeId: 'terrain'
          });
          var flightPlanCoordinates = [ {lat: response.recordDetails.pickuplocation.coordinates[1], lng: response.recordDetails.pickuplocation.coordinates[0]},
                                         {lat: response.recordDetails.droplocation.coordinates[1], lng: response.recordDetails.droplocation.coordinates[0]}
          ];
          var lineSymbol = {
              path: google.maps.SymbolPath.CIRCLE
          };
          var flightPath = new google.maps.Polyline({
              path: flightPlanCoordinates,
              geodesic: true,
              strokeColor: '#006400',
              strokeOpacity: 1.0,
              strokeWeight: 2,
              icons: [{
                  icon: lineSymbol,
                  offset: '0%'
              }, {
                  icon: lineSymbol,
                  offset: '100%'
              }]
          });
          flightPath.setMap(map);
               $('#showdirection6').addClass('showdirectiongooglemap');
      }

              Materialize.updateTextFields();
                $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);
  
              } 
              }); // end of getRecord By ID
          },
          error: function (xhr, status, error) {
              handleError(xhr, status, error); 
          },
      }); 
              }); // end of getRecord By ID
   
});//end of ready 
                 function getRecordByIDProcessBeforeCall211357(paramsType,callback) { 
                 var response = paramsType;
 
if(getParameterByName('ordersid') && getParameterByName('ordersid') != 'undefined'){paramsType.recordID = getParameterByName('ordersid')} else if(getParameterByName('recordID') && getParameterByName('recordID') != 'undefined'){paramsType.recordID = getParameterByName('recordID')};callback(); 
                 } 
                 function getRecordByIDProcessAfterCall211357(response,callback) {
 callback(); 
                 }