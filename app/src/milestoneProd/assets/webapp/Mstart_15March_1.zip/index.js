function setupWebViewJavascriptBridge(callback) {
  if (window.WebViewJavascriptBridge) {
    return callback(WebViewJavascriptBridge);
  }
  if (window.WVJBCallbacks) {
    return window.WVJBCallbacks.push(callback);
  }
  window.WVJBCallbacks = [callback];
  var WVJBIframe = document.createElement("iframe");
  WVJBIframe.style.display = "none";
  WVJBIframe.src = "wvjbscheme://__BRIDGE_LOADED__";
  document.documentElement.appendChild(WVJBIframe);
  setTimeout(function () {
    document.documentElement.removeChild(WVJBIframe);
  }, 0);
}

function fingurePrintAuth(resAuthToken) {
    if (resAuthToken.status == "1") {
        var tokenKey = getParameterByName("tokenKey");
        var secretKey = getParameterByName("secretKey");

        var roleName = localStorage.getItem('userRole')
        if (roleName.toLowerCase() === "customer") {
          window.location.href = "app_userhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=" + tokenKey + "&secretKey=" + secretKey;
          return false;
        } else if (roleName.toLowerCase() === "consultant") {
          window.location.href = "app_consultantuserhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=" + tokenKey + "&secretKey=" + secretKey;
          return false;
        } else {
          window.location.href = "splash1_5da73cac545050343288ce7a.html";
          return false;
        }
    } else {
    writeLog('weblog : fingurPrint not valid -  index.js ');
    window.location.href = 'login_cognito.html';
    return false;
  }
}


$(document).ready(function () {
  var tokenKey = getParameterByName("tokenKey");
  var secretKey = getParameterByName("secretKey");

  // if no tokenkey or secretKey
  if (!tokenKey || !secretKey) {
    writeLog("weblog : tokenKey or secretKey missing from native tokenKey=" + tokenKey + "secretKey=" + secretKey + " -  index.js");
    tokenKey = localStorage.tokenKey;
    secretKey = localStorage.secretKey;
  }

  const roleName = localStorage.getItem("roleName");

  // if no tokenkey or secretKey
  if (!tokenKey || !secretKey) {
    writeLog("weblog : tokenKey or secretKey missing from localStorage + native tokenKey=" + tokenKey + "secretKey=" + secretKey + " -  index.js");
    window.location.href = "splash1_5da73cac545050343288ce7a.html";
    return false;
  }

  // if no rolename found
  if (!roleName) {
    writeLog("weblog : roleName = " + roleName + " missing -  index.js");
    window.location.href = "splash1_5da73cac545050343288ce7a.html";
    return false;
  }

  var appJSON = {};
  appJSON.authToken = tokenKey;
  appJSON.authSecretKey = secretKey;
  appJSON.roleName = roleName;
  appJSON.nextButtonCallback = "fingurePrintAuth";
  var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
  if (isAndroid > -1) {
    window.Android.authenticateWithTouchID(JSON.stringify(appJSON));
  } else {
    setupWebViewJavascriptBridge(function (bridgeObj) {
      bridgeObj.callHandler("authenticateWithTouchID", appJSON, function (response) {});
      bridgeObj.registerHandler("fingurePrintAuth", function (responseData, responseCallback) {
        fingurePrintAuth(responseData);
      });
    });
  }

  /**
   * End :: Token changes
   */

});
