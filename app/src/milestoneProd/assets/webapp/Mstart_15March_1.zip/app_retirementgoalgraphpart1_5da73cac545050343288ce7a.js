$(document).ready(function () {
    var isPie2 = true
    financialCalculator = JSON.parse(localStorage.financialCalculator)
    var LeftForAgeCurrent = [];
    var CurrentLeft = [];
    var CurrentLeft2 = [];
    var YourGoalLeft = [];
    var YourGoalLeft2 = [];
    var YearlyExp = [];
    var YearlyExp2 = [];
    var annualExpensesArray = [];
    var annualExpensesArray2 = [];
    var TotAnnAmtLeft = 0;
    var objExpectedLumpsumat = [];
    var ageArray = [];
    console.log(financialCalculator)
    var currentAge = financialCalculator.iamcurrent;
    var RetireAge = financialCalculator.intendedRetireAge;


    var lumpsumhtml = `    <table style="width:90%;border: 1px solid black;border-collapse: collapse; margin-left: 5%;" id="minisummarytable">
    <tr   style="border: 1px solid black;border-collapse: collapse;background-color: #C3A468;color: white;margin-left: 5%;">
   
            <td colspan="3" style="width: 100%; border: 1px solid black;border-collapse: collapse;">
            Lumpsum
            </td>
          
    
    </tr>`;;

    var minisummaryhtml = `    <table style="width:90%;border: 1px solid black;border-collapse: collapse; margin-left: 5%;" id="minisummarytable">
    <tr   style="border: 1px solid black;border-collapse: collapse;background-color: #C3A468;color: white;margin-left: 5%;">
   
    <td colspan="3" style="width: 100%; border: 1px solid black;border-collapse: collapse; text-align:center; font-weight:bold">
    Current Policies
    </td>
  

</tr>

    <tr   style="border: 1px solid black;border-collapse: collapse;background-color: #C3A468;color: white;margin-left: 5%;">
   
            <td style="width: 50%; border: 1px solid black;border-collapse: collapse;">
            Insurer/Self
            </td>
            <td style="width: 25%; border: 1px solid black;border-collapse: collapse;">
            Amount
            
            </td>
            <td style="width: 25%; border: 1px solid black;border-collapse: collapse;">
            Payout Age
    
    </tr>
    <tr   style="border: 1px solid black;border-collapse: collapse;background-color: #C3A468;color: white;margin-left: 5%;">
   
  

    <td colspan="3" style="width: 100%; border: 1px solid black;border-collapse: collapse; text-align:left;  ">
    Passive Income (Monthly)
    </td>
  

</tr>
    
    `;


    var html = `    <table style="width:90%;border: 1px solid black;border-collapse: collapse; margin-left: 5%;" id="datatable">
    <tr   style="border: 1px solid black;border-collapse: collapse;background-color: #C3A468;color: white;margin-left: 5%;">
   
            <td style="width: 15%; border: 1px solid black;border-collapse: collapse;">
                Age
            </td>
            <td style="width: 43%; border: 1px solid black;border-collapse: collapse;">
            Annual Expenses 
            
            </td>
            <td style="width: 42%; border: 1px solid black;border-collapse: collapse;">
            Beginning Cash Flow
    
    </tr>`;



    // Page 1 Calculation
    var monthlyexpnceCurrent = financialCalculator.monthlyexpnceCurrent
    var monthlyPassiveIncomeCurrent = 0;
    var expectedPersonalSaveMatureCurrent = 0;
    var partLumsum = 0;

    var endPayoutYear =
        $(financialCalculator.passiveArray).each(function (index) {

            endPayoutYearCurrent = this['endpayout'];
            if (endPayoutYearCurrent > endPayoutYear) {
                endPayoutYearCurrent = endPayoutYear;
            }
        });

    var passiveArraySorted = financialCalculator.passiveArray.sort((a, b) => parseFloat(a.startpayout) - parseFloat(b.startpayout));
    var passiveArrayEndSorted = financialCalculator.passiveArray.sort((a, b) => parseFloat(a.endpayout) - parseFloat(b.endpayout));
    console.log(passiveArraySorted);
    var counter = 0;
    var rAge = 0;
    //  $(financialCalculator.passiveArray).each(function (index) {


    insuer = ''// this['insuer'];
    passiveincome = 0; //this['passiveincome'];
    startpayout = parseInt(passiveArraySorted[0].startpayout)//this['startpayout'];
    endpayout = 85;//parseInt(passiveArrayEndSorted[0].endpayout);// this['endpayout'];
    if (startpayout.toString() == 'NaN') {
        startpayout = parseInt(financialCalculator.intendedRetireAge);

    }
    // if (endpayout.toString() == 'NaN') {
    //     endpayout = 90;
    // }


    for (rAge = RetireAge; rAge <= endpayout; rAge++) {

        ageArray.push(rAge);
        var passiveincomeTotal = 0;
        passiveincome = 0;
        for (i = 0; i < financialCalculator.passiveArray.length; i++) {
        
            
             if (financialCalculator.passiveArray[i].startpayout <= rAge && financialCalculator.passiveArray[i].endpayout >= rAge) {
                passiveincomeTotal = Number(financialCalculator.passiveArray[i].passiveincome) + Number(passiveincomeTotal);
                passiveincome = passiveincomeTotal;
            }
            // if (financialCalculator.passiveArray[i].endpayout < rAge) {
            //     passiveincome = passiveincome - Number(financialCalculator.passiveArray[i].passiveincome)

            // }
            if (counter == 0) {
                var currentstartendpayout = ''
                //var currentendpayout = ''
                if (financialCalculator.passiveArray[i].startpayout != 'Start of passive income payout' && financialCalculator.passiveArray[i].endpayout != 'End of passive income payout')
                    currentstartendpayout = financialCalculator.passiveArray[i].startpayout + `-` + financialCalculator.passiveArray[i].endpayout

                var passiveincomeamt = ''
                if (financialCalculator.passiveArray[i].passiveincome != '')
                    passiveincomeamt = parseFloat(financialCalculator.passiveArray[i].passiveincome).toFixed(2)
                minisummaryhtml = minisummaryhtml + `   
         
            <tr>
              <td  style="width: 50%; border: 1px solid black;border-collapse: collapse; background-color:white;color: "  >`+ financialCalculator.passiveArray[i].insuer + `</td>
              <td style="width: 25%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black; text-align:right !important; "  >`+ passiveincomeamt + `</td>
              <td style="width: 25%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black; text-align:right !important; "  >`+ currentstartendpayout + `</td>
              
            </tr>`
            }

        }



        monthlyPassiveIncomeCurrent = Number(passiveincome);

        $(financialCalculator.lumbsumArray).each(function (index) {
            if (this['ExpectedLumpsumat'] == rAge && this['ExpectedLumpsumat'] >= RetireAge)
                expectedPersonalSaveMatureCurrent = Number(expectedPersonalSaveMatureCurrent) + Number(this['lumpsumd']);
            else {
                if (this['ExpectedLumpsumat'] < rAge && rAge == RetireAge)
                    expectedPersonalSaveMatureCurrent = Number(expectedPersonalSaveMatureCurrent) + Number(this['lumpsumd']);
            }
        


            if (counter == 0) {

                var lumsumAt = ''
                //var currentendpayout = ''
                if (this['ExpectedLumpsumat'] != 'Payout Year')
                    lumsumAt = this['ExpectedLumpsumat']

                var lumpsumd = ''
                if (this['lumpsumd'] != '')
                    lumpsumd = parseFloat(this['lumpsumd']).toFixed(2)

                lumpsumhtml = lumpsumhtml + `   
                <tr>
                  <td  style="width: 50%; border: 1px solid black;border-collapse: collapse; background-color:white;color: "  >`+ this['insuer'] + `</td>
                  <td style="width: 25%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black; text-align:right !important; "  >`+ lumpsumd + `</td>
                  <td style="width: 25%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black; text-align:right !important;"  >`+ lumsumAt + `</td>
                  
                </tr>`
            }

        })
        for (i = 0; i < financialCalculator.passiveArray.length; i++) {
            if (financialCalculator.passiveArray[i].startpayout <= rAge && rAge == RetireAge && financialCalculator.passiveArray[i].endpayout >= rAge) {
                if (rAge == RetireAge) {
                    expectedPersonalSaveMatureCurrent = expectedPersonalSaveMatureCurrent + ((financialCalculator.passiveArray[i].passiveincome * 12) * (rAge - financialCalculator.passiveArray[i].startpayout));
                }
                else if (rAge> RetireAge && financialCalculator.passiveArray[i].endpayout > rAge) {
                    expectedPersonalSaveMatureCurrent = expectedPersonalSaveMatureCurrent + ((financialCalculator.passiveArray[i].passiveincome * 12) );
                }
               


            }

            else if (financialCalculator.passiveArray[i].startpayout <= rAge && rAge == RetireAge) {
                expectedPersonalSaveMatureCurrent = expectedPersonalSaveMatureCurrent + ((financialCalculator.passiveArray[i].passiveincome * 12) * (financialCalculator.passiveArray[i].endpayout - financialCalculator.passiveArray[i].startpayout));
            }
          

        }
        lastYearLumpSum = expectedPersonalSaveMatureCurrent;

        TotAnnAmtLeft = TotAnnAmtLeft + lastYearLumpSum - (((monthlyexpnceCurrent * ((1 + 0.025) ** (rAge - currentAge))) - monthlyPassiveIncomeCurrent) * 12)
        //TotAnnAmtLeft=lastYearLumpSum-((monthlyexpnceCurrent*((1+0.025)^(rAge-currentAge)))*12)+(monthlyPassiveIncomeCurrent*12)
        
        TotAnnAmtLeft_display   =   TotAnnAmtLeft + (((monthlyexpnceCurrent * ((1 + 0.025) ** (rAge - currentAge)))) * 12);

        //console.log("TotAnnAmtLeft_display" + TotAnnAmtLeft_display)
        let objFileds = {};
        objFileds.Age = rAge;
        objFileds.Left = Number(TotAnnAmtLeft_display).toFixed(2);
        LeftForAgeCurrent.push(objFileds)
        var annualExpenses = (financialCalculator.monthlyexpnceCurrent * (1.025 ** (rAge - currentAge))) * 12
        //TotAnnAmtLeft = TotAnnAmtLeft + annualExpenses;
        CurrentLeft.push([rAge, TotAnnAmtLeft_display]);
        CurrentLeft2.push([TotAnnAmtLeft_display, rAge]);

        expectedPersonalSaveMatureCurrent = 0
        console.log(' 1)  ' + rAge + '   ' + TotAnnAmtLeft_display.toFixed(2))
        
        annualExpenses = parseFloat(annualExpenses.toFixed(2));
        annualExpensesArray.push([rAge, annualExpenses]);
        console.log(' Annual Expenses =   ' + annualExpenses + '  Age = ' + rAge);



        html = html + `
     
     
  
        
         
       </tr>
         
         <tr>
           <td  style="width: 15%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black; text-align: right"  >`+ rAge + `</td>
           <td style="width: 43%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black; text-align: right"  >`+ parseFloat(annualExpensesArray[counter][1]).toFixed(2) + `</td>
           <td style="width: 42%; border: 1px solid black;border-collapse: collapse; background-color:white;color: black; text-align: right"  >`+ parseFloat(TotAnnAmtLeft_display).toFixed(2)  + `</td>
           
         </tr>
    
`
//parseFloat(CurrentLeft[counter][1]).toFixed(2)
        counter++;
    }

    console.log('CurrentLeft')
    console.log(CurrentLeft)
    console.log('annualExpensesArray')
    console.log(annualExpensesArray)

    const data = {
        labels: ageArray,
        datasets: [
            {
                label: 'Beginning Cash Flow',
                data: CurrentLeft,//Utils.numbers(NUMBER_CFG),
                borderColor: "rgba(255,215,0,0.5)",
                backgroundColor: "rgba(255,215,0,0.5)",
                fill: true
            },

            {
                label: 'Annual Expenses',
                data: annualExpensesArray,//Utils.numbers(NUMBER_CFG),

                borderColor: "rgba(97, 233, 237, 0.5)",
                backgroundColor: "rgba(97, 233, 237, 0.5)",
                fill: true
            }

        ]
    };


    const config = {
        type: 'line',
        data: data,
        options: {
            responsive: true,
            plugins: {
                title: {
                    display: true,
                    //text: (ctx) => 'Chart.js Line Chart - stacked=' + ctx.chart.options.scales.y.stacked
                },
                tooltip: {
                    mode: 'index'
                },
            },
            interaction: {
                mode: 'nearest',
                axis: 'x',
                intersect: false
            },
            scales: {
                x: {
                    title: {
                        display: true,
                        text: 'Age'
                    }
                },
                y: {
                    stacked: false,
                    title: {
                        display: true,
                        text: 'Annual Expenses & Beginning Cash Flow'
                    },
                    ticks: {
                        // forces step size to be 50 units
                        stepSize: 50000
                    },
                    min: -250000

                }
            }
        }
    };


    const myChart = new Chart(
        document.getElementById('pie2'),
        config
    );
    $("#chardatagrid").append(html)

    $("#minisummary").append(minisummaryhtml)
    $("#minisummary").append(lumpsumhtml)





    $(document).on('click', '#changeorientation', function (e) {
        $("#pie2").toggleClass("vertical");

        if (isPie2 == true) {

            $("#minisummary").css("top", "180px");
            $("#chardatagrid").css("top", "230px");
            $(".bottominfo").css("top", "150px");
            isPie2 = false;

        }
        else {
            $("#minisummary").css("top", "130px");
            $("#chardatagrid").css("top", "150px");
            $(".bottominfo").css("top", "70px");
            isPie2 = true;
        }





    });

    $(document).on('click', '#nextbtn', function (e) {
        var parent = getParameterByName('parent');
        var nextPage = 'app_retirementgoalstep2';
        var queryParams = queryStringToJSON();
        queryParams["queryMode"] = "mylist";
        var recordID = $(this).attr("recordID");
        if (recordID) {
            queryParams["recordID"] = recordID;
        }
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
        return false;
    });

    $(document).on('click', '#download', function (e) {

        var imageSrc = $('#pie2')[0].toDataURL(); // this stores the base64 image url in imagesrc

        var html = `<html><head></head><body class="app-theme-background-primary-mk app-theme-foreground-primary-mk sgclsapp_retirementcalculateadd"
            style="display: contents;"><div><img  style="margin-left: 10px;"   src="`+ imageSrc + `"></div>`
        var chardivhtml = $("#summarydiv ")[0].innerHTML;
        chardivhtml = chardivhtml.trim();
        var chardivhtml = chardivhtml.replace(/\n|\r/g, "");
        html = html + chardivhtml + `</body></html>`


        var appJSON = {}
        appJSON.htmlPageData = html
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        if (isAndroid === -1) {
            setupWebViewJavascriptBridge(function (bridge) {
                bridge.callHandler("previewHtmlPage", appJSON, function (response) { });
                //   bridge.registerHandler("offlineMode", function (responseData, responseCallback) {
                //offlineMode(responseData);
                // });
            });
        } else {
            window.Android.previewHtmlPage(JSON.stringify(appJSON));
        }
    });
    $(document).on('click', '#backbutton1', function (e) {
        try {
            var element = $(this);
            var rolename = localStorage.getItem("roleName");
            // var nextPage = 'app_custmoreinfodetails';
            var nextPage = 'app_retirementgoalstep1';
            // if (rolename == "consultant") {
            //   nextPage = "app_consultantcustmoreinfodetails";
            // }

            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "update";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - backbutton1", error)
        }
    })
});