
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#status9', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorderslistingstatusfilter'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - status9", error) 
		} 
	})
	$(document).on('click', '.radiodatesfilter', function(e) {
		try {
			var element = $(this);
			var objParams = {};
			objParams.recordID = getParameterByName('recordID');
			if ($(this).attr('recordID')) {
				objParams.recordID = $(this).attr('recordID');
			}
		
			customcodeDueToday(objParams, element,{}, function (processCustomcode) {
			    return false;
			});
		} catch (error) {
			console.log('Error in customcode click', error);
		}
	});
	$(document).on('change', '#enddate15', function(e) {
		try {
			var element = $(this);
			var objParams = {};
			objParams.recordID = getParameterByName('recordID');
			if ($(this).attr('recordID')) {
				objParams.recordID = $(this).attr('recordID');
			}
		
			customcodeBazaar5da73cac545050343288ce7aTo(objParams, element,{}, function (processCustomcode) {
			    return false;
			});
		} catch (error) {
			console.log('Error in customcode click', error);
		}
	});
  $(document).on('click', '#clear3', function () {
   $('#alldate18').val('');
   $('#fromdate14').val('');
   $('#alldate19').val('');
   $('#enddate15').val('');
  localStorage.removeItem('filterchkstatusleads');
  localStorage.removeItem('filterchksourceleads');
  localStorage.removeItem('filterchkownerleads');
  localStorage.removeItem('filterradiodatesleads');
  localStorage.removeItem('filterfromdates');
  localStorage.removeItem('filtertodates');
   $('input[type="checkbox"]').prop("checked",false);
 });
  var alldate18 =  getParameterByName('alldate');
  if(alldate18 != "" && alldate18 != null && alldate18 != 'null' && alldate18 != 'undefined'  && alldate18 != 'false' ){
  	$('#alldate18').val(alldate18);
  }
  var fromdate14 =  getParameterByName('fromdate');
  if(fromdate14 != "" && fromdate14 != null && fromdate14 != 'null' && fromdate14 != 'undefined'  && fromdate14 != 'false' ){
  	$('#fromdate14').val(fromdate14);
  }
  var alldate19 =  getParameterByName('alldate');
  if(alldate19 != "" && alldate19 != null && alldate19 != 'null' && alldate19 != 'undefined'  && alldate19 != 'false' ){
  	$('#alldate19').val(alldate19);
  }
  var enddate15 =  getParameterByName('enddate');
  if(enddate15 != "" && enddate15 != null && enddate15 != 'null' && enddate15 != 'undefined'  && enddate15 != 'false' ){
  	$('#enddate15').val(enddate15);
  }
 var applyFilter = getParameterByName('applyFilter');
 if(applyFilter == 'true' || applyFilter == true ){
 }
 $(document).on('click', '#apply20', function(e) {
  var tokenKey = getParameterByName('tokenKey');
 var secretKey = getParameterByName('secretKey');
 var queryMode = getParameterByName('queryMode');
 var recordID = getParameterByName('recordID');
 
    if( getParameterByName('applyFilter')){
      var applyFilter =  getParameterByName('applyFilter');
    }
  window.location.href = 'app_myorderslisting_5da73cac545050343288ce7a.html?queryMode='+ queryMode+'&tokenKey='+tokenKey+ '&secretKey=' + secretKey + '&recordID='+ recordID+'&applyFilter=' + applyFilter+'&applyFilter=true'
return false;
 });
 var applyFilter = getParameterByName('applyFilter');
 if(applyFilter == 'true' || applyFilter == true ){
 }
 $(document).on('click', '#backbutton1', function(e) {
  var tokenKey = getParameterByName('tokenKey');
 var secretKey = getParameterByName('secretKey');
 var queryMode = getParameterByName('queryMode');
 var recordID = getParameterByName('recordID');
 queryMode = 'mylist'
  window.location.href = 'app_myorderslisting_5da73cac545050343288ce7a.html?queryMode='+ queryMode+'&tokenKey='+tokenKey+ '&secretKey=' + secretKey + '&recordID='+ recordID
return false;
 });
	$(document).on('change', '#fromdate14', function(e) {
		try {
			var element = $(this);
			var objParams = {};
			objParams.recordID = getParameterByName('recordID');
			if ($(this).attr('recordID')) {
				objParams.recordID = $(this).attr('recordID');
			}
		
			customcodeBazaar5da73cac545050343288ce7aFrom(objParams, element,{}, function (processCustomcode) {
			    return false;
			});
		} catch (error) {
			console.log('Error in customcode click', error);
		}
	});
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#region10', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorderslistingsourcefilter'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - region10", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#owner11', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorderslistingownerfilter'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - owner11", error) 
		} 
	})
});//end of ready
          setTimeout(function(){
if(localStorage.getItem('filterradiodatesleads')){
	var arrFilterSelectedBoxSplite = localStorage.getItem('filterradiodatesleads').split(',');
	for(count = 0;count < arrFilterSelectedBoxSplite.length;count++){
		$('.with-gap[value='+arrFilterSelectedBoxSplite[count]+']').prop('checked', true);
	}
} else {
       $('.with-gap[value="alldates"]').prop('checked', true);
       localStorage.setItem('filterradiodatesleads',"appointmentdate-asc");
}
}, 500);
   function customcodeDueToday(objParams, element,response,callback){
      try{ 	    var response = objParams; 	    response.element = element;

	selectDateCheckbox(response, function (responseselectDateCheckbox) {
	if(responseselectDateCheckbox.inValid) {
			Materialize.updateTextFields();
			return false;
 		} else {
			Materialize.updateTextFields();
			return false;
 		}
 });

 function selectDateCheckbox(response, callback) {
 		localStorage.setItem('filterradiodatesleads',element.attr('value'));
	callback({'inValid': 1});
 }
     } catch(err){
          callback();
          // console.log('Error in customcode', err);
     }
 }
          setTimeout(function(){ if(localStorage.getItem('filtertodates')){ 	$('#enddate15').val(localStorage.getItem('filtertodates'));         Materialize.updateTextFields(); }  }, 1000);
   function customcodeBazaar5da73cac545050343288ce7aTo(objParams, element,response,callback){
      try{ 	    var response = objParams; 	    response.element = element;

	selectToDateTextbox(response, function (responseselectToDateTextbox) {
	if(responseselectToDateTextbox.inValid) {
			Materialize.updateTextFields();
			return false;
 		} else {
			Materialize.updateTextFields();
			return false;
 		}
 });

 function selectToDateTextbox(response, callback) {
         setInterval(function(){
             localStorage.setItem('filtertodates',$('#enddate15').val());
         }, 1000);
	callback({'inValid': 1});
 }
     } catch(err){
          callback();
          // console.log('Error in customcode', err);
     }
 }
          setTimeout(function(){ if(localStorage.getItem('filterfromdates')){ 	$('#fromdate14').val(localStorage.getItem('filterfromdates'));         Materialize.updateTextFields(); }  }, 1000);
   function customcodeBazaar5da73cac545050343288ce7aFrom(objParams, element,response,callback){
      try{ 	    var response = objParams; 	    response.element = element;

	selectFromDateTextbox(response, function (responseselectFromDateTextbox) {
	if(responseselectFromDateTextbox.inValid) {
			Materialize.updateTextFields();
			return false;
 		} else {
			Materialize.updateTextFields();
			return false;
 		}
 });

 function selectFromDateTextbox(response, callback) {
         setInterval(function(){
             localStorage.setItem('filterfromdates',$('#fromdate14').val());
         }, 1000);
	callback({'inValid': 1});
 }
     } catch(err){
          callback();
          // console.log('Error in customcode', err);
     }
 }