
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
  $('#display_loading').removeClass('hideme');
  $('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
    $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

  var objParamsToken = {};
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  objParamsToken.tokenKey = getParameterByName('tokenKey');
  objParamsToken.secretKey = getParameterByName('secretKey');

  var userRole = $('#userRole').val();
  var userID = $('#userID').val();
  var createrOfRecord = $('#createrOfRecord').val();
  var queryMode = getParameterByName('queryMode');
  var recordID = $.trim($('#recordID').val());
  var addSessionComments = [];
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  checkConsultant();
  $(document).on('click', '#next11', function () {
   // $('#display_loading').removeClass('hideme');
    var objParams = {};
    var ordersnumber = $.trim($('#ordersnumber12').val());
    if ($('#ordersnumber12_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber12').val());
    if ($('#ordersnumber12_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var note = $.trim($('#note10').val());
    var obj = {}
    if ($('#note10_div').is(':visible')) {
      if (note == '') {
        $('#note10_error').show();
        if (!Object.keys(errorFields).length) errorFields['note10'] = 'textbox';
        validAll = false;
      } else {
        $('#note10_error').hide();
      }
    }
    if ($('#note10_div').is(':visible')) {
      objParams.note = note;
    }
    var ordersnumber = $.trim($('#ordersnumber12').val());
    if ($('#ordersnumber12_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber12').val());
    if ($('#ordersnumber12_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber12').val());
    if ($('#ordersnumber12_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber12').val());
    if ($('#ordersnumber12_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var name = $.trim($('#name13').val());
    if ($('#name13_div').is(':visible')) {
      objParams.name = name;
    }
    var clientcontact = $.trim($('#clientcontact8').val());
    var obj = {}
    if ($('#clientcontact8_div').is(':visible')) {
      if (clientcontact == '') {
        $('#clientcontact8_error').show();
        if (!Object.keys(errorFields).length) errorFields['clientcontact8'] = 'textbox';
        validAll = false;
      } else {
        $('#clientcontact8_error').hide();
      }
    }
    if ($('#clientcontact8_div').is(':visible')) {
      objParams.clientcontact = clientcontact;
    }
    var email = $.trim($('#email9').val());
    var obj = {}
    if ($('#email9_div').is(':visible')) {
      if (email == '') {
        $('#email9_error').html('Email is required');
        $('#email9_error').show();
        if (!Object.keys(errorFields).length) errorFields['email9'] = 'textbox';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email9_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email9'] = 'textbox';
        validAll = false;
      } else {
        $('#email9_error').hide();
      }
    }
    if ($('#email9_div').is(':visible')) {
      objParams.email = email;
    }
    var note = $.trim($('#note10').val());
    var obj = {}
    if ($('#note10_div').is(':visible')) {
      if (note == '') {
        $('#note10_error').show();
        if (!Object.keys(errorFields).length) errorFields['note10'] = 'textbox';
        validAll = false;
      } else {
        $('#note10_error').hide();
      }
    }
    if ($('#note10_div').is(':visible')) {
      objParams.note = note;
    }
    var ordersnumber = $.trim($('#ordersnumber12').val());
    if ($('#ordersnumber12_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber12').val());
    if ($('#ordersnumber12_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber12').val());
    if ($('#ordersnumber12_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber12').val());
    if ($('#ordersnumber12_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var ordersnumber = $.trim($('#ordersnumber12').val());
    if ($('#ordersnumber12_div').is(':visible')) {
      objParams.ordersnumber = ordersnumber;
    }
    var tempobjParams = getParams(window.location.href)
    function extend(obj, src) {
      for (var key in src) {
        if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
      }
      return obj;
    }
    objParams = extend(objParams, tempobjParams);
    var recordID = $('#recordID').val();
    objParams.isDelete = 0;
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParams.tokenKey = getParameterByName('tokenKey');
    objParams.secretKey = getParameterByName('secretKey');
    objParams.offlineDataID = localStorage.getItem("offlineDataID");
    var queryMode = getParameterByName('queryMode');
    $('#display_loading1').removeClass('hideme');
    if (queryMode == 'add') {
      objParams.callUrl = ajaXCallURL + '/milestone003/saveAjaxorders3921nextapp_appointmentsadd';
    } else {
      objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxorders3921nextapp_appointmentsadd';
      objParams.recordID = recordID;
    }
    if (errorFields && Object.keys(errorFields).length) {
      $('#display_loading1').addClass('hideme');
      for (var firstErrorField in errorFields) {
        var controlType = errorFields[firstErrorField];
        errorFields = []
        var errField = $('#' + firstErrorField);
        if (controlType == 'dropdown') {
          errField.prev().prev().focus();
        } else {
          errField.focus()
        }
        validAll = true;
        return false;
      }
    }
    if (!validAll) {
      validAll = true;
      return false;
    }
    $('#next11').prop('disabled', true);
    $('#display_loading1').removeClass('hideme');
    if (addSessionComments.length > 0) {
      objParams.addSessionComments = addSessionComments;
    } else {
      objParams.addSessionComments = [];
    }
    var parentID = $('#parentID').val();
    var parentName = $('#parentName').val();
    if (parentID != '') {
      objParams.parentID = parentID;
      objParams.parentName = parentName
    }
    if (typeof (addedFiles) != "undefined" && addedFiles && addedFiles.length > 0) {
      objParams.addedFiles = addedFiles;
    }
    objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    objParams.organizationID = $("#organizationID").val();;
    objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    objParams.organizationID = $("#organizationID").val();;
    processBeforeCallForSave3921next(objParams, {}, function (processBeforeRes) {
      $.ajax({
        url: objParams.callUrl,
        data: processBeforeRes,
        type: 'POST',
        success: function (response) {
          if (response.status == 0) {
            $('#display_loading1').addClass('hideme');
            response.nextPage = 'app_timeslot'
            processAfterCallForSave3921next(response, function (processAfterRes) {
              var tokenKey = getParameterByName('tokenKey');
              var secretKey = getParameterByName('secretKey');
              var queryMode = getParameterByName('queryMode');
            //  queryMode = queryMode.replace('add', '');
              localStorage.setItem("headerPageName", 'app_timeslot');
              var queryString = window.location.search.slice(1);
              var newQuery = queryString + '&queryMode=add&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&queryMode=add' + '&ordersid=' + response.data._id + '&recordID=' + response.data._id
              var queryParams = queryStringToJSON(newQuery);
              queryString = $.param(queryParams);
              queryString = queryString.replace(/\+/g, "%20");
              queryString = decodeURIComponent(queryString);
              if (recordID == '') {
                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
              } else {
                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
              }
              return false;
            }); // End of After Process
          } else {
            $('#display_loading1').addClass('hideme');
            $('#2656d_error').html(response.error);
            $('#2656d_error').show();
          }
          $('#next11').removeProp('disabled');
        },
        error: function (xhr, status, error) {
          $('#display_loading1').addClass('hideme');
          $('#next11').removeProp('disabled');
        },
      });
      return false;
    }); // End of Before Process
  });//end of Event Next_is_click 
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#backbutton1', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_appointmentslisting';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error)
    }
  })
  var paramsEdit = {};
  paramsEdit.tokenKey = getParameterByName('tokenKey');
  paramsEdit.secretKey = getParameterByName('secretKey')
  if (getParameterByName('clientid') && getParameterByName('clientid') != null && getParameterByName('clientid') != '') {
    paramsEdit.clientid = getParameterByName('clientid');
  }
  getRecordByIDProcessBeforeCall122978(paramsEdit, function (processBeforeRes) {
    $.ajax({
      url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_appointmentsadd_Orders5da73cac545050343288ce7a',
      data: paramsEdit,
      type: 'POST',
      jsonpCallback: 'callback',
      success: function (response) {
        $('#display_loading').addClass('hideme');
        getRecordByIDProcessAfterCall122978(response, function (processBeforeRes) {
          if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
            var objParamsList = {};
            var queryMode = $('#queryMode').val();
            objParamsList.queryMode = queryMode;;
            var tokenKey = $('#tokenKey').val();;
            objParamsList.tokenKey = tokenKey;;
            if (!$('#addappointment2').html()) {
              $('#addappointment2').append(response.recordDetails.undefined);
            }
            $('#ordersnumber12_value').html(response.recordDetails.ordersnumber);
            if (!$('#backbutton1').html()) {
              $('#backbutton1').append(response.recordDetails.undefined);
            }
            if (response.recordDetails.contactnumber != undefined) {
              if (response.recordDetails.contactnumber_dialcode) {
                response.recordDetails.contactnumber = response.recordDetails.contactnumber.toString();
                response.recordDetails.contactnumber = response.recordDetails.contactnumber.replace('+' + response.recordDetails.contactnumber_dialcode, '');
                $('#contactnumber15').intlTelInput('setCountry', response.recordDetails.contactnumber_countrycode);
                var sampleNumber = intlTelInputUtils.getExampleNumber(response.recordDetails.contactnumber_countrycode, false, 1);
                var placeholder = sampleNumber.replace('+' + response.recordDetails.contactnumber_dialcode + ' ', '');
                var mask1 = placeholder.replace(/[0-9]/g, 0);
                $('#contactnumber15').val(response.recordDetails.contactnumber);
                $('#contactnumber15').mask(mask1);
                $('#contactnumber15').val($('#contactnumber15').masked(response.recordDetails.contactnumber));
              } else {
                $('#contactnumber15').val(response.recordDetails.contactnumber);
              }
            }
            if (response.recordDetails.email != undefined) $('#email14').val(response.recordDetails.email);
            if (response.recordDetails.email != undefined) $('#email9').val(response.recordDetails.email);
            if (response.recordDetails.clientcontact != undefined) $('#clientcontact8').val(response.recordDetails.clientcontact);
            if (response.recordDetails.clientname != undefined) $('#clientname7').val(response.recordDetails.clientname);
            if (response.recordDetails.name != undefined) $('#name13').val(response.recordDetails.name);
            if (response.recordDetails.note != undefined) $('#note10').val(response.recordDetails.note);

            Materialize.updateTextFields();
            $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

          }
        }); // end of getRecord By ID
      },
      error: function (xhr, status, error) {
        handleError(xhr, status, error);
      },
    });
  }); // end of getRecord By ID

  var paramsEdit = {};
  paramsEdit.tokenKey = getParameterByName('tokenKey');
  paramsEdit.secretKey = getParameterByName('secretKey')
  getRecordByIDProcessBeforeCallcontactnumber15(paramsEdit, function (processBeforeRes) {
    $.ajax({
      url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_appointmentsadd_Usermanagement5da73cac545050343288ce7a',
      data: paramsEdit,
      type: 'POST',
      jsonpCallback: 'callback',
      success: function (response) {
        getRecordByIDProcessAfterCallcontactnumber15(response, function (processBeforeRes) {
          if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
            $('#display_loading').addClass('hideme');
            var objParamsList = {};
            var queryMode = $('#queryMode').val();
            objParamsList.queryMode = queryMode;;
            var tokenKey = $('#tokenKey').val();;
            objParamsList.tokenKey = tokenKey;;
            if (!$('#addappointment2').html()) {
              $('#addappointment2').append(response.recordDetails.undefined);
            }
            $('#ordersnumber12_value').html(response.recordDetails.ordersnumber);
            if (!$('#backbutton1').html()) {
              $('#backbutton1').append(response.recordDetails.undefined);
            }
            if (response.recordDetails.contactnumber != undefined) {
              if (response.recordDetails.contactnumber_dialcode) {
                response.recordDetails.contactnumber = response.recordDetails.contactnumber.toString();
                response.recordDetails.contactnumber = response.recordDetails.contactnumber.replace('+' + response.recordDetails.contactnumber_dialcode, '');
                $('#contactnumber15').intlTelInput('setCountry', response.recordDetails.contactnumber_countrycode);
                var sampleNumber = intlTelInputUtils.getExampleNumber(response.recordDetails.contactnumber_countrycode, false, 1);
                var placeholder = sampleNumber.replace('+' + response.recordDetails.contactnumber_dialcode + ' ', '');
                var mask1 = placeholder.replace(/[0-9]/g, 0);
                $('#contactnumber15').val(response.recordDetails.contactnumber);
                $('#contactnumber15').mask(mask1);
                $('#contactnumber15').val($('#contactnumber15').masked(response.recordDetails.contactnumber));
              } else {
                $('#contactnumber15').val(response.recordDetails.contactnumber);
              }
            }

            Materialize.updateTextFields();
            $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

          }
        }); // end of getRecord By ID
      },
      error: function (xhr, status, error) {
        handleError(xhr, status, error);
      },
    });
  }); // end of getRecord By ID

});//end of ready
function getParams(url) {
  var urlParams = {};
  url.replace(
    new RegExp("([^?=&]+)(=([^&]*))?", "g"),
    function ($0, $1, $2, $3) {
      if ($3 && $3 != 'undefined') urlParams[$1] = $3;
    }
  );
  return urlParams;
}
function processBeforeCallForSave3921next(objParams, response, callback) {


  objParams.clientid = localStorage.getItem("userID");
  objParams.type = 'appointments'
  objParams.status = 'New'
  var appUser = localStorage.getItem("appUser");
  //  if (appUser && appUser !== '') {
  // appUser = JSON.parse(appUser);
  //  if (appUser && appUser.consultantid) {
  var objParamsToken = {};
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  objParamsToken.tokenKey = getParameterByName('tokenKey');
  objParamsToken.secretKey = getParameterByName('secretKey');
  objParamsToken.recordID = localStorage.getItem('userID');

  var consultantid = localStorage.getItem('consultantid');
          objParams.consultantid = consultantid
          var ajaXCallURL = $.trim($('#ajaXCallURL').val());
          var appointmentID = localStorage.getItem("appointmentID");
          if (appointmentID && appointmentID != '' && appointmentID != null) {
            objParams.recordID = appointmentID;
            //objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxorders3921nextapp_appointmentsadd';
          }
          callback(objParams);
        

  //
  //  }
  //}


}
function checkConsultant()
{
  var objParamsToken = {};
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  objParamsToken.tokenKey = getParameterByName('tokenKey');
  objParamsToken.secretKey = getParameterByName('secretKey');
  objParamsToken.recordID = localStorage.getItem('userID');
  try{
    $.ajax({
      url: ajaXCallURL + '/milestone003/get_data_by_record_Usermanagement5da73cac545050343288ce7aapp_clientprofile',
      data: objParamsToken,
      type: 'POST',
      success: function (response) {
         $('#display_loading1').addClass('hideme');
        if (response && response.status == 0) {
          response.recordDetails[0].isredeemdisplay =0;
          if (response.recordDetails[0] && response.recordDetails[0].consultantid && response.recordDetails[0].isredeemdisplay==0) {
            var consultantid = response.recordDetails[0].consultantid;
  
            localStorage.setItem('consultantid', consultantid);
           // objParams.consultantid = consultantid
            var ajaXCallURL = $.trim($('#ajaXCallURL').val());
            // var appointmentID = localStorage.getItem("appointmentID");
            // if (appointmentID && appointmentID != '' && appointmentID != null) {
              // objParams.recordID = appointmentID;
             // objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxorders3921nextapp_appointmentsadd';
              $('#next11').removeProp('disabled');
             $('#invite20friendstoredeem10').html("By clicking “Next”, a financial consultant will be meeting up with you for a financial consultation.");
              
              $("#next11").addClass("clssg6567");
  
              $("#next11").removeClass("clssg6567disabled");
           // }
           // callback(objParams);
          }
          
          else {
            $('#invite20friendstoredeem10').html("We will designate a consultant for you to meet with.");
  
            $('#next11').prop('disabled', true);
          
            $("#next11").removeClass("clssg6567");
  
            $("#next11").addClass("clssg6567disabled");
            // shareAppData('Thank you! Your designated consultant will be contacting you.', 'toast');
            return false;
          }
  
        }
        else {
          $('#next11').prop('disabled', true);
          $('#invite20friendstoredeem10').removeClass("hide");
            $("#next11").removeClass("clssg6567");
  
           $("#next11").addClass("clssg6567disabled");
  
           
          $('#display_loading1').addClass('hideme');
  
       //   shareAppData('Thank you! Your designated consultant will be contacting you.', 'toast');
          return false;
        }
  
  
      },
      error: function (xhr, status, error) {
        $('#display_loading1').addClass('hideme');
  
        $('#next11').prop('disabled', true);
  
      },
    });
  }catch(error)
  {
    alert("")
  }
 
}

function processAfterCallForSave3921next(response, callback) {


  if (response.data && response.data._id) {
    localStorage.setItem("appointmentID", response.data._id);

  }

  if (response.data && response.data.consultantid) {
    callback();

  } else {
    var nextPage = 'app_consultantlisting'
    var queryParams = queryStringToJSON();
    queryParams["queryMode"] = "mylist";
    var queryString = $.param(queryParams);
    queryString = queryString.replace(/\+/g, "%20");
    queryString = decodeURIComponent(queryString);
    window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
    return false;
  }
}
function getRecordByIDProcessBeforeCall122978(paramsType, callback) {
  var response = paramsType;

  var appointmentID = localStorage.getItem("appointmentID");
  if (appointmentID && appointmentID != '' && appointmentID != null) {
    paramsType.recordID = appointmentID;
    paramsType.clientid = localStorage.getItem("userID");;
    callback();
  } else {
    return false;

  }
}
function getRecordByIDProcessAfterCall122978(response, callback) {
  callback();
}
function getRecordByIDProcessBeforeCallcontactnumber15(paramsType, callback) {
  var response = paramsType;

  paramsType.recordID = localStorage.getItem("userID");
  callback();
}
function getRecordByIDProcessAfterCallcontactnumber15(response, callback) {

  if (response.recordDetails && response.recordDetails.name) {
    $("#clientname7").val(response.recordDetails.name);

  }

  if (response.recordDetails && response.recordDetails.contactnumber) {
    $("#clientcontact8").val(response.recordDetails.contactnumber);

  }

  if (response.recordDetails && response.recordDetails.email) {
    $("#email9").val(response.recordDetails.email);

  }

  callback();
}
