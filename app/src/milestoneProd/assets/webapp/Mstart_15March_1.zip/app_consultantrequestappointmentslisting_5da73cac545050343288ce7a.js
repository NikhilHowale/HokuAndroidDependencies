
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var totaldcard_leftimage_collectioncontainer = 0;
$(document).ready(function () {
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"))
    }
                  updatenotificationunreadcount();
    var objParamsToken = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsToken.tokenKey = getParameterByName('tokenKey');
    objParamsToken.secretKey = getParameterByName('secretKey');

    var userRole = $('#userRole').val();
    var userID = $('#userID').val();
    var createrOfRecord = $('#createrOfRecord').val();
    var queryMode = getParameterByName('queryMode');
    var recordID = $.trim($('#recordID').val());
    var addSessionComments = [];


    var queryMode = getParameterByName('queryMode');
    var isMobile = $('#isMobile').val();
    var isiPad = $('#isiPad').val();
    if (queryMode != '') {
        var tokenKey = $('#tokenKey').val();
        var objParamsList = {};
        objParamsList.queryMode = queryMode;
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParamsList.tokenKey = getParameterByName('tokenKey');
        objParamsList.secretKey = getParameterByName('secretKey');
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = isMobile;
        objParamsList.isiPad = isiPad;
        objParamsList.applyFilter = false;
        getDataProcessBeforeCalldcard_leftimage_collectioncontainerOrders5da73cac545050343288ce7a(objParamsList, function (processBeforeRes) {
            if (getParameterByName('type') && getParameterByName('type') != '' && getParameterByName('type') != null && getParameterByName('type') != 'undefined') {
                objParamsList.type = getParameterByName('type');
            }
            if (getParameterByName('consultantid') && getParameterByName('consultantid') != '' && getParameterByName('consultantid') != null && getParameterByName('consultantid') != 'undefined') {
                objParamsList.consultantid = getParameterByName('consultantid');
            }
            var applyFilter = getParameterByName('applyFilter');
            if (applyFilter == null && objParamsList.applyFilter == false) {
                objParamsList.status = 'Requested,Rejected';
                objParamsList.applystaticfilter = true;
            }
            var dcard_leftimage_collectioncontainerapp_consultantrequestappointmentslisting = false;//localStorage.getItem('dcard_leftimage_collectioncontainerapp_consultantrequestappointmentslisting');
            var applyFilter = getParameterByName('applyFilter');
            $('#display_loading').removeClass('hideme');
            if (dcard_leftimage_collectioncontainerapp_consultantrequestappointmentslisting && applyFilter != 'true') {
                response = JSON.parse(dcard_leftimage_collectioncontainerapp_consultantrequestappointmentslisting);
                $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html('');
                getdcard_leftimage_collectioncontainerapp_consultantrequestappointmentslistingMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
                dcard_leftimage_collectioncontainerapp_consultantrequestappointmentslistingSync(response.timestamp);
            } else {
                show_dcard_leftimage_collectioncontainerapp_consultantrequestappointmentslisting_Details(objParamsList)
            }
        });//End of get data process before call.
    }
    $(document).on('click', '.dcard_leftimage_collectioncontainer', function () {
        if (dcardLoaded && !dcardLoaded['dcard_leftimage_collectioncontainer']) { return false; }; // added for use should not able to click until data loaded
        localStorage.setItem("headerPageName", 'app_consultantappointmentdetails');
        var recordID = $(this).attr('recordID');// get record ID;
        var ordersid = $(this).attr('recordID');// get record ID;
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = 'update';
        var nextPage = 'app_consultantappointmentdetails';
        if (!nextPage) {
            return false;
        }
        var pageurl = nextPage + '_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&ordersid=' + ordersid + '&recordID=' + recordID + '&applyFilter=true';
        window.location.href = pageurl;
        return false;
    }); // to add New record

    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#backbutton1', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_consultantuserhome';
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "update";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - backbutton1", error)
        }
    })
    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#accepted8', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_consultantacceptappointmentslisting';
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "mylist";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - accepted8", error)
        }
    })
                    showBottomMenu();
});//end of ready
function getDataProcessBeforeCalldcard_leftimage_collectioncontainerOrders5da73cac545050343288ce7a(objParamsList, callback) {
    var response = objParamsList
    objParamsList.type = 'appointments'
    objParamsList.consultantid = localStorage.userID;

    callback();
}
function dcard_leftimage_collectioncontainerapp_consultantrequestappointmentslistingSync(timestamp) {
    try {
        var objParamsList = {};
        objParamsList.queryMode = 'mylist';
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParamsList.tokenKey = getParameterByName('tokenKey');
        objParamsList.secretKey = getParameterByName('secretKey');
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = true;
        objParamsList.timestamp = timestamp;
        $.ajax({
            url: objParamsList.ajaXCallURL + '/milestone003/syncListDetails_Orders5da73cac545050343288ce7a_app_consultantrequestappointmentslisting',
            data: objParamsList,
            type: 'POST',
            success: function (response) {
                $('#display_loading').addClass('hideme');
                if (response.status != undefined && response.status == 1) {
                    localStorage.removeItem('dcard_leftimage_collectioncontainerapp_consultantrequestappointmentslisting');
                    var objParamsList = {};
                    objParamsList.queryMode = 'mylist';
                    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                    objParamsList.tokenKey = getParameterByName('tokenKey');
                    objParamsList.secretKey = getParameterByName('secretKey');
                    objParamsList.ajaXCallURL = ajaXCallURL;
                    objParamsList.isMobile = 'true';
                    objParamsList.isiPad = false;
                    objParamsList.timestamp = timestamp;
                    if (getParameterByName('type') && getParameterByName('type') != '' && getParameterByName('type') != null && getParameterByName('type') != 'undefined') {
                        objParamsList.type = getParameterByName('type');
                    }
                    if (getParameterByName('consultantid') && getParameterByName('consultantid') != '' && getParameterByName('consultantid') != null && getParameterByName('consultantid') != 'undefined') {
                        objParamsList.consultantid = getParameterByName('consultantid');
                    }
                    var applyFilter = getParameterByName('applyFilter');
                    if (applyFilter == null && objParamsList.applyFilter == false) {
                        objParamsList.status = 'Requested,Rejected';
                        objParamsList.applystaticfilter = true;
                    }
                    show_dcard_leftimage_collectioncontainerapp_consultantrequestappointmentslisting_Details(objParamsList)
                }
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            }
        });
    } catch (err) {
        // console.log('Error in workingtoolsSync', err);
    }
}
function show_dcard_leftimage_collectioncontainerapp_consultantrequestappointmentslisting_Details(objParamsList) {
    if (getParameterByName('type') && getParameterByName('type') != '' && getParameterByName('type') != null && getParameterByName('type') != 'undefined') {
        objParamsList.type = getParameterByName('type');
    }
    //if (getParameterByName('consultantid') && getParameterByName('consultantid') != '' && getParameterByName('consultantid') != null && getParameterByName('consultantid') != 'undefined') {
        objParamsList.consultantid = localStorage.getItem('userID') //getParameterByName('consultantid');
    //}
    var applyFilter = getParameterByName('applyFilter');
    if (applyFilter == null && objParamsList.applyFilter == false) {
        objParamsList.status = 'Requested,Rejected';
        objParamsList.applystaticfilter = true;
    }
    localStorage.setItem('appconsultantrequestappointmentslistingFilterBox', '');

    $.ajax({
        url: objParamsList.ajaXCallURL + '/milestone003/getListDetails_Orders5da73cac545050343288ce7a_app_consultantrequestappointmentslisting_dcard_leftimage_collectioncontainer',
        data: objParamsList,
        type: 'POST',
        success: function (response) {
            getDataProcessAfterCalldcard_leftimage_collectioncontainerOrders5da73cac545050343288ce7a(response, function () {
                if (response.status != undefined && response.status == 0) {
                    if (objParamsList.isMobile == 'true') {
                        $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html('');
                        //localStorage.removeItem('dcard_leftimage_collectioncontainerapp_consultantrequestappointmentslisting');
                        localStorage.setItem('dcard_leftimage_collectioncontainerapp_consultantrequestappointmentslisting',JSON.stringify(response));
                        getdcard_leftimage_collectioncontainerapp_consultantrequestappointmentslistingMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    } else if (objParamsList.isiPad == 'true') {
                        getdcard_leftimage_collectioncontainerapp_consultantrequestappointmentslistingiPadView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    } else {
                        getdcard_leftimage_collectioncontainerapp_consultantrequestappointmentslistingWebView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    }
                    $('#display_loading').addClass('hideme');
                } else {
                    $('#display_loading').addClass('hideme')
                }
            });
        },
        error: function (xhr, status, error) {
            $('#display_loading').addClass('hideme')
            handleError(xhr, status, error);
        },
    });
} // end of function     

function getDataProcessAfterCalldcard_leftimage_collectioncontainerOrders5da73cac545050343288ce7a(response, callback) {

    callback();
}

function getdcard_leftimage_collectioncontainerapp_consultantrequestappointmentslistingMobileView(response, tokenKey, queryMode) {
    var html = '';
    if (response.data.length == 0) {
        html += '<div class="nodatafound">';
        html += '<img src="nodatafound.gif" width="100%">';
        html += '<br>';
        html += '<!-- span>No record found</span -->';
        html += '</div>';
        $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html);;
    } else {
        html = '';
        var radioGroups = [];
        $.each(response.data, function (keyList, objList) {

            var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
            var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
//            if (isAndroid > -1 || ios > -1) {  // need to fix with native gyes.. images not getting download
//                var mediaID = '';
//                var fileName = '';
//                if (objList['userphotoupload'] && objList['userphotoupload'][0].mediaID) {
//                    mediaID = objList['userphotoupload'][0].mediaID;
//                    fileName = objList['userphotoupload'][0].mediaID + '.png';
//                }
//                getLocalImagedcard_leftimage_collectioncontainer(objList, mediaID, fileName);
//            } else
               if(true)
               {

                html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.imageupload + objList.clientname + objList.policytype_name + objList.date + objList.fromtime + objList.totime + objList.address_name) + '">';
                html += '      		<div class="col s12 m12">';
                html += '               <div class="card-content">';
                html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
                html += '      <div class="row  element" style=""  >';
                // html += '      <div class="col s3 cls_sg2790" style="">';
                // var localFilePath = '';
                // if (response && response.localFilePath) {
                //     localFilePath = response.localFilePath;
                // }
                // html += '           <div class="col s12 clssg6790" style="">';
                // var filetodisplay = '';
                // if (objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID) {
                //     filetodisplay = getuploadedfilepreview(objList.userphotoupload[0].fileNm);
                // }
                // if (localFilePath && localFilePath != '') {
                //     html += '               <img recordID="' + objList._id + '"   id="userphotoupload14"   class=" clssg6790image userphotoupload14" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
                // } else if (objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID) {
                //     if (filetodisplay && filetodisplay != objList.userphotoupload[0].fileNm) {
                //         html += '               <img recordID="' + objList._id + '"    id="userphotoupload14"   class=" clssg6790image userphotoupload14" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
                //     } else {
                //         html += '               <img recordID="' + objList._id + '"    id="userphotoupload14"   class=" clssg6790image userphotoupload14" style="" onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + CDN_PATH + objList.userphotoupload[0].mediaID + '_compressed.png">';
                //     }
                // } else {
                //     // stage 22222222222222
                //     html += '               <img recordID="' + objList._id + '"    id="userphotoupload14"   class=" clssg6790image userphotoupload14" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
                // }
                // html += '           </div>';
                // html += '     </div>';
                html += '<div class="col s3 cls_sg8468 addshimmer" style="border-radius:50px">';
                    if(objList.userIduserphotoupload && Array.isArray(objList.userIduserphotoupload) && objList.userIduserphotoupload[0]) {
                        html += '<img class="userprofilepic" src="https://d1hlq0tvec6h4x.cloudfront.net/5e22017115dcb4102be65911/5da73cac545050343288ce7a/'+ objList.userIduserphotoupload[0].mediaID +'_compressed.png"></img>';
                    } else {
                        html += '<img class="userprofilepic" src="default.png"></img>';
                    }
                html += '</div> ';
                html += '<div class="col s3"></div>';
                html += '      <div class="col s9 cls_sg4790 addshimmer" style="margin-top:15px;padding-left:5px !important;">';
                var adddbclass = ''
                html += '           <div recordID="' + objList._id + '" class="col s12 clssg8790  ' + adddbclass + ' " style=" cursor: pointer;">';
                //  objList['clientname'] = objList['clientname'] ? objList['clientname'] : '';
                //  if(response.showShimmer){
                //     objList['clientname'] = '';
                //  }
                var clientname = objList['name'];
                html += '           <div recordID="' + objList._id + '"   id="clientname15" class="languagetranslation " style="" >' + clientname + '</div>';
                html += '     </div>';
                var adddbclass = ''
                html += '           <div recordID="' + objList._id + '" class="col s12 clssg0890 hide ' + adddbclass + ' " style=" cursor: pointer;">';
                objList['email'] = objList['email'] ? objList['email'] : '';
                if (response.showShimmer) {
                    objList['email'] = '';
                }
                var policytype_name = objList['email'];
                html += '           <div recordID="' + objList._id + '"   id="policytype_name16" class="languagetranslation " style="" >' + policytype_name + '</div>';
                html += '     </div>';

///////////


var adddbclass = ''
html += '           <div recordID="' + objList._id + '" class="col s12 clssg0890 hideme ' + adddbclass + ' " style=" cursor: pointer;">';
objList['contactnumber'] = objList['contactnumber'] ? objList['contactnumber'] : '';
if (response.showShimmer) {
    objList['email'] = '';
}
var contactnumber = objList['contactnumber'];
html += '           <div recordID="' + objList._id + '"   id="contactnumber16" class="languagetranslation " style="" >' + contactnumber + '</div>';
html += '     </div>';


//////////

                
                var adddbclass = ''
                html += '           <div recordID="' + objList._id + '" class="col s3 clssg2890  ' + adddbclass + ' " style=" cursor: pointer;">';
                objList['slotdate'] = objList['slotdate'] ? moment(new Date(objList['slotdate'])).format('DD MMM YYYY') : '';
                var slotdate = objList['slotdate'];
                html += '           <div recordID="' + objList._id + '"   id="slotdate17" class="languagetranslation " style="" >' + slotdate + '</div>';
                html += '     </div>';
                var adddbclass = ''
                html += '           <div recordID="' + objList._id + '" class="col s5 clssg4890  ' + adddbclass + ' " style=" cursor: pointer;">';
                objList['starttime'] = objList['starttime'] ? objList['starttime'] : '';
                if (response.showShimmer) {
                    objList['starttime'] = '';
                }
                var starttime = objList['starttime'];
                html += '           <div recordID="' + objList._id + '"   id="starttime18" class="languagetranslation " style="" >' + starttime + ' - </div>';
                html += '     </div>';
                var adddbclass = ''
                html += '           <div recordID="' + objList._id + '" class="col s4 clssg6890  ' + adddbclass + ' " style=" cursor: pointer;padding-left:0px !important;">';
                objList['endtime'] = objList['endtime'] ? objList['endtime'] : '';
                if (response.showShimmer) {
                    objList['endtime'] = '';
                }
                var endtime = objList['endtime'];
                html += '           <div recordID="' + objList._id + '"   id="endtime19" class="languagetranslation " style="" >' + endtime + '</div>';
                html += '     </div>';
                var adddbclass = ''
                html += '           <div recordID="' + objList._id + '" class="col s12 clssg8890  ' + adddbclass + ' " style=" cursor: pointer;">';
                objList['address_name'] = objList['address_name'] ? objList['address_name'] : '';
                if (response.showShimmer) {
                    objList['address_name'] = '';
                }
                var address_name = objList['address_name'];
                html += '           <div recordID="' + objList._id + '"   id="address_name20" class="languagetranslation " style="" >' + address_name + '</div>';
                html += '     </div>';
                html += '     </div>';
                html += '     </div>';
                html += '      				</div>';
                html += '          </div>';
                html += '        </div>';
                html += '     </div>';
                html += '   </div>';
            }
        });
        var ios = navigator.userAgent.toLowerCase().indexOf("iphone os");
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        if (1) {
            $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html)
            $('#full-body-container').addClass('fadeInUp');
        };
        if (!response.showShimmer) {
            dcardLoaded['dcard_leftimage_collectioncontainer'] = true;
            $('#collectioncontainerDivdcard_leftimage_collectioncontainer').find('.view_list_record').removeClass('shimmer');
        }
        $('.carddropdown').material_select();
        $('<input>').attr({ type: 'hidden', class: 'cardtoggleswitch', id: 'togleswitchvalue' }).appendTo('body')
        if ($('.js-candlestick').length) $('.js-candlestick').candlestick({ afterSetting: function (input, wrapper, value) { $('#togleswitchvalue').val(value).attr('recordID', input.attr('id')).trigger('click'); } });
        if (radioGroups && radioGroups.length) {
            for (var key in radioGroups) {
                var groupName = radioGroups[key];
                $('input:radio[name=' + groupName + ']:first').prop('checked', true);
                $('input:radio[name=' + groupName + ']:first').trigger('change');
            }
        }
    };
};
function getLocalImagedcard_leftimage_collectioncontainer(objList, mediaID, fileName) {
    try {
        var appJSON = {};
        appJSON.nextButtonCallback = 'handleLocalImagedcard_leftimage_collectioncontainer';
        appJSON.url = CDN_PATH + mediaID + '_compressed.png';
        appJSON.fileMimeType = 'image/png';
        appJSON.fileName = fileName;
        appJSON.objList = objList;
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        if (isAndroid > -1) {
            window.Android.getLocalImage(JSON.stringify(appJSON))
        } else {
            setupWebViewJavascriptBridge(function (bridge) {
                bridgeObj = bridge;
                bridgeObj.callHandler('getLocalImage', appJSON, function (response) { });
                bridgeObj.registerHandler('handleLocalImagedcard_leftimage_collectioncontainer', function (responseData, responseCallback) {
                    handleLocalImagedcard_leftimage_collectioncontainer(responseData)
                });
            });
        }
    } catch (err) {

    }
}
function handleLocalImagedcard_leftimage_collectioncontainer(response) {
    var objList = response.dataDictionay.objList;
    var html = '';

    html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.imageupload + objList.clientname + objList.policytype_name + objList.date + objList.fromtime + objList.totime + objList.address_name) + '">';
    html += '      		<div class="col s12 m12">';
    html += '               <div class="card-content">';
    html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
    html += '      <div class="row  element" style=""  >';
    html += '      <div class="col s3 cls_sg2790" style="">';
    var localFilePath = '';
    if (response && response.localFilePath) {
        localFilePath = response.localFilePath;
    }
    html += '           <div class="col s12 clssg6790" style="">';
    var filetodisplay = '';
    if (objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID) {
        filetodisplay = getuploadedfilepreview(objList.userphotoupload[0].fileNm);
    }
    if (localFilePath && localFilePath != '') {
        html += '               <img recordID="' + objList._id + '"   id="userphotoupload14"   class=" clssg6790image userphotoupload14" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
    } else if (objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID) {
        if (filetodisplay && filetodisplay != objList.userphotoupload[0].fileNm) {
            html += '               <img recordID="' + objList._id + '"    id="userphotoupload14"   class=" clssg6790image userphotoupload14" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
        } else {
            html += '               <img recordID="' + objList._id + '"    id="userphotoupload14"   class=" clssg6790image userphotoupload14" style="" onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + CDN_PATH + objList.userphotoupload[0].mediaID + '_compressed.png">';
        }
    } else {
        // stage 22222222222222
        html += '               <img recordID="' + objList._id + '"    id="userphotoupload14"   class=" clssg6790image userphotoupload14" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
    }
    html += '           </div>';
    html += '     </div>';
    html += '      <div class="col s9 cls_sg4790 addshimmer" style="">';
    var adddbclass = '';


    html += '<div recordID="' + objList._id + '" class="col s12 clssg8790 hide ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['clientname'] = objList['clientname'] ? objList['clientname'] : '';
    if (response.showShimmer) {
        objList['clientname'] = '';
    }
    var clientname = objList['clientname'];
    html += '           <div recordID="' + objList._id + '"   id="clientname15" class="languagetranslation " style="" >' + clientname + '</div>';
    html += '     </div>';


    html += '           <div recordID="' + objList._id + '" class="col s12 clssg8790 hide ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['clientname'] = objList['clientname'] ? objList['clientname'] : '';
    if (response.showShimmer) {
        objList['clientname'] = '';
    }
    var clientname = objList['clientname'];
    html += '           <div recordID="' + objList._id + '"   id="clientname15" class="languagetranslation " style="" >' + clientname + '</div>';
    html += '     </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s12 clssg0890  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['policytype_name'] = objList['policytype_name'] ? objList['policytype_name'] : '';
    if (response.showShimmer) {
        objList['policytype_name'] = '';
    }
    var policytype_name = objList['policytype_name'];
    html += '           <div recordID="' + objList._id + '"   id="policytype_name16" class="languagetranslation " style="" >' + policytype_name + '</div>';
    html += '     </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s3 clssg2890  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['slotdate'] = objList['slotdate'] ? moment(new Date(objList['slotdate'])).format('DD MMM YYYY') : '';
    var slotdate = objList['slotdate'];
    html += '           <div recordID="' + objList._id + '"   id="slotdate17" class="languagetranslation " style="" >' + slotdate + '</div>';
    html += '     </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s5 clssg4890  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['starttime'] = objList['starttime'] ? objList['starttime'] : '';
    if (response.showShimmer) {
        objList['starttime'] = '';
    }
    var starttime = objList['starttime'];
    html += '           <div recordID="' + objList._id + '"   id="starttime18" class="languagetranslation " style="" >' + starttime + '</div>';
    html += '     </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s4 clssg6890  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['endtime'] = objList['endtime'] ? objList['endtime'] : '';
    if (response.showShimmer) {
        objList['endtime'] = '';
    }
    var endtime = objList['endtime'];
    html += '           <div recordID="' + objList._id + '"   id="endtime19" class="languagetranslation " style="" >' + endtime + '</div>';
    html += '     </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s12 clssg8890  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['address_name'] = objList['address_name'] ? objList['address_name'] : '';
    if (response.showShimmer) {
        objList['address_name'] = '';
    }
    var address_name = objList['address_name'];
    html += '           <div recordID="' + objList._id + '"   id="address_name20" class="languagetranslation " style="" >' + address_name + '</div>';
    html += '     </div>';
    html += '     </div>';
    html += '     </div>';
    html += '      				</div>';
    html += '          </div>';
    html += '        </div>';
    html += '     </div>';
    html += '   </div>';
    $('#collectioncontainerDivdcard_leftimage_collectioncontainer').append(html)
    $('#full-body-container').addClass('fadeInUp');
    dcardLoaded['dcard_leftimage_collectioncontainer'] = true;
    $('#collectioncontainerDivdcard_leftimage_collectioncontainer').find('.view_list_record').removeClass('shimmer');
    // after html bining code
};

function getdcard_leftimage_collectioncontainerapp_consultantrequestappointmentslistingPadView(response, tokenKey, queryMode) {
    var html = '';
    if (response.data.length == 0) {
        html += '<tr>';
        html += '<td colspan="1" class="text_center first_row_table_td">';
        html += 'No record found';
        html += '</td>';
        html += '</tr>';
    } else {
        html = '';
        $.each(response.data, function (keyList, objList) {

            html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.imageupload + objList.clientname + objList.policytype_name + objList.date + objList.fromtime + objList.totime + objList.address_name) + '">';
            html += '      		<div class="col s12 m12">';
            html += '               <div class="card-content">';
            html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
            html += '      <div class="row  element" style=""  >';
            html += '      <div class="col s3 cls_sg2790" style="">';
            var localFilePath = '';
            if (response && response.localFilePath) {
                localFilePath = response.localFilePath;
            }
            html += '           <div class="col s12 clssg6790" style="">';
            var filetodisplay = '';
            if (objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID) {
                filetodisplay = getuploadedfilepreview(objList.userphotoupload[0].fileNm);
            }
            if (localFilePath && localFilePath != '') {
                html += '               <img recordID="' + objList._id + '"   id="userphotoupload14"   class=" clssg6790image userphotoupload14" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
            } else if (objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID) {
                if (filetodisplay && filetodisplay != objList.userphotoupload[0].fileNm) {
                    html += '               <img recordID="' + objList._id + '"    id="userphotoupload14"   class=" clssg6790image userphotoupload14" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
                } else {
                    html += '               <img recordID="' + objList._id + '"    id="userphotoupload14"   class=" clssg6790image userphotoupload14" style="" onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + CDN_PATH + objList.userphotoupload[0].mediaID + '_compressed.png">';
                }
            } else {
                // stage 22222222222222
                html += '               <img recordID="' + objList._id + '"    id="userphotoupload14"   class=" clssg6790image userphotoupload14" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
            }
            html += '           </div>';
            html += '     </div>';
            html += '      <div class="col s9 cls_sg4790 addshimmer" style="">';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg8790  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['clientname'] = objList['clientname'] ? objList['clientname'] : '';
            if (response.showShimmer) {
                objList['clientname'] = '';
            }
            var clientname = objList['clientname'];
            html += '           <div recordID="' + objList._id + '"   id="clientname15" class="languagetranslation " style="" >' + clientname + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg0890  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['policytype_name'] = objList['policytype_name'] ? objList['policytype_name'] : '';
            if (response.showShimmer) {
                objList['policytype_name'] = '';
            }
            var policytype_name = objList['policytype_name'];
            html += '           <div recordID="' + objList._id + '"   id="policytype_name16" class="languagetranslation " style="" >' + policytype_name + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s3 clssg2890  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['slotdate'] = objList['slotdate'] ? moment(new Date(objList['slotdate'])).format('DD MMM YYYY') : '';
            var slotdate = objList['slotdate'];
            html += '           <div recordID="' + objList._id + '"   id="slotdate17" class="languagetranslation " style="" >' + slotdate + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s5 clssg4890  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['starttime'] = objList['starttime'] ? objList['starttime'] : '';
            if (response.showShimmer) {
                objList['starttime'] = '';
            }
            var starttime = objList['starttime'];
            html += '           <div recordID="' + objList._id + '"   id="starttime18" class="languagetranslation " style="" >' + starttime + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s4 clssg6890  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['endtime'] = objList['endtime'] ? objList['endtime'] : '';
            if (response.showShimmer) {
                objList['endtime'] = '';
            }
            var endtime = objList['endtime'];
            html += '           <div recordID="' + objList._id + '"   id="endtime19" class="languagetranslation " style="" >' + endtime + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg8890  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['address_name'] = objList['address_name'] ? objList['address_name'] : '';
            if (response.showShimmer) {
                objList['address_name'] = '';
            }
            var address_name = objList['address_name'];
            html += '           <div recordID="' + objList._id + '"   id="address_name20" class="languagetranslation " style="" >' + address_name + '</div>';
            html += '     </div>';
            html += '     </div>';
            html += '     </div>';
            html += '      				</div>';
            html += '          </div>';
            html += '        </div>';
            html += '     </div>';
            html += '   </div>';
        }); // end of each loop
    };
    $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html)
};

function getdcard_leftimage_collectioncontainerapp_consultantrequestappointmentslistingWebView(response, tokenKey, queryMode) {
    var html = '';
    if (response.data.length == 0) {
        html += '<tr>';
        html += '<td colspan="1" class="text_center first_row_table_td">';
        html += 'No record found';
        html += '</td>';
        html += '</tr>';
    } else {
        html = '';
        $.each(response.data, function (keyList, objList) {

            html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.imageupload + objList.clientname + objList.policytype_name + objList.date + objList.fromtime + objList.totime + objList.address_name) + '">';
            html += '      		<div class="col s12 m12">';
            html += '               <div class="card-content">';
            html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_leftimage_collectioncontainer" style="" >';
            html += '      <div class="row  element" style=""  >';
            html += '      <div class="col s3 cls_sg2790" style="">';
            var localFilePath = '';
            if (response && response.localFilePath) {
                localFilePath = response.localFilePath;
            }
            html += '           <div class="col s12 clssg6790" style="">';
            var filetodisplay = '';
            if (objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID) {
                filetodisplay = getuploadedfilepreview(objList.userphotoupload[0].fileNm);
            }
            if (localFilePath && localFilePath != '') {
                html += '               <img recordID="' + objList._id + '"   id="userphotoupload14"   class=" clssg6790image userphotoupload14" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + localFilePath + '" mediaid="' + objList.mediaID + '" filenm="' + objList.filenm + '" >';
            } else if (objList.userphotoupload && objList.userphotoupload[0] && objList.userphotoupload[0].mediaID) {
                if (filetodisplay && filetodisplay != objList.userphotoupload[0].fileNm) {
                    html += '               <img recordID="' + objList._id + '"    id="userphotoupload14"   class=" clssg6790image userphotoupload14" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + filetodisplay + '">';
                } else {
                    html += '               <img recordID="' + objList._id + '"    id="userphotoupload14"   class=" clssg6790image userphotoupload14" style="" onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + CDN_PATH + objList.userphotoupload[0].mediaID + '_compressed.png">';
                }
            } else {
                // stage 22222222222222
                html += '               <img recordID="' + objList._id + '"    id="userphotoupload14"   class=" clssg6790image userphotoupload14" style=""  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="card.png">';
            }
            html += '           </div>';
            html += '     </div>';
            html += '      <div class="col s9 cls_sg4790 addshimmer" style="">';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg8790  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['clientname'] = objList['clientname'] ? objList['clientname'] : '';
            if (response.showShimmer) {
                objList['clientname'] = '';
            }
            var clientname = objList['clientname'];
            html += '           <div recordID="' + objList._id + '"   id="clientname15" class="languagetranslation " style="" >' + clientname + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg0890  ' + adddbclass + ' " style=" cursor: pointer;">';
            // objList['policytype_name'] = objList['policytype_name'] ? objList['policytype_name'] : '';
            // if (response.showShimmer) {
            //     objList['policytype_name'] = '';
            // }
            var policytype_name = objList['email'];
            html += '           <div recordID="' + objList._id + '"   id="policytype_name16" class="languagetranslation " style="" >' + policytype_name + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s3 clssg2890  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['slotdate'] = objList['slotdate'] ? moment(new Date(objList['slotdate'])).format('DD MMM YYYY') : '';
            var slotdate = objList['slotdate'];
            html += '           <div recordID="' + objList._id + '"   id="slotdate17" class="languagetranslation " style="" >' + slotdate + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s5 clssg4890  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['starttime'] = objList['starttime'] ? objList['starttime'] : '';
            if (response.showShimmer) {
                objList['starttime'] = '';
            }
            var starttime = objList['starttime'];
            html += '           <div recordID="' + objList._id + '"   id="starttime18" class="languagetranslation " style="" >' + starttime + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s4 clssg6890  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['endtime'] = objList['endtime'] ? objList['endtime'] : '';
            if (response.showShimmer) {
                objList['endtime'] = '';
            }
            var endtime = objList['endtime'];
            html += '           <div recordID="' + objList._id + '"   id="endtime19" class="languagetranslation " style="" >' + endtime + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg8890  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['address_name'] = objList['address_name'] ? objList['address_name'] : '';
            if (response.showShimmer) {
                objList['address_name'] = '';
            }
            var address_name = objList['address_name'];
            html += '           <div recordID="' + objList._id + '"   id="address_name20" class="languagetranslation " style="" >' + address_name + '</div>';
            html += '     </div>';
            html += '     </div>';
            html += '     </div>';
            html += '      				</div>';
            html += '          </div>';
            html += '        </div>';
            html += '     </div>';
            html += '   </div>';
        }); // end of each loop 1
    };
    $('#collectioncontainerDivdcard_leftimage_collectioncontainer').html(html)
};
function showBottomMenu() {
    var menuObj = localStorage.getItem('objGetUserDetailsWithmenu');
    if (menuObj) {
        menuObj = JSON.parse(menuObj);
        if (menuObj.data && menuObj.data.roleName) {
            var roleName = menuObj.data.roleName;
        }
    }
    try {
        var roleName = localStorage.getItem('roleName');
        var clientIcon = "icon_client.svg"
        var notificationicon = "icon_notification.svg"
        
        if (roleName == "consultant") {
            clientIcon = "icon_team.png";
            notificationicon = "icon_calendaractive.svg"
            
        }
        var  appUser = JSON.parse(localStorage.getItem("appUser"));
       var notificationCount = 0
       if(appUser.notificationunreadcount)
       {
           notificationCount = appUser.notificationunreadcount
       }
       $("#notificationcount5").html(notificationCount)
       var appointmentunreadcount = 0
       if(appUser.appointmentunreadcount)
       {
           appointmentunreadcount = appUser.appointmentunreadcount
       }
       var roleName = localStorage.getItem('roleName');
       var clientIcon = "icon_client.svg"
       var notificationicon = "icon_notification.svg"

       if (roleName == "consultant") {
           clientIcon = "icon_team.png";
           notificationicon = "icon_calendaractive.svg"

       }
        var bottommenu = '';
        bottommenu += '<div class="mobilebottommenu">'
        bottommenu += '    <div class="row">'
        bottommenu += '    <div class="menuwrapper " style="width: 16% !important;"><a class="redirecttopage" nativeredirect="" id="Home" fileName="app_consultantuserhome_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_home.svg"><span>Home</span></a></div>'
        bottommenu += '    <div class="menuwrapper " style="width: 15% !important;"><a class="redirecttopage" nativeredirect="" id="Client" fileName="app_consultantclientlisting_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="'+clientIcon+'"><span>Clients</span></a></div>'
        bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Appointments" fileName="app_consultantrequestappointmentslisting_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="Account-MyAppointment-Gold.svg"><span>Appointments</span></a></div>'
        bottommenu += '    <div class="menuwrapper "  style="width: 19% !important;"><a class="redirecttopage" nativeredirect="" id="Chat" fileName="undefined_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_chat.svg"><span>Messages</span></a><div id="chatCount" style="display:none !important" " class="chatunreadcount active">0</div></div>'
        bottommenu += '    <div class="menuwrapper " style="width: 18% !important;"><a class="redirecttopage" nativeredirect="" id="More" fileName="app_consultantcustmoreinfodetails_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_more.svg"><span>Account</span></a></div>'
        bottommenu += '    </div>'
        bottommenu += '</div>'
        $('#bottommenu22').html(bottommenu)
    } catch (err) {
        // console.log('Error in showBottomMenu', err);
    }
}



function updatenotificationunreadcount()
{
    var userID = JSON.parse( localStorage.getItem("appUser"))._id
    var objParams = {}
    var recordID = $('#recordID').val();
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParams.tokenKey = getParameterByName('tokenKey');
    objParams.secretKey = getParameterByName('secretKey');
    objParams.offlineDataID =  localStorage.getItem("offlineDataID");
    var queryMode = getParameterByName('queryMode')
    
    objParams.callUrl = ajaXCallURL +'/milestone003/updateAjaxusermanagement7555updateapp_clientprofile';
    objParams.recordID = userID;
    objParams.appointmentunreadcount = 0;
    $.ajax({
           url: objParams.callUrl ,
           data: objParams,
           type: 'POST',
           success: function (response) {
           
           
           
           },
           error: function (xhr, status, error) {
           // $('#display_loading').addClass('hideme')
           // handleError(xhr, status, error);
           },
           });
    
}
