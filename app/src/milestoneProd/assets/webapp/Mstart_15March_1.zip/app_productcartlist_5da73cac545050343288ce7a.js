
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
     var totalshowcartlist = 0;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
	$(document).on('click', '.minus', function(e) {
		try {
			e.preventDefault();
			var objParams = {};
			var element = $(this);
			objParams.recordID = getParameterByName('recordID');
			if ($(this).attr('recordID')) {
				objParams.recordID = $(this).attr('recordID');
			}
		
			objParams.byinput = 1;
			var quantityTotal = $('#'+objParams.recordID+'_quantity').val();
			if(quantityTotal){
				objParams.isMinusButton = true;
			    if(quantityTotal == "" || quantityTotal == 0 ){
			        $('#'+objParams.recordID+'_quantity').val(0);
			    }else if(quantityTotal){
			        quantityTotal =  parseInt(quantityTotal)-1;
			        $('#'+objParams.recordID+'_quantity').val(quantityTotal);
			    }
			    $('#'+objParams.recordID+'_quantity').val(quantityTotal);
			}else {
			    $('#'+objParams.recordID+'_quantity').val(0);
			}
			objParams.updatequantity = $('#'+objParams.recordID+'_quantity').val();
			objParams.quantity = $('#'+objParams.recordID+'_quantity').val();
			addtocartv2Cartitems5da73cac545050343288ce7aremoveitem21(objParams, element);
			return false;
		} catch (error) {
			console.log('Error in addtocart click', error);
		}
	});
		$(document).on('keypress', '.updatecartquantity', function(evt) {
		  	try {
		    	
		      	var iKeyCode = (evt.which) ? evt.which : evt.keyCode
		      	if (iKeyCode != 46 && iKeyCode > 31 && (iKeyCode < 48 || iKeyCode > 57)){
		          	return false;
		      	} else {
		        	return true;
		      	}
		  	} catch (error) {
		   // console.log('Error in addtocart click', error);
		  	}
		});
	$(document).on('keyup', '.updatecartquantity', function(e) {
		try {
			e.preventDefault();
			var objParams = {};
			var element = $(this);
			objParams.recordID = getParameterByName('recordID');
			if ($(this).attr('recordID')) {
				objParams.recordID = $(this).attr('recordID');
			}
		
			objParams.byinput = 1;
			var quantityTotal = $(this).val();
			if(quantityTotal == '' ){
				quantityTotal = 0;
			}
			objParams.updatequantity = quantityTotal;
			objParams.quantity = quantityTotal;
			addtocartv2Cartitems5da73cac545050343288ce7aquantity22(objParams, element);
			return false;
		} catch (error) {
			console.log('Error in addtocart click', error);
		}
	});
	$(document).on('click', '.plus', function(e) {
		try {
			e.preventDefault();
			var objParams = {};
			var element = $(this);
			objParams.recordID = getParameterByName('recordID');
			if ($(this).attr('recordID')) {
				objParams.recordID = $(this).attr('recordID');
			}
		
			objParams.byinput = 1;
			var quantityTotal = $('#'+objParams.recordID+'_quantity').val();
			if(quantityTotal){
			    quantityTotal =  parseInt(quantityTotal)+1;
			    $('#'+objParams.recordID+'_quantity').val(quantityTotal);
			}else {
			    $('#'+objParams.recordID+'_quantity').val(1);
			}
			objParams.updatequantity = $('#'+objParams.recordID+'_quantity').val();
			objParams.quantity = $('#'+objParams.recordID+'_quantity').val();
			addtocartv2Cartitems5da73cac545050343288ce7aadditem23(objParams, element);
			return false;
		} catch (error) {
			console.log('Error in addtocart click', error);
		}
	});
			var objParams = {};
			getcartcountCartitems5da73cac545050343288ce7a(objParams);
	$(document).on('click', '.deletecartquantity', function(e) {
		try {
			e.preventDefault();
			var plaincard = $(this).closest('.plain-card');
			var objParams = {};
			objParams.recordID = getParameterByName('recordID');
			if ($(this).attr('recordID')) {
				objParams.recordID = $(this).attr('recordID');
			}
			removefromcartv2Cartitems5da73cac545050343288ce7a(objParams, plaincard);
			return false;
		} catch (error) {
			console.log('Error in removefromcart click', error);
		}
	}); 
    $(document).on('click', '#backbutton1', function(e) { 
    		window.history.back();  
    		return false;  
    })
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#proceedtocheckout9', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_productcartlist'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "add"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - proceedtocheckout9", error) 
		} 
	})
});//end of ready
	function addtocartv2Cartitems5da73cac545050343288ce7aremoveitem21(objParams, element) {
		try {
			objParams.userId = localStorage.getItem('userID');
			var ajaXCallURL = $.trim($('#ajaXCallURL').val());
			objParams.tokenKey = getParameterByName('tokenKey');
			objParams.secretKey = getParameterByName('secretKey');
		objParams.updatequantity = true;
			var callUrl = ajaXCallURL + '/milestone003/addtocartv2_Cartitems5da73cac545050343288ce7a_app_productcartlist';
			$('#display_loading').removeClass('hideme');
 			addToCartV2ProcessBeforeCallCartitems5da73cac545050343288ce7aremoveitem(element, objParams, function(){
			$.ajax({
				url: callUrl,
				data: objParams,
				type: 'POST',
				success: function (response) {
					$('#display_loading').addClass('hideme');
 					addToCartV2ProcessAfterCallCartitems5da73cac545050343288ce7aremoveitem(response, function(){
					if (response.status == 0) {
						if(response.carttotal){
						    response.carttotal = Math.round(response.carttotal * 100) / 100
						}
					    if(objParams.quantity == 0){ // remove div no record found
					        $('[recordID="'+ objParams.recordID +'"]').closest('.plain-card').remove()
					    }
					    if(response.cartcount && $('#cartcountid').length){ 
					    	$('#cartcountid').html(response.cartcount); 
					    } else if(response.cartcount && $('.clsshowcartcount').length){ 
						    var cls = 'clscartcount1';
						    if(response.cartcount > 9 ) { cls = 'clscartcount2';}
						    $('.clsshowcartcount').append('<span id="cartcountid" class="'+ cls +'">'+ response.cartcount +'</span>');
						    $('#cartcountid').on('click', function(){ $('#cartcountid').parent().find('img').trigger('click'); })
					    }
	
						response.carttotal = response.carttotal ? response.carttotal : '0';
						$('#cartitemssubtotal8').html('$ '+ response.carttotal+'');
						response.cartcount = response.cartcount ? response.cartcount : '0';
						$('#cartitemcount7').html('Cart Subtotal '+ response.cartcount+'item(s) :');
					    if (response.cartcount == 0) {
					        $('[id^="proceedtocheckout"]').hide()
					    } else {
					        $('[id^="proceedtocheckout"]').show()
					    }
	
						shareAppData('Item removed to the cart successfully.', 'toast');
						return;
					} else {
 	var quantityTotal = $('#'+objParams.recordID+'_quantity').val();
 	if(quantityTotal){
		quantityTotal =  parseInt(quantityTotal)-1;
		$('#'+objParams.recordID+'_quantity').val(quantityTotal);
 	}else {
		$('#'+objParams.recordID+'_quantity').val(1);
 	}
						var errorMessage = '';
						errorMessage = 'Item is Out-of-Stock';
						if( response.error &&  response.error.trim() != ''){
							errorMessage = response.error;
						}
						if(errorMessage){
							shareAppData(errorMessage, 'toast');
						}
						return;
					 }
					}); //close client after call
				},
				error: function (xhr, status, error) {
					$('#display_loading').addClass('hideme');
				},
			});
			}); // close precessbeforecall
		} catch (error) {
			$('#display_loading').addClass('hideme');
			console.log('Error in addtocartv2_fieldname', error);
		}
	} 
 function addToCartV2ProcessBeforeCallCartitems5da73cac545050343288ce7aremoveitem(element, objParams, callback) { 	var response = objParams;
 callback(); 
 } 
 function addToCartV2ProcessAfterCallCartitems5da73cac545050343288ce7aremoveitem(response, callback) {
 callback(); 
 }
	function addtocartv2Cartitems5da73cac545050343288ce7aquantity22(objParams, element) {
		try {
			objParams.userId = localStorage.getItem('userID');
			var ajaXCallURL = $.trim($('#ajaXCallURL').val());
			objParams.tokenKey = getParameterByName('tokenKey');
			objParams.secretKey = getParameterByName('secretKey');
		objParams.updatequantity = true;
			var callUrl = ajaXCallURL + '/milestone003/addtocartv2_Cartitems5da73cac545050343288ce7a_app_productcartlist';
			$('#display_loading').removeClass('hideme');
 			addToCartV2ProcessBeforeCallCartitems5da73cac545050343288ce7aQuantity(element, objParams, function(){
			$.ajax({
				url: callUrl,
				data: objParams,
				type: 'POST',
				success: function (response) {
					$('#display_loading').addClass('hideme');
 					addToCartV2ProcessAfterCallCartitems5da73cac545050343288ce7aQuantity(response, function(){
					if (response.status == 0) {
						if(response.carttotal){
						    response.carttotal = Math.round(response.carttotal * 100) / 100
						}
					    if(objParams.quantity == 0){ // remove div no record found
					        $('[recordID="'+ objParams.recordID +'"]').closest('.plain-card').remove()
					    }
					    if(response.cartcount && $('#cartcountid').length){ 
					    	$('#cartcountid').html(response.cartcount); 
					    } else if(response.cartcount && $('.clsshowcartcount').length){ 
						    var cls = 'clscartcount1';
						    if(response.cartcount > 9 ) { cls = 'clscartcount2';}
						    $('.clsshowcartcount').append('<span id="cartcountid" class="'+ cls +'">'+ response.cartcount +'</span>');
						    $('#cartcountid').on('click', function(){ $('#cartcountid').parent().find('img').trigger('click'); })
					    }
	
						response.carttotal = response.carttotal ? response.carttotal : '0';
						$('#cartitemssubtotal8').html('$ '+ response.carttotal+'');
						response.cartcount = response.cartcount ? response.cartcount : '0';
						$('#cartitemcount7').html('Cart Subtotal '+ response.cartcount+'item(s) :');
					    if (response.cartcount == 0) {
					        $('[id^="proceedtocheckout"]').hide()
					    } else {
					        $('[id^="proceedtocheckout"]').show()
					    }
	
						shareAppData('Item added to the cart successfully.', 'toast');
						return;
					} else if(response.stockquantity && element){
							element.val(response.stockquantity);					
					} else {
 	var quantityTotal = $('#'+objParams.recordID+'_quantity').val();
 	if(quantityTotal){
		quantityTotal =  parseInt(quantityTotal)-1;
		$('#'+objParams.recordID+'_quantity').val(quantityTotal);
 	}else {
		$('#'+objParams.recordID+'_quantity').val(1);
 	}
						var errorMessage = '';
						errorMessage = 'Item is Out-of-Stock';
						if( response.error &&  response.error.trim() != ''){
							errorMessage = response.error;
						}
						if(errorMessage){
							shareAppData(errorMessage, 'toast');
						}
						return;
					 }
					}); //close client after call
				},
				error: function (xhr, status, error) {
					$('#display_loading').addClass('hideme');
				},
			});
			}); // close precessbeforecall
		} catch (error) {
			$('#display_loading').addClass('hideme');
			console.log('Error in addtocartv2_fieldname', error);
		}
	} 
 function addToCartV2ProcessBeforeCallCartitems5da73cac545050343288ce7aQuantity(element, objParams, callback) { 	var response = objParams;
 callback(); 
 } 
 function addToCartV2ProcessAfterCallCartitems5da73cac545050343288ce7aQuantity(response, callback) {
 callback(); 
 }
	function addtocartv2Cartitems5da73cac545050343288ce7aadditem23(objParams, element) {
		try {
			objParams.userId = localStorage.getItem('userID');
			var ajaXCallURL = $.trim($('#ajaXCallURL').val());
			objParams.tokenKey = getParameterByName('tokenKey');
			objParams.secretKey = getParameterByName('secretKey');
		objParams.updatequantity = true;
			var callUrl = ajaXCallURL + '/milestone003/addtocartv2_Cartitems5da73cac545050343288ce7a_app_productcartlist';
			$('#display_loading').removeClass('hideme');
 			addToCartV2ProcessBeforeCallCartitems5da73cac545050343288ce7aadditem(element, objParams, function(){
			$.ajax({
				url: callUrl,
				data: objParams,
				type: 'POST',
				success: function (response) {
					$('#display_loading').addClass('hideme');
 					addToCartV2ProcessAfterCallCartitems5da73cac545050343288ce7aadditem(response, function(){
					if (response.status == 0) {
						if(response.carttotal){
						    response.carttotal = Math.round(response.carttotal * 100) / 100
						}
					    if(objParams.quantity == 0){ // remove div no record found
					        $('[recordID="'+ objParams.recordID +'"]').closest('.plain-card').remove()
					    }
					    if(response.cartcount && $('#cartcountid').length){ 
					    	$('#cartcountid').html(response.cartcount); 
					    } else if(response.cartcount && $('.clsshowcartcount').length){ 
						    var cls = 'clscartcount1';
						    if(response.cartcount > 9 ) { cls = 'clscartcount2';}
						    $('.clsshowcartcount').append('<span id="cartcountid" class="'+ cls +'">'+ response.cartcount +'</span>');
						    $('#cartcountid').on('click', function(){ $('#cartcountid').parent().find('img').trigger('click'); })
					    }
	
						response.carttotal = response.carttotal ? response.carttotal : '0';
						$('#cartitemssubtotal8').html('$ '+ response.carttotal+'');
						response.cartcount = response.cartcount ? response.cartcount : '0';
						$('#cartitemcount7').html('Cart Subtotal '+ response.cartcount+'item(s) :');
					    if (response.cartcount == 0) {
					        $('[id^="proceedtocheckout"]').hide()
					    } else {
					        $('[id^="proceedtocheckout"]').show()
					    }
	
						shareAppData('Item added to the cart successfully.', 'toast');
						return;
					} else {
 	var quantityTotal = $('#'+objParams.recordID+'_quantity').val();
 	if(quantityTotal){
		quantityTotal =  parseInt(quantityTotal)-1;
		$('#'+objParams.recordID+'_quantity').val(quantityTotal);
 	}else {
		$('#'+objParams.recordID+'_quantity').val(1);
 	}
						var errorMessage = '';
						errorMessage = 'Item is Out-of-Stock';
						if( response.error &&  response.error.trim() != ''){
							errorMessage = response.error;
						}
						if(errorMessage){
							shareAppData(errorMessage, 'toast');
						}
						return;
					 }
					}); //close client after call
				},
				error: function (xhr, status, error) {
					$('#display_loading').addClass('hideme');
				},
			});
			}); // close precessbeforecall
		} catch (error) {
			$('#display_loading').addClass('hideme');
			console.log('Error in addtocartv2_fieldname', error);
		}
	} 
 function addToCartV2ProcessBeforeCallCartitems5da73cac545050343288ce7aadditem(element, objParams, callback) { 	var response = objParams;
 callback(); 
 } 
 function addToCartV2ProcessAfterCallCartitems5da73cac545050343288ce7aadditem(response, callback) {
 callback(); 
 }
	function getcartcountCartitems5da73cac545050343288ce7a(objParams) {
		try {
			objParams.userId = localStorage.getItem('userID');
			var ajaXCallURL = $.trim($('#ajaXCallURL').val());
			objParams.tokenKey = getParameterByName('tokenKey');
			objParams.secretKey = getParameterByName('secretKey');
	
			var callUrl = ajaXCallURL + '/milestone003/getcartcount_Cartitems5da73cac545050343288ce7a';
			$('#display_loading').removeClass('hideme');
			$.ajax({
				url: callUrl,
				data: objParams,
				type: 'POST',
				success: function (response) {
                getcartcountProcessAfterCartitems5da73cac545050343288ce7a(response, function(){
					$('#display_loading').addClass('hideme');
					if (response.status == 0) {
						if(response.carttotal){
						    response.carttotal = Math.round(response.carttotal * 100) / 100
						}
						if(response.cartcount && $('.clsshowcartcount').length){
						    var cls = 'clscartcount1';
						    if(response.cartcount > 9 ) { cls = 'clscartcount2';}
						    $('.clsshowcartcount').append('<span id="cartcountid" class="'+ cls +'">'+ response.cartcount +'</span>');
						    $('#cartcountid').on('click', function(){ $('#cartcountid').parent().find('img').trigger('click'); })
						} else if(response.cartcount){
						    $('.clscartcount').html(response.cartcount).removeClass('hide');
						}
						response.carttotal = response.carttotal ? response.carttotal : '0';
						$('#cartitemssubtotal8').html('$ '+ response.carttotal+' ');
						response.cartcount = response.cartcount ? response.cartcount : '0';
						$('#cartitemcount7').html('Cart Subtotal '+ response.cartcount+' item(s) :');
						return;
					} else {
						shareAppData('Item is Out-of-Stock', 'toast');
						return;
					}
				  })
				},
				error: function (xhr, status, error) {
					$('#display_loading').addClass('hideme');
				},
			});
		} catch (error) {
			$('#display_loading').addClass('hideme');
			console.log('Error in getcartcount_fieldname', error);
		}
	} 
 function getcartcountProcessAfterCartitems5da73cac545050343288ce7a(response,callback) {
 callback(); 
 }
	function removefromcartv2Cartitems5da73cac545050343288ce7a(objParams, element) {
		try {
			objParams.userId = localStorage.getItem('userID');
			var ajaXCallURL = $.trim($('#ajaXCallURL').val());
			objParams.tokenKey = getParameterByName('tokenKey');
			objParams.secretKey = getParameterByName('secretKey');
	
			var callUrl = ajaXCallURL + '/milestone003/removefromcartv2_Cartitems5da73cac545050343288ce7a';
 			removefromcartV2ProcessBeforeCallCartitems5da73cac545050343288ce7aDelete(element, objParams, function(){
			$('#display_loading').removeClass('hideme');
			$.ajax({
				url: callUrl,
				data: objParams,
				type: 'POST',
				success: function (response) {
					$('#display_loading').addClass('hideme');
					if (response.status == 0) {
						if(response.carttotal){
						    response.carttotal = Math.round(response.carttotal * 100) / 100
						}
	
						response.carttotal = response.carttotal ? response.carttotal : '0';
						$('#cartitemssubtotal8').html('$ '+ response.carttotal+'');
						response.cartcount = response.cartcount ? response.cartcount : '0';
						$('#cartitemcount7').html('Cart Subtotal '+ response.cartcount+'item(s) :');
					    if (response.cartcount == 0) {
					        $('[id^="proceedtocheckout"]').hide()
					    } else {
					        $('[id^="proceedtocheckout"]').show()
					    }
			element.fadeOut(500);
	
						shareAppData('Item removed successfully.', 'toast');
						return;
					} else {
						shareAppData('Item is Out-of-Stock', 'toast');
						return;
					}
				},
				error: function (xhr, status, error) {
					$('#display_loading').addClass('hideme');
				},
			});
			}); // close precessbeforecall
		} catch (error) {
			$('#display_loading').addClass('hideme');
			console.log('Error in removefromcartv2_fieldname', error);
		}
	} 
 function removefromcartV2ProcessBeforeCallCartitems5da73cac545050343288ce7aDelete(element, objParams, callback) {
 callback(); 
 }