
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
     var totaldcard_collectioncontainer = 0;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#addproduct5', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_productpickeralllisting'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - addproduct5", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#done13', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_productcartlist'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - done13", error) 
		} 
	})
  showBottomMenu(); 
});//end of ready
 function showBottomMenu(){ 
   var menuObj = localStorage.getItem('objGetUserDetailsWithmenu');
   if(menuObj){
     menuObj = JSON.parse(menuObj);
     if( menuObj.data && menuObj.data.roleName ) {
          var roleName = menuObj.data.roleName;
     }
   }
   try { 
      var bottommenu = ''; 
	    bottommenu += '<div class="mobilebottommenu">'
	    bottommenu += '    <div class="row">'
	    bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Home" fileName="app_userhome_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_home.svg"><span>Home</span></a></div>'
	    bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="QuickShop" fileName="app_productpickerlist_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_quickshopactive.svg"><span>Quick Shop</span></a></div>'
	    bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Orders" fileName="app_myorderslisting_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_home.svg"><span>Orders</span></a></div>'
	    bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Chat" fileName="undefined_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_chat.svg"><span>Chat</span></a><div style="display:none !important"  class="chatunreadcount"></div></div>'
	    bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="More" fileName="app_custmoreinfodetails_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_more.svg"><span>More</span></a></div>'
	    bottommenu += '    </div>'
	    bottommenu += '</div>'
      $('#bottommenu14').html(bottommenu)
  } catch(err){
     // console.log('Error in showBottomMenu', err);
  }
}
