
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var totaldcard_collectioncontainer = 0;
$(document).ready(function () {
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"))
    }

    var objParamsToken = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsToken.tokenKey = getParameterByName('tokenKey');
    objParamsToken.secretKey = getParameterByName('secretKey');

    var userRole = $('#userRole').val();
    var userID = $('#userID').val();
    var createrOfRecord = $('#createrOfRecord').val();
    var queryMode = getParameterByName('queryMode');
    var recordID = $.trim($('#recordID').val());
    var addSessionComments = [];


    var queryMode = getParameterByName('queryMode');
    var isMobile = $('#isMobile').val();
    var isiPad = $('#isiPad').val();
    if (queryMode != '') {
        var tokenKey = $('#tokenKey').val();
        var objParamsList = {};
        objParamsList.queryMode = queryMode;
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParamsList.tokenKey = getParameterByName('tokenKey');
        objParamsList.secretKey = getParameterByName('secretKey');
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = isMobile;
        objParamsList.isiPad = isiPad;
        objParamsList.applyFilter = false;
        getDataProcessBeforeCalldcard_collectioncontainerOrders5da73cac545050343288ce7a(objParamsList, function (processBeforeRes) {
            var applyFilter = getParameterByName('applyFilter');
            if (applyFilter == null && objParamsList.applyFilter == false) {
                objParamsList.type = 'redeemstampcard';
                objParamsList.applystaticfilter = true;
            }
            var dcard_collectioncontainerapp_mystampcardlisting = localStorage.getItem('dcard_collectioncontainerapp_mystampcardlisting');
            var applyFilter = getParameterByName('applyFilter');
            $('#display_loading').removeClass('hideme');
          //  if (dcard_collectioncontainerapp_mystampcardlisting && applyFilter != 'true') {
           //     response = JSON.parse(dcard_collectioncontainerapp_mystampcardlisting);
            //    $('#collectioncontainerDivdcard_collectioncontainer').html('');
            //    getdcard_collectioncontainerapp_mystampcardlistingMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
             //   dcard_collectioncontainerapp_mystampcardlistingSync(response.timestamp);
           // } else {
                show_dcard_collectioncontainerapp_mystampcardlisting_Details(objParamsList)
           // }
        });//End of get data process before call.
    }

    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#backbutton1', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_custmoreinfodetails';
                   var  appUser = JSON.parse(localStorage.getItem("appUser"));

                   if(appUser.rolename.toLowerCase() == "consultant")
                   {
                   nextPage = 'app_consultantcustmoreinfodetails';
                   }
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "update";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - backbutton1", error)
        }
    })
});//end of ready
function getDataProcessBeforeCalldcard_collectioncontainerOrders5da73cac545050343288ce7a(objParamsList, callback) {
    var response = objParamsList

    callback();
}
function dcard_collectioncontainerapp_mystampcardlistingSync(timestamp) {
    try {
        var objParamsList = {};
        objParamsList.queryMode = 'mylist';
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParamsList.tokenKey = getParameterByName('tokenKey');
        objParamsList.secretKey = getParameterByName('secretKey');
        objParamsList.ajaXCallURL = ajaXCallURL;
        objParamsList.isMobile = true;
        objParamsList.timestamp = timestamp;
        $.ajax({
            url: objParamsList.ajaXCallURL + '/milestone003/syncListDetails_Orders5da73cac545050343288ce7a_app_mystampcardlisting',
            data: objParamsList,
            type: 'POST',
            success: function (response) {
                $('#display_loading').addClass('hideme');
                if (response.status != undefined && response.status == 1) {
                    localStorage.removeItem('dcard_collectioncontainerapp_mystampcardlisting');
                    var objParamsList = {};
                    objParamsList.queryMode = 'mylist';
                    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                    objParamsList.tokenKey = getParameterByName('tokenKey');
                    objParamsList.secretKey = getParameterByName('secretKey');
                    objParamsList.ajaXCallURL = ajaXCallURL;
                    objParamsList.isMobile = 'true';
                    objParamsList.isiPad = false;
                    objParamsList.timestamp = timestamp;
                    var applyFilter = getParameterByName('applyFilter');
                    if (applyFilter == null && objParamsList.applyFilter == false) {
                        objParamsList.type = 'redeemstampcard';
                        objParamsList.applystaticfilter = true;
                    }
                    show_dcard_collectioncontainerapp_mystampcardlisting_Details(objParamsList)
                }
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            }
        });
    } catch (err) {
        // console.log('Error in workingtoolsSync', err);
    }
}
function show_dcard_collectioncontainerapp_mystampcardlisting_Details(objParamsList) {
    var applyFilter = getParameterByName('applyFilter');
    if (applyFilter == null && objParamsList.applyFilter == false) {
        objParamsList.type = 'redeemstampcard';
        objParamsList.applystaticfilter = true;
    }
    localStorage.setItem('appmystampcardlistingFilterBox', '');
    objParamsList.clientid = localStorage.getItem("userID");
    $.ajax({
        url: objParamsList.ajaXCallURL + '/milestone003/getListDetails_Orders5da73cac545050343288ce7a_app_mystampcardlisting_dcard_collectioncontainer',
        data: objParamsList,
        type: 'POST',
        success: function (response) {
            getDataProcessAfterCalldcard_collectioncontainerOrders5da73cac545050343288ce7a(response, function () {
                if (response.status != undefined && response.status == 0) {
                    if (objParamsList.isMobile == 'true') {
                        $('#collectioncontainerDivdcard_collectioncontainer').html('');
                        //localStorage.removeItem('dcard_collectioncontainerapp_mystampcardlisting');
                        localStorage.setItem('dcard_collectioncontainerapp_mystampcardlisting',JSON.stringify(response));
                        getdcard_collectioncontainerapp_mystampcardlistingMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    } else if (objParamsList.isiPad == 'true') {
                        getdcard_collectioncontainerapp_mystampcardlistingiPadView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    } else {
                        getdcard_collectioncontainerapp_mystampcardlistingWebView(response, objParamsList.tokenKey, objParamsList.queryMode);
                    }
                    $('#display_loading').addClass('hideme');
                } else {
                    $('#display_loading').addClass('hideme')
                }
            });
        },
        error: function (xhr, status, error) {
            $('#display_loading').addClass('hideme')
            handleError(xhr, status, error);
        },
    });
} // end of function     

function getDataProcessAfterCalldcard_collectioncontainerOrders5da73cac545050343288ce7a(response, callback) {

    callback();
}

function getdcard_collectioncontainerapp_mystampcardlistingMobileView(response, tokenKey, queryMode) {
    var html = '';
    if (response.data.length == 0) {
        html += '<tr>';
        html += '<td colspan="1" class="text_center first_row_table_td">';
        html += 'No record found';
        html += '</td>';
        html += '</tr>';
    } else {
        html = '';
        $.each(response.data, function (keyList, objList) {

            var notusedstamp = 10 - objList.quantity;


            html += '      <div class="col s12 mystamp">';

            html += '   <div id="sg4099" class="row">';
            html += '   <div id="sg5099" class="col s12 cls_sg4099">';
            html += '      <div id="group2row6" class="" style="">';
                 
            html += '          <div id="sg8099" class="row">';
            html += '            <div id="sg9099" class="col s12 clssg8099">';
            html += '                <div class="divtag languagetranslation " id="availablerewardpoints8" style="">'+objList.merchantname+'</div>';
            html += '             </div>';
            html += '          </div>'
            html += '       </div>'
            html += '   </div>'
            html += '  </div>'

            html += '<div id="sg5095" class="row  padding_0px">';
            html += '  <div id="sg6095" class="col s12 padding_0px">';
            html += '      <div class="clsoutercollectiondiv" id="dcardcollectioncontainer6">';
            html += '         <div id="collectioncontainerDivdcard_collectioncontainer" style="" class="">'
            
                html += '   <div class="row">';
                html += '   <div class="col s12">';

                if (objList.quantity > 0) {
                for (i = 0; i < objList.quantity; i++) {
                html += '   <div style="text-align: center;margin-top: 10px;margin-bottom: 10px;" class="col s2"><img style="width: 60px;height: 60px;" src="filledstamp.png"/></div>';
                }
                }

                if (notusedstamp > 0) {
                for (i = 0; i < notusedstamp; i++) {
                html += '   <div style="text-align: center;margin-top: 10px;margin-bottom: 10px;" class="col s2"><img style="width: 60px;height: 60px;" src="emptystamp.png"/></div>';
                }
                }

                html += '   </div>';
                html += '   </div>';
            
                html += '   </div>';
            html += '      </div>';
            html += '  </div>';
            html += ' </div>';

            html += '<div id="sg4099" class="row bottom">';
            html += '   <div id="sg5099" class="col s12 cls_sg4099" style="padding: 8px 20px;">';
            html += '      <div id="group2row6" class="" style="">';
            html += '        <div id="sg6099" class="row">';
            html += '             <div id="sg7099" class="col s12 clssg6099">';
            html += '              <div class="divtag languagetranslation " id="totalrewards7" style="text-align: center;">'+objList.quantity + '/10</div>';
            html += '            </div>';
            html += '         </div>';
            
            html += '       </div>'
            html += '   </div>'
            html += ' </div>'

            html += ' </div>'



              //  var 


              //  $('#collectioncontainerDivdcard_collectioncontainer').html(html)
                     });
        
        $('.mystamp22').html(html)
        $('#full-body-container').addClass('fadeInUp');
        if (!response.showShimmer) {
        dcardLoaded['dcard_collectioncontainer'] = true;
        $('#collectioncontainerDivdcard_collectioncontainer').find('.view_list_record').removeClass('shimmer');
        }
        $('.carddropdown').material_select();
        $('<input>').attr({ type: 'hidden', class: 'cardtoggleswitch', id: 'togleswitchvalue' }).appendTo('body')
        if ($('.js-candlestick').length) $('.js-candlestick').candlestick({ afterSetting: function (input, wrapper, value) { $('#togleswitchvalue').val(value).attr('recordID', input.attr('id')).trigger('click'); } });

         //    if (radioGroups && radioGroups.length) {
        //        for (var key in radioGroups) {
        //            var groupName = radioGroups[key];
        //            $('input:radio[name=' + groupName + ']:first').prop('checked', true);
        //            $('input:radio[name=' + groupName + ']:first').trigger('change');
        //        }
        //    }
        // };

    }
};
function getLocalImagedcard_collectioncontainer(objList, mediaID, fileName) {
    try {
        var appJSON = {};
        appJSON.nextButtonCallback = 'handleLocalImagedcard_collectioncontainer';
        appJSON.url = CDN_PATH + mediaID + '_compressed.png';
        appJSON.fileMimeType = 'image/png';
        appJSON.fileName = fileName;
        appJSON.objList = objList;
        var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
        if (isAndroid > -1) {
            window.Android.getLocalImage(JSON.stringify(appJSON))
        } else {
            setupWebViewJavascriptBridge(function (bridge) {
                bridgeObj = bridge;
                bridgeObj.callHandler('getLocalImage', appJSON, function (response) { });
                bridgeObj.registerHandler('handleLocalImagedcard_collectioncontainer', function (responseData, responseCallback) {
                    handleLocalImagedcard_collectioncontainer(responseData)
                });
            });
        }
    } catch (err) {

    }
}
function handleLocalImagedcard_collectioncontainer(response) {
    var objList = response.dataDictionay.objList;
    var html = '';

    html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.quantity + objList.merchantname + objList.expirationdate + objList.description) + '">';
    html += '      		<div class="col s12 m12">';
    html += '               <div class="card-content">';
    html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_collectioncontainer" style="" >';
    html += '      <div class="row  element" style=""  >';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s12 clssg1195  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['quantity'] = objList['quantity'] ? objList['quantity'] : '0';
    if (response.showShimmer) {
        objList['quantity'] = '';
    }
    var quantity = objList['quantity'];
    html += '           <div recordID="' + objList._id + '"   id="quantity9" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Quantity  :</span>' + quantity + '</div>';
    html += '     </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s12 clssg3195  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['merchantname'] = objList['merchantname'] ? objList['merchantname'] : '';
    if (response.showShimmer) {
        objList['merchantname'] = '';
    }
    var merchantname = objList['merchantname'];
    html += '           <div recordID="' + objList._id + '"   id="merchantname10" class="languagetranslation " style="" >' + merchantname + '</div>';
    html += '     </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s12 clssg5195  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['expirationdate'] = objList['expirationdate'] ? moment(new Date(objList['expirationdate'])).format('DD MMM YYYY') : '';
    var expirationdate = objList['expirationdate'];
    html += '           <div recordID="' + objList._id + '"   id="expirationdate11" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Expiry Date :</span>' + expirationdate + '</div>';
    html += '     </div>';
    var adddbclass = ''
    html += '           <div recordID="' + objList._id + '" class="col s12 clssg7195  ' + adddbclass + ' " style=" cursor: pointer;">';
    objList['description'] = objList['description'] ? objList['description'] : '';
    if (response.showShimmer) {
        objList['description'] = '';
    }
    var description = objList['description'];
    html += '           <div recordID="' + objList._id + '"   id="description12" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Description :</span>' + description + '</div>';
    html += '     </div>';
    html += '     </div>';
    html += '      				</div>';
    html += '          </div>';
    html += '        </div>';
    html += '     </div>';
    html += '   </div>';
    $('#collectioncontainerDivdcard_collectioncontainer').append(html)
    $('#full-body-container').addClass('fadeInUp');
    dcardLoaded['dcard_collectioncontainer'] = true;
    $('#collectioncontainerDivdcard_collectioncontainer').find('.view_list_record').removeClass('shimmer');
    // after html bining code
};

function getdcard_collectioncontainerapp_mystampcardlistingPadView(response, tokenKey, queryMode) {
    var html = '';
    if (response.data.length == 0) {
        html += '<tr>';
        html += '<td colspan="1" class="text_center first_row_table_td">';
        html += 'No record found';
        html += '</td>';
        html += '</tr>';
    } else {
        html = '';
        $.each(response.data, function (keyList, objList) {

            html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.quantity + objList.merchantname + objList.expirationdate + objList.description) + '">';
            html += '      		<div class="col s12 m12">';
            html += '               <div class="card-content">';
            html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_collectioncontainer" style="" >';
            html += '      <div class="row  element" style=""  >';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg1195  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['quantity'] = objList['quantity'] ? objList['quantity'] : '0';
            if (response.showShimmer) {
                objList['quantity'] = '';
            }
            var quantity = objList['quantity'];
            html += '           <div recordID="' + objList._id + '"   id="quantity9" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Quantity  :</span>' + quantity + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg3195  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['merchantname'] = objList['merchantname'] ? objList['merchantname'] : '';
            if (response.showShimmer) {
                objList['merchantname'] = '';
            }
            var merchantname = objList['merchantname'];
            html += '           <div recordID="' + objList._id + '"   id="merchantname10" class="languagetranslation " style="" >' + merchantname + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg5195  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['expirationdate'] = objList['expirationdate'] ? moment(new Date(objList['expirationdate'])).format('DD MMM YYYY') : '';
            var expirationdate = objList['expirationdate'];
            html += '           <div recordID="' + objList._id + '"   id="expirationdate11" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Expiry Date :</span>' + expirationdate + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg7195  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['description'] = objList['description'] ? objList['description'] : '';
            if (response.showShimmer) {
                objList['description'] = '';
            }
            var description = objList['description'];
            html += '           <div recordID="' + objList._id + '"   id="description12" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Description :</span>' + description + '</div>';
            html += '     </div>';
            html += '     </div>';
            html += '      				</div>';
            html += '          </div>';
            html += '        </div>';
            html += '     </div>';
            html += '   </div>';
        }); // end of each loop
    };
    $('#collectioncontainerDivdcard_collectioncontainer').html(html)
};

function getdcard_collectioncontainerapp_mystampcardlistingWebView(response, tokenKey, queryMode) {
    var html = '';
    if (response.data.length == 0) {
        html += '<tr>';
        html += '<td colspan="1" class="text_center first_row_table_td">';
        html += 'No record found';
        html += '</td>';
        html += '</tr>';
    } else {
        html = '';
        $.each(response.data, function (keyList, objList) {

            html += '      <div class="row plain-card search" search="' + removeSpecialChars(objList.quantity + objList.merchantname + objList.expirationdate + objList.description) + '">';
            html += '      		<div class="col s12 m12">';
            html += '               <div class="card-content">';
            html += '                  <div     status="' + objList.status + '"  recordID="' + objList._id + '" class="shimmer card  view_list_record dcard_collectioncontainer" style="" >';
            html += '      <div class="row  element" style=""  >';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg1195  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['quantity'] = objList['quantity'] ? objList['quantity'] : '0';
            if (response.showShimmer) {
                objList['quantity'] = '';
            }
            var quantity = objList['quantity'];
            html += '           <div recordID="' + objList._id + '"   id="quantity9" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Quantity  :</span>' + quantity + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg3195  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['merchantname'] = objList['merchantname'] ? objList['merchantname'] : '';
            if (response.showShimmer) {
                objList['merchantname'] = '';
            }
            var merchantname = objList['merchantname'];
            html += '           <div recordID="' + objList._id + '"   id="merchantname10" class="languagetranslation " style="" >' + merchantname + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg5195  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['expirationdate'] = objList['expirationdate'] ? moment(new Date(objList['expirationdate'])).format('DD MMM YYYY') : '';
            var expirationdate = objList['expirationdate'];
            html += '           <div recordID="' + objList._id + '"   id="expirationdate11" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Expiry Date :</span>' + expirationdate + '</div>';
            html += '     </div>';
            var adddbclass = ''
            html += '           <div recordID="' + objList._id + '" class="col s12 clssg7195  ' + adddbclass + ' " style=" cursor: pointer;">';
            objList['description'] = objList['description'] ? objList['description'] : '';
            if (response.showShimmer) {
                objList['description'] = '';
            }
            var description = objList['description'];
            html += '           <div recordID="' + objList._id + '"   id="description12" class="languagetranslation " style="" ><span class="prefixicon languagetranslation">Description :</span>' + description + '</div>';
            html += '     </div>';
            html += '     </div>';
            html += '      				</div>';
            html += '          </div>';
            html += '        </div>';
            html += '     </div>';
            html += '   </div>';
        }); // end of each loop 1
    };
    $('#collectioncontainerDivdcard_collectioncontainer').html(html)
};
