var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = "";
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
  $("#recordID").val(getParameterByName("recordID"));
  var queryMode = getParameterByName("queryMode");
  var authKey = $("#authKey").val();
  var appID = $("#hdnAppID").val();
  if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
    $("#headerPageName").html(localStorage.getItem("headerPageName"));
  }

  var objParamsToken = {};
  var ajaXCallURL = $.trim($("#ajaXCallURL").val());
  objParamsToken.tokenKey = getParameterByName("tokenKey");
  objParamsToken.secretKey = getParameterByName("secretKey");

  var userRole = $("#userRole").val();
  var userID = $("#userID").val();
  var createrOfRecord = $("#createrOfRecord").val();
  var queryMode = getParameterByName("queryMode");
  var recordID = $.trim($("#recordID").val());
  var addSessionComments = [];
  var forwardChekbox = [];

  var roleName = localStorage.getItem("roleName");
                 if(roleName.toLowerCase() == "consultant" )
                   {
                    $("#scanqrcode27_div").addClass("hide")
                   $("#sg7704").addClass("hide")
                   $("#sg6804").addClass('s12');
  
                   }
  var isOpenForwardPopup = 0;
  $(document).on("click", "#addstampcards28", function () {
    var objParams = {};
    var tested = $.trim($("#tested34").val());
    if ($("#tested34_div").is(":visible")) {
      objParams.tested = tested;
    }
    var tempobjParams = getParams(window.location.href);
    function extend(obj, src) {
      for (var key in src) {
        if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
      }
      return obj;
    }
    objParams = extend(objParams, tempobjParams);
    var recordID = getParameterByName("merchantID");
    objParams.isDelete = 0;
    var ajaXCallURL = $.trim($("#ajaXCallURL").val());
    objParams.tokenKey = getParameterByName("tokenKey");
    objParams.secretKey = getParameterByName("secretKey");
    objParams.offlineDataID = localStorage.getItem("offlineDataID");
    var queryMode = getParameterByName("queryMode");
    if (queryMode == "update") {
      objParams.callUrl =
        ajaXCallURL +
        "/milestone003/saveAjaxreferraldetailsapp_merchantdetails";
    } else {
      objParams.callUrl =
        ajaXCallURL +
        "/milestone003/updateAjaxreferraldetailsapp_merchantdetails";
      objParams.recordID = recordID;
    }
    if (errorFields && Object.keys(errorFields).length) {
      $("#display_loading1").addClass("hideme");
      for (var firstErrorField in errorFields) {
        var controlType = errorFields[firstErrorField];
        errorFields = [];
        var errField = $("#" + firstErrorField);
        if (controlType == "dropdown") {
          errField.prev().prev().focus();
        } else {
          errField.focus();
        }
        validAll = true;
        return false;
      }
    }
    if (!validAll) {
      validAll = true;
      return false;
    }
    $("#addstampcards28").prop("disabled", true);
    $("#display_loading1").removeClass("hideme");
    if (addSessionComments.length > 0) {
      objParams.addSessionComments = addSessionComments;
    } else {
      objParams.addSessionComments = [];
    }
    var parentID = $("#parentID").val();
    var parentName = $("#parentName").val();
    if (parentID != "") {
      objParams.parentID = parentID;
      objParams.parentName = parentName;
    }
    if (
      typeof addedFiles != "undefined" &&
      addedFiles &&
      addedFiles.length > 0
    ) {
      objParams.addedFiles = addedFiles;
    }
    objParams.ajaXCallURL = $("#ajaXCallURL").val();
    objParams.organizationID = $("#organizationID").val();
    objParams.ajaXCallURL = $("#ajaXCallURL").val();
    objParams.organizationID = $("#organizationID").val();
    processBeforeCallForSavereferraldetails(objParams, {}, function (
      processBeforeRes
    ) {
      $.ajax({
        url: objParams.callUrl,
        data: objParams,
        type: "POST",
        success: function (response) {
          if (response.status == 0) {
            $("#display_loading1").addClass("hideme");
            response.nextPage = "app_userhome";
            processAfterCallForSavereferraldetails(response, function (
              processAfterRes
            ) {
              var tokenKey = getParameterByName("tokenKey");
              var secretKey = getParameterByName("secretKey");
              var queryMode = getParameterByName("queryMode");
              queryMode = queryMode.replace("edit", "");
              localStorage.setItem("headerPageName", "app_userhome");
              var queryString = window.location.search.slice(1);
              var newQuery =
                queryString +
                "&queryMode=mylist&tokenKey=" +
                tokenKey +
                "&secretKey=" +
                secretKey;
              var queryParams = queryStringToJSON(newQuery);
              queryString = $.param(queryParams);
              queryString = queryString.replace(/\+/g, "%20");
              queryString = decodeURIComponent(queryString);
              if (recordID == "") {
                window.location.href =
                  response.nextPage +
                  "_5da73cac545050343288ce7a.html?" +
                  queryString;
              } else {
                window.location.href =
                  response.nextPage +
                  "_5da73cac545050343288ce7a.html?" +
                  queryString;
              }
              return false;
            }); // End of After Process
          } else {
            $("#display_loading1").addClass("hideme");
            $("#2656d_error").html(response.error);
            $("#2656d_error").show();
          }
          $("#addstampcards28").removeProp("disabled");
        },
        error: function (xhr, status, error) {
          $("#display_loading1").addClass("hideme");
          $("#addstampcards28").removeProp("disabled");
        },
      });
      return false;
    }); // End of Before Process
  }); //end of Event Add Stamp Cards_is_click
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on("click", "#scanqrcode27", function () {
    var tokenKey = getParameterByName("tokenKey");
    var secretKey = getParameterByName("secretKey");
    var queryMode = getParameterByName("queryMode");
    var ajaXCallURL = $.trim($("#ajaXCallURL").val());
    loadNativescanqrcodeControl(tokenKey, queryMode, secretKey, ajaXCallURL);
  }); //end of Event Scan QR Code_is_click
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};
  var addedRecords = [];
  localStorage.setItem("addedRecords", []);
  $(document).on("click", "#backbutton1", function (e) {
    try {
      var element = $(this);
      var nextPage =
        localStorage.getItem("isFromHome") == "true"
          ? "app_userhome"
          : "app_merchantlisting";
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href =
        nextPage + "_5da73cac545050343288ce7a.html?" + queryString;
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error);
    }
  });
  var addedRecords = [];
  localStorage.setItem("addedRecords", []);
  $(document).on("click", "#icongetdirection12", function (e) {
    try {
      var tokenKey = getParameterByName("tokenKey");
      var secretKey = getParameterByName("secretKey");
      var queryMode = getParameterByName("queryMode");
      var ajaXCallURL = $.trim($("#ajaXCallURL").val());
      loadNativeicon_getdirectionControl(
        tokenKey,
        queryMode,
        secretKey,
        ajaXCallURL
      );
      return false;
      // var element = $(this);
      // var nextPage = 'app_shoplocationoverlaymap';
      // var queryParams = queryStringToJSON();
      // queryParams["queryMode"] = "mylist";
      // var recordID = $(this).attr("recordID");
      // if (recordID) {
      //     queryParams["recordID"] = recordID;
      // }
      // var queryString = $.param(queryParams);
      // queryString = queryString.replace(/\+/g, "%20");
      // queryString = decodeURIComponent(queryString);
      // window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - icongetdirection12", error);
    }
  });
  var addedRecords = [];
  localStorage.setItem("addedRecords", []);
  $(document).on("click", "#shopdetails15", function (e) {
    try {
      var element = $(this);
      var nextPage = "app_merchantspecificationdetails";
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "update";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href =
        nextPage + "_5da73cac545050343288ce7a.html?" + queryString;
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - shopdetails15", error);
    }
  });
  var addedRecords = [];
  localStorage.setItem("addedRecords", []);
  $(document).on("click", "#iconnext416", function (e) {
    try {
      var element = $(this);
      var nextPage = "app_merchantspecificationdetails";
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "update";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href =
        nextPage + "_5da73cac545050343288ce7a.html?" + queryString;
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - iconnext416", error);
    }
  });
  var addedRecords = [];
  localStorage.setItem("addedRecords", []);
  $(document).on("click", "#stampcards23", function (e) {
    try {
      var element = $(this);
      var nextPage = "app_stampcardlisting";
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      //window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString + "&merchantID=" + recordID;
      window.location.href =
        nextPage + "_5da73cac545050343288ce7a.html?" + queryString;
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - stampcards23", error);
    }
  });
  var addedRecords = [];
  localStorage.setItem("addedRecords", []);
  $(document).on("click", "#iconnext24", function (e) {
    try {
      var element = $(this);
      var nextPage = "app_stampcardlisting";
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href =
        nextPage + "_5da73cac545050343288ce7a.html?" + queryString;
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - iconnext24", error);
    }
  });
  var addedRecords = [];
  localStorage.setItem("addedRecords", []);
  $(document).on("click", "#getdiscount26", function (e) {
    try {
      var status = $(this).attr("status") ? $(this).attr("status") : "";
      if (status != "Inactive") {
        var element = $(this);
        var nextPage = "app_merchantdiscountlist";
        var queryParams = queryStringToJSON();
        queryParams["queryMode"] = "mylist";
        queryParams["applyFilter"] = "false";
        var recordID = $(this).attr("recordID");
        if (getParameterByName("merchantID")) {
          queryParams.recordID = getParameterByName("merchantID");
        } else {
          if (recordID) {
            queryParams["recordID"] = recordID;
          }
        }
        queryParams.backPage = 'app_merchantdetails'
        var tokenKey = getParameterByName("tokenKey");
        var secretKey = getParameterByName("secretKey");
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href =
          nextPage + "_5da73cac545050343288ce7a.html?" + queryString;
        return false;
      }
    } catch (error) {
      console.log("Error in pageredirect workflow - getdiscount26", error);
    }
  });
  var paramsEdit = {};
  localStorage.setItem("aboutmerchant", "")
  paramsEdit.tokenKey = getParameterByName("tokenKey");
  paramsEdit.secretKey = getParameterByName("secretKey");
  paramsEdit.outletid = getParameterByName("recordID");
  $("#display_loading1").removeClass("hideme");
  getRecordByIDProcessBeforeCall502567(paramsEdit, function (processBeforeRes) {
    $.ajax({
      url:
        ajaXCallURL +
        "/milestone003/getRecordByCustomeQuery_app_merchantdetails_Bazaar5da73cac545050343288ce7a",
      data: paramsEdit,
      type: "POST",
      jsonpCallback: "callback",
      success: function (response) {
        $("#display_loading1").addClass("hideme");
        getRecordByIDProcessAfterCall502567(response, function (
          processBeforeRes
        ) {
          if (
            response.status != undefined &&
            response.status == 0 &&
            response.recordDetails != undefined
          ) {
            var objParamsList = {};
            var queryMode = $("#queryMode").val();
            objParamsList.queryMode = queryMode;
            var tokenKey = $("#tokenKey").val();
            objParamsList.tokenKey = tokenKey;
            if (response.recordDetails.accumalatedstampcard != undefined)
              $("#accumalatedstampcard33").val(
                response.recordDetails.accumalatedstampcard
              );
            if (!$("#backbutton1").html()) {
              $("#backbutton1").append(response.recordDetails.undefined);
            }
            response.recordDetails["createdOn_preserved"] =
              response.recordDetails["createdOn"];
            response.recordDetails["createdOn"] = response.recordDetails[
              "createdOn"
            ]
              ? moment(new Date(response.recordDetails["createdOn"])).format(
                "DD MMMM YYYY hh:mm A"
              )
              : "";
            if (!$("#createdOn11").html()) {
              $("#createdOn11").append(response.recordDetails.createdOn);
              $("#createdOn11").remove();
            }
            response.recordDetails["createdOn"] =
              response.recordDetails["createdOn_preserved"];
            if (response.recordDetails.aboutmerchant) {

              var html = "";
              var description18Edit = response.recordDetails.aboutmerchant;//.replace(/<[^>]*>?/gm, '');
              description18Edit = description18Edit.replace(/\n/g, '<br />');

              var charLength = description18Edit.length;
              var firstLine = description18Edit.slice(0, 200);
              var secondLine = description18Edit.slice(200, charLength);
              localStorage.setItem("firstLine", firstLine);
              localStorage.setItem("secondLine", secondLine);
              //html = description18Edit;
              if (charLength > 200) {
                //  html = description18Edit;
                firstLine = firstLine
                $("#myBtn").css("display", "inline");
                $("#more").css("display", "none");
                $("#dots").css("display", "inline");
                //  $("#more").html(secondLine);
                //html += `<div>${firstLine}<span id="dots">...</span><span id="more" style="display:none;">${secondLine}</span><p  onclick="showMoreLess()" class="showMoreBtM" id="myBtn"> Show more</p></div>`;
                //  $('#merchantdescription134').css("text-overflow: ellipsis; ");

                html += firstLine
              } else {
                html = description18Edit;
              }

              $('#aboutDesc').append(html);
            }
            // if (response.recordDetails.aboutmerchant) {
            //   let aboutmerchant = response.recordDetails.aboutmerchant.replace(/<[^>]*>?/gm, '');
            //   $("#aboutmerchant19").append(
            //     aboutmerchant
            //   );
            // }
            /* if (!$("#aboutmerchant19").html()) {
              $("#aboutmerchant19").append(
                response.recordDetails.aboutmerchant
              );
            } */
            if (!$("#description13").html()) {
              $("#description13").append(response.recordDetails.description);
            }
            if (!$("#merchantcategory_name8").html()) {
              $("#merchantcategory_name8").append(
                response.recordDetails.merchantcategory_name
              );
            }
            if (!$("#name10").html()) {
              $("#name10").append(response.recordDetails.name);
            }
            if (!$("#status9").html()) {
              $("#status9").append(response.recordDetails.status);
            }
            if (!$("#description18").html()) {
              $("#description18").append(response.recordDetails.undefined);
            }

            $("#getdiscount26").attr(
              "recordID",
              response.recordDetails.currentID
            );

            if (
              response.recordDetails.status &&
              response.recordDetails.status == "Inactive"
            ) {
              // $('#getdiscount26').css('border','1px solid #d2d6d8 !important');
              // $('#getdiscount26').css('color','#d2d6d8');
              $("#getdiscount26").css("pointer-events", "none");
              $("#getdiscount26").removeClass("clssg5804");
              $("#getdiscount26").addClass("btn-disabled");

              $("#getdiscount26").attr("status", response.recordDetails.status);

              $("#stampcards23").css("pointer-events", "none");
              $("#stampcards23").css("color", "gray");
              $("#iconnext24").css("pointer-events", "none");
            }
            if (response.recordDetails.droplocation != undefined)
              $("#droplocation30").val(response.recordDetails.droplocation);
            if (
              response.recordDetails.droplocation &&
              response.recordDetails.droplocation["coordinates"]
            ) {
              var coordinates =
                response.recordDetails.droplocation["coordinates"];
              if (coordinates && coordinates.length) {
                localStorage.setItem("droplocationLatitude", coordinates[1]);
                localStorage.setItem("droplocationLongitute", coordinates[0]);
              }
            }
            if (response.recordDetails.droplocation_name != undefined)
              $("#droplocation_name32").val(
                response.recordDetails.droplocation_name
              );
            if (response.recordDetails.pickuplocation != undefined)
              $("#pickuplocation29").val(response.recordDetails.pickuplocation);
            if (
              response.recordDetails.pickuplocation &&
              response.recordDetails.pickuplocation["coordinates"]
            ) {
              var coordinates =
                response.recordDetails.pickuplocation["coordinates"];
              if (coordinates && coordinates.length) {
                localStorage.setItem("pickuplocationLatitude", coordinates[1]);
                localStorage.setItem("pickuplocationLongitute", coordinates[0]);
              }
            }
            if (response.recordDetails.pickuplocation_name != undefined)
              $("#pickuplocation_name31").val(
                response.recordDetails.pickuplocation_name
              );
            var url = "icon_location.png";
            $("#icongetdirection12").attr("src", url);
            var url = "icon_next.png";
            $("#iconnext24").attr("src", url);
            var url = "icon_next4.png";
            $("#iconnext416").attr("src", url);
            // getrecordbycustomquery - Stage - 111111111111
            if (
              response.recordDetails["merchantimage"] &&
              response.recordDetails["merchantimage"].length > 0
            ) {
              if (
                (response.recordDetails["merchantimage"][0].displayType =
                  "html")
              ) {
                var eleParent = $("#merchantimage6").parent();
                for (var key in response.recordDetails["merchantimage"]) {
                  var objImage = response.recordDetails["merchantimage"][key];
                  if (
                    response.recordDetails["merchantimage"][key].name == "Audio"
                  ) {
                    var token = $("#tokenKey").val();
                    if (token && token != "") {
                      token = $("#tokenKey").val();
                    } else {
                      token = getParameterByName("tokenKey");
                    }
                    var mediaIDa =
                      response.recordDetails["merchantimage"][0].mediaID;
                    var filenamea =
                      response.recordDetails["merchantimage"][0].fileName;
                    var CDN_PATH2 =
                      "https://devfiles.hokuapps.com/downloadOriginal?f=" +
                      mediaIDa +
                      "&fn=" +
                      filenamea +
                      "&t=" +
                      token;
                    var url = CDN_PATH2;
                  } else {
                    var filetodisplay = getuploadedfilepreview(objImage.fileNm);
                    if (filetodisplay && filetodisplay != objImage.fileNm) {
                      var url = filetodisplay;
                    } else {
                      var url = CDN_PATH + objImage.mediaID + "_compressed.png";
                    }
                  }
                  if (
                    response.recordDetails["merchantimage"][key].name == "Audio"
                  ) {
                    var html = "";
                    html += '<div class="col s12" style="float: right;">';
                    html +=
                      '<audio class="" src="' + url + '" controls></audio>';
                    html += "</div>";
                  } else {
                    var html =
                      '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' +
                      url +
                      '" />';
                  }
                  if (!key || key == "0") {
                    eleParent.html(html);
                  } else {
                    eleParent.append(html);
                  }
                }
              } else {
                if (
                  response.recordDetails["merchantimage"][key].name == "Audio"
                ) {
                  var url =
                    CDN_PATH +
                    response.recordDetails["merchantimage"][0].mediaID;
                } else {
                  var url =
                    CDN_PATH +
                    response.recordDetails["merchantimage"][0].mediaID +
                    "_compressed.png";
                }
                $("#merchantimage6").attr("src", url);
              }
            }

            if (
              response.recordDetails.outletList &&
              response.recordDetails.outletList.length > 0
            ) {
              var outletList = [];
              if (localStorage.getItem("isFromHome") == "true") {
                $.each(response.recordDetails.outletList, function (
                  keyList,
                  objList
                ) {
                  if (
                    objList.outletaddress &&
                    objList.outletaddress.coordinates &&
                    objList.outletaddress.coordinates.length > 0
                  ) {
                    outletList = objList;
                  }
                });
              } else {

                $.each(response.recordDetails.outletList, function (
                  keyList,
                  objList
                ) {
                  if (objList._id == getParameterByName("recordID")) {
                    outletList = objList;
                  }
                });

              }

              if (response.recordDetails.exactaddress && response.recordDetails.exactaddress !== undefined) {
                $("#extactaddress").append($.trim(response.recordDetails.exactaddress.replace(/,(\s+)?$/, '')));
              } else {
                $(".extactaddresscls").remove();
              }
              if (response.recordDetails.contactnumber && response.recordDetails.contactnumber !== undefined) {
                $("#contactnumber").append('<a href="tel:' + $.trim(response.recordDetails.contactnumber.replace(/,(\s+)?$/, '')) + '">' + $.trim(response.recordDetails.contactnumber.replace(/,(\s+)?$/, '')) + '</a>');
              } else {
                $(".contactnumbercls").remove();
              }

              if (
                outletList &&
                outletList.outletaddress &&
                outletList.outletaddress_name
              ) {
                $("#icongetdirection12").removeClass("hide");
                localStorage.setItem(
                  "merchantlocationLatitude",
                  outletList.outletaddress.coordinates[1]
                );
                localStorage.setItem(
                  "merchantlocationLongitute",
                  outletList.outletaddress.coordinates[0]
                );
                localStorage.setItem(
                  "merchantAddressText",
                  outletList.outletaddress_name &&
                    outletList.outletaddress_name != ""
                    ? outletList.outletaddress_name
                    : ""
                );
              }
            }
            if (!$("#merchantdetails2").html()) {
              $("#merchantdetails2").append(response.recordDetails.undefined);
            }
            if (!$("#merchantoverview21").html()) {
              $("#merchantoverview21").append(response.recordDetails.undefined);
            }
            if (response.recordDetails.tested != undefined)
              $("#tested34").val(response.recordDetails.tested);
            if (!$("#shopdetails15").html()) {
              $("#shopdetails15").append(response.recordDetails.undefined);
            }
            if (!$("#stampcards23").html()) {
              $("#stampcards23").append(response.recordDetails.undefined);
            }

            Materialize.updateTextFields();
            $(".languagetranslation.fieldshimmer")
              .removeClass("fieldshimmer")
              .fadeOut(0)
              .fadeIn(100);
          }
        }); // end of getRecord By ID
      },
      error: function (xhr, status, error) {
        $("#display_loading1").addClass("hideme");
        handleError(xhr, status, error);
      },
    });
  }); // end of getRecord By ID
}); //end of ready
function getParams(url) {
  var urlParams = {};
  url.replace(new RegExp("([^?=&]+)(=([^&]*))?", "g"), function (
    $0,
    $1,
    $2,
    $3
  ) {
    if ($3 && $3 != "undefined") urlParams[$1] = $3;
  });
  return urlParams;
}
function processBeforeCallForSavereferraldetails(
  objParams,
  response,
  callback
) {
  objParams.type = "Stamp Card";

  objParams.referralAmount = 1;
  objParams.displayAmount = 1;
  objParams.status = "Approved";
  objParams.clientID = localStorage.getItem("userID");
  objParams.productid = localStorage.getItem("eventID");

  callback();
}
function processAfterCallForSavereferraldetails(response, callback) {
  shareAppData("You have grabbed stamp successfully.", "toast");

  callback();
}
function loadNativescanqrcodeControl(
  tokenKey,
  queryMode,
  secretKey,
  ajaXCallURL
) {
  try {
    var appJSON = {};
    appJSON.tokenKey = tokenKey;
    appJSON.secretKey = secretKey;
    appJSON.queryMode = queryMode;
    appJSON.action = queryMode;
    appJSON.ajaXCallURL = ajaXCallURL;
    var AWSCredentials = localStorage.getItem("AWSCredentials");
    if (localStorage.IDENTITY_TOKEN) {
      var token = localStorage.IDENTITY_TOKEN;
      var playload = JSON.parse(atob(token.split(".")[1]));
      appJSON.Authorization = token;
      appJSON.Expiration = playload.exp;
    } else if (AWSCredentials) {
      AWSCredentials = JSON.parse(AWSCredentials);
      appJSON.accessKeyId = AWSCredentials.accessKeyId;
      appJSON.secretAccessKey = AWSCredentials.secretAccessKey;
      appJSON.sessionToken = AWSCredentials.sessionToken;
      appJSON.Expiration = AWSCredentials.Expiration;
    }
    appJSON.msgText =
      "<b><b><b><b><b><b><b><b><b>undefined</b></b></b></b></b></b></b></b></b>";
    appJSON.organizationID = $("#organizationID").val();
    appJSON.userID = $("#userID").val();
    appJSON.callbackFunction = "setNativescanqrcodeControl";
    appJSON.nextButtonCallback = "setNativescanqrcodeControl";
    appJSON.appID = $("#appID").val();
    var element = element ? element : null;
    clientbeforeNativescanqrcode(appJSON, element, function (pbcRes) {
      if (DEVICE_TYPE == "ios") {
        setupWebViewJavascriptBridge(function (bridgeObj) {
          bridgeObj.callHandler(
            "loadNativeQRCodeScannerUpload",
            appJSON,
            function (response) { }
          );
          bridgeObj.registerHandler("setNativescanqrcodeControl", function (
            responseData,
            responseCallback
          ) {
            setNativescanqrcodeControl(responseData);
          });
        });
      } else {
        window.Android.loadNativeQRCodeScannerUpload(JSON.stringify(appJSON));
      }
    }); // end of process before call
  } catch (err) { }
}
function clientbeforeNativescanqrcode(appJSON, element, callback) {
  var response = appJSON;
  callback();
}
function setNativescanqrcodeControl(responseData) {
  try {
    if (responseData) {
      // Add Custome function Call here
      clientafterNativescanqrcode(responseData, function (pbcRes) {
        // handle client after call
      });
    }
  } catch (err) { }
}
function clientafterNativescanqrcode(response, callback) {
  if (response) {
    // Add Custome function Call here
    var barcode = response.data.split("&&");
    if (barcode != "") {
      var objParams = {};
      var recordID = barcode[0];
      objParams.isDelete = 0;
      var ajaXCallURL = $.trim($("#ajaXCallURL").val());
      objParams.tokenKey = getParameterByName("tokenKey");
      objParams.secretKey = getParameterByName("secretKey");
      objParams.offlineDataID = localStorage.getItem("offlineDataID");
      var merchantID = getParameterByName("merchantID");
      if (recordID == merchantID) {
        objParams.clientid = localStorage.getItem("userID");

        objParams.merchantid = recordID;

        var queryMode = getParameterByName("queryMode");
        // localStorage.setItem("eventID", recordID);
        objParams.callUrl =
          ajaXCallURL + "/milestone003/saveAjaxordersclientstampweb";
        objParams.recordID = recordID;
        $.ajax({
          url: objParams.callUrl,
          data: objParams,
          type: "POST",
          success: function (response) {
            if (response.status == 0) {
              $("#display_loading").addClass("hideme");
              shareAppData(
                "Congratulations! You have earned a stamp. Redeem Stamp from My Reward Points to get exciting offers.",
                "toast"
              );
              var objParams = {};
              //                        if (response.recordDetails && response.recordDetails[0]) {
              //                            $("#addstampcards28").trigger("click");
              //
              //                        } else {
              //                            shareAppData("Invalid QR Code.", "toast");
              //                        }
            } else {
              $("#display_loading").addClass("hideme");
              shareAppData(response.error, "toast");
            }
          },
          error: function (xhr, status, error) {
            $("#display_loading").addClass("hideme");
            shareAppData("Invalid QR Code.", "toast");
          },
        });
      } else {
        shareAppData("Invalid QR Code.", "toast");
      }

      //    return false;
    } else {
      shareAppData("Invalid QR Code.", "toast");
    }
  }
  console.log("last one");
}
function loadNativeicon_getdirectionControl(
  tokenKey,
  queryMode,
  secretKey,
  ajaXCallURL
) {
  try {
    var appJSON = {};
    appJSON.tokenKey = tokenKey;
    appJSON.secretKey = secretKey;
    appJSON.queryMode = queryMode;
    appJSON.action = queryMode;
    appJSON.ajaXCallURL = ajaXCallURL;
    var AWSCredentials = localStorage.getItem("AWSCredentials");
    if (localStorage.IDENTITY_TOKEN) {
      var token = localStorage.IDENTITY_TOKEN;
      var playload = JSON.parse(atob(token.split(".")[1]));
      appJSON.Authorization = token;
      appJSON.Expiration = playload.exp;
    } else if (AWSCredentials) {
      AWSCredentials = JSON.parse(AWSCredentials);
      appJSON.accessKeyId = AWSCredentials.accessKeyId;
      appJSON.secretAccessKey = AWSCredentials.secretAccessKey;
      appJSON.sessionToken = AWSCredentials.sessionToken;
      appJSON.Expiration = AWSCredentials.Expiration;
    }
    appJSON.organizationID = $("#organizationID").val();
    appJSON.userID = $("#userID").val();
    appJSON.callbackFunction = "setNativeicon_getdirectionControl";
    appJSON.nextButtonCallback = "setNativeicon_getdirectionControl";
    appJSON.appID = $("#appID").val();
    appJSON.isOtherNearbyLocation = true;
    clientbeforeNativeicon_getdirection(appJSON, function (pbcRes) {
      if (DEVICE_TYPE == "ios") {
        setupWebViewJavascriptBridge(function (bridgeObj) {
          bridgeObj.callHandler("loadMapViewByConfig", appJSON, function (
            response
          ) { });
          bridgeObj.registerHandler(
            "setNativeicon_getdirectionControl",
            function (responseData, responseCallback) {
              setNativeicon_getdirectionControl(responseData);
            }
          );
        });
      } else {
        window.Android.loadMapViewByConfig(JSON.stringify(appJSON));
      }
    }); // end of process before call
  } catch (err) { }
}
function clientbeforeNativeicon_getdirection(appJSON, callback) {
  var response = appJSON;
  appJSON.openMapApp = false;
  appJSON.isShowDirections = false;
  appJSON.isPlotAddressLocation = true;
  appJSON.sourceAddressString = localStorage.getItem("merchantAddressText");
  appJSON.selectedLocationFromSearch = localStorage.getItem(
    "merchantAddressText"
  );
  // appJSON.DestAddress = $('input[name="droplocation_name"]').val();
  appJSON.isReadOnly = true;
  appJSON.isShowBottomButton = 0;
  appJSON.isSelectLocation = 0;
  appJSON.mapZoomLevel = 16;
  appJSON.isNavigation = 1;
  //  appJSON.DestLongitude = localStorage.getItem('droplocationLongitute');
  //  appJSON.DestLatitude = localStorage.getItem('droplocationLatitude');
  // appJSON.Longitude = localStorage.getItem('pickuplocationLongitute');
  // appJSON.Latitude = localStorage.getItem('pickuplocationLatitude');
  appJSON.long = parseFloat(localStorage.getItem("merchantlocationLongitute"));
  appJSON.lat = parseFloat(localStorage.getItem("merchantlocationLatitude"));
  callback();
}
function getRecordByIDProcessBeforeCall502567(paramsType, callback) {
  var response = paramsType;
  if (getParameterByName("merchantID")) {
    paramsType.recordID = getParameterByName("merchantID");
    callback();
  } else {
    if (
      getParameterByName("bazaarid") &&
      getParameterByName("bazaarid") != "undefined"
    ) {
      paramsType.recordID = getParameterByName("bazaarid");
    } else if (
      getParameterByName("recordID") &&
      getParameterByName("recordID") != "undefined"
    ) {
      paramsType.recordID = getParameterByName("recordID");
    }
    callback();
  }
}
function getRecordByIDProcessAfterCall502567(response, callback) {
  callback();
}
function showMoreLess() {
  var dots = document.getElementById("dots");
  var moreText = document.getElementById("more");
  var btnText = document.getElementById("myBtn");
  if (btnText.innerHTML == " Show more") {
    btnText.innerHTML = " Show less";
    $("#more").css("display", "none");
    $("#myBtn").css("display", "inline");

    $("#dots").css("display", "none");
    var data = localStorage.getItem("firstLine") + localStorage.getItem("secondLine");;
    $('#merchantdescription134').html(data);

  }
  else {
    var data = localStorage.getItem("firstLine") //+  localStorage.getItem("secondLine");;
    $('#merchantdescription134').html(data);

    btnText.innerHTML = " Show more";
    $("#more").css("display", "none");

    $("#myBtn").css("display", "inline");

    $("#dots").css("display", "inline");
  }


  // if (dots.style.display === "none") {
  //   dots.style.display = "inline";
  //   btnText.innerHTML = " Show more";
  //   moreText.style.display = "none";
  // } else {
  //   dots.style.display = "none";
  //   btnText.innerHTML = " Show less";
  //   moreText.style.display = "inline";
  // }
}
