
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_merchantdetails'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "update"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#icongetdirection11', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_shoplocationoverlaymap'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - icongetdirection11", error) 
		} 
	})
      var paramsEdit = {};
      paramsEdit.tokenKey = getParameterByName('tokenKey');
      paramsEdit.secretKey = getParameterByName('secretKey') 
                       getRecordByIDProcessBeforeCall477955(paramsEdit, function (processBeforeRes) {
      $.ajax({
          url: ajaXCallURL+'/milestone003/getRecordByCustomeQuery_app_merchantspecificationdetails_Bazaar5da73cac545050343288ce7a',
          data: paramsEdit,
          type: 'POST',
          jsonpCallback: 'callback',
          success: function (response) { 
                       getRecordByIDProcessAfterCall477955(response, function (processBeforeRes) {
              if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                  var objParamsList = {};
                  var queryMode = $('#queryMode').val(); 
                  objParamsList.queryMode = queryMode;;
                  var tokenKey = $('#tokenKey').val();;
                  objParamsList.tokenKey = tokenKey;;
  if(!$('#about26').html()){
            $('#about26').append(response.recordDetails.undefined);
 }
  if(!$('#backbutton1').html()){
            $('#backbutton1').append(response.recordDetails.undefined);
 }
  if(!$('#addres_name10').html()){
            $('#addres_name10').append(response.recordDetails.addres_name);
 }
  if(!$('#contactnumber18').html()){
            $('#contactnumber18').append('<a id="contactnumberImg" class="tellink" href="tel:'+ response.recordDetails.contactnumber+'">'+ response.recordDetails.contactnumber+'</a>');
 }
  if(!$('#contactperson_name15').html()){
            $('#contactperson_name15').append(response.recordDetails.contactperson_name);
 }
 response.recordDetails['createdOn_preserved'] = response.recordDetails['createdOn'] ;
 response.recordDetails['createdOn'] = response.recordDetails['createdOn']  ? moment(new Date(response.recordDetails['createdOn'])).format('DD MMMM YYYY hh:mm A') : '';
  if(!$('#createdOn7').html()){
            $('#createdOn7').append(response.recordDetails.createdOn);
 }
 response.recordDetails['createdOn'] =  response.recordDetails['createdOn_preserved'];
 response.recordDetails['date_preserved'] = response.recordDetails['date'] ;
 response.recordDetails['date'] = response.recordDetails['date']  ? moment(new Date(response.recordDetails['date'])).format('DD MMM YYYY') : '';
  if(!$('#date21').html()){
            $('#date21').append(response.recordDetails.date);
 }
 response.recordDetails['date'] =  response.recordDetails['date_preserved'];
  if(!$('#description28').html()){
            $('#description28').append(response.recordDetails.description);
 }
  if(!$('#description12').html()){
            $('#description12').append(response.recordDetails.description);
 }
  if(!$('#name9').html()){
            $('#name9').append(response.recordDetails.name);
 }
  if(!$('#status8').html()){
            $('#status8').append(response.recordDetails.status);
 }
  if(!$('#time24').html()){
            $('#time24').append(response.recordDetails.time);
 }
  if(!$('#contactperson14').html()){
            $('#contactperson14').append(response.recordDetails.undefined);
 }
             if(response.recordDetails.droplocation != undefined) $('#droplocation30').val(response.recordDetails.droplocation);
             if (response.recordDetails.droplocation && response.recordDetails.droplocation['coordinates']) {
               var coordinates = response.recordDetails.droplocation['coordinates'];
               if (coordinates && coordinates.length) {
                   localStorage.setItem('droplocationLatitude', coordinates[1]);
                   localStorage.setItem('droplocationLongitute', coordinates[0]);
               }
             }
             if(response.recordDetails.droplocation_name != undefined) $('#droplocation_name32').val(response.recordDetails.droplocation_name);
             if(response.recordDetails.pickuplocation != undefined) $('#pickuplocation29').val(response.recordDetails.pickuplocation);
             if (response.recordDetails.pickuplocation && response.recordDetails.pickuplocation['coordinates']) {
               var coordinates = response.recordDetails.pickuplocation['coordinates'];
               if (coordinates && coordinates.length) {
                   localStorage.setItem('pickuplocationLatitude', coordinates[1]);
                   localStorage.setItem('pickuplocationLongitute', coordinates[0]);
               }
             }
             if(response.recordDetails.pickuplocation_name != undefined) $('#pickuplocation_name31').val(response.recordDetails.pickuplocation_name);
           var url = 'icon_location.png'
          $('#icongetdirection11').attr("src", url);
  if(!$('#openhours20').html()){
            $('#openhours20').append(response.recordDetails.undefined);
 }
  if(!$('#phonenumber17').html()){
            $('#phonenumber17').append(response.recordDetails.undefined);
 }
  if(!$('#shopdetails2').html()){
            $('#shopdetails2').append(response.recordDetails.undefined);
 }
  if(!$('#time23').html()){
            $('#time23').append(response.recordDetails.undefined);
 }

              Materialize.updateTextFields();
                $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);
  
              } 
              }); // end of getRecord By ID
          },
          error: function (xhr, status, error) {
              handleError(xhr, status, error); 
          },
      }); 
              }); // end of getRecord By ID
   
});//end of ready 
                 function getRecordByIDProcessBeforeCall477955(paramsType,callback) { 
                 var response = paramsType;
 
if(getParameterByName('bazaarid') && getParameterByName('bazaarid') != 'undefined'){paramsType.recordID = getParameterByName('bazaarid')} else if(getParameterByName('recordID') && getParameterByName('recordID') != 'undefined'){paramsType.recordID = getParameterByName('recordID')};callback(); 
                 } 
                 function getRecordByIDProcessAfterCall477955(response,callback) {
 callback(); 
                 }
