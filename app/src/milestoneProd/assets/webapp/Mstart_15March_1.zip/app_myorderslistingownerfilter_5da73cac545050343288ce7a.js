
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
     var totaldcard_leftimage3_collectioncontainer = 0;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#region10', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorderslistingsourcefilter'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - region10", error) 
		} 
	})
  $(document).on('click', '#clear3', function () {
  localStorage.removeItem('filterchkstatusleads');
  localStorage.removeItem('filterchksourceleads');
  localStorage.removeItem('filterchkownerleads');
  localStorage.removeItem('filterradiodatesleads');
  localStorage.removeItem('filterfromdates');
  localStorage.removeItem('filtertodates');
   $('input[type="checkbox"]').prop("checked",false);
 });
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#status9', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorderslistingstatusfilter'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - status9", error) 
		} 
	})
 var applyFilter = getParameterByName('applyFilter');
 if(applyFilter == 'true' || applyFilter == true ){
 }
 $(document).on('click', '#apply20', function(e) {
  var tokenKey = getParameterByName('tokenKey');
 var secretKey = getParameterByName('secretKey');
 var queryMode = getParameterByName('queryMode');
 var recordID = getParameterByName('recordID');
 
    if( getParameterByName('applyFilter')){
      var applyFilter =  getParameterByName('applyFilter');
    }
  window.location.href = 'app_myorderslisting_5da73cac545050343288ce7a.html?queryMode='+ queryMode+'&tokenKey='+tokenKey+ '&secretKey=' + secretKey + '&recordID='+ recordID+'&applyFilter=' + applyFilter+'&applyFilter=true'
return false;
 });
	$(document).on('click', '.cardradiobutton', function(e) {
		try {
			var element = $(this);
			var objParams = {};
			objParams.recordID = getParameterByName('recordID');
			if ($(this).attr('recordID')) {
				objParams.recordID = $(this).attr('recordID');
			}
		
			customcodebazaar_contactperson_chk(objParams, element,{}, function (processCustomcode) {
			    return false;
			});
		} catch (error) {
			console.log('Error in customcode click', error);
		}
	});
 var applyFilter = getParameterByName('applyFilter');
 if(applyFilter == 'true' || applyFilter == true ){
 }
 $(document).on('click', '#backbutton1', function(e) {
  var tokenKey = getParameterByName('tokenKey');
 var secretKey = getParameterByName('secretKey');
 var queryMode = getParameterByName('queryMode');
 var recordID = getParameterByName('recordID');
 queryMode = 'mylist'
  window.location.href = 'app_myorderslisting_5da73cac545050343288ce7a.html?queryMode='+ queryMode+'&tokenKey='+tokenKey+ '&secretKey=' + secretKey + '&recordID='+ recordID
return false;
 });
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#date8', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorderslistingdatefilter'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - date8", error) 
		} 
	})
});//end of ready
   function customcodebazaar_contactperson_chk(objParams, element,response,callback){
      try{ 	    var response = objParams; 	    response.element = element;

	selectOwnerCheckbox(response, function (responseselectOwnerCheckbox) {
	if(responseselectOwnerCheckbox.inValid) {
			Materialize.updateTextFields();
			return false;
 		} else {
			Materialize.updateTextFields();
			return false;
 		}
 });

 function selectOwnerCheckbox(response, callback) {
     if(!element.is(':checked')){
         if(localStorage.getItem('filterchkownerleads')){
             var arrFilterSelectedBox = localStorage.getItem('filterchkownerleads').split(',');
         } else {
             var arrFilterSelectedBox = [];
         }
 		var arrFilterSelectedBoxSplite = []
 		arrFilterSelectedBoxSplite.push(element.attr('recordID'))
 		for(count = 0;count < arrFilterSelectedBoxSplite.length;count++){
         		arrFilterSelectedBox = arrFilterSelectedBox.filter(function(elem){
             		return elem != arrFilterSelectedBoxSplite[count]; 
         		});
 		}
         localStorage.setItem('filterchkownerleads',arrFilterSelectedBox.toString());
     } else {
         if(localStorage.getItem('filterchkownerleads')){
             var arrFilterSelectedBox = localStorage.getItem('filterchkownerleads').split(',');
         } else {
             var arrFilterSelectedBox = [];
         }
 		var arrFilterSelectedBoxSplite = []
 		arrFilterSelectedBoxSplite.push(element.attr('recordID'))
 		for(count = 0;count < arrFilterSelectedBoxSplite.length;count++){
 			if (arrFilterSelectedBox.indexOf(arrFilterSelectedBoxSplite[count]) == -1){
					arrFilterSelectedBox.push(arrFilterSelectedBoxSplite[count]);
 			}
 		}
         localStorage.setItem('filterchkownerleads',arrFilterSelectedBox.toString());
     }
	callback({'inValid': 1});
 }
     } catch(err){
          callback();
          // console.log('Error in customcode', err);
     }
 }