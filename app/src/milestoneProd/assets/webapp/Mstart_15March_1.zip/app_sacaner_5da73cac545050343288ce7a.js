
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"))
    }

    var objParamsToken = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsToken.tokenKey = getParameterByName('tokenKey');
    objParamsToken.secretKey = getParameterByName('secretKey');

    var userRole = $('#userRole').val();
    var userID = $('#userID').val();
    var createrOfRecord = $('#createrOfRecord').val();
    var queryMode = getParameterByName('queryMode');
    var recordID = $.trim($('#recordID').val());
    var addSessionComments = [];
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $("#openqrscanner7").trigger("click");


    $(document).on('click', '#backbutton1', function () {
        try {
            var element = $(this);
            var nextPage = 'app_consultantcustmoreinfodetails';
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "mylist";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - backbutton1", error)
        }
    });

    $(document).on('click', '#openqrscanner7', function () {
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = getParameterByName('queryMode');
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        loadNativeopenqrscannerControl(tokenKey, queryMode, secretKey, ajaXCallURL);
    });//end of Event Open QR Scanner_is_click 
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('click', '#addeventpoints8', function () {
        var objParams = {};
        var test = $.trim($('#test10').val());
        if ($('#test10_div').is(':visible')) {
            objParams.test = test;
        }
        var tempobjParams = getParams(window.location.href)
        function extend(obj, src) {
            for (var key in src) {
                if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
            }
            return obj;
        }
        objParams = extend(objParams, tempobjParams);
        var recordID = $('#recordID').val();
        objParams.isDelete = 0;
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParams.tokenKey = getParameterByName('tokenKey');
        objParams.secretKey = getParameterByName('secretKey');
        objParams.offlineDataID = localStorage.getItem("offlineDataID");
        var queryMode = getParameterByName('queryMode')
        if (queryMode == 'mylist') {
            objParams.callUrl = ajaXCallURL + '/milestone003/saveAjaxreferraldetailsapp_sacaner';
        } else {
            objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxreferraldetailsapp_sacaner';
            objParams.recordID = recordID;
        }
        if (errorFields && Object.keys(errorFields).length) {
            $('#display_loading1').addClass('hideme');
            for (var firstErrorField in errorFields) {
                var controlType = errorFields[firstErrorField];
                errorFields = []
                var errField = $('#' + firstErrorField);
                if (controlType == 'dropdown') {
                    errField.prev().prev().focus();
                } else {
                    errField.focus()
                }
                validAll = true;
                return false;
            }
        }
        if (!validAll) {
            validAll = true;
            return false;
        }
        $('#addeventpoints8').prop('disabled', true);
        $('#display_loading1').removeClass('hideme');
        if (addSessionComments.length > 0) {
            objParams.addSessionComments = addSessionComments;
        } else {
            objParams.addSessionComments = [];
        }
        var parentID = $('#parentID').val();
        var parentName = $('#parentName').val();
        if (parentID != '') {
            objParams.parentID = parentID;
            objParams.parentName = parentName
        }
        if (typeof (addedFiles) != "undefined" && addedFiles && addedFiles.length > 0) {
            objParams.addedFiles = addedFiles;
        }
        objParams.ajaXCallURL = $("#ajaXCallURL").val();;
        objParams.organizationID = $("#organizationID").val();;
        objParams.ajaXCallURL = $("#ajaXCallURL").val();;
        objParams.organizationID = $("#organizationID").val();;
        processBeforeCallForSavereferraldetails(objParams, {}, function (processBeforeRes) {
            $.ajax({
                url: objParams.callUrl,
                data: objParams,
                type: 'POST',
                success: function (response) {
                    if (response.status == 0) {
                        $('#display_loading1').addClass('hideme');
                        var roleName = localStorage.getItem('roleName');
                        if (roleName == 'customer') {
                            response.nextPage = 'app_userhome'

                        }
                        else {
                            response.nextPage = 'app_consultantuserhome';
                        }
                        processAfterCallForSavereferraldetails(response, function (processAfterRes) {
                            var tokenKey = getParameterByName('tokenKey');
                            var secretKey = getParameterByName('secretKey');
                            var queryMode = getParameterByName('queryMode');
                            queryMode = queryMode.replace('edit', '');
                            localStorage.setItem("headerPageName", 'app_userhome');
                            var queryString = window.location.search.slice(1);
                            var newQuery = queryString + '&queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey
                            var queryParams = queryStringToJSON(newQuery);
                            queryString = $.param(queryParams);
                            queryString = queryString.replace(/\+/g, "%20");
                            queryString = decodeURIComponent(queryString);
                            if (recordID == '') {
                                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
                            } else {
                                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
                            }
                            return false;
                        }); // End of After Process
                    } else {
                        $('#display_loading1').addClass('hideme');
                        $('#2656d_error').html(response.error);
                        $('#2656d_error').show();
                    }
                    $('#addeventpoints8').removeProp('disabled');
                },
                error: function (xhr, status, error) {
                    $('#display_loading1').addClass('hideme');
                    $('#addeventpoints8').removeProp('disabled');
                },
            });
            return false;
        }); // End of Before Process
    });//end of Event Add Event Points_is_click 
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('click', '#updatevoucherstatus9', function () {
        var objParams = {};
        var expirationdate = $.trim($('#expirationdate11').val());
        if ($('#expirationdate11_div').is(':visible')) {
            objParams.expirationdate = expirationdate;
        }
        var tempobjParams = getParams(window.location.href)
        function extend(obj, src) {
            for (var key in src) {
                if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
            }
            return obj;
        }
        objParams = extend(objParams, tempobjParams);
        var recordID = $('#recordID').val();
        objParams.isDelete = 0;
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParams.tokenKey = getParameterByName('tokenKey');
        objParams.secretKey = getParameterByName('secretKey');
        objParams.offlineDataID = localStorage.getItem("offlineDataID");
        var queryMode = getParameterByName('queryMode')
        if (queryMode == 'mylista') {
            objParams.callUrl = ajaXCallURL + '/milestone003/saveAjaxredeemedvouchersapp_sacaner';
        } else {
            objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxredeemedvouchersapp_sacaner';
            objParams.recordID = recordID;
        }
        if (errorFields && Object.keys(errorFields).length) {
            $('#display_loading1').addClass('hideme');
            for (var firstErrorField in errorFields) {
                var controlType = errorFields[firstErrorField];
                errorFields = []
                var errField = $('#' + firstErrorField);
                if (controlType == 'dropdown') {
                    errField.prev().prev().focus();
                } else {
                    errField.focus()
                }
                validAll = true;
                return false;
            }
        }
        if (!validAll) {
            validAll = true;
            return false;
        }
        $('#updatevoucherstatus9').prop('disabled', true);
        $('#display_loading1').removeClass('hideme');
        if (addSessionComments.length > 0) {
            objParams.addSessionComments = addSessionComments;
        } else {
            objParams.addSessionComments = [];
        }
        var parentID = $('#parentID').val();
        var parentName = $('#parentName').val();
        if (parentID != '') {
            objParams.parentID = parentID;
            objParams.parentName = parentName
        }
        if (typeof (addedFiles) != "undefined" && addedFiles && addedFiles.length > 0) {
            objParams.addedFiles = addedFiles;
        }
        objParams.ajaXCallURL = $("#ajaXCallURL").val();;
        objParams.organizationID = $("#organizationID").val();;
        objParams.ajaXCallURL = $("#ajaXCallURL").val();;
        objParams.organizationID = $("#organizationID").val();;
        processBeforeCallForSaveredeemedvouchers(objParams, {}, function (processBeforeRes) {
            $.ajax({
                url: objParams.callUrl,
                data: objParams,
                type: 'POST',
                success: function (response) {
                    if (response.status == 0) {
                        $('#display_loading1').addClass('hideme');
                        response.nextPage = 'app_userhome'
                        processAfterCallForSaveredeemedvouchers(response, function (processAfterRes) {
                            var tokenKey = getParameterByName('tokenKey');
                            var secretKey = getParameterByName('secretKey');
                            var queryMode = getParameterByName('queryMode');
                            queryMode = queryMode.replace('edit', '');
                            localStorage.setItem("headerPageName", 'app_userhome');
                            var queryString = window.location.search.slice(1);
                            var newQuery = queryString + '&queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey
                            var queryParams = queryStringToJSON(newQuery);
                            queryString = $.param(queryParams);
                            queryString = queryString.replace(/\+/g, "%20");
                            queryString = decodeURIComponent(queryString);
                            if (recordID == '') {
                                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
                            } else {
                                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
                            }
                            return false;
                        }); // End of After Process
                    } else {
                        $('#display_loading1').addClass('hideme');
                        $('#2656d_error').html(response.error);
                        $('#2656d_error').show();
                    }
                    $('#updatevoucherstatus9').removeProp('disabled');
                },
                error: function (xhr, status, error) {
                    $('#display_loading1').addClass('hideme');
                    $('#updatevoucherstatus9').removeProp('disabled');
                },
            });
            return false;
        }); // End of Before Process
    });//end of Event update Voucher Status_is_click 
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};

    var roleName = localStorage.getItem('roleName');
    if (roleName.toLowerCase() != "consultant") {
        $('#backbutton1').addClass('hide');
        showBottomMenu();

    }


    var paramsEdit = {};
    paramsEdit.tokenKey = getParameterByName('tokenKey');
    paramsEdit.secretKey = getParameterByName('secretKey')
    if (getParameterByName('productid') && getParameterByName('productid') != null && getParameterByName('productid') != '') {
        paramsEdit.productid = getParameterByName('productid');
    }
    if (getParameterByName('clientID') && getParameterByName('clientID') != null && getParameterByName('clientID') != '') {
        paramsEdit.clientID = getParameterByName('clientID');
    }
    getRecordByIDProcessBeforeCall110650(paramsEdit, function (processBeforeRes) {
        $.ajax({
            url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_sacaner_Referraldetails5da73cac545050343288ce7a',
            data: paramsEdit,
            type: 'POST',
            jsonpCallback: 'callback',
            success: function (response) {
                getRecordByIDProcessAfterCall110650(response, function (processBeforeRes) {
                    if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                        var objParamsList = {};
                        var queryMode = $('#queryMode').val();
                        objParamsList.queryMode = queryMode;;
                        var tokenKey = $('#tokenKey').val();;
                        objParamsList.tokenKey = tokenKey;;

                        if (!$('#bottommenu12').html()) {
                            $('#bottommenu12').append(response.recordDetails.undefined);
                        }
                        if (response.recordDetails.expirationdate != undefined) $('#expirationdate11').val(response.recordDetails.expirationdate);
                        if (response.recordDetails.test != undefined) $('#test10').val(response.recordDetails.test);
                        if (!$('#scancode2').html()) {
                            $('#scancode2').append(response.recordDetails.undefined);
                        }

                        Materialize.updateTextFields();
                        $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

                    }
                }); // end of getRecord By ID
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            },
        });
    }); // end of getRecord By ID

    var paramsEdit = {};
    paramsEdit.tokenKey = getParameterByName('tokenKey');
    paramsEdit.secretKey = getParameterByName('secretKey')
    if (getParameterByName('userId') && getParameterByName('userId') != null && getParameterByName('userId') != '') {
        paramsEdit.userId = getParameterByName('userId');
    }
    getRecordByIDProcessBeforeCall110650(paramsEdit, function (processBeforeRes) {
        $.ajax({
            url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_sacaner_Redeemedvouchers5da73cac545050343288ce7a',
            data: paramsEdit,
            type: 'POST',
            jsonpCallback: 'callback',
            success: function (response) {
                getRecordByIDProcessAfterCall110650(response, function (processBeforeRes) {
                    if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                        var objParamsList = {};
                        var queryMode = $('#queryMode').val();
                        objParamsList.queryMode = queryMode;;
                        var tokenKey = $('#tokenKey').val();;
                        objParamsList.tokenKey = tokenKey;;
                        if (!$('#backbutton1').html()) {
                            $('#backbutton1').append(response.recordDetails.undefined);
                        }
                        if (!$('#bottommenu12').html()) {
                            $('#bottommenu12').append(response.recordDetails.undefined);
                        }
                        if (response.recordDetails.expirationdate != undefined) $('#expirationdate11').val(response.recordDetails.expirationdate);
                        if (response.recordDetails.test != undefined) $('#test10').val(response.recordDetails.test);
                        if (!$('#scancode2').html()) {
                            $('#scancode2').append(response.recordDetails.undefined);
                        }

                        Materialize.updateTextFields();
                        $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

                    }
                }); // end of getRecord By ID
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            },
        });
    }); // end of getRecord By ID

});//end of ready 
function loadNativeopenqrscannerControl(tokenKey, queryMode, secretKey, ajaXCallURL) {
    try {
        var appJSON = {};
        appJSON.tokenKey = tokenKey;
        appJSON.secretKey = secretKey;
        appJSON.queryMode = queryMode;
        appJSON.action = queryMode;
        appJSON.ajaXCallURL = ajaXCallURL;
        var AWSCredentials = localStorage.getItem("AWSCredentials");
        if (localStorage.IDENTITY_TOKEN) {
            var token = localStorage.IDENTITY_TOKEN;
            var playload = JSON.parse(atob(token.split(".")[1]));
            appJSON.Authorization = token;
            appJSON.Expiration = playload.exp;
        } else if (AWSCredentials) {
            AWSCredentials = JSON.parse(AWSCredentials);
            appJSON.accessKeyId = AWSCredentials.accessKeyId;
            appJSON.secretAccessKey = AWSCredentials.secretAccessKey;
            appJSON.sessionToken = AWSCredentials.sessionToken;
            appJSON.Expiration = AWSCredentials.Expiration;
        }
        appJSON.organizationID = $('#organizationID').val();
        appJSON.userID = $('#userID').val();
        appJSON.callbackFunction = 'setNativeopenqrscannerControl';
        appJSON.nextButtonCallback = 'setNativeopenqrscannerControl';
        appJSON.appID = $('#appID').val();
        var element = element ? element : null;
        clientbeforeNativeopenqrscanner(appJSON, element, function (pbcRes) {
            if (DEVICE_TYPE == 'ios') {
                setupWebViewJavascriptBridge(function (bridgeObj) {
                    bridgeObj.callHandler('loadNativeQRCodeScannerUpload', appJSON, function (response) {
                    });
                    bridgeObj.registerHandler('setNativeopenqrscannerControl', function (responseData, responseCallback) {
                        setNativeopenqrscannerControl(responseData);
                    });
                });
            } else {
                window.Android.loadNativeQRCodeScannerUpload(JSON.stringify(appJSON));
            }
        }); // end of process before call 
    } catch (err) {

    }
}
function clientbeforeNativeopenqrscanner(appJSON, element, callback) {
    var response = appJSON;
    callback();
}
function setNativeopenqrscannerControl(responseData) {
    try {
        if (responseData) {
            // Add Custome function Call here                 
            clientafterNativeopenqrscanner(responseData, function (pbcRes) {
                // handle client after call 
            })
        }
    } catch (err) {

    }
}
function clientafterNativeopenqrscanner(response, callback) {
    if (response) {
        // Add Custome function Call here                 
        var barcode = response.data.split("&&");
        var objParams = {};
        if (barcode != '') {






            if (barcode && barcode.length >= 3) {
                var recordID = barcode[0];
                localStorage.setItem("voucherID", recordID);
                objParams.isDelete = 0;
                var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                objParams.tokenKey = getParameterByName('tokenKey');
                objParams.secretKey = getParameterByName('secretKey');
                objParams.offlineDataID = localStorage.getItem("offlineDataID");
                var queryMode = getParameterByName('queryMode');
                objParams.userId = localStorage.getItem("userID");
                objParams.callUrl = ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_sacaner_Redeemedvouchers5da73cac545050343288ce7a';
                objParams.recordID = recordID;
                $.ajax({
                    url: objParams.callUrl,
                    data: objParams,
                    type: 'POST',
                    success: function (response) {
                        if (response.status == 0) {
                            $('#display_loading').addClass('hideme');
                            var objParams = {};
                            if (response.recordDetails) {
                                $("#updatevoucherstatus9").trigger("click");

                            } else {
                                shareAppData("Invalid QR Code.", "toast");
                            }
                        } else {
                            $('#display_loading').addClass('hideme');
                            shareAppData("Invalid QR Code.", "toast");
                        }
                    },
                    error: function (xhr, status, error) {
                        $('#display_loading').addClass('hideme');
                        shareAppData("Invalid QR Code.", "toast");
                    },
                });
            } else {

                var objParams = {};
                var recordID = barcode[0];
                objParams.isDelete = 0;
                var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                objParams.tokenKey = getParameterByName('tokenKey');
                objParams.secretKey = getParameterByName('secretKey');
                objParams.offlineDataID = localStorage.getItem("offlineDataID");
                var queryMode = getParameterByName('queryMode');
                localStorage.setItem("eventID", recordID);
                objParams.recordID = recordID;
                objParams.callUrl = ajaXCallURL + '/milestone003/updateStatuseventorders';
                objParams.status = "Attended";
                $.ajax({
                    url: objParams.callUrl,
                    data: objParams,
                    type: 'POST',
                    success: function (response) {
    
                        if (response.status == 0) {
                           
                            shareAppData("Thanks for attending the event.", "toast");
                           
    
                        } else {

                            var objParams = {};
                            var recordID = barcode[0];
                            objParams.isDelete = 0;
                            var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                            objParams.tokenKey = getParameterByName('tokenKey');
                            objParams.secretKey = getParameterByName('secretKey');
                            objParams.offlineDataID = localStorage.getItem("offlineDataID");
                         //   var merchantID = getParameterByName("merchantID");
                           // if (recordID == merchantID) {
                                objParams.clientid = localStorage.getItem("userID");
                
                                objParams.merchantid = recordID;
                
                                var queryMode = getParameterByName('queryMode');
                                // localStorage.setItem("eventID", recordID);
                                objParams.callUrl = ajaXCallURL + '/milestone003/saveAjaxordersclientstampweb';
                                objParams.recordID = recordID;
                                $.ajax({
                                    url: objParams.callUrl,
                                    data: objParams,
                                    type: 'POST',
                                    success: function (response) {
                                        if (response.status == 0) {
                                            $('#display_loading').addClass('hideme');
                                            shareAppData("Congratulations! You have earned a stamp. Redeem Stamp from My Reward Points to get exciting offers.", "toast");
                                            var objParams = {};
                                            //                        if (response.recordDetails && response.recordDetails[0]) {
                                            //                            $("#addstampcards28").trigger("click");
                                            //
                                            //                        } else {
                                            //                            shareAppData("Invalid QR Code.", "toast");
                                            //                        }
                                        } else {
                                            $('#display_loading').addClass('hideme');
                                            shareAppData(response.error, "toast");
                                       
                               
                                        }
                                    },
                                    error: function (xhr, status, error) {
                                        $('#display_loading').addClass('hideme');
                                        shareAppData("Invalid QR Code.", "toast");
                                    },
                                });
                          //  }
                           // shareAppData("Invalid QR Code.", "toast");
    
                        }
                    },
                    error: function (xhr, status, error) {
                        $('#display_loading').addClass('hideme');
                        shareAppData("Invalid QR Code.", "toast");
                    },
                })
                // var objParams = {};
                // var recordID = barcode[0];
                // objParams.isDelete = 0;
                // var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                // objParams.tokenKey = getParameterByName('tokenKey');
                // objParams.secretKey = getParameterByName('secretKey');
                // objParams.offlineDataID = localStorage.getItem("offlineDataID");
                // var queryMode = getParameterByName('queryMode');
                // localStorage.setItem("eventID", recordID);
                // objParams.recordID = recordID;
                // objParams.callUrl = ajaXCallURL + '/milestone003/get_data_by_record_Bazaar5da73cac545050343288ce7aadditionalenquuiryweb';

                // $.ajax({
                //     url: objParams.callUrl,
                //     data: objParams,
                //     type: 'POST',
                //     success: function (response) {

                //         if (response.status == 0) {
                //             var objParams = {};
                //             objParams.isDelete = 0;
                //             var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                //             objParams.tokenKey = getParameterByName('tokenKey');
                //             objParams.secretKey = getParameterByName('secretKey');
                //             objParams.offlineDataID = localStorage.getItem("offlineDataID");
                //             var queryMode = getParameterByName('queryMode');

                //             objParams.callUrl = ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_sacaner_Referraldetails5da73cac545050343288ce7a';
                //             objParams.clientID = localStorage.getItem("userID");
                //             objParams.productid = localStorage.getItem("eventID");;

                //             $.ajax({
                //                 url: objParams.callUrl,
                //                 data: objParams,
                //                 type: 'POST',
                //                 success: function (response) {

                //                     if (response.status == 1) {
                //                         shareAppData("Thanks for attending the event.", "toast");
                //                         $("#addeventpoints8").trigger("click");
                //                         return false;
                //                     } else if (response.status == 0) {
                //                         $('#display_loading').addClass('hideme');
                //                         var objParams = {};
                //                         if (response.recordDetails) {
                //                             shareAppData("Thanks for attending the event.", "toast");
                //                             return false;
                //                         }
                //                     } else {

                //                         $('#display_loading').addClass('hideme');
                //                         shareAppData("Invalid QR Code.", "toast");
                //                     }
                //                 },
                //                 error: function (xhr, status, error) {
                //                     $('#display_loading').addClass('hideme');
                //                     shareAppData("Invalid QR Code.", "toast");
                //                 },
                //             });

                //         } else {

                //             shareAppData("Invalid QR Code.", "toast");

                //         }


                //     },
                //     error: function (xhr, status, error) {
                //         $('#display_loading').addClass('hideme');
                //         shareAppData("Invalid QR Code.", "toast");
                //     },
                // });
                //    return false;   

            }
        } else {
            shareAppData("Invalid QR Code.", "toast");
        }
    }
    console.log('last one');
}
function getParams(url) {
    var urlParams = {};
    url.replace(
        new RegExp("([^?=&]+)(=([^&]*))?", "g"),
        function ($0, $1, $2, $3) {
            if ($3 && $3 != 'undefined') urlParams[$1] = $3;
        }
    );
    return urlParams;
}
function processBeforeCallForSavereferraldetails(objParams, response, callback) {


    objParams.type = 'Event';

    objParams.referralAmount = 1;
    objParams.displayAmount = 1;
    objParams.status = 'Approved';
    objParams.clientID = localStorage.getItem("userID");
    objParams.productid = localStorage.getItem("eventID");


    callback();
}
function processAfterCallForSavereferraldetails(response, callback) {


    shareAppData("Thanks for attending event.", "toast");

    callback();
}
function getParams(url) {
    var urlParams = {};
    url.replace(
        new RegExp("([^?=&]+)(=([^&]*))?", "g"),
        function ($0, $1, $2, $3) {
            if ($3 && $3 != 'undefined') urlParams[$1] = $3;
        }
    );
    return urlParams;
}
function processBeforeCallForSaveredeemedvouchers(objParams, response, callback) {


    objParams.type = 'Event';

    objParams.referralAmount = 1;
    objParams.displayAmount = 1;
    objParams.status = 'Approved';
    objParams.clientID = localStorage.getItem("userID");
    objParams.recordID = localStorage.getItem("voucherID");
    objParams.status = "Handed Over";
    objParams.handoverdate = new Date();
    callback();
}
function processAfterCallForSaveredeemedvouchers(response, callback) {


    shareAppData("Your voucher is successfuly handover", "toast");

    callback();
}
function showBottomMenu() {
    var menuObj = localStorage.getItem('objGetUserDetailsWithmenu');
    if (menuObj) {
        menuObj = JSON.parse(menuObj);
        if (menuObj.data && menuObj.data.roleName) {
            var roleName = menuObj.data.roleName;
        }
    }
    try {
        var bottommenu = '';
        bottommenu += '<div class="mobilebottommenu">'
        bottommenu += '    <div class="row">'
        bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Home" fileName="app_userhome_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_home.svg"><span>Home</span></a></div>'
        bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Appointment" fileName="app_appointmentslisting_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_calendar.svg"><span>Appointment</span></a></div>'
        bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Scan" fileName="app_sacaner_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_barcodeactive.svg"><span>Scan</span></a></div>'
        bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Chat" fileName="undefined_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_chat.svg"><span>Chat</span></a><div class="chatunreadcount"></div></div>'
        bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="More" fileName="app_custmoreinfodetails_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_more.svg"><span>More</span></a></div>'
        bottommenu += '    </div>'
        bottommenu += '</div>'
        $('#bottommenu12').html(bottommenu)
    } catch (err) {
        // console.log('Error in showBottomMenu', err);
    }
}
function getRecordByIDProcessBeforeCall110650(paramsType, callback) {
    var response = paramsType;
    callback();
}
function getRecordByIDProcessAfterCall110650(response, callback) {
    callback();
}
function getRecordByIDProcessBeforeCall110650(paramsType, callback) {
    var response = paramsType;

    paramsType.todaydate = new Date();
    paramsType.bazaarid = localStorage.getItem('bazaarid');
    callback();
}
function getRecordByIDProcessAfterCall110650(response, callback) {
    callback();
}
