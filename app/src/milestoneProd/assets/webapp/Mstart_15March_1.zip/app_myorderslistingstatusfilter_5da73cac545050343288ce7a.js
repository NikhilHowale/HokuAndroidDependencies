
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#owner11', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorderslistingownerfilter'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - owner11", error) 
		} 
	})
 var applyFilter = getParameterByName('applyFilter');
 if(applyFilter == 'true' || applyFilter == true ){
 }
 $(document).on('click', '#backbutton1', function(e) {
  var tokenKey = getParameterByName('tokenKey');
 var secretKey = getParameterByName('secretKey');
 var queryMode = getParameterByName('queryMode');
 var recordID = getParameterByName('recordID');
 queryMode = 'mylist'
  window.location.href = 'app_myorderslisting_5da73cac545050343288ce7a.html?queryMode='+ queryMode+'&tokenKey='+tokenKey+ '&secretKey=' + secretKey + '&recordID='+ recordID
return false;
 });
	$(document).on('click', '.chkstatus', function(e) {
		try {
			var element = $(this);
			var objParams = {};
			objParams.recordID = getParameterByName('recordID');
			if ($(this).attr('recordID')) {
				objParams.recordID = $(this).attr('recordID');
			}
		
			customcodeContacted(objParams, element,{}, function (processCustomcode) {
			    return false;
			});
		} catch (error) {
			console.log('Error in customcode click', error);
		}
	});
  $(document).on('click', '#clear3', function () {
   $('#statusfilter18').prop("checked",false);
   $('#statusfilter17').prop("checked",false);
   $('#statusfilter15').prop("checked",false);
   $('#statusfilter16').prop("checked",false);
   $('#statusfilter14').prop("checked",false);
   $('#statusfilter13').prop("checked",false);
  localStorage.removeItem('filterchkstatusleads');
  localStorage.removeItem('filterchksourceleads');
  localStorage.removeItem('filterchkownerleads');
  localStorage.removeItem('filterradiodatesleads');
  localStorage.removeItem('filterfromdates');
  localStorage.removeItem('filtertodates');
   $('input[type="checkbox"]').prop("checked",false);
 });
  var statusfilter18 =  getParameterByName('statusfilter');
  if(statusfilter18 != "" && statusfilter18 != null && statusfilter18 != 'null' && statusfilter18 != 'undefined'  && statusfilter18 != 'false' ){
  	$('#statusfilter18').val(statusfilter18);
   $('#statusfilter18').attr("checked","checked");;
  }
  var statusfilter17 =  getParameterByName('statusfilter');
  if(statusfilter17 != "" && statusfilter17 != null && statusfilter17 != 'null' && statusfilter17 != 'undefined'  && statusfilter17 != 'false' ){
  	$('#statusfilter17').val(statusfilter17);
   $('#statusfilter17').attr("checked","checked");;
  }
  var statusfilter15 =  getParameterByName('statusfilter');
  if(statusfilter15 != "" && statusfilter15 != null && statusfilter15 != 'null' && statusfilter15 != 'undefined'  && statusfilter15 != 'false' ){
  	$('#statusfilter15').val(statusfilter15);
   $('#statusfilter15').attr("checked","checked");;
  }
  var statusfilter16 =  getParameterByName('statusfilter');
  if(statusfilter16 != "" && statusfilter16 != null && statusfilter16 != 'null' && statusfilter16 != 'undefined'  && statusfilter16 != 'false' ){
  	$('#statusfilter16').val(statusfilter16);
   $('#statusfilter16').attr("checked","checked");;
  }
  var statusfilter14 =  getParameterByName('statusfilter');
  if(statusfilter14 != "" && statusfilter14 != null && statusfilter14 != 'null' && statusfilter14 != 'undefined'  && statusfilter14 != 'false' ){
  	$('#statusfilter14').val(statusfilter14);
   $('#statusfilter14').attr("checked","checked");;
  }
  var statusfilter13 =  getParameterByName('statusfilter');
  if(statusfilter13 != "" && statusfilter13 != null && statusfilter13 != 'null' && statusfilter13 != 'undefined'  && statusfilter13 != 'false' ){
  	$('#statusfilter13').val(statusfilter13);
   $('#statusfilter13').attr("checked","checked");;
  }
 var applyFilter = getParameterByName('applyFilter');
 if(applyFilter == 'true' || applyFilter == true ){
 }
 $(document).on('click', '#apply19', function(e) {
  var tokenKey = getParameterByName('tokenKey');
 var secretKey = getParameterByName('secretKey');
 var queryMode = getParameterByName('queryMode');
 var recordID = getParameterByName('recordID');
 
    if( getParameterByName('applyFilter')){
      var applyFilter =  getParameterByName('applyFilter');
    }
  window.location.href = 'app_myorderslisting_5da73cac545050343288ce7a.html?queryMode='+ queryMode+'&tokenKey='+tokenKey+ '&secretKey=' + secretKey + '&recordID='+ recordID+'&applyFilter=' + applyFilter+'&applyFilter=true'
return false;
 });
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#date8', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorderslistingdatefilter'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - date8", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#region10', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myorderslistingsourcefilter'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - region10", error) 
		} 
	})
});//end of ready
          setTimeout(function(){
if(localStorage.getItem('filterchkstatusleads')){
	var arrFilterSelectedBoxSplite = localStorage.getItem('filterchkstatusleads').split(',');
	for(count = 0;count < arrFilterSelectedBoxSplite.length;count++){
		$('.chkstatus[status="'+arrFilterSelectedBoxSplite[count]+'"]').prop('checked', true);
	}
}

}, 500);
   function customcodeContacted(objParams, element,response,callback){
      try{ 	    var response = objParams; 	    response.element = element;

	selectClosedLostCheckbox(response, function (responseselectClosedLostCheckbox) {
	if(responseselectClosedLostCheckbox.inValid) {
			Materialize.updateTextFields();
			return false;
 		} else {
			Materialize.updateTextFields();
			return false;
 		}
 });

 function selectClosedLostCheckbox(response, callback) {
     if(!element.is(':checked')){
         if(localStorage.getItem('filterchkstatusleads')){
             var arrFilterSelectedBox = localStorage.getItem('filterchkstatusleads').split(',');
         } else {
             var arrFilterSelectedBox = [];
         }
 		var arrFilterSelectedBoxSplite = []
 		arrFilterSelectedBoxSplite.push(element.attr('status'))
 		for(count = 0;count < arrFilterSelectedBoxSplite.length;count++){
         		arrFilterSelectedBox = arrFilterSelectedBox.filter(function(elem){
             		return elem != arrFilterSelectedBoxSplite[count]; 
         		});
 		}
         localStorage.setItem('filterchkstatusleads',arrFilterSelectedBox.toString());
     } else {
         if(localStorage.getItem('filterchkstatusleads')){
             var arrFilterSelectedBox = localStorage.getItem('filterchkstatusleads').split(',');
         } else {
             var arrFilterSelectedBox = [];
         }
 		var arrFilterSelectedBoxSplite = []
 		arrFilterSelectedBoxSplite.push(element.attr('status'))
 		for(count = 0;count < arrFilterSelectedBoxSplite.length;count++){
 			if (arrFilterSelectedBox.indexOf(arrFilterSelectedBoxSplite[count]) == -1){
					arrFilterSelectedBox.push(arrFilterSelectedBoxSplite[count]);
 			}
 		}
         localStorage.setItem('filterchkstatusleads',arrFilterSelectedBox.toString());
     }
	callback({'inValid': 1});
 }
     } catch(err){
          callback();
          // console.log('Error in customcode', err);
     }
 }