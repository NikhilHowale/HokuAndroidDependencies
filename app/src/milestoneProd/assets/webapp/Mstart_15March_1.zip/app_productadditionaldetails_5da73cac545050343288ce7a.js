
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"))
    }
    // var parent = getParameterByName('parent');
    var roleName = localStorage.getItem('roleName');
    if (roleName == "consultant") {
        $("#registerevent30").hide();
    }
    if (roleName == "customer") {
        $("#referlist28row27").parent().parent().remove();
    }
    $('#sg8096').hide();
    $('#sg8645').hide();
    var objParamsToken = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsToken.tokenKey = getParameterByName('tokenKey');
    objParamsToken.secretKey = getParameterByName('secretKey');

    var userRole = $('#userRole').val();
    var userID = $('#userID').val();
    var createrOfRecord = $('#createrOfRecord').val();
    var queryMode = getParameterByName('queryMode');
    var recordID = $.trim($('#recordID').val());
    var addSessionComments = [];
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;


    // $(document).on('click', '#registerevent30', function () {
    //     var objParams = {};
    //     var test = $.trim($('#test31').val());
    //     if ($('#test31_div').is(':visible')) {
    //         objParams.test = test;
    //     }
    //     var pickuplocation = $.trim($('#pickuplocation32').val());
    //     if ($('#pickuplocation32_div').is(':visible')) {
    //         objParams.pickuplocation = pickuplocation;
    //     }
    //     var droplocation = $.trim($('#droplocation33').val());
    //     if ($('#droplocation33_div').is(':visible')) {
    //         objParams.droplocation = droplocation;
    //     }
    //     var pickuplocation_name = $.trim($('#pickuplocation_name34').val());
    //     if ($('#pickuplocation_name34_div').is(':visible')) {
    //         objParams.pickuplocation_name = pickuplocation_name;
    //     }
    //     var droplocation_name = $.trim($('#droplocation_name35').val());
    //     if ($('#droplocation_name35_div').is(':visible')) {
    //         objParams.droplocation_name = droplocation_name;
    //     }
    //     var tempobjParams = getParams(window.location.href)
    //     function extend(obj, src) {
    //         for (var key in src) {
    //             if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
    //         }
    //         return obj;
    //     }
    //     objParams = extend(objParams, tempobjParams);
    //     var recordID = $('#recordID').val();
    //     objParams.isDelete = 0;
    //     var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    //     objParams.tokenKey = getParameterByName('tokenKey');
    //     objParams.secretKey = getParameterByName('secretKey');
    //     objParams.offlineDataID = localStorage.getItem("offlineDataID");
    //     var queryMode = getParameterByName('queryMode')
    //     if (queryMode == 'update') {
    //         objParams.callUrl = ajaXCallURL + '/milestone003/saveAjaxorders6254registereventapp_productadditionaldetails';
    //     } else {
    //         objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxorders6254registereventapp_productadditionaldetails';
    //         objParams.recordID = recordID;
    //     }
    //     if (errorFields && Object.keys(errorFields).length) {
    //         $('#display_loading1').addClass('hideme');
    //         for (var firstErrorField in errorFields) {
    //             var controlType = errorFields[firstErrorField];
    //             errorFields = []
    //             var errField = $('#' + firstErrorField);
    //             if (controlType == 'dropdown') {
    //                 errField.prev().prev().focus();
    //             } else {
    //                 errField.focus()
    //             }
    //             validAll = true;
    //             return false;
    //         }
    //     }
    //     if (!validAll) {
    //         validAll = true;
    //         return false;
    //     }
    //     $('#registerevent30').prop('disabled', true);
    //     $('#display_loading1').removeClass('hideme');
    //     if (addSessionComments.length > 0) {
    //         objParams.addSessionComments = addSessionComments;
    //     } else {
    //         objParams.addSessionComments = [];
    //     }
    //     var parentID = $('#parentID').val();
    //     var parentName = $('#parentName').val();
    //     if (parentID != '') {
    //         objParams.parentID = parentID;
    //         objParams.parentName = parentName
    //     }
    //     if (typeof (addedFiles) != "undefined" && addedFiles && addedFiles.length > 0) {
    //         objParams.addedFiles = addedFiles;
    //     }
    //     objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    //     objParams.organizationID = $("#organizationID").val();;
    //     objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    //     objParams.organizationID = $("#organizationID").val();;
    //     processBeforeCallForSave6254registerevent(objParams, {}, function (processBeforeRes) {
    //         $.ajax({
    //             url: objParams.callUrl,
    //             data: objParams,
    //             type: 'POST',
    //             success: function (response) {
    //                 if (response.status == 0) {
    //                     $('#display_loading1').addClass('hideme');
    //                     response.nextPage = 'app_productsuccess'
    //                     processAfterCallForSave6254registerevent(response, function (processAfterRes) {
    //                         var tokenKey = getParameterByName('tokenKey');
    //                         var secretKey = getParameterByName('secretKey');
    //                         var queryMode = getParameterByName('queryMode');
    //                         queryMode = queryMode.replace('edit', '');
    //                         localStorage.setItem("headerPageName", 'app_productsuccess');
    //                         var queryString = window.location.search.slice(1);
    //                         var newQuery = queryString + '&queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&queryMode=mylist' + '&bazaarid=' + response.data._id + '&recordID=' + response.data._id
    //                         var queryParams = queryStringToJSON(newQuery);
    //                         queryString = $.param(queryParams);
    //                         queryString = queryString.replace(/\+/g, "%20");
    //                         queryString = decodeURIComponent(queryString);
    //                         if (recordID == '') {
    //                             window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
    //                         } else {
    //                             window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
    //                         }
    //                         return false;
    //                     }); // End of After Process
    //                 } else {
    //                     $('#display_loading1').addClass('hideme');
    //                     $('#2656d_error').html(response.error);
    //                     $('#2656d_error').show();
    //                 }
    //                 $('#registerevent30').removeProp('disabled');
    //             },
    //             error: function (xhr, status, error) {
    //                 $('#display_loading1').addClass('hideme');
    //                 $('#registerevent30').removeProp('disabled');
    //             },
    //         });
    //         return false;
    //     }); // End of Before Process
    // });//end of Event Register Event_is_click 
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};
    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#backbutton1', function (e) {
        try {
            var element = $(this);
            var parent = getParameterByName('parent');
            var nextPage = 'app_productwithinsubcategorylisting';
            if (parent) {

                nextPage = parent;
            }

            if (parent == 'app_allupcomingeventslist') {

                nextPage = 'app_productadditionaldetails';
            }
            if (localStorage.getItem('eventbackpage')) {
                nextPage = localStorage.getItem('eventbackpage');
                localStorage.removeItem('eventbackpage')
            }
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "mylist";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - backbutton1", error)
        }
    });


    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#icongetdirection14', function (e) {
        try {
            var tokenKey = getParameterByName('tokenKey');
            var secretKey = getParameterByName('secretKey');
            var queryMode = getParameterByName('queryMode');
            var ajaXCallURL = $.trim($('#ajaXCallURL').val());;
            loadNativeicon_getdirectionControl(tokenKey, queryMode, secretKey, ajaXCallURL);
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - icongetdirection14", error)
        }
    })
    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#aditionaldetails22', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_productspecificationdetails';
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "update";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - aditionaldetails22", error)
        }
    })
    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#iconnext423', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_productspecificationdetails';
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "update";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - iconnext423", error)
        }
    })
    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#photos25', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_photoslisting';
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "mylist";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - photos25", error)
        }
    })
    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#iconnext126', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_photoslisting';
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "mylist";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - iconnext126", error)
        }
    })
    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#documents28', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_documentslisting';
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "mylist";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - documents28", error)
        }
    })

    $(document).on('click', '#referlist28row27', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_consultanteventclient';
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "mylist";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - documents28", error)
        }
    })

    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#iconnext629', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_documentslisting';
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "mylist";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - iconnext629", error)
        }
    })
    var paramsEdit = {};
    paramsEdit.tokenKey = getParameterByName('tokenKey');
    paramsEdit.secretKey = getParameterByName('secretKey')
    getRecordByIDProcessBeforeCall710799(paramsEdit, function (processBeforeRes) {
        $.ajax({
            url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_productadditionaldetails_Bazaar5da73cac545050343288ce7a',
            data: paramsEdit,
            type: 'POST',
            jsonpCallback: 'callback',
            success: function (response) {
                getRecordByIDProcessAfterCall710799(response, function (processBeforeRes) {
                    if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                        var objParamsList = {};
                        var queryMode = $('#queryMode').val();
                        objParamsList.queryMode = queryMode;;
                        var tokenKey = $('#tokenKey').val();;
                        objParamsList.tokenKey = tokenKey;;
                        if (!$('#9').html()) {
                            $('#9').append(response.recordDetails.undefined);
                        }
                        var parent = getParameterByName('parent');

                        if (parent != "app_consultantuserhome") {
                            if (response.recordDetails.isBooked && response.recordDetails.isBooked == true) {
                                $('#sg8096').hide();
                                if (response.recordDetails.orderStatus == "Attended") {
                                    $('#sg8645').hide();

                                }
                                else {
                                    $('#sg8645').show();

                                }

                            }
                            else {
                                $('#sg8096').show();
                                $('#sg8645').hide();

                            }
                        }

                        if (response.recordDetails.venue) {
                            localStorage.setItem("venue_name", response.recordDetails.venue_name)
                            localStorage.setItem('pickuplocationLongitute', response.recordDetails.venue.coordinates[0]);
                            localStorage.setItem('pickuplocationLatitude', response.recordDetails.venue.coordinates[1]);
                            //  $('#eventcategory_name7').append(response.recordDetails.venue);
                        }
                        if (!$('#aditionaldetails22').html()) {
                            $('#aditionaldetails22').append(response.recordDetails.undefined);
                        }
                        $('#bazaarnumber36_value').html(response.recordDetails.bazaarnumber);
                        if (!$('#backbutton1').html()) {
                            $('#backbutton1').append(response.recordDetails.undefined);
                        }
                        if (!$('#contactperson10').html()) {
                            $('#contactperson10').append(response.recordDetails.contactperson);
                        }
                        if (response.recordDetails.description) {
                            var html = "";
                            var description18Edit = unescape(response.recordDetails.description);
                            description18Edit = description18Edit.replace(/<[^>]*>?/gm, '');
                            var charLength = description18Edit.length;
                            var firstLine = description18Edit.slice(0, 100);
                            var secondLine = description18Edit.slice(100, charLength);
                            if (charLength < 100) {
                                html += `<div>${description18Edit}</div>`;
                                $('#description18').append(html);
                            } else {
                                html += `<div>${firstLine}<span id="dots">...</span><span id="more">${secondLine}</span><p  onclick="showMoreLess()" class="showMoreBtm" id="myBtn"> Show more</p></div>`;
                                $('#description18').append(html);
                            }

                        }

                        /* if (!$('#description15').html()) {
                            $('#description15').append(response.recordDetails.description);
                            // $('#termsandconditions13').append(response.recordDetails.termsandconditions);

                        } */
                        if (response.recordDetails.termsandconditions) {
                            var terms = unescape(response.recordDetails.termsandconditions);
                            // terms = terms.replace(/<[^>]*>?/gm, '');
                            if(terms.length > 100) {
                                dropdownvalues.showTermLess = true;

                                let html = `<div id='termcondtionless'> ${terms.substring(0,100)}... <p onclick="managetermConditionShowHide('more')" class="showMoreBtm"> Show More</p></div>
                                            <div class="hideme" id='termcondtionmore'> ${terms} <p onclick="managetermConditionShowHide('less')" class="showMoreBtm"> Show Less</p> </div>`;
                                $('#termsandconditions13').append(html);
                            } else
                                $('#termsandconditions13').append(terms);
                        }


                        if (!$('#eventcategory_name8').html()) {
                            $('#eventcategory_name8').append(response.recordDetails.eventcategory_name);
                        }
                        response.recordDetails['eventdate_preserved'] = response.recordDetails['eventdate'];
                        response.recordDetails['eventdate'] = response.recordDetails['eventdate'] ? moment(new Date(response.recordDetails['eventdate'])).format('ddd, MMMM DD, YYYY') : '';
                        if (!$('#eventdate13').html()) {
                            $('#eventdate13').append(response.recordDetails.eventdate);
                        }
                        let fromTime = response.recordDetails.fromtime || 'N.A.';
                        let toTime = response.recordDetails.totime || 'N.A.';
                        let timeString = `${fromTime} - ${toTime}`;
                        $('#eventtime13').html(timeString);
                        $('#timezone13').html('Singapore Standard Time');
                        response.recordDetails['eventdate'] = response.recordDetails['eventdate_preserved'];
                        if (!$('#eventname12').html()) {
                            $('#eventname12').append(response.recordDetails.eventname);
                        }
                        if (!$('#status11').html()) {
                            $('#status11').append(response.recordDetails.status);
                        }
                        if (!$('#description17').html()) {
                            $('#description17').append(response.recordDetails.undefined);
                        }
                        if (!$('#documents28').html()) {
                            $('#documents28').append(response.recordDetails.undefined);
                        }
                        if (!$('#eventdetails2').html()) {
                            $('#eventdetails2').append(response.recordDetails.undefined);
                        }
                        if (!$('#eventoverview20').html()) {
                            $('#eventoverview20').append(response.recordDetails.undefined);
                        }
                        if (response.recordDetails.contactphonenumber) {
                            $('#contactno13').html(`<a  style="color: rgb(175, 147, 93)" href="tel:${response.recordDetails.contactphonenumber}">${response.recordDetails.contactphonenumber}</a>`);
                        }
                        if (response.recordDetails.droplocation != undefined) $('#droplocation33').val(response.recordDetails.droplocation);
                        if (response.recordDetails.droplocation && response.recordDetails.droplocation['coordinates']) {
                            var coordinates = response.recordDetails.droplocation['coordinates'];
                            if (coordinates && coordinates.length) {
                                localStorage.setItem('droplocationLatitude', coordinates[1]);
                                localStorage.setItem('droplocationLongitute', coordinates[0]);
                            }
                        }
                        if (response.recordDetails.droplocation_name != undefined) $('#droplocation_name35').val(response.recordDetails.droplocation_name);
                        if (response.recordDetails.pickuplocation != undefined) $('#pickuplocation32').val(response.recordDetails.pickuplocation);
                        if (response.recordDetails.pickuplocation && response.recordDetails.pickuplocation['coordinates']) {
                            var coordinates = response.recordDetails.pickuplocation['coordinates'];
                            if (coordinates && coordinates.length) {
                                localStorage.setItem('pickuplocationLatitude', coordinates[1]);
                                localStorage.setItem('pickuplocationLongitute', coordinates[0]);
                            }
                        }
                        if (response.recordDetails.pickuplocation_name != undefined) $('#pickuplocation_name34').val(response.recordDetails.pickuplocation_name);
                        var url = 'icon_location.png'
                        $('#icongetdirection14').attr("src", url);
                        var url = 'icon_next1.png'
                        $('#iconnext126').attr("src", url);
                        var url = 'icon_next4.png'
                        $('#iconnext423').attr("src", url);
                        var url = 'icon_next6.png'
                        $('#iconnext629').attr("src", url);
                        // getrecordbycustomquery - Stage - 111111111111
                        if (response.recordDetails['eventimage'] && response.recordDetails['eventimage'].length > 0) {
                            makeSlidesbannerimageupload6(response.recordDetails['eventimage']);
                            // return false
                            // if (response.recordDetails['eventimage'][0].displayType = 'html') {
                            //     var eleParent = $('#eventimage6').parent();
                            //     for (var key in response.recordDetails['eventimage']) {
                            //         var objImage = response.recordDetails['eventimage'][key];
                            //         if (response.recordDetails['eventimage'][key].name == 'Audio') {
                            //             var token = $('#tokenKey').val();
                            //             if (token && token != '') {
                            //                 token = $('#tokenKey').val();
                            //             } else {
                            //                 token = getParameterByName('tokenKey');
                            //             }
                            //             var mediaIDa = response.recordDetails['eventimage'][0].mediaID
                            //             var filenamea = response.recordDetails['eventimage'][0].fileName
                            //             var CDN_PATH2 = 'https://devfiles.hokuapps.com/downloadOriginal?f=' + mediaIDa + '&fn=' + filenamea + '&t=' + token
                            //             var url = CDN_PATH2
                            //         } else {
                            //             var filetodisplay = getuploadedfilepreview(objImage.fileNm);
                            //             if (filetodisplay && filetodisplay != objImage.fileNm) {
                            //                 var url = filetodisplay;
                            //             } else {
                            //                 var url = CDN_PATH + objImage.mediaID + '_compressed.png';
                            //             }
                            //         }
                            //         if (response.recordDetails['eventimage'][key].name == 'Audio') {
                            //             var html = '';
                            //             html += '<div class="col s12" style="float: right;">'
                            //             html += '<audio class="" src="' + url + '" controls></audio>'
                            //             html += '</div>'
                            //         } else {
                            //             var html = '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + url + '" />';
                            //         }
                            //         if (!key || key == '0') {
                            //             eleParent.html(html);
                            //         } else {
                            //             eleParent.append(html);
                            //         }
                            //     }
                            // } else {
                            //     if (response.recordDetails['eventimage'][key].name == 'Audio') {
                            //         var url = CDN_PATH + response.recordDetails['eventimage'][0].mediaID;
                            //     } else {
                            //         var url = CDN_PATH + response.recordDetails['eventimage'][0].mediaID + '_compressed.png';
                            //     }
                            //     $('#eventimage6').attr("src", url);
                            // }
                        }
                        if (response.recordDetails.test != undefined) $('#test31').val(response.recordDetails.test);
                        if (!$('#photos25').html()) {
                            $('#photos25').append(response.recordDetails.undefined);
                        }
                        if (response.recordDetails.venue_name) {
                            $('#onlinevenueaddress').html(response.recordDetails.venue_name);
                        }

                        if (response.recordDetails.eventtype == 'Online') {
                            $('#onlinevenue_group124row16').removeClass('hide');
                            $('#onlinevenueaddress').html(response.recordDetails.eventlink);
                            $('#onlinevenueaddress').attr('href', response.recordDetails.eventlink);
                        }


                        if (response.recordDetails.eventtype == 'Offline') {
                            $('#offlinevenue_group124row16').addClass('hide');
                            $('#onlinevenueaddress').html(response.recordDetails.venue_name);
                        }

                        Materialize.updateTextFields();
                        $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

                    }
                }); // end of getRecord By ID
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            },
        });
    }); // end of getRecord By ID


    $(document).on('click', '#scan30', function () {
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = getParameterByName('queryMode');
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        loadNativeopenqrscannerControl(tokenKey, queryMode, secretKey, ajaXCallURL);

    });
    $(document).on('click', '#offlinevenuelink', function () {
        let url = $('#offlinevenuelink').html()
        shareAppData(url, "web");

    });

    $(document).on('click', '#share12', function () {
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = getParameterByName('queryMode');
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        loadNativesendinvitesControl(tokenKey, queryMode, secretKey, ajaXCallURL);
    });//end of Event Send invites_is_click 



    //     var objParams = {};
    //     var status = $.trim($('#status11').val());
    //     var obj = {}
    //     if ($('#status11_div').is(':visible')) {
    //       if (status == '') {
    //         $('#status11_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#status11_error').hide();
    //       }
    //     }
    //     if ($('#status11_div').is(':visible')) {
    //       objParams.status = status;
    //     }
    //     var contactperson = $.trim($('#contactperson10').val());
    //     var obj = {}
    //     if ($('#contactperson10_div').is(':visible')) {
    //       if (contactperson == '') {
    //         $('#contactperson10_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['contactperson10'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#contactperson10_error').hide();
    //       }
    //     }
    //     if ($('#contactperson10_div').is(':visible')) {
    //       objParams.contactperson = contactperson;
    //     }
    //     var status = $.trim($('#status11').val());
    //     var obj = {}
    //     if ($('#status11_div').is(':visible')) {
    //       if (status == '') {
    //         $('#status11_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#status11_error').hide();
    //       }
    //     }
    //     if ($('#status11_div').is(':visible')) {
    //       objParams.status = status;
    //     }
    //     var eventname = $.trim($('#eventname12').val());
    //     var obj = {}
    //     if ($('#eventname12_div').is(':visible')) {
    //       if (eventname == '') {
    //         $('#eventname12_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['eventname12'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#eventname12_error').hide();
    //       }
    //     }
    //     if ($('#eventname12_div').is(':visible')) {
    //       objParams.eventname = eventname;
    //     }
    //     var eventdate = $.trim($('#eventdate13').val());
    //     var obj = {}
    //     if ($('#eventdate13_div').is(':visible')) {
    //       if (eventdate == '') {
    //         $('#eventdate13_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['eventdate13'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#eventdate13_error').hide();
    //       }
    //     }
    //     if ($('#eventdate13_div').is(':visible')) {
    //       objParams.eventdate = eventdate;
    //     }
    //     var contactperson = $.trim($('#contactperson10').val());
    //     var obj = {}
    //     if ($('#contactperson10_div').is(':visible')) {
    //       if (contactperson == '') {
    //         $('#contactperson10_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['contactperson10'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#contactperson10_error').hide();
    //       }
    //     }
    //     if ($('#contactperson10_div').is(':visible')) {
    //       objParams.contactperson = contactperson;
    //     }
    //     var eventdate = $.trim($('#eventdate13').val());
    //     var obj = {}
    //     if ($('#eventdate13_div').is(':visible')) {
    //       if (eventdate == '') {
    //         $('#eventdate13_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['eventdate13'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#eventdate13_error').hide();
    //       }
    //     }
    //     if ($('#eventdate13_div').is(':visible')) {
    //       objParams.eventdate = eventdate;
    //     }
    //     var description = $.trim($('#description15').val());
    //     var obj = {}
    //     if ($('#description15_div').is(':visible')) {
    //       if (description == '') {
    //         $('#description15_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['description15'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#description15_error').hide();
    //       }
    //     }
    //     if ($('#description15_div').is(':visible')) {
    //       objParams.description = description;
    //     }
    //     var status = $.trim($('#status11').val());
    //     var obj = {}
    //     if ($('#status11_div').is(':visible')) {
    //       if (status == '') {
    //         $('#status11_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#status11_error').hide();
    //       }
    //     }
    //     if ($('#status11_div').is(':visible')) {
    //       objParams.status = status;
    //     }
    //     var ordersnumber = $.trim($('#ordersnumber35').val());
    //     if ($('#ordersnumber35_div').is(':visible')) {
    //       objParams.ordersnumber = ordersnumber;
    //     }
    //     var ordersnumber = $.trim($('#ordersnumber35').val());
    //     if ($('#ordersnumber35_div').is(':visible')) {
    //       objParams.ordersnumber = ordersnumber;
    //     }
    //     var ordersnumber = $.trim($('#ordersnumber35').val());
    //     if ($('#ordersnumber35_div').is(':visible')) {
    //       objParams.ordersnumber = ordersnumber;
    //     }
    //     var status = $.trim($('#status11').val());
    //     var obj = {}
    //     if ($('#status11_div').is(':visible')) {
    //       if (status == '') {
    //         $('#status11_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#status11_error').hide();
    //       }
    //     }
    //     if ($('#status11_div').is(':visible')) {
    //       objParams.status = status;
    //     }
    //     var ordersnumber = $.trim($('#ordersnumber35').val());
    //     if ($('#ordersnumber35_div').is(':visible')) {
    //       objParams.ordersnumber = ordersnumber;
    //     }
    //     var ordersnumber = $.trim($('#ordersnumber35').val());
    //     if ($('#ordersnumber35_div').is(':visible')) {
    //       objParams.ordersnumber = ordersnumber;
    //     }
    //     var description = $.trim($('#description15').val());
    //     var obj = {}
    //     if ($('#description15_div').is(':visible')) {
    //       if (description == '') {
    //         $('#description15_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['description15'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#description15_error').hide();
    //       }
    //     }
    //     if ($('#description15_div').is(':visible')) {
    //       objParams.description = description;
    //     }
    //     var ordersnumber = $.trim($('#ordersnumber35').val());
    //     if ($('#ordersnumber35_div').is(':visible')) {
    //       objParams.ordersnumber = ordersnumber;
    //     }
    //     var ordersnumber = $.trim($('#ordersnumber35').val());
    //     if ($('#ordersnumber35_div').is(':visible')) {
    //       objParams.ordersnumber = ordersnumber;
    //     }
    //     var status = $.trim($('#status11').val());
    //     var obj = {}
    //     if ($('#status11_div').is(':visible')) {
    //       if (status == '') {
    //         $('#status11_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#status11_error').hide();
    //       }
    //     }
    //     if ($('#status11_div').is(':visible')) {
    //       objParams.status = status;
    //     }
    //     var status = $.trim($('#status11').val());
    //     var obj = {}
    //     if ($('#status11_div').is(':visible')) {
    //       if (status == '') {
    //         $('#status11_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#status11_error').hide();
    //       }
    //     }
    //     if ($('#status11_div').is(':visible')) {
    //       objParams.status = status;
    //     }
    //     var status = $.trim($('#status11').val());
    //     var obj = {}
    //     if ($('#status11_div').is(':visible')) {
    //       if (status == '') {
    //         $('#status11_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#status11_error').hide();
    //       }
    //     }
    //     if ($('#status11_div').is(':visible')) {
    //       objParams.status = status;
    //     }
    //     var status = $.trim($('#status11').val());
    //     var obj = {}
    //     if ($('#status11_div').is(':visible')) {
    //       if (status == '') {
    //         $('#status11_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#status11_error').hide();
    //       }
    //     }
    //     if ($('#status11_div').is(':visible')) {
    //       objParams.status = status;
    //     }
    //     var status = $.trim($('#status11').val());
    //     var obj = {}
    //     if ($('#status11_div').is(':visible')) {
    //       if (status == '') {
    //         $('#status11_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#status11_error').hide();
    //       }
    //     }
    //     if ($('#status11_div').is(':visible')) {
    //       objParams.status = status;
    //     }
    //     var status = $.trim($('#status11').val());
    //     var obj = {}
    //     if ($('#status11_div').is(':visible')) {
    //       if (status == '') {
    //         $('#status11_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#status11_error').hide();
    //       }
    //     }
    //     if ($('#status11_div').is(':visible')) {
    //       objParams.status = status;
    //     }
    //     var ordersnumber = $.trim($('#ordersnumber35').val());
    //     if ($('#ordersnumber35_div').is(':visible')) {
    //       objParams.ordersnumber = ordersnumber;
    //     }
    //     var eventname = $.trim($('#eventname12').val());
    //     var obj = {}
    //     if ($('#eventname12_div').is(':visible')) {
    //       if (eventname == '') {
    //         $('#eventname12_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['eventname12'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#eventname12_error').hide();
    //       }
    //     }
    //     if ($('#eventname12_div').is(':visible')) {
    //       objParams.eventname = eventname;
    //     }
    //     var eventdate = $.trim($('#eventdate13').val());
    //     var obj = {}
    //     if ($('#eventdate13_div').is(':visible')) {
    //       if (eventdate == '') {
    //         $('#eventdate13_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['eventdate13'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#eventdate13_error').hide();
    //       }
    //     }
    //     if ($('#eventdate13_div').is(':visible')) {
    //       objParams.eventdate = eventdate;
    //     }
    //     var ordersnumber = $.trim($('#ordersnumber35').val());
    //     if ($('#ordersnumber35_div').is(':visible')) {
    //       objParams.ordersnumber = ordersnumber;
    //     }
    //     var status = $.trim($('#status11').val());
    //     var obj = {}
    //     if ($('#status11_div').is(':visible')) {
    //       if (status == '') {
    //         $('#status11_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#status11_error').hide();
    //       }
    //     }
    //     if ($('#status11_div').is(':visible')) {
    //       objParams.status = status;
    //     }
    //     var status = $.trim($('#status11').val());
    //     var obj = {}
    //     if ($('#status11_div').is(':visible')) {
    //       if (status == '') {
    //         $('#status11_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#status11_error').hide();
    //       }
    //     }
    //     if ($('#status11_div').is(':visible')) {
    //       objParams.status = status;
    //     }
    //     var eventimage = $.trim($('#eventimage6').val());
    //     var obj = {}
    //     if ($('#eventimage6_div').is(':visible')) {
    //       if (eventimage == '') {
    //         $('#eventimage6_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['eventimage6'] = 'image';
    //         validAll = false;
    //       } else {
    //         $('#eventimage6_error').hide();
    //       }
    //     }
    //     if ($('#eventimage6_div').is(':visible') && eventimage) {
    //       objParams.eventimage = eventimage;
    //     }
    //     var eventcategory_name = $.trim($('#eventcategory_name8').val());
    //     var obj = {}
    //     if ($('#eventcategory_name8_div').is(':visible')) {
    //       if (eventcategory_name == '') {
    //         $('#eventcategory_name8_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['eventcategory_name8'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#eventcategory_name8_error').hide();
    //       }
    //     }
    //     if ($('#eventcategory_name8_div').is(':visible')) {
    //       objParams.eventcategory_name = eventcategory_name;
    //     }
    //     var contactperson = $.trim($('#contactperson10').val());
    //     var obj = {}
    //     if ($('#contactperson10_div').is(':visible')) {
    //       if (contactperson == '') {
    //         $('#contactperson10_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['contactperson10'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#contactperson10_error').hide();
    //       }
    //     }
    //     if ($('#contactperson10_div').is(':visible')) {
    //       objParams.contactperson = contactperson;
    //     }
    //     var status = $.trim($('#status11').val());
    //     var obj = {}
    //     if ($('#status11_div').is(':visible')) {
    //       if (status == '') {
    //         $('#status11_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['status11'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#status11_error').hide();
    //       }
    //     }
    //     if ($('#status11_div').is(':visible')) {
    //       objParams.status = status;
    //     }
    //     var eventname = $.trim($('#eventname12').val());
    //     var obj = {}
    //     if ($('#eventname12_div').is(':visible')) {
    //       if (eventname == '') {
    //         $('#eventname12_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['eventname12'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#eventname12_error').hide();
    //       }
    //     }
    //     if ($('#eventname12_div').is(':visible')) {
    //       objParams.eventname = eventname;
    //     }
    //     var eventdate = $.trim($('#eventdate13').val());
    //     var obj = {}
    //     if ($('#eventdate13_div').is(':visible')) {
    //       if (eventdate == '') {
    //         $('#eventdate13_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['eventdate13'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#eventdate13_error').hide();
    //       }
    //     }
    //     if ($('#eventdate13_div').is(':visible')) {
    //       objParams.eventdate = eventdate;
    //     }
    //     var description = $.trim($('#description15').val());
    //     var obj = {}
    //     if ($('#description15_div').is(':visible')) {
    //       if (description == '') {
    //         $('#description15_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['description15'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#description15_error').hide();
    //       }
    //     }
    //     if ($('#description15_div').is(':visible')) {
    //       objParams.description = description;
    //     }
    //     var description = $.trim($('#description15').val());
    //     var obj = {}
    //     if ($('#description15_div').is(':visible')) {
    //       if (description == '') {
    //         $('#description15_error').show();
    //         if (!Object.keys(errorFields).length) errorFields['description15'] = 'divtag';
    //         validAll = false;
    //       } else {
    //         $('#description15_error').hide();
    //       }
    //     }
    //     if ($('#description15_div').is(':visible')) {
    //       objParams.description = description;
    //     }
    //     var pickuplocation = $.trim($('#pickuplocation31').val());
    //     if ($('#pickuplocation31_div').is(':visible')) {
    //       objParams.pickuplocation = pickuplocation;
    //     }
    //     var droplocation = $.trim($('#droplocation32').val());
    //     if ($('#droplocation32_div').is(':visible')) {
    //       objParams.droplocation = droplocation;
    //     }
    //     var pickuplocation_name = $.trim($('#pickuplocation_name33').val());
    //     if ($('#pickuplocation_name33_div').is(':visible')) {
    //       objParams.pickuplocation_name = pickuplocation_name;
    //     }
    //     var droplocation_name = $.trim($('#droplocation_name34').val());
    //     if ($('#droplocation_name34_div').is(':visible')) {
    //       objParams.droplocation_name = droplocation_name;
    //     }
    //     var ordersnumber = $.trim($('#ordersnumber35').val());
    //     if ($('#ordersnumber35_div').is(':visible')) {
    //       objParams.ordersnumber = ordersnumber;
    //     }
    //     var ordersnumber = $.trim($('#ordersnumber35').val());
    //     if ($('#ordersnumber35_div').is(':visible')) {
    //       objParams.ordersnumber = ordersnumber;
    //     }
    //     var tempobjParams = getParams(window.location.href)
    //     function extend(obj, src) {
    //       for (var key in src) {
    //         if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
    //       }
    //       return obj;
    //     }
    //     objParams = extend(objParams, tempobjParams);
    //     var recordID = $('#recordID').val();
    //     objParams.isDelete = 0;
    //     var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    //     objParams.tokenKey = getParameterByName('tokenKey');
    //     objParams.secretKey = getParameterByName('secretKey');
    //     objParams.offlineDataID = localStorage.getItem("offlineDataID");
    //     var queryMode = getParameterByName('queryMode')
    //     if (queryMode == 'add') {
    //       objParams.callUrl = ajaXCallURL + '/milestone003/saveAjaxorders2765scanapp_myeventdetails';
    //     } else {
    //       objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxorders2765scanapp_myeventdetails';
    //       objParams.recordID = recordID;
    //     }
    //     if (errorFields && Object.keys(errorFields).length) {
    //       $('#display_loading1').addClass('hideme');
    //       for (var firstErrorField in errorFields) {
    //         var controlType = errorFields[firstErrorField];
    //         errorFields = []
    //         var errField = $('#' + firstErrorField);
    //         if (controlType == 'dropdown') {
    //           errField.prev().prev().focus();
    //         } else {
    //           errField.focus()
    //         }
    //         validAll = true;
    //         return false;
    //       }
    //     }
    //     if (!validAll) {
    //       validAll = true;
    //       return false;
    //     }
    //     $('#scan30').prop('disabled', true);
    //     $('#display_loading1').removeClass('hideme');
    //     if (addSessionComments.length > 0) {
    //       objParams.addSessionComments = addSessionComments;
    //     } else {
    //       objParams.addSessionComments = [];
    //     }
    //     var parentID = $('#parentID').val();
    //     var parentName = $('#parentName').val();
    //     if (parentID != '') {
    //       objParams.parentID = parentID;
    //       objParams.parentName = parentName
    //     }
    //     if (typeof (addedFiles) != "undefined" && addedFiles && addedFiles.length > 0) {
    //       objParams.addedFiles = addedFiles;
    //     }
    //     objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    //     objParams.organizationID = $("#organizationID").val();;
    //     objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    //     objParams.organizationID = $("#organizationID").val();;
    //     processBeforeCallForSave2765scan(objParams, {}, function (processBeforeRes) {
    //       $.ajax({
    //         url: objParams.callUrl,
    //         data: objParams,
    //         type: 'POST',
    //         success: function (response) {
    //           if (response.status == 0) {
    //             $('#display_loading1').addClass('hideme');
    //             response.nextPage = 'app_eventscansuccess'
    //             processAfterCallForSave2765scan(response, function (processAfterRes) {
    //               var tokenKey = getParameterByName('tokenKey');
    //               var secretKey = getParameterByName('secretKey');
    //               var queryMode = getParameterByName('queryMode');
    //               queryMode = queryMode.replace('edit', '');
    //               localStorage.setItem("headerPageName", 'app_eventscansuccess');
    //               var queryString = window.location.search.slice(1);
    //               var newQuery = queryString + '&queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&queryMode=mylist' + '&ordersid=' + response.data._id + '&recordID=' + response.data._id
    //               var queryParams = queryStringToJSON(newQuery);
    //               queryString = $.param(queryParams);
    //               queryString = queryString.replace(/\+/g, "%20");
    //               queryString = decodeURIComponent(queryString);
    //               if (recordID == '') {
    //                 window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
    //               } else {
    //                 window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
    //               }
    //               return false;
    //             }); // End of After Process
    //           } else {
    //             $('#display_loading1').addClass('hideme');
    //             $('#2656d_error').html(response.error);
    //             $('#2656d_error').show();
    //           }
    //           $('#scan30').removeProp('disabled');
    //         },
    //         error: function (xhr, status, error) {
    //           $('#display_loading1').addClass('hideme');
    //           $('#scan30').removeProp('disabled');
    //         },
    //       });
    //       return false;
    //     }); // End of Before Process
    //   });//end of Event Scan_is_click 
});//end of ready
function getParams(url) {
    var urlParams = {};
    url.replace(
        new RegExp("([^?=&]+)(=([^&]*))?", "g"),
        function ($0, $1, $2, $3) {
            if ($3 && $3 != 'undefined') urlParams[$1] = $3;
        }
    );
    return urlParams;
}
function loadNativeicon_getdirectionControl(tokenKey, queryMode, secretKey, ajaXCallURL) {
    try {
        var appJSON = {};
        appJSON.tokenKey = tokenKey;
        appJSON.secretKey = secretKey;
        appJSON.queryMode = queryMode;
        appJSON.action = queryMode;
        appJSON.ajaXCallURL = ajaXCallURL;
        var AWSCredentials = localStorage.getItem("AWSCredentials");
        if (localStorage.IDENTITY_TOKEN) {
            var token = localStorage.IDENTITY_TOKEN;
            var playload = JSON.parse(atob(token.split(".")[1]));
            appJSON.Authorization = token;
            appJSON.Expiration = playload.exp;
        } else if (AWSCredentials) {
            AWSCredentials = JSON.parse(AWSCredentials);
            appJSON.accessKeyId = AWSCredentials.accessKeyId;
            appJSON.secretAccessKey = AWSCredentials.secretAccessKey;
            appJSON.sessionToken = AWSCredentials.sessionToken;
            appJSON.Expiration = AWSCredentials.Expiration;
        }
        appJSON.organizationID = $('#organizationID').val();
        appJSON.userID = $('#userID').val();
        appJSON.callbackFunction = '';
        appJSON.nextButtonCallback = ' ';
        appJSON.appID = $('#appID').val();

        clientbeforeNativeicon_getdirection(appJSON, function (pbcRes) {
            if (DEVICE_TYPE == 'ios') {
                setupWebViewJavascriptBridge(function (bridgeObj) {
                    bridgeObj.callHandler('loadMapViewByConfig', appJSON, function (response) {
                    });
                    //                                                                         bridgeObj.registerHandler('setNativeicon_getdirectionControl', function (responseData, responseCallback) {
                    //                                                                                                   //setNativeicon_getdirectionControl(responseData);
                    //                                                                                                   });
                });
            } else {
                window.Android.loadMapViewByConfig(JSON.stringify(appJSON));
            }
        }); // end of process before call
    } catch (err) {

    }
}
function clientbeforeNativeicon_getdirection(appJSON, callback) {
    var response = appJSON;
    appJSON.openMapApp = false;
    appJSON.isShowDirections = false;
    appJSON.isPlotAddressLocation = true;
    appJSON.sourceAddressString = localStorage.getItem('venue_name');
    // appJSON.DestAddress = $('input[name="droplocation_name"]').val();
    appJSON.isReadOnly = true;
    appJSON.isShowBottomButton = 0;
    appJSON.isSelectLocation = 0;
    appJSON.mapZoomLevel = 16;
    appJSON.isNavigation = 1;
    //  appJSON.DestLongitude = localStorage.getItem('droplocationLongitute');
    //  appJSON.DestLatitude = localStorage.getItem('droplocationLatitude');
    appJSON.long = localStorage.getItem('pickuplocationLongitute');
    appJSON.lat = localStorage.getItem('pickuplocationLatitude');
    appJSON.selectedLocationFromSearch = localStorage.getItem('venue_name');
    appJSON.isOtherNearbyLocation = true;
    callback();
}
function loadNativeopenqrscannerControl(tokenKey, queryMode, secretKey, ajaXCallURL) {
    try {
        var appJSON = {};
        appJSON.tokenKey = tokenKey;
        appJSON.secretKey = secretKey;
        appJSON.queryMode = queryMode;
        appJSON.action = queryMode;
        appJSON.ajaXCallURL = ajaXCallURL;
        var AWSCredentials = localStorage.getItem("AWSCredentials");
        if (localStorage.IDENTITY_TOKEN) {
            var token = localStorage.IDENTITY_TOKEN;
            var playload = JSON.parse(atob(token.split(".")[1]));
            appJSON.Authorization = token;
            appJSON.Expiration = playload.exp;
        } else if (AWSCredentials) {
            AWSCredentials = JSON.parse(AWSCredentials);
            appJSON.accessKeyId = AWSCredentials.accessKeyId;
            appJSON.secretAccessKey = AWSCredentials.secretAccessKey;
            appJSON.sessionToken = AWSCredentials.sessionToken;
            appJSON.Expiration = AWSCredentials.Expiration;
        }
        appJSON.organizationID = $('#organizationID').val();
        appJSON.userID = $('#userID').val();
        appJSON.callbackFunction = 'setNativeopenqrscannerControl';
        appJSON.nextButtonCallback = 'setNativeopenqrscannerControl';
        appJSON.appID = $('#appID').val();
        var element = element ? element : null;
        //clientbeforeNativeopenqrscanner(appJSON, element, function (pbcRes) {
        if (DEVICE_TYPE == 'ios') {
            setupWebViewJavascriptBridge(function (bridgeObj) {
                bridgeObj.callHandler('loadNativeQRCodeScannerUpload', appJSON, function (response) {
                });
                bridgeObj.registerHandler('setNativeopenqrscannerControl', function (responseData, responseCallback) {
                    setNativeopenqrscannerControl(responseData);
                });
            });
        } else {
            window.Android.loadNativeQRCodeScannerUpload(JSON.stringify(appJSON));
        }
        //  }); // end of process before call 
    } catch (err) {

    }
}
function setNativeopenqrscannerControl(responseData) {
    try {
        if (responseData) {
            // Add Custome function Call here                 
            clientafterNativeopenqrscanner(responseData, function (pbcRes) {
                // handle client after call 
            })
        }
    } catch (err) {

    }
}
function clientafterNativeopenqrscanner(response, callback) {
    if (response) {
        // Add Custome function Call here                 
        var barcode = response.data.split("&&");
        var objParams = {};
        if (barcode != '') {

            //          if (barcode && barcode.length >= 3) {
            //              var recordID = barcode[0];
            //              localStorage.setItem("voucherID", recordID);
            //              objParams.isDelete = 0;
            //              var ajaXCallURL = $.trim($('#ajaXCallURL').val());
            //              objParams.tokenKey = getParameterByName('tokenKey');
            //              objParams.secretKey = getParameterByName('secretKey');
            //              objParams.offlineDataID = localStorage.getItem("offlineDataID");
            //              var queryMode = getParameterByName('queryMode');
            //              objParams.userId = localStorage.getItem("userID");
            //              objParams.callUrl = ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_sacaner_Redeemedvouchers5da73cac545050343288ce7a';
            //              objParams.recordID = recordID;
            //              $.ajax({
            //                  url: objParams.callUrl,
            //                  data: objParams,
            //                  type: 'POST',
            //                  success: function (response) {
            //                      if (response.status == 0) {
            //                          $('#display_loading').addClass('hideme');
            //                          var objParams = {};
            //                          if (response.recordDetails) {
            //                              $("#updatevoucherstatus9").trigger("click");
            //
            //                          } else {
            //                              shareAppData("Invalid QR Code.", "toast");
            //                          }
            //                      } else {
            //                          $('#display_loading').addClass('hideme');
            //                          shareAppData("Invalid QR Code.", "toast");
            //                      }
            //                  },
            //                  error: function (xhr, status, error) {
            //                      $('#display_loading').addClass('hideme');
            //                      shareAppData("Invalid QR Code.", "toast");
            //                  },
            //              });
            //          } else {
            var objParams = {};
            var recordID = barcode[0];
            objParams.isDelete = 0;
            var ajaXCallURL = $.trim($('#ajaXCallURL').val());
            objParams.tokenKey = getParameterByName('tokenKey');
            objParams.secretKey = getParameterByName('secretKey');
            objParams.offlineDataID = localStorage.getItem("offlineDataID");
            var queryMode = getParameterByName('queryMode');
            localStorage.setItem("eventID", recordID);
            objParams.recordID = recordID;
            objParams.callUrl = ajaXCallURL + '/milestone003/updateStatuseventorders';
            objParams.status = "Attended";
            $.ajax({
                url: objParams.callUrl,
                data: objParams,
                type: 'POST',
                success: function (response) {

                    if (response.status == 0) {
                        //                          var objParams = {};
                        //                          objParams.isDelete = 0;
                        //                          var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                        //                          objParams.tokenKey = getParameterByName('tokenKey');
                        //                          objParams.secretKey = getParameterByName('secretKey');
                        //                          objParams.offlineDataID = localStorage.getItem("offlineDataID");
                        //                          var queryMode = getParameterByName('queryMode');
                        //
                        //                          objParams.callUrl = ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_sacaner_Referraldetails5da73cac545050343288ce7a';
                        //                          objParams.clientID = localStorage.getItem("userID");
                        //                          objParams.productid = localStorage.getItem("eventID");;
                        //
                        //                          $.ajax({
                        //                              url: objParams.callUrl,
                        //                              data: objParams,
                        //                              type: 'POST',
                        //                              success: function (response) {
                        //
                        //                                  if (response.status == 1) {
                        //                                      shareAppData("Thanks for attending the event.", "toast");
                        //                                      $("#addeventpoints8").trigger("click");
                        //                                      return false;
                        //                                  } else if (response.status == 0) {
                        //                                      $('#display_loading').addClass('hideme');
                        //                                      var objParams = {};
                        //                                      if (response.recordDetails) {
                        shareAppData("Thanks for attending the event.", "toast");
                        //                                          return false;
                        //                                      }
                        //                                  } else {
                        //                                      $('#display_loading').addClass('hideme');
                        //                                      shareAppData("Invalid QR Code.", "toast");
                        //                                  }
                        //                              },
                        //                              error: function (xhr, status, error) {
                        //                                  $('#display_loading').addClass('hideme');
                        //                                  shareAppData("Invalid QR Code.", "toast");
                        //                              },
                        //                          });

                    } else {
                        shareAppData("Invalid QR Code.", "toast");

                    }
                },
                error: function (xhr, status, error) {
                    $('#display_loading').addClass('hideme');
                    shareAppData("Invalid QR Code.", "toast");
                },
            });
            //    return false;   

        }
        //      } else {
        //          shareAppData("Invalid QR Code.", "toast");
        //      }
    }
    console.log('last one');
}
function processBeforeCallForSave6254registerevent(objParams, response, callback) {


    objParams.clientid = localStorage.userID;
    objParams.type = 'participant';
    objParams.status = 'Registered';
    objParams.eventid = getParameterByName('recordID')
    objParams.bazaarid = getParameterByName('recordID')
    objParams.productid = getParameterByName('recordID');

    callback();
}
function processAfterCallForSave6254registerevent(response, callback) {

    callback();
}
function getRecordByIDProcessBeforeCall710799(paramsType, callback) {
    var response = paramsType;

    if (getParameterByName('bazaarid') && getParameterByName('bazaarid') != 'undefined') { paramsType.recordID = getParameterByName('bazaarid') } else if (getParameterByName('recordID') && getParameterByName('recordID') != 'undefined') { paramsType.recordID = getParameterByName('recordID') }; callback();
}
function getRecordByIDProcessAfterCall710799(response, callback) {
    callback();
}
$(document).on('click', '#registerevent30', function () {
    var element = $(this);
    var parent = getParameterByName('parent');
    var nextPage = 'app_productadditionalregisterdetails';
    // if(parent)
    // {

    //     nextPage = parent ;
    // }
    // if (localStorage.getItem('eventbackpage')) {
    //     nextPage = localStorage.getItem('eventbackpage');
    //     localStorage.removeItem('eventbackpage')
    // }
    var queryParams = queryStringToJSON();
    queryParams["queryMode"] = "update";
    var recordID = $(this).attr("recordID");
    if (recordID) {
        queryParams["recordID"] = recordID;
    }
    var queryString = $.param(queryParams);
    queryString = queryString.replace(/\+/g, "%20");
    queryString = decodeURIComponent(queryString);
    window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
    return false;
});

function showMoreLess() {
    var dots = document.getElementById("dots");
    var moreText = document.getElementById("more");
    var btnText = document.getElementById("myBtn");

    if (dots.style.display === "none") {
        dots.style.display = "inline";
        btnText.innerHTML = " Show more";
        moreText.style.display = "none";
    } else {
        dots.style.display = "none";
        btnText.innerHTML = " Show less";
        moreText.style.display = "inline";
    }
}

    function managetermConditionShowHide(flag) {
        if(flag == 'less') {
            $('#termcondtionless').removeClass('hideme')
            $('#termcondtionmore').addClass('hideme')
        } else {
            $('#termcondtionmore').removeClass('hideme')
            $('#termcondtionless').addClass('hideme')
        }
        
    }


function makeSlidesbannerimageupload6(data) {
  var slide = "";
  var htmlString = "";
  if (data && data.length > 0) {
    for (let index = 0; index < data.length; index++) {
      const element = data[index];
      var mediaID;
      if (element && element.mediaID) {
        mediaID = element.mediaID;
      }
      slide += ' <div class="swiper-slide" href="#one!" >';
      slide += '    <div class="row  col s12" style="padding: 0px" !important;>';
      slide += '       <div id="image6_div" style="text-align: center;">';
      slide += '          <img  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + mediaID + '_compressed.png" style="width:100%; height:210px">';
      slide += "       </div>";
      slide += "    </div>";
      slide += "        </div>";
    }
    if (slide) {
      $("#eventimage6").html(slide);
    }
    var swiper = new Swiper(".swiper-container", {
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
      watchOverflow: true,
      pagination: {
        el: ".swiper-pagination",
      },
    });
    $(".dynamic-slider-view").removeClass("shimmer");
  }
}

function loadNativesendinvitesControl(tokenKey, queryMode, secretKey, ajaXCallURL) {
    try {
      var appJSON = {};
      appJSON.tokenKey = tokenKey;
      appJSON.secretKey = secretKey;
      appJSON.queryMode = queryMode;
      appJSON.action = queryMode;
      appJSON.ajaXCallURL = ajaXCallURL;
      var AWSCredentials = localStorage.getItem("AWSCredentials");
      if (localStorage.IDENTITY_TOKEN) {
        var token = localStorage.IDENTITY_TOKEN;
        var playload = JSON.parse(atob(token.split(".")[1]));
        appJSON.Authorization = token;
        appJSON.Expiration = playload.exp;
      } else if (AWSCredentials) {
        AWSCredentials = JSON.parse(AWSCredentials);
        appJSON.accessKeyId = AWSCredentials.accessKeyId;
        appJSON.secretAccessKey = AWSCredentials.secretAccessKey;
        appJSON.sessionToken = AWSCredentials.sessionToken;
        appJSON.Expiration = AWSCredentials.Expiration;
      }
      var storeurl = localStorage.getItem("storeurl");
      var appuser = JSON.parse(localStorage.getItem("appUser"))
      var queryParams = queryStringToJSON();
      let url = `https://milestone.hokuapps.com/?pageName=app_productadditionaldetails_5da73cac545050343288ce7a&bazaarid=${queryParams.bazaarid}&recordID=${queryParams.recordID}&applyFilter=${queryParams.applyFilter}&parent=${queryParams.parent}`;
      appJSON.title = "Message on Share Event:";
      appJSON.msgText = `Hi, check this event on MSTAR Application ${url}\n\n Don't have MSTAR Application.? Please use http://onelink.to/jabqrj to download it. \n\n Apply the referral code below during sign-up.\n ${appuser.userreferralcode}`;
    
      appJSON.organizationID = $('#organizationID').val();
      appJSON.userID = $('#userID').val();
      appJSON.appID = $('#appID').val();
      var element = element ? element : null;
    //   clientbeforeNativesendinvites(appJSON, element, function (pbcRes) {
        if (DEVICE_TYPE == 'ios') {
          setupWebViewJavascriptBridge(function (bridgeObj) {
            bridgeObj.callHandler('shareTextToApps', appJSON, function (response) {
            });
          });
        } else {
          window.Android.shareTextToApps(JSON.stringify(appJSON));
        }
    //   }); // end of process before call 
    } catch (err) {
  
    }
  }

  function clientbeforeNativesendinvites(appJSON, element, callback) {
    callback();
  }
