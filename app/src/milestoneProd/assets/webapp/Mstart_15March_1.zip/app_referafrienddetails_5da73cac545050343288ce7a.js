
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
  $('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
    $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

  var objParamsToken = {};
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  objParamsToken.tokenKey = getParameterByName('tokenKey');
  objParamsToken.secretKey = getParameterByName('secretKey');

  var userRole = $('#userRole').val();
  var userID = $('#userID').val();
  var createrOfRecord = $('#createrOfRecord').val();
  var queryMode = getParameterByName('queryMode');
  var recordID = $.trim($('#recordID').val());
  var addSessionComments = [];
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on('click', '#sendinvites14', function () {
    var tokenKey = getParameterByName('tokenKey');
    var secretKey = getParameterByName('secretKey');
    var queryMode = getParameterByName('queryMode');
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    loadNativesendinvitesControl(tokenKey, queryMode, secretKey, ajaXCallURL);
  });//end of Event Send invites_is_click 
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#backbutton1', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_custmoreinfodetails';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "update";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error)
    }
  })
  var paramsEdit = {};
  paramsEdit.tokenKey = getParameterByName('tokenKey');
  paramsEdit.secretKey = getParameterByName('secretKey');
  var appUser = JSON.parse(localStorage.getItem('appUser'));
  if(appUser){
    if (appUser.userreferralcode) {
      $('#userreferralcode13').html(appUser.userreferralcode);
    }
      localStorage.setItem("storeurl",'http://onelink.to/jabqrj');
    Materialize.updateTextFields();
    $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

  }
 /* getRecordByIDProcessBeforeCall181727(paramsEdit, function (processBeforeRes) {
    $.ajax({
      url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_referafrienddetails_Usermanagement5da73cac545050343288ce7a',
      data: paramsEdit,
      type: 'POST',
      jsonpCallback: 'callback',
      success: function (response) {
        getRecordByIDProcessAfterCall181727(response, function (processBeforeRes) {
          if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
            var objParamsList = {};
            var queryMode = $('#queryMode').val();
            objParamsList.queryMode = queryMode;;
            var tokenKey = $('#tokenKey').val();;
            objParamsList.tokenKey = tokenKey;;
            if (!$('#backbutton1').html()) {
              $('#backbutton1').append(response.recordDetails.undefined);
            }
            var url = 'icon_invite.png'
            $('#iconinvite6').attr("src", url);
            if (!$('#invite20friendstoredeem10').html()) {
              $('#invite20friendstoredeem10').append(response.recordDetails.undefined);
            }
            if (!$('#invitefriends2').html()) {
              $('#invitefriends2').append(response.recordDetails.undefined);
            }
            if (!$('#one100pointsvoucher11').html()) {
              $('#one100pointsvoucher11').append(response.recordDetails.undefined);
            }
            if (!$('#referyourfriend8').html()) {
              $('#referyourfriend8').append(response.recordDetails.undefined);
            }
            if (!$('#usebelowreferralcode9').html()) {
              $('#usebelowreferralcode9').append(response.recordDetails.undefined);
            }
            if (!$('#userreferralcode13').html()) {
              $('#userreferralcode13').append(response.recordDetails.userreferralcode);
            }
            if(response.recordDetails.storeurl)
            {
              localStorage.setItem("storeurl",response.recordDetails.storeurl);
            }

            Materialize.updateTextFields();
            $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

          }
        }); // end of getRecord By ID
      },
      error: function (xhr, status, error) {
        handleError(xhr, status, error);
      },
    });
  }); // end of getRecord By ID*/

});//end of ready 
function loadNativesendinvitesControl(tokenKey, queryMode, secretKey, ajaXCallURL) {
  try {
    var appJSON = {};
    appJSON.tokenKey = tokenKey;
    appJSON.secretKey = secretKey;
    appJSON.queryMode = queryMode;
    appJSON.action = queryMode;
    appJSON.ajaXCallURL = ajaXCallURL;
    var AWSCredentials = localStorage.getItem("AWSCredentials");
    if (localStorage.IDENTITY_TOKEN) {
      var token = localStorage.IDENTITY_TOKEN;
      var playload = JSON.parse(atob(token.split(".")[1]));
      appJSON.Authorization = token;
      appJSON.Expiration = playload.exp;
    } else if (AWSCredentials) {
      AWSCredentials = JSON.parse(AWSCredentials);
      appJSON.accessKeyId = AWSCredentials.accessKeyId;
      appJSON.secretAccessKey = AWSCredentials.secretAccessKey;
      appJSON.sessionToken = AWSCredentials.sessionToken;
      appJSON.Expiration = AWSCredentials.Expiration;
    }
    var storeurl = localStorage.getItem("storeurl");
    appJSON.title = "Invite Friends For MSTAR";
    appJSON.msgText = "Hi, please use "+ storeurl +" to download the MSTAR Application.\n\nApply the referral code below during sign-up.\n\n" + $('#userreferralcode13').html();
  
    appJSON.organizationID = $('#organizationID').val();
    appJSON.userID = $('#userID').val();
    appJSON.appID = $('#appID').val();
    var element = element ? element : null;
    clientbeforeNativesendinvites(appJSON, element, function (pbcRes) {
      if (DEVICE_TYPE == 'ios') {
        setupWebViewJavascriptBridge(function (bridgeObj) {
          bridgeObj.callHandler('shareTextToApps', appJSON, function (response) {
          });
        });
      } else {
        window.Android.shareTextToApps(JSON.stringify(appJSON));
      }
    }); // end of process before call 
  } catch (err) {

  }
}
function clientbeforeNativesendinvites(appJSON, element, callback) {
  var response = appJSON;
  appJSON.title = "Invite Friends";
  var publicUrl = $("#ajaXCallURL").val() + '/social/' + $("#hdnAppID").val() + '/publicshare.html';

  msgText = "Hi Please use " + $('#userreferralcode13').html() + " code while signup";
  //$('[id^="about24"]').html();
  //appJSON.msgText = appJSON.msgText ? appJSON.msgText : '';
  //appJSON.msgText += ' '+publicUrl 


  callback();
}
function setNativesendinvitesControl(responseData) {
  try {
    if (responseData) {
      // Add Custome function Call here                 
      clientafterNativesendinvites(responseData, function (pbcRes) {
        // handle client after call 
      })
    }
  } catch (err) {

  }
}
function clientafterNativesendinvites(response, callback) {
  callback();
}
function getRecordByIDProcessBeforeCall181727(paramsType, callback) {
  var response = paramsType;

  if (getParameterByName('usermanagementid') && getParameterByName('usermanagementid') != 'undefined') { paramsType.recordID = getParameterByName('usermanagementid') } else if (getParameterByName('recordID') && getParameterByName('recordID') != 'undefined') { paramsType.recordID = getParameterByName('recordID') }; paramsType.recordID = localStorage.userID; callback();
}
function getRecordByIDProcessAfterCall181727(response, callback) {
  callback();
}