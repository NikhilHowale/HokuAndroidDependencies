
var offlineDataID = randomString();
var arrAllMedia = [];
var count = 0;
var passwordchanged = 0;
var errorFields = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"))
    }

    var objParamsToken = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsToken.tokenKey = getParameterByName('tokenKey');
    objParamsToken.secretKey = getParameterByName('secretKey');

    var userRole = $('#userRole').val();
    var userID = $('#userID').val();
    var createrOfRecord = $('#createrOfRecord').val();
    var queryMode = getParameterByName('queryMode');
    var recordID = $.trim($('#recordID').val());
    var addSessionComments = [];
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('keyup', '#password10', function () {
        var password = $(this).val();
        showPasswordStrength(password)
    });

    $(document).on('click', '#signup14', function () {



        
        $("#signupError").addClass('hide')
        var objParams = {};
        objParams.isDelete = 0;
        // var confirmpassword = $.trim($('#confirmpassword11').val());
        // if ($('#confirmpassword11_div').is(':visible')) {
        //     if (confirmpassword == '') {
        //         $('#confirmpassword11_error').show();
        //         $('#confirmpassword11').fadeIn(1000);
        //         errorFields.push('confirmpassword11');
        //     }
        //     else {
        //         $('#confirmpassword11_error').hide();
        //     }
        // }
        // if ($('#confirmpassword11_div').is(':visible')) {
        //     objParams.confirmpassword = confirmpassword;
        // }



        var confirmemail = $.trim($('#confirmEmail7').val());
        if ($('#confirmEmail7_div').is(':visible')) {
            if (confirmemail == '') {
                $('#confirmEmail7_error').show();
                $('#confirmEmail7').fadeIn(1000);
                errorFields.push('confirmEmail7');
            }
            else {
                $('#confirmEmail7_error').hide();
            }
        }
        if ($('#confirmEmail7_div').is(':visible')) {
            objParams.confirmemail = confirmemail;
        }

        var customerid = $.trim($('#customerid13').val());
        if ($('#customerid13_div').is(':visible')) {
            if (customerid == '') {
                $('#customerid13_error').show();
                $('#customerid13').fadeIn(1000);
                errorFields.push('customerid13');
            }
            else {
                $('#customerid13_error').hide();
            }
        }
        if ($('#customerid13_div').is(':visible')) {
            objParams.customerid = customerid;
        }
        var email = $.trim($('#email7').val());
        if ($('#email7_div').is(':visible')) {
            if (email == '') {
                $('#email7_error').show();
                $('#email7').fadeIn(1000);
                errorFields.push('email7');
            } else if (typeof EMAIL_REGEX !== 'undefined' && EMAIL_REGEX && !EMAIL_REGEX.test(email)) {
                $('#email7_error').html('Incorrect email format').show();
                $('#email7').focus();
                return false;
            }
            else {
                $('#email7_error').hide();
            }
        }
        if ($('#email7_div').is(':visible')) {
            objParams.email = email;
        }
        //var contactnumber = $.trim($('#contactnumber9').val());
        // if ($('#contactnumber9_div').is(':visible')) {
        //     if (contactnumber == '') {

        //         $('#contactnumber9_error').show();
        //         $('#contactnumber9').fadeIn(1000);
        //         errorFields.push('contactnumber9');
        //     }
        //     else {

        //         $('#contactnumber9_error').hide();
        //     }
        // }

        // if ($('#contactnumber9_div').is(':visible')) {
        //     var dialCode = $('#contactnumber9').attr('dialCode');
        //     var countryCode = $('#contactnumber9').attr('countryCode');
        //     var placeholder = $('#contactnumber9').attr('placeholder');
        //     contactnumber = contactnumber.replace(/[^0-9]/gi, '');
        //     placeholder = placeholder.replace(/[^0-9]/gi, '');
        //     //            if (contactnumber && placeholder.length != contactnumber.length) {
        //     //                $('#contactnumber9_error').html('Valid Mobile Number is required').show();
        //     //                $('#contactnumber9').fadeIn(1000);
        //     //                errorFields.push('contactnumber9');
        //     //            }
        //     objParams.contactnumber = '+' + dialCode + contactnumber;
        //     objParams.contactnumber_dialcode = dialCode;
        //     objParams.contactnumber_countrycode = countryCode;
        // }
        var name = $.trim($('#name6').val());
        if ($('#name6_div').is(':visible')) {
            if (name == '') {
                $('#name6_error').show();
                $('#name6').fadeIn(1000);
                errorFields.push('name6');
            }
            else {
                $('#name6_error').hide();
            }
        }
        if ($('#name6_div').is(':visible')) {
            objParams.name = name;
            objParams.displayname = name;
        }
        var password = $.trim($('#password10').val());
        if ($('#password10_div').is(':visible')) {
            if (password == '') {
                $('#password10_error').show();
                $('#password10').fadeIn(1000);
                errorFields.push('password10');
            }
            else {
                $('#password10_error').hide();
            }
        }
        if ($('#password10_div').is(':visible')) {
            objParams.password = password;
        }
        var userreferralcode = $.trim($('#userreferralcode11').val());
        // if ($('#userreferralcode8_div').is(':visible')) {
        objParams.userreferralcode = userreferralcode;
        //  }

        objParams.referralbycode = '';
        var referralbycode = $.trim($('#referralbycode12').val());
        objParams.referralbycode = referralbycode;

        // if (password != confirmpassword) {
        //     $('#confirmpassword11_error').html('Password and Confirm password should be same.');
        //     $('#confirmpassword11_error').show();
        //     $('#confirmpassword11').focus();
        //     return false;
        // } else {
        //     $('#confirmpassword11_error').html('Confirm Password is required');
        // }

        if (email != confirmemail) {
            $('#confirmEmail7_error').html('Email and Confirm Email should be same.');
            $('#confirmEmail7_error').show();
            $('#confirmpassword11').focus();
            return false;
        } else {
            $('#confirmEmail7_error').html('Confirm Email is required');
        }

        // var signing_in = $.trim($('#agreecheck').val());
        // if (signing_in == "") {
        //     return false;
        // } else {

        // }

        if ($("#agreecheck").prop('checked') == true) {
            $('#agreecheck_error').hide();
        } else {
            $('#agreecheck_error').show();
            return false;
        }


        if (errorFields && errorFields.length) {
            $('#display_loading').addClass('hideme');
            var firstErrorField = errorFields[0];
            errorFields = []
            $('#' + firstErrorField).focus();
            $('#' + firstErrorField).focus();
            return false;
        }
        objParams.offlineDataID = localStorage.getItem("offlineDataID");
        $('#undefined').prop('disabled', true);
        $('#display_loading').removeClass('hideme');
        var recordID = $('#recordID').val();
        if (forwardChekbox.length > 0) {
            objParams.forwardChekbox = forwardChekbox;
        } else {
            objParams.forwardChekbox = [];
        }
        if (addSessionComments.length > 0) {
            objParams.addSessionComments = addSessionComments;
        } else {
            objParams.addSessionComments = [];
        }
        if (typeof (addedFiles) != 'undefined' && addedFiles.length > 0) {
            objParams.addedFiles = addedFiles;
        } else {
            objParams.addedFiles = [];
        }
        var parentID = $('#parentID').val();
        var parentName = $('#parentName').val();
        objParams.isDelete = 0;
        if (parentID != '') {
            objParams.parentID = parentID;
            objParams.parentName = parentName
        }
        objParams.lastpage = 'usersignup'
        localStorage.setItem('usersignup', JSON.stringify(objParams))
        var dataObj = {};
        var tokenKey = $('#tokenKey').val();
        var queryMode = $('#queryMode').val();
        var secretKey = $('#secretKey').val();
        if (dataObj && Object.keys(dataObj).length > 0) {
            objParams = dataObj;
        }
        objParams.IsAdmin = "No";
        var ajaXCallURL = $('#ajaXCallURL').val();
        objParams.rolename = "customer";//admin
        objParams.subdomain = CognitoConfig.SUBDOMAIN;
        objParams.appID = CognitoConfig.APPID;
        objParams.integrationName = 'incorv56';
        localStorage.clear();
        objParams.email = objParams.email.trim().toLowerCase();
        var hokuusername = objParams.contactnumber
        var objString = JSON.stringify(objParams);
        var signupParams = objParams;
        signupParams.attributes = []
        signupParams.attributes.push({ Name: 'custom:role', Value: objParams.rolename });
        signupParams.attributes.push({ Name: 'name', Value: objParams.name });
        signupParams.attributes.push({ Name: 'nickname', Value: objParams.name });

        signupParams.attributes.push({ Name: 'email', Value: objParams.email });

        //if(objParams.referralbycode){
        // signupParams.attributes.push({ Name: 'custom:referralbycode', Value: objParams.referralbycode });
        //}

        signupParams.attributes.push({ Name: 'custom:appId', Value: CognitoConfig.APPID });
        signupParams.attributes.push({ Name: 'custom:subdomain', Value: CognitoConfig.SUBDOMAIN });
        signupParams.attributes.push({ Name: 'custom:hosturl', Value: CognitoConfig.APP_URL });
        signupParams.attributes.push({ Name: 'custom:contactnumber', Value: objParams.contactnumber });
        signupParams.attributes.push({ Name: 'custom:dialcode', Value: objParams.contactnumber_dialcode });
        signupParams.attributes.push({ Name: 'custom:countrycode', Value: objParams.contactnumber_countrycode });
        signupParams.attributes.push({ Name: 'custom:referalcode', Value: objParams.userreferralcode });
        //signupParams.attributes.push({ Name: 'custom:metadata', Value: objString });

        signupParams.username = objParams.email;
        signupParams.email = objParams.email;
        signupParams.password = objParams.password;
        signupParams.useremail = objParams.email;
        signupParams.contactnumber = objParams.contactnumber;
        signupParams.countrycode = objParams.contactnumber_countrycode;
        signupParams.dialcode = objParams.contactnumber_dialcode;
        signupParams.referralbycode = objParams.referralbycode;
        loginInfo = null;
        forgotEmail = null;
        signupInfo = signupParams;
        $('#display_loading').removeClass('hideme');

        if (objParams.userreferralcode && objParams.userreferralcode !== undefined && objParams.userreferralcode !== 'undefined' && objParams.userreferralcode !== "") {
            const domainName = $('#domainName').val();
            const ajaXCallURL = 'https://milestone.hokuapps.com/api/validateReferralCode'
            let validateReferralCodeParams = {}
            validateReferralCodeParams.userreferralcode = objParams.userreferralcode
            $.ajax({
                url: ajaXCallURL,
                data: validateReferralCodeParams,
                type: 'POST',
                success: function (response) {
                    if (response.status == 0) {
                        signUP(signupInfo);
                        return false
                    }
                    else {
                        $('#display_loading').addClass('hideme');
                        $(".cognitoError").show();

                        $("#signupError").removeClass('hide');
                        $("#signupError").html("Invalid referral code");
                    }
                },
                error: function (xhr, status, error) { },
            });
        }
        else {
            signUP(signupInfo);

        }
        // createNewThingINProcessBeforeCallsignup14(objParams, function (processBeforeRes) {
        //     $.ajax({
        //         url: ajaXCallURL + '/incorv56/hokuexternalsignup5ce2e616f9039e46f12edc4d',
        //         data: objParams,
        //         type: 'POST',
        //         success: function (response) {
        //             if (response.status != undefined && response.status == 0) {
        //                 localStorage.setItem('objGetUserDetailsWithmenu', JSON.stringify(response.objGetUserDetailsWithmenu));
        //                 localStorage.setItem('perms', JSON.stringify(response.perms));
        //                 localStorage.setItem('user', JSON.stringify(response.user));
        //                 localStorage.setItem('appUser', JSON.stringify(response.appUser));
        //                 localStorage.setItem('organizationID', response.user.organizationId);
        //                 localStorage.setItem('userID', response.user.userId);
        //                 localStorage.setItem('CDN_PATH', 'https://dxrq26z7a1rw3.cloudfront.net');
        //                 localStorage.setItem('CDN_THUMB', response.CDN_THUMB);
        //                 if (response.appUser) {
        //                     localStorage.setItem('appUser', JSON.stringify(response.appUser));
        //                 }
        //                 if (response.appUser && response.appUser.userphotoupload && response.appUser.userphotoupload[0]) {
        //                     localStorage.setItem('profileThumb', response.appUser.userphotoupload[0].mediaID);
        //                 } else {
        //                     localStorage.removeItem('profileThumb');
        //                 }
        //                 localStorage.setItem('tokenData', JSON.stringify(response.tokenData));
        //                 loginNativeCallWrappersignup14(response, '5ce2e616f9039e46f12edc4d');
        //                 return false;
        //             } else if (response.errorMessage) {
        //                 $('#display_loading').addClass('hideme');
        //                 $('#confirmpassword_error').html(response.errorMessage).show();
        //                 return false;
        //             } else {
        //                 $('#display_loading').addClass('hideme');
        //                 return false;
        //             }
        //         },
        //         error: function (xhr, status, error) { }
        //     });
        // }); // end of CreateNewThingin Session ID Process Before Call 
    });//end of Event Sign Up_is_click 
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('click', '#backbutton1', function () {
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = getParameterByName('queryMode');
        var recordID = getParameterByName('recordID');
        queryMode = 'add'
        window.location.href = 'login_cognito.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey
        return false;
    });//end of Event backbutton_is_click 
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('click', '#login5', function () {
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = getParameterByName('queryMode');
        var recordID = getParameterByName('recordID');
        queryMode = 'mylist'
        window.location.href = 'login_cognito.html';
        return false;
    });//end of Event Log In_is_click 
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};

});//end of ready 
function createNewThingINProcessBeforeCallsignup14(objParams, callback) {
    callback();
}
function loginNativeCallWrappersignup14(response, appID) {
    try {
        var queryMode = $('#queryMode').val();
        var appJSON = {};
        appJSON.organizationID = response.user.organizationId;
        appJSON.userID = response.user.userId;
        appJSON.appID = $('#appID').val();
        appJSON.nextButtonCallback = 'setloginNativeCallBacksignup14';
        appJSON.action = queryMode;
        appJSON.colorCode = '#3c3c3c';
        appJSON.response = response;
        appJSON.launchNative = false;
        appJSON.authToken = response.appTokenDetails.authToken;
        appJSON.authSecretKey = response.appTokenDetails.authSecretKey;
        appJSON.roleName = response.appTokenDetails.roleName;
        appJSON.expiredTime = response.appTokenDetails.expiredTime;
        appJSON.launchNextpage = 'customerhome_5ce2e616f9039e46f12edc4d.html'

        var roleName = response.appTokenDetails.roleName;
        localStorage.setItem('roleName', roleName);
        var ISDEV_MODE = localStorage.getItem('ISDEV_MODE');
        var DEV_MODE = getParameterByName('devmode');
        if (ISDEV_MODE == 'true' || DEV_MODE) {
            var tokenKey = response.appTokenDetails.authToken;
            var secretKey = response.appTokenDetails.authSecretKey;
            var queryMode = 'mylist';
            window.location.href = 'customerhome_5ce2e616f9039e46f12edc4d.html?queryMode=add&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
            return false
        } else {
            var isAndroid = navigator.userAgent.toLowerCase().indexOf('android');
            if (isAndroid > -1) {
                window.Android.loginNativeCallV2(JSON.stringify(appJSON))
            } else {
                bridgeObj.callHandler('loginNativeCall', appJSON, function (response) { });
                bridgeObj.registerHandler('setloginNativeCallBacksignup14', function (responseData, responseCallback) {
                    setloginNativeCallBacksignup14(responseData)
                });
            }
        }
    } catch (err) {
        $('#display_loading').addClass('hideme');
    }
}
function setloginNativeCallBacksignup14(responseData) {
    try {
        if (responseData) {
            var userDeviceObj = responseData.userDeviceObj;
            if (responseData.data) {
                responseData = responseData.data;
            }
            var tokenKey = responseData.authToken;
            var secretKey = responseData.authSecretKey;
            var queryMode = 'mylist';
            var domainName = $('#domainName').val();
            var ajaXCallURL = 'https://gateway.' + domainName + '.com'
            var objParams = {};
            objParams.organizationID = responseData.organizationID;
            objParams.userID = responseData.userID;
            objParams.appID = responseData.appID;
            objParams.tokenKey = tokenKey;
            objParams.secretKey = secretKey;
            appJSON.apiName = ajaXCallURL + '/api/addUserDeviceForApp_5ce2e616f9039e46f12edc4d';
            appJSON.Authorization = localStorage.getItem('IDENTITY_TOKEN');
            objParams.userDeviceObj = userDeviceObj;
            objParams.isLogin = true;
            if (responseData.roleName) {
                objParams.roleName = responseData.roleName;
            }
            $.ajax({
                url: ajaXCallURL + '/api/addUserDeviceForApp_5ce2e616f9039e46f12edc4d',
                data: objParams,
                type: 'POST',
                success: function (response) {
                    if (response.status == 0) {
                        var roleName = localStorage.getItem('roleName');
                        window.location.href = 'customerhome_5ce2e616f9039e46f12edc4d.html?queryMode=add&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                        return false
                    }
                },
                error: function (xhr, status, error) { },
            });
        };
    } catch (err) { };
}
function showPasswordStrength(password) {
    try {
        var isDigit = false;
        var isLowerChar = false;
        var isUpperChar = false;
        var isNonAlpha = false;
        var isLength = false;

        $('.strongpass').removeClass('valid')
        var charArray = password.split('');
        if (!password.trim().length) {
            return;
        }

        $.each(charArray, function (key, value) {
            if (value) {
                if (!isNaN(value)) {
                    isDigit = true;
                    $('.numberValid').addClass('valid')
                }

                if (value.toUpperCase() != value.toLowerCase()) {
                    isLetter = true;
                    if (value == value.toLowerCase()) {
                        isLowerChar = true;
                        $('.lowercaseValid').addClass('valid');
                    }
                    if (value == value.toUpperCase()) {
                        isUpperChar = true;
                        $('.uppercaseValid').addClass('valid');
                    }
                }
                if (/[^a-zA-Z0-9]/.test(value)) {
                    isNonAlpha = true;
                    $('.specialcharValid').addClass('valid');
                }
            }
        });

        if (password.length >= 8) {
            isLength = true;
            $('.lengthValid').addClass('valid');
        }

    } catch (err) {
        console.log(err, 'showPasswordStrength ');
    }
}


