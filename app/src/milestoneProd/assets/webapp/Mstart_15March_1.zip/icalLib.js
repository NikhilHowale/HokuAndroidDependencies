
function showMonthsCalenderEvents(iCalArray,callback) {
    //1 > Today
    //2 > List
    //3 > Month
    var eventHTML = "";
    var sortedData = iCalArray["vevent"].sort(function(v1, v2) {
        var dt1 = new moment(v1["dtstart"]["_value"].toString());
        var dt2 = new moment(v2["dtstart"]["_value"].toString());
        return ((dt1 < dt2) ? -1 : ((dt1 > dt2) ? 1 : 0));
    });

    var minDateVal = new moment(sortedData[0]["dtstart"]["_value"].toString());
    var maxDateVal = new moment(sortedData[sortedData.length - 1]["dtstart"]["_value"].toString());
    minDateVal = moment(moment(minDateVal).add(1 - parseInt(moment(minDateVal).format('DD')), 'day'))
    maxDateVal = moment(moment(maxDateVal).add(1 - parseInt(moment(maxDateVal).format('DD')), 'day'))

    while (minDateVal < maxDateVal) {
        var monthEndDate = moment(minDateVal).add(1, 'months');
        var data = $.grep(sortedData, function(i) {
            var date = new moment(i["dtstart"]["_value"].toString());
            return date > minDateVal && date < monthEndDate;
        });

        if (data && data.length) {
            eventHTML += "<div class='row' style='height:30px; background-color: #F2F2F2;'>";
            eventHTML += "<div class='col s12'> <span>" + minDateVal.format("MMMM YYYY") + "</span></div>";
            eventHTML += "</div>";
            eventHTML += "<div class=''>";
        }

        $.each(data, function(key, val) {
            eventHTML += "<div class='row' onclick='onClickEvent(" + JSON.stringify(val) + ")'>";
            eventHTML += "<div class='col s3'>";
            eventHTML += "<span>" + (parseInt(moment(val["dtstart"]["_value"].toString()).utc().format("HH")) == 0 ? "All Day" : moment(val["dtstart"]["_value"].toString()).utc().format("hh:mm A")) + "</span>";
            eventHTML += "</div>";
            eventHTML += "<div class='col s9'>";
            eventHTML += "<span>" + val["summary"].toString() + "</span>";
            eventHTML += "<br \>";
            eventHTML += "<span>" + new moment(val["dtstart"]["_value"].toString()).format("ddd, MMMM DD") + "</span>";
            eventHTML += "</div>";
            eventHTML += "</div>";
        });

        if (data && data.length) {
            eventHTML += "</div>";
        }

        minDateVal = minDateVal.add(1, 'months');
    }

    callback({
        "eventHTML": eventHTML
    })
    //$("#eventContainer").html(eventHTML);
}

function showDaysCalenderEvents(iCalArray,callback) {
    //1 > Today
    //2 > List
    //3 > Month
    var eventHTML = "";
    var sortedData = iCalArray["vevent"].sort(function(v1, v2) {
        var dt1 = new moment(v1["dtstart"]["_value"].toString());
        var dt2 = new moment(v2["dtstart"]["_value"].toString());
        return ((dt1 < dt2) ? -1 : ((dt1 > dt2) ? 1 : 0));
    });

    var today = moment(moment(new Date()).utc().format("YYYY MM DD"));
    var endDate = moment(today).set('hour', 23).set('minute', 59);
    var data = $.grep(sortedData, function(i) {
        var date = moment(moment(i["dtstart"]["_value"].toString()).utc().format("YYYY MM DD")).utc();
        return date == moment(moment(new Date()).utc().format("YYYY MM DD")).utc();
    });
    $.each(data, function(key, val) {
        eventHTML += "<div class='row'>";
        eventHTML += "<div class='col s3'>";
        eventHTML += "<span>" + (parseInt(moment(val["dtstart"]["_value"].toString()).utc().format("HH")) == 0 ? "All Day" : moment(val["dtstart"]["_value"].toString()).utc().format("hh:mm A")) + "</span>";
        eventHTML += "</div>";
        eventHTML += "<div class='col s9'>";
        eventHTML += "<span>" + val["summary"].toString() + "</span>";
        eventHTML += "<br \>";
        eventHTML += "<span>" + new moment(val["dtstart"]["_value"].toString()).format("ddd, MMMM DD") + "</span>";
        eventHTML += "</div>";
        eventHTML += "</div>";
    });

    callback({
        "eventHTML": eventHTML
    })
    //$("#eventContainer").html(eventHTML);
}


function showListCalenderEvents(iCalArray,callback) {
    //1 > Today
    //2 > List
    //3 > Month
    var eventHTML = "";
    var sortedData = iCalArray["vevent"].sort(function(v1, v2) {
        var dt1 = new moment(v1["dtstart"]["_value"].toString());
        var dt2 = new moment(v2["dtstart"]["_value"].toString());
        return ((dt1 < dt2) ? -1 : ((dt1 > dt2) ? 1 : 0));
    });

    $.each(sortedData, function(key, val) {
        eventHTML += "<div class='row' style='height:30px; background-color: #F2F2F2;'>";
        eventHTML += "<div class='col s12'> <span>" + new moment(val["dtstart"]["_value"].toString()).format("ddd, MMMM DD YYYY") + "</span></div>";
        eventHTML += "</div>";

        eventHTML += "<div class='row'>";
        eventHTML += "<div class='col s3'>";
        eventHTML += "<span>" + (parseInt(moment(val["dtstart"]["_value"].toString()).utc().format("HH")) == 0 ? "All Day" : moment(val["dtstart"]["_value"].toString()).utc().format("hh:mm A")) + "</span>";
        eventHTML += "</div>";
        eventHTML += "<div class='col s9'>";
        eventHTML += "<span>" + val["summary"].toString() + "</span>";
        eventHTML += "</div>";
        eventHTML += "</div>";
    });

    callback({
        "eventHTML": eventHTML
    })
    //$("#eventContainer").html(eventHTML);
}