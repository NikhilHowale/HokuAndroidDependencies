
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
  if (recordID != '') {
      var paramsEdit = {};
      paramsEdit.recordID = recordID;
      paramsEdit.tokenKey = getParameterByName('tokenKey');
      paramsEdit.secretKey = getParameterByName('secretKey') 
                       getRecordByIDProcessBeforeCall941669(paramsEdit, function (processBeforeRes) {
      $.ajax({
          url: ajaXCallURL+'/milestone003/getRecordByCustomeQuery_successpayment_Orders5da73cac545050343288ce7a',
          data: paramsEdit,
          type: 'POST',
          jsonpCallback: 'callback',
          success: function (response) { 
                       getRecordByIDProcessAfterCall941669(response, function (processBeforeRes) {
              if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                  var objParamsList = {};
                  var queryMode = $('#queryMode').val(); 
                  objParamsList.queryMode = queryMode;;
                  var tokenKey = $('#tokenKey').val();;
                  objParamsList.tokenKey = tokenKey;;
  if(!$('#addressstring11').html()){
            $('#addressstring11').append(response.recordDetails.addressstring);
 }
  if(!$('#backbutton1').html()){
            $('#backbutton1').append(response.recordDetails.undefined);
 }
 response.recordDetails['orderslotdate_preserved'] = response.recordDetails['orderslotdate'] ;
 response.recordDetails['orderslotdate'] = response.recordDetails['orderslotdate']  ? moment(new Date(response.recordDetails['orderslotdate'])).format('DD MMM YYYY by hh:mm A') : '';
  if(!$('#orderslotdate12').html()){
            $('#orderslotdate12').append('<span class="prefixlink">Delivery Date:</span>'+response.recordDetails.orderslotdate);
 }
 response.recordDetails['orderslotdate'] =  response.recordDetails['orderslotdate_preserved'];
  if(!$('#fullname10').html()){
            $('#fullname10').append(response.recordDetails.fullname+'<span class="suffixlink">at</span>');
 }
  if(!$('#orderitemcount9').html()){
            $('#orderitemcount9').append(response.recordDetails.orderitemcount+'<span class="suffixlink">item(s) will be delivered to</span>');
 }
  if(!$('#pleasecheckyouremailorderconfirmationanddetaileddeliveryinformationinyourmyordersection7').html()){
            $('#pleasecheckyouremailorderconfirmationanddetaileddeliveryinformationinyourmyordersection7').append(response.recordDetails.undefined);
 }
           var url = 'paymentsuccess.png'
          $('#successimage5').attr("src", url);
  if(!$('#thankyou2').html()){
            $('#thankyou2').append(response.recordDetails.undefined);
 }
  if(!$('#thankyouforshoppingwithus6').html()){
            $('#thankyouforshoppingwithus6').append(response.recordDetails.undefined);
 }

              Materialize.updateTextFields();
                $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);
  
              } 
              }); // end of getRecord By ID
          },
          error: function (xhr, status, error) {
              handleError(xhr, status, error); 
          },
      }); 
              }); // end of getRecord By ID
   }
});//end of ready 
                 function getRecordByIDProcessBeforeCall941669(paramsType,callback) { 
                 var response = paramsType;
 callback(); 
                 } 
                 function getRecordByIDProcessAfterCall941669(response,callback) {
 callback(); 
                 }