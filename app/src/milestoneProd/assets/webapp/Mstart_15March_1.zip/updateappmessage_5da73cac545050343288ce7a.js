var offlineDataID = randomString();
var arrAllMedia = [];
var count = 1;
var passwordchanged = 0;
var errorFields = [];
var gMediaOfflineDataID = "";
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
  $("#recordID").val(getParameterByName("recordID"));
  var queryMode = getParameterByName("queryMode");
  var authKey = $("#authKey").val();
  var appID = $("#hdnAppID").val();

  var objParamsToken = {};
  var ajaXCallURL = $.trim($("#ajaXCallURL").val());
  objParamsToken.tokenKey = getParameterByName("tokenKey");
  objParamsToken.secretKey = getParameterByName("secretKey");

  var userRole = $("#userRole").val();
  var userID = $("#userID").val();
  var createrOfRecord = $("#createrOfRecord").val();
  var queryMode = getParameterByName("queryMode");
  var recordID = $.trim($("#recordID").val());
  var addSessionComments = [];
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on("click", "#update10", function () {
    var tokenKey = getParameterByName("tokenKey");
    var secretKey = getParameterByName("secretKey");
    var queryMode = getParameterByName("queryMode");
    var ajaXCallURL = $.trim($("#ajaXCallURL").val());
    loadNativeupdateControl(tokenKey, queryMode, secretKey, ajaXCallURL);
  }); //end of Event Update_is_click
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};
  var applyFilter = getParameterByName("applyFilter");
  if (applyFilter == "true" || applyFilter == true) {
  }
  $(document).on("click", "#backbutton1", function (e) {
    var tokenKey = getParameterByName("tokenKey");
    var secretKey = getParameterByName("secretKey");
    var queryMode = getParameterByName("queryMode");
    var recordID = getParameterByName("recordID");
    window.location.href =
      "pm_otherhomecust_5da73cac545050343288ce7a.html?queryMode=" +
      queryMode +
      "&tokenKey=" +
      tokenKey +
      "&secretKey=" +
      secretKey +
      "&recordID=" +
      recordID;
    return false;
  });
  function show_updateappmessageaboutus_Details() {
    window.location.reload();
  }
   


  localStorage.updateappmessage=false;

}); //end of ready

function loadNativeupdateControl(tokenKey, queryMode, secretKey, ajaXCallURL) {
  try {
    // To logout while making update call to the playstore.
    var queryMode = "add";
    var ajaXCallURL = getParameterByName("ajaXCallURL");
    var tokenKey = getParameterByName("tokenKey");
    var secretKey = getParameterByName("secretKey");
    logoutNativeCall(tokenKey, queryMode, secretKey, ajaXCallURL);

    var appJSON = {};
    appJSON.tokenKey = tokenKey;
    appJSON.secretKey = secretKey;
    appJSON.queryMode = queryMode;
    appJSON.action = queryMode;
    appJSON.ajaXCallURL = ajaXCallURL;
    appJSON.organizationID = $("#organizationID").val();
    appJSON.userID = $("#userID").val();
    appJSON.callbackFunction = "setNativeupdateControl";
    appJSON.nextButtonCallback = "setNativeupdateControl";
    appJSON.appID = $("#appID").val();
    pbcNativeupdate(appJSON, function (pbcRes) {
      if (DEVICE_TYPE == "ios") {
        setupWebViewJavascriptBridge(function (bridge) {
          bridgeObj.callHandler("openPlayStoreForUpdate", appJSON, function (
            response
          ) {});
          bridgeObj.registerHandler("setNativeupdateControl", function (
            responseData,
            responseCallback
          ) {
            setNativeupdateControl(responseData);
          });
        });
      } else {
        window.Android.openPlayStoreForUpdate(JSON.stringify(appJSON));
      }
    }); // end of process before call
  } catch (err) {}
}
function pbcNativeupdate(appJSON, callback) {
  // To logout from application
  $("#ok1312").trigger("click");
  localStorage.updateappmessage = "false";

  callback();
}
function setNativeupdateControl(responseData) {
  try {
    var queryMode = "add";
    var ajaXCallURL = getParameterByName("ajaXCallURL");
    var tokenKey = getParameterByName("tokenKey");
    var secretKey = getParameterByName("secretKey");
    logoutNativeCall(tokenKey, queryMode, secretKey, ajaXCallURL);
    if (responseData) {
      // Add Custome function Call here
    }
  } catch (err) {}
}
