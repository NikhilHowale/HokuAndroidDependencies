var firstErrorField = '';
var EMAIL_REGEX = /^(([^<>()\[\]\\.,;:\s@"]+(\.[^<>()\[\]\\.,;:\s@"]+)*)|(".+"))@((\[[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\.[0-9]{1,3}\])|(([a-zA-Z\-0-9]+\.)+[a-zA-Z]{2,}))$/;
$(document).ready(function () {
    if (!navigator.onLine) {
        var shareData = {
            type: 'toast',
            data: 'It looks like your internet connection is not working. Please try again later.'
        };
        var isAndroid = navigator.userAgent.toLowerCase().indexOf('android');
        if (isAndroid > -1) {
            window.Android.shareAppData(JSON.stringify(shareData));
        } else {
            setupWebViewJavascriptBridge(function (bridge) {
                bridgeObj = bridge;
                bridgeObj.callHandler('shareAppData', JSON.stringify(shareData), function (response) { });
            });
        }
    }

    $('ul.tabs').tabs();
    $('select').material_select();    

    //new code for birthdate
    var todayBirthDate = new Date();
    var selectBirthYears = 50;
    var minBirthYears = new Date();
    minBirthYears.setFullYear(minBirthYears.getFullYear() - selectBirthYears);

    $('.birthdatepicker').pickadate({
        selectMonths: true, // Creates a dropdown to control month
        selectYears: 50, // Creates a dropdown of 15 years to control year
        dateFormat: 'd mmmm, yyyy',
        max: todayBirthDate,
        min: minBirthYears
    });

    $('input').on('blur', function () {
        var id = $(this).attr('id');
        if ($(this).val().trim() != '') {
            $('#' + id + '_error').hide();
        }
    });

    $('select').on('blur', function () {
        var id = $(this).attr('id');
        if ($(this).val().trim() != '') {
            $('#' + id + '_error').hide();
        }
    });
    $('textarea').on('blur', function () {
        var id = $(this).attr('id');
        if ($(this).val().trim() != '') {
            $('#' + id + '_error').hide();
        }
    });

    $('.searchButton').click(function () {
        $('#searchInput').focus();
    });

    $('.bot-menu').click(function () {
        var objThis = $(this);
        var linkPage = objThis.attr('linkpage');
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = getParameterByName('queryMode');
        var appID = $("#hdnAppID").val();
        var appName = $('#appName').val();
        window.location.href = "/" + appName + "/" + linkPage + "/" + tokenKey + "/" + queryMode;
        window.location.href = linkPage + '_' + appID + '.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
    });

    $(document).on('keypress', '.numberonly', function (event) {
        var length = $(this).attr('maxlength');
        length = length ? parseInt(length) : 12;
        checkNumber(event, 12)
    });

    $(document).on('keypress', '.charonly', function (event) {
        var length = $(this).attr('maxlength');
        length = length ? parseInt(length) : 150;
        checkValidName(event)
    });

    $(document).on('keypress', '.phoneonly', function (event) {
        var length = $(this).attr('maxlength');
        length = length ? parseInt(length) : 12;
        checkValidPhone(event)
    });

});
function getParameterByName(name, url) {
    if (!url) url = window.location.href;
    name = name.replace(/[\[\]]/g, "\\$&");
    var regex = new RegExp("[?&]" + name + "(=([^&#]*)|&|#|$)"),
        results = regex.exec(url);
    if (!results) return null;
    if (!results[2]) return '';
    return decodeURIComponent(results[2].replace(/\+/g, " "));
}

function randomString() {
    try {
        var randomValue = 'xxxxxxxxxxxxxxxxxxxxxxxx'.replace(/[xy]/g, function (c) {
            var ranString = Math.random() * 16 | 0,
                v = c == 'x' ? ranString : (ranString & 0x3 | 0x8);
            return v.toString(16);
        });
        return randomValue;
    } catch (err) {
        return '';
    }
}

function setDynamicHeight() {
    try {
        var windowHieght = $(window).height();
        var windowWidth = $(window).width();
        var headerHeight = $("#Header-Content").attr('height');
        var footerHeight = 0;
        if ($(".bot-nav").is(":visible")) {
            footerHeight = $(".bot-nav").height();
        }

        headerHeight = headerHeight ? parseInt(headerHeight) : 60;
        footerHeight = 0;



        if (window.location.href.indexOf("login") > -1 || window.location.href.indexOf("signup") > -1) {
            $("#Header-Content").height(0);
            parentContinerHeight = windowHieght - (footerHeight);
            $('#full-body-container').height(parentContinerHeight);
        } else {
            parentContinerHeight = windowHieght - (headerHeight + footerHeight);
            $('#full-body-container').height(parentContinerHeight);
        }


        if (window.location.href.indexOf("login_") > -1) {
            $("#Header-Content").height(0)
        }
    } catch (err) {
        console.log('Error in setDynamicHeight', err);
    }
}

function resetAllInputs(elementID) {
    try {
        $("#" + elementID).find(':input').each(function () {
            switch (this.type) {
                case 'password':
                case 'text':
                case 'textarea':
                case 'file':
                case 'select-one':
                case 'select-multiple':
                case 'date':
                case 'number':
                case 'tel':
                case 'email':
                    jQuery(this).val('');
                    break;
                case 'checkbox':
                case 'radio':
                    this.checked = false;
                    break;
            }
        });
        $('.error_message').hide();
        Materialize.updateTextFields();
    } catch (err) {
        console.log('Error in resetAllInputs', err);
    }
}

function globalSearch(currentTraget, objList, attr) {
    try {
        var filter = currentTraget.val();
        if (filter === '+')
            filter = '';
        var cnt = 0;
        var total = 0;
        objList.each(function () {
            if ($(this).attr('' + attr) != undefined && $(this).attr('' + attr).search(new RegExp(filter, "i")) < 0) {
                $(this).hide();
            } else {
                $(this).show();
            }
        });
    } catch (err) {
        console.log(err, 'globalSearch');
    }
}

function findObjectByKey(key, value) {
    var allUsersMedia = localStorage.getItem('allUsersMedia');
    var array = allUsersMedia ? JSON.parse(allUsersMedia) : [];
    for (var i = 0; i < array.length; i++) {
        if (array[i][key] === value) {
            return array[i];
        }
    }
    return null;
}

function addslashes(str) {
    return (str + '').replace(/[\\"']/g, '\\$&').replace(/\u0000/g, '\\0');
}

function removeSpecialChars(str) {
    try {
        if (str) {
            return str.replace(/[^A-Z0-9]/ig, " ");
        } else {
            return '';
        }
    } catch (error) {
        return '';
    }
}

function shareAppData(message, type) {
    var shareData = {
        type: type,
        data: message
    };
    var isAndroid = navigator.userAgent.toLowerCase().indexOf('android');
    if (isAndroid > -1) {
        window.Android.shareAppData(JSON.stringify(shareData));
    } else {
        setupWebViewJavascriptBridge(function (bridge) {
            bridgeObj = bridge;
            bridgeObj.callHandler('shareAppData', JSON.stringify(shareData), function (response) { });
        });
    }
}

function downloadFile(url, type, fileName) {
    var shareData = {
        type: type,
        data: url
    };

    if (fileName) {
        shareData.fileName = fileName;
    }

    var isAndroid = navigator.userAgent.toLowerCase().indexOf('android');
    if (isAndroid > -1) {
        window.Android.shareAppData(JSON.stringify(shareData));
    } else {
        setupWebViewJavascriptBridge(function (bridge) {
            bridgeObj = bridge;
            bridgeObj.callHandler('shareAppData', JSON.stringify(shareData), function (response) { });
        });
    }
}

function getDateFormat(date, isShortDate, isTime) {
    try {
        date = new Date(date);
        // isShortDate = true;
        var days = ['Sunday', 'Monday', 'Tuesday', 'Wednesday', 'Thursday', 'Friday', 'Saturday'];
        var months = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'June', 'July', 'Aug', 'Sept', 'Oct', 'Nov', 'Dec'];
        var today = new Date();
        today.setHours(0, 0, 0, 0);
        var yesterday = new Date();
        yesterday.setHours(0, 0, 0, 0);
        yesterday.setDate(yesterday.getDate() - 1);
        var weekDay = new Date();
        weekDay.setHours(0, 0, 0, 0);
        var weekstart = weekDay.getDate() - weekDay.getDay() + 1;
        var week = new Date(weekDay.setDate(weekstart));
        var timeFormat = formatAMPM(date);
        // var timeFormat = date.format('shortTime');
        if (isTime) {
            return timeFormat;
        }
        if (date.getTime() >= today.getTime()) {
            return date.format('shortTime').toUpperCase();
        } else if (date.getTime() >= yesterday.getTime()) {
            return isShortDate ? "Yesterday" : timeFormat.toUpperCase();
        } else if (date.getTime() >= week.getTime()) {
            return isShortDate ? days[date.getDay()] : days[date.getDay()] + " " + timeFormat.toUpperCase();
        } else if (date.getFullYear() < today.getFullYear()) {
            var day = date.getDate();
            var finalDate = isShortDate ? months[date.getMonth()] + ' ' + day + ', ' + date.getFullYear() : months[date.getMonth()] + ' ' + day + ', ' + date.getFullYear() + " " + timeFormat.toUpperCase();
            return finalDate;
        } else {
            var day = date.getDate();
            var finalDate = isShortDate ? months[date.getMonth()] + ' ' + day : months[date.getMonth()] + ' ' + day + " " + timeFormat.toUpperCase();
            return finalDate;
        }
    } catch (err) {
        console.log(err, 'getDateFormat');
    }
}

function formatAMPM(date) {
    try {
        var hours = date.getHours();
        var minutes = date.getMinutes();
        var ampm = hours >= 12 ? 'pm' : 'am';
        hours = hours % 12;
        hours = hours ? hours : 12; // the hour '0' should be '12'
        minutes = minutes < 10 ? '0' + minutes : minutes;
        var strTime = hours + ':' + minutes + ' ' + ampm;
        return strTime;
    } catch (err) {
        console.log(err, 'formatAMPM');
    }
}


var dateFormat = function () {
    // try{
    var e = /d{1,4}|m{1,4}|yy(?:yy)?|([HhMsTt])\1?|[LloSZ]|"[^"]*"|'[^']*'/g,
        t = /\b(?:[PMCEA][SDP]T|(?:Pacific|Mountain|Central|Eastern|Atlantic) (?:Standard|Daylight|Prevailing) Time|(?:GMT|UTC)(?:[-+]\d{4})?)\b/g,
        a = /[^-+\dA-Z]/g,
        n = function (e, t) {
            for (e = String(e), t = t || 2; e.length < t;)
                e = "0" + e;
            return e
        };
    return function (m, d, r) {
        // try{
        var s = dateFormat;
        if (1 != arguments.length || "[object String]" != Object.prototype.toString.call(m) || /\d/.test(m) || (d = m, m = void 0), m = m ? new Date(m) : new Date, isNaN(m))
            throw SyntaxError("invalid date");
        d = String(s.masks[d] || d || s.masks["default"]), "UTC:" == d.slice(0, 4) && (d = d.slice(4), r = !0);
        var y = r ? "getUTC" : "get",
            i = m[y + "Date"](),
            o = m[y + "Day"](),
            u = m[y + "Month"](),
            M = m[y + "FullYear"](),
            l = m[y + "Hours"](),
            T = m[y + "Minutes"](),
            h = m[y + "Seconds"](),
            c = m[y + "Milliseconds"](),
            g = r ? 0 : m.getTimezoneOffset(),
            D = {
                d: i,
                dd: n(i),
                ddd: s.i18n.dayNames[o],
                dddd: s.i18n.dayNames[o + 7],
                m: u + 1,
                mm: n(u + 1),
                mmm: s.i18n.monthNames[u],
                mmmm: s.i18n.monthNames[u + 12],
                yy: String(M).slice(2),
                yyyy: M,
                h: l % 12 || 12,
                hh: n(l % 12 || 12),
                H: l,
                HH: n(l),
                M: T,
                MM: n(T),
                s: h,
                ss: n(h),
                l: n(c, 3),
                L: n(c > 99 ? Math.round(c / 10) : c),
                t: 12 > l ? "a" : "p",
                tt: 12 > l ? "am" : "pm",
                T: 12 > l ? "A" : "P",
                TT: 12 > l ? "AM" : "PM",
                Z: r ? "UTC" : (String(m).match(t) || [""]).pop().replace(a, ""),
                o: (g > 0 ? "-" : "+") + n(100 * Math.floor(Math.abs(g) / 60) + Math.abs(g) % 60, 4),
                S: ["th", "st", "nd", "rd"][i % 10 > 3 ? 0 : (i % 100 - i % 10 != 10) * i % 10]
            };
        return d.replace(e, function (e) {
            return e in D ? D[e] : e.slice(1, e.length - 1)
        })
    }
}();
dateFormat.masks = {
    "default": "ddd mmm dd yyyy HH:MM:ss",
    shortDate: "m/d/yy",
    mediumDate: "mmm d, yyyy",
    longDate: "mmmm d, yyyy",
    fullDate: "dddd, mmmm d, yyyy",
    materialdesigndate: "d mmmm, yyyy",
    shortTime: "hh:MM TT",
    mediumTime: "h:MM:ss TT",
    longTime: "h:MM:ss TT Z",
    isoDate: "yyyy-mm-dd",
    isoTime: "HH:MM:ss",
    isoDateTime: "yyyy-mm-dd'T'HH:MM:ss",
    isoUtcDateTime: "UTC:yyyy-mm-dd'T'HH:MM:ss'Z'",
    dayDateTime: "ddd, dd mmm 'at' h:MM TT",
    dayForwardDateTime: "dd mmm hh:MM TT",
    monthDateTime: "mmm dd 'at' hh:MMTT",
    monthDateTimeExport: "mmmm dd,yyyy 'at' hh:MMTT",
    dayDateOnly: "ddd, dd mmm",
}, dateFormat.i18n = {
    dayNames: ["Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat", "Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"],
    monthNames: ["Jan", "Feb", "Mar", "Apr", "May", "Jun", "Jul", "Aug", "Sep", "Oct", "Nov", "Dec", "January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"]

},
    Date.prototype.getNanoseconds = function () {
        return this.getTime() * 10e6 + (Math.random() * 10e5)
    },
    Date.prototype.format = function (e, t) {
        var a = this,
            n = new Date,
            m = new Date(n - a),
            d = m / 1e3 / 60 / 60 / 24;
        return parseInt(d) >= 1 && (e = "isoDate"), dateFormat(this, e, t)
    };

Date.prototype.customFormat = function (formatString) {
    var YYYY, YY, MMMM, MMM, MM, M, DDDD, DDD, DD, D, hhhh, hhh, hh, h, mm, m, ss, s, ampm, AMPM, dMod, th;
    YY = ((YYYY = this.getFullYear()) + "").slice(-2);
    MM = (M = this.getMonth() + 1) < 10 ? ('0' + M) : M;
    MMM = (MMMM = ["January", "February", "March", "April", "May", "June", "July", "August", "September", "October", "November", "December"][M - 1]).substring(0, 3);
    DD = (D = this.getDate()) < 10 ? ('0' + D) : D;
    DDD = (DDDD = ["Sunday", "Monday", "Tuesday", "Wednesday", "Thursday", "Friday", "Saturday"][this.getDay()]).substring(0, 3);
    th = (D >= 10 && D <= 20) ? 'th' : ((dMod = D % 10) == 1) ? 'st' : (dMod == 2) ? 'nd' : (dMod == 3) ? 'rd' : 'th';
    formatString = formatString.replace("#YYYY#", YYYY).replace("#YY#", YY).replace("#MMMM#", MMMM).replace("#MMM#", MMM).replace("#MM#", MM).replace("#M#", M).replace("#DDDD#", DDDD).replace("#DDD#", DDD).replace("#DD#", DD).replace("#D#", D).replace("#th#", th);
    h = (hhh = this.getHours());
    if (h == 0) h = 24;
    if (h > 12) h -= 12;
    hh = h < 10 ? ('0' + h) : h;
    hhhh = h < 10 ? ('0' + hhh) : hhh;
    AMPM = (ampm = hhh < 12 ? 'am' : 'pm').toUpperCase();
    mm = (m = this.getMinutes()) < 10 ? ('0' + m) : m;
    ss = (s = this.getSeconds()) < 10 ? ('0' + s) : s;
    return formatString.replace("#hhhh#", hhhh).replace("#hhh#", hhh).replace("#hh#", hh).replace("#h#", h).replace("#mm#", mm).replace("#m#", m).replace("#ss#", ss).replace("#s#", s).replace("#ampm#", ampm).replace("#AMPM#", AMPM);
};

function checkNumber(event, length) {
    try {
        var theEvent = event || window.event;
        var obj = $(event.currentTarget);
        var key = theEvent.keyCode || theEvent.which;
        var keychar = String.fromCharCode(key);
        var keycheck = /^[0-9]+$/;
        // backspace || delete || escape || arrows
        if (!(key == 8 || key == 9 || key == 27 || key == 46 || key == 37 || key == 39)) {
            if (!keycheck.test(keychar)) {
                theEvent.returnValue = false; //for IE
                if (theEvent.preventDefault)
                    theEvent.preventDefault(); //Firefox
            } else {
                if (obj.val().length === length || obj.val().length >= length) {
                    theEvent.returnValue = false; //for IE
                    if (theEvent.preventDefault)
                        theEvent.preventDefault(); //Firefox
                } else {
                    return true;
                }
            }
        }
    } catch (err) {
        console.log(err, 'checkNumber');
    }
}

function checkValidPhone(event, length) {
    try {
        var theEvent = event || window.event;
        var obj = $(event.currentTarget);
        var key = theEvent.keyCode || theEvent.which;
        var keychar = String.fromCharCode(key);
        var keycheck = /^[0-9+-]+$/;
        // backspace || delete || escape || arrows
        if (!(key == 8 || key == 9 || key == 27 || key == 46 || key == 37 || key == 39)) {
            if (!keycheck.test(keychar)) {
                theEvent.returnValue = false; //for IE
                if (theEvent.preventDefault)
                    theEvent.preventDefault(); //Firefox
            } else {
                if (obj.val().length === length || obj.val().length >= length) {
                    theEvent.returnValue = false; //for IE
                    if (theEvent.preventDefault)
                        theEvent.preventDefault(); //Firefox
                } else {
                    return true;
                }
            }
        }
    } catch (err) {
        console.log(err, 'checkNumber');
    }
}

function checkValidName(event, length) {
    length = length ? length : 100;
    try {
        var theEvent = event || window.event;
        var obj = $(event.currentTarget);
        var key = theEvent.keyCode || theEvent.which;
        var keychar = String.fromCharCode(key);
        var code = theEvent.keyCode;
        var keycheck = /^[a-zA-Z\s]/g;
        //prevent single quates and module sign
        if (theEvent.which == 39 || theEvent.which == 37) {
            if (theEvent.keyCode == 0 || theEvent.keyCode == 39 || theEvent.keyCode == 37) {
                theEvent.returnValue = false; //for IE
                if (theEvent.preventDefault)
                    theEvent.preventDefault(); //Firefox
                return;
            }
        }
        // backspace || delete || escape || arrows
        if (!(key == 8 || key == 9 || key == 27 || key == 46 || key == 37 || key == 39)) {

            //If language is english then apply character validations, ignore for other languages
            if (!keycheck.test(keychar)) {
                theEvent.returnValue = false; //for IE
                if (theEvent.preventDefault)
                    theEvent.preventDefault(); //Firefox
            } else {
                if (obj.val().length >= length) {
                    theEvent.returnValue = false; //for IE
                    if (theEvent.preventDefault)
                        theEvent.preventDefault(); //Firefox
                } else {
                    return true;
                }
            }
        }
    } catch (err) {
        console.log(err, 'checkValidName');
    }
}


function updateProfileInfo(objUser) {
    if (objUser && objUser['userphotoupload']) {
        var objGetUserDetailsWithmenu = localStorage.getItem('objGetUserDetailsWithmenu');
        var profilethumb = objUser['userphotoupload'][0];
        var mediaID = profilethumb.mediaID;
        var name = '';
        if (objGetUserDetailsWithmenu) {
            objGetUserDetailsWithmenu = JSON.parse(objGetUserDetailsWithmenu);
            if (objUser.firstName) {
                name = objUser.firstName;
            } else if (objUser.firstname) {
                name = objUser.firstname;
            } else if (objUser.name) {
                name = objUser.name;
            }
            objGetUserDetailsWithmenu.userNameDetails = name;
            objGetUserDetailsWithmenu.thumbImage = CDN_PATH + mediaID + '_compressed.png';
            //$('#thumbImage').attr('src', CDN_PATH + mediaID);
            var url = CDN_PATH + mediaID + '_compressed.png';
            $('#thumbImage').css("background-image", 'url(' + url + ')');
            $('#userNameDetails').html(name);
            localStorage.setItem('objGetUserDetailsWithmenu', JSON.stringify(objGetUserDetailsWithmenu));
            if (mediaID) {
                localStorage.setItem('profileThumb', mediaID);
                localStorage.removeItem('allUsersMedia');
            }
        }
    }
}

function callWakeupApp() {
    try {

    } catch (error) {
        console.log('Error in callWakeupApp', error);
    }
}

// get distance in km or miles from lat long of 2 points
function getDistanceByLatLong(lat1, lon1, lat2, lon2, unit) {
    try {
        if ((lat1 == lat2) && (lon1 == lon2)) {
            return 0;
        }
        else {
            var radlat1 = Math.PI * lat1 / 180;
            var radlat2 = Math.PI * lat2 / 180;
            var theta = lon1 - lon2;
            var radtheta = Math.PI * theta / 180;
            var dist = Math.sin(radlat1) * Math.sin(radlat2) + Math.cos(radlat1) * Math.cos(radlat2) * Math.cos(radtheta);
            if (dist > 1) {
                dist = 1;
            }
            dist = Math.acos(dist);
            dist = dist * 180 / Math.PI;
            dist = dist * 60 * 1.1515;
            if (unit == "K") { dist = dist * 1.609344 }
            if (unit == "N") { dist = dist * 0.8684 }
            return dist;
        }
    } catch (err) {
        return 0;
    }
}

function form2Json(str)
{
    "use strict";
    var obj,i,pt,keys,j,ev;
    if (typeof form2Json.br !== 'function')
    {
        form2Json.br = function(repl)
        {
            if (repl.indexOf(']') !== -1)
            {
                return repl.replace(/\](.+?)(,|$)/g,function($1,$2,$3)
                {
                    return form2Json.br($2+'}'+$3);
                });
            }
            return repl;
        };
    }
    str = '{"'+(str.indexOf('%') !== -1 ? decodeURI(str) : str)+'"}';
    obj = str.replace(/\=/g,'":"').replace(/&/g,'","').replace(/\[/g,'":{"').replace(/\+/g,' ').replace(/\%3A/g,':').replace(/\%2C/g,',').replace(/\%40/g,'@').replace(/\%2B/g,'+');
    obj = JSON.parse(obj.replace(/\](.+?)(,|$)/g,function($1,$2,$3){ return form2Json.br($2+'}'+$3);}));
    pt = ('&'+str).replace(/(\[|\]|\=)/g,'"$1"').replace(/\]"+/g,']').replace(/&([^\[\=]+?)(\[|\=)/g,'"&["$1]$2');
    pt = (pt + '"').replace(/^"&/,'').split('&');
    for (i=0;i<pt.length;i++)
    {
        ev = obj;
        keys = pt[i].match(/(?!:(\["))([^"]+?)(?=("\]))/g);
        for (j=0;j<keys.length;j++)
        {
            if (!ev.hasOwnProperty(keys[j]))
            {
                if (keys.length > (j + 1))
                {
                    ev[keys[j]] = {};
                }
                else
                {
                    ev[keys[j]] = pt[i].split('=')[1].replace(/"/g,'');
                    break;
                }
            }
            ev = ev[keys[j]];
        }
    }
    return obj;
}

function strip_html_tags(str)
{
   if ((str===null) || (str===''))
       return false;
  else
   str = str.toString();
  return str.replace(/<[^>]*>/g, '');
}