
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
  $('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
    $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

  var objParamsToken = {};
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  objParamsToken.tokenKey = getParameterByName('tokenKey');
  objParamsToken.secretKey = getParameterByName('secretKey');

  var userRole = $('#userRole').val();
  var userID = $('#userID').val();
  var createrOfRecord = $('#createrOfRecord').val();
  var queryMode = getParameterByName('queryMode');
  var recordID = $.trim($('#recordID').val());
  var addSessionComments = [];
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};

  $(document).on('click', '#skip1', function() { 
    window.location.href = 'login_cognito.html'; 
    return false; 
  }); 

  $(document).on('click', '#next1', function() { 
    window.location.href = 'login_cognito.html'; 
    return false; 
  });

});//end of ready
