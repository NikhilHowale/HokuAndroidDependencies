
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_myeventdetails'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "update"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
      var paramsEdit = {};
      paramsEdit.tokenKey = getParameterByName('tokenKey');
      paramsEdit.secretKey = getParameterByName('secretKey') 
                       getRecordByIDProcessBeforeCall142562(paramsEdit, function (processBeforeRes) {
      $.ajax({
          url: ajaXCallURL+'/milestone003/getRecordByCustomeQuery_app_myeventadditionaldetails_Orderdetails5da73cac545050343288ce7a',
          data: paramsEdit,
          type: 'POST',
          jsonpCallback: 'callback',
          success: function (response) { 
                       getRecordByIDProcessAfterCall142562(response, function (processBeforeRes) {
              if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                  var objParamsList = {};
                  var queryMode = $('#queryMode').val(); 
                  objParamsList.queryMode = queryMode;;
                  var tokenKey = $('#tokenKey').val();;
                  objParamsList.tokenKey = tokenKey;;
  if(!$('#8').html()){
            $('#8').append(response.recordDetails.undefined);
 }
  if(!$('#about26').html()){
            $('#about26').append(response.recordDetails.undefined);
 }
  if(!$('#backbutton1').html()){
            $('#backbutton1').append(response.recordDetails.undefined);
 }
  if(!$('#contactperson14').html()){
            $('#contactperson14').append(response.recordDetails.undefined);
 }
  if(!$('#date20').html()){
            $('#date20').append(response.recordDetails.undefined);
 }
  if(!$('#eventdetails2').html()){
            $('#eventdetails2').append(response.recordDetails.undefined);
 }
  if(!$('#contactnumber18').html()){
            $('#contactnumber18').append('<a id="contactnumberImg" class="tellink" href="tel:'+ response.recordDetails.contactnumber+'">'+ response.recordDetails.contactnumber+'</a>');
 }
  if(!$('#contactperson9').html()){
            $('#contactperson9').append(response.recordDetails.contactperson);
 }
  if(!$('#contactperson15').html()){
            $('#contactperson15').append(response.recordDetails.contactperson);
 }
  if(!$('#description28').html()){
            $('#description28').append(response.recordDetails.description);
 }
  if(!$('#eventcategory7').html()){
            $('#eventcategory7').append(response.recordDetails.eventcategory);
 }
 response.recordDetails['eventdate_preserved'] = response.recordDetails['eventdate'] ;
 response.recordDetails['eventdate'] = response.recordDetails['eventdate']  ? moment(new Date(response.recordDetails['eventdate'])).format('DD MMM YYYY') : '';
  if(!$('#eventdate12').html()){
            $('#eventdate12').append(response.recordDetails.eventdate);
 }
 response.recordDetails['eventdate'] =  response.recordDetails['eventdate_preserved'];
 response.recordDetails['eventdate_preserved'] = response.recordDetails['eventdate'] ;
 response.recordDetails['eventdate'] = response.recordDetails['eventdate']  ? moment(new Date(response.recordDetails['eventdate'])).format('DD MMM YYYY') : '';
  if(!$('#eventdate21').html()){
            $('#eventdate21').append(response.recordDetails.eventdate);
 }
 response.recordDetails['eventdate'] =  response.recordDetails['eventdate_preserved'];
  if(!$('#eventname11').html()){
            $('#eventname11').append(response.recordDetails.eventname);
 }
//  response.recordDetails['startenddate_preserved'] = response.recordDetails['startenddate'] ;
//  response.recordDetails['startenddate'] = response.recordDetails['startenddate']  ? moment(new Date(response.recordDetails['startenddate'])).format('DD MMM YYYY') : '';
  if(!$('#startenddate24').html()){
            $('#startenddate24').append(response.recordDetails.startenddate);
 }
 response.recordDetails['startenddate'] =  response.recordDetails['startenddate_preserved'];
  if(!$('#status10').html()){
            $('#status10').append(response.recordDetails.status);
 }
  if(!$('#phonenumber17').html()){
            $('#phonenumber17').append(response.recordDetails.undefined);
 }
  if(!$('#time23').html()){
            $('#time23').append(response.recordDetails.undefined);
 }

              Materialize.updateTextFields();
                $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);
  
              } 
              }); // end of getRecord By ID
          },
          error: function (xhr, status, error) {
              handleError(xhr, status, error); 
          },
      }); 
              }); // end of getRecord By ID
   
});//end of ready 
                 function getRecordByIDProcessBeforeCall142562(paramsType,callback) { 
                 var response = paramsType;
 
if(getParameterByName('orderdetailsid') && getParameterByName('orderdetailsid') != 'undefined'){paramsType.recordID = getParameterByName('orderdetailsid')} else if(getParameterByName('recordID') && getParameterByName('recordID') != 'undefined'){paramsType.recordID = getParameterByName('recordID')};callback(); 
                 } 
                 function getRecordByIDProcessAfterCall142562(response,callback) {
 callback(); 
                 }