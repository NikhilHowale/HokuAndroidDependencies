
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
         var paramsType = {};
             getRegion(paramsType); 
    $(document).on('click', '#backbutton1', function(e) { 
    		window.history.back();  
    		return false;  
    })
});//end of ready
 function processBeforeCallForgetfromothertable_app_addressadd_region_5da73cac545050343288ce7a_Region(paramsType,callback){
var response = paramsType;
 callback();
 }
 function processAfterCallForgetfromothertable_app_addressadd_region_5da73cac545050343288ce7a_Region(data,response,callback){
      callback();
 }
         function getRegion(paramsType){
         var ajaXCallURL = $.trim($('#ajaXCallURL').val());
         paramsType.tokenKey = getParameterByName('tokenKey');
         paramsType.secretKey = getParameterByName('secretKey');
         if(getParameterByName('recordID') && getParameterByName('recordID') != null && getParameterByName('recordID') != 'null'){
         		paramsType.recordID = getParameterByName('recordID');
         }
  		processBeforeCallForgetfromothertable_app_addressadd_region_5da73cac545050343288ce7a_Region(paramsType,function(processBeforeRes){
         $.ajax({
             url: ajaXCallURL+'/milestone003/getfromothertable_app_addressadd_region_5da73cac545050343288ce7a_Region',
             data: paramsType,
             type: 'POST',
             success: function(response) {
                 if (response.status == 0) {
  				processAfterCallForgetfromothertable_app_addressadd_region_5da73cac545050343288ce7a_Region(response.data,response, function(processBeforeRes){
 						//var selectOptionHtml = '<option value="">Region</option>';
 						var selectOptionHtml = '<option disabled selected value="">Select</option>';
 						$.each( response.data, function( keyList, objList ) {
								selectOptionHtml += '<option  value="'+objList._id+'">'+objList.regionname+'</option>';
 						});
 						$('#region15').html(selectOptionHtml);
 						$('#region15').material_select();
 						var region15 =  getParameterByName('region');
 						if(region15 != "" && region15 != null && region15 != 'null' ){
 						   $('#region15').val(region15);
 						   $('#region15').material_select();
 						}
               	})
                 } else {
                     
                 }
                 
             },
             error: function(xhr, status, error) {
                 
             },
         });
         });
                 }