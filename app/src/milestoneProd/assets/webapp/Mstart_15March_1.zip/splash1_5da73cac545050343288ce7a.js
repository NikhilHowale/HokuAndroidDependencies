
var offlineDataID = randomString();
var arrAllMedia = [];
var count = 0;
var otpCode = 0;
var passwordchanged = 0;
var errorFields = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var loginInfo = null;
var signupInfo = null;
var forgotEmail = null;
var changePassword = null;
var deviceInfo = {};
var forgotEmailOtp = 0;

var dropdownvalues = {};
var isFetch = true;
var isLock = false;
localStorage.setItem('objGetUserDetailsWithmenu', '');
$(document).ready(function () {

  getbannerImage();



  $('#sg4075').removeClass('hide')

  $(".cognitoError").hide();
  $('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
    $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

  var objParamsToken = {};
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  objParamsToken.tokenKey = getParameterByName('tokenKey');
  objParamsToken.secretKey = getParameterByName('secretKey');

  var userRole = $('#userRole').val();
  var userID = $('#userID').val();
  var createrOfRecord = $('#createrOfRecord').val();
  var queryMode = getParameterByName('queryMode');
  var recordID = $.trim($('#recordID').val());
  var addSessionComments = [];
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;

  $(document).on('click', '#next1', function () {
    window.location.href = 'login_cognito.html';
    return false;
  });

});//end of ready


// get mobile device info
function getDeviceInfo() {
  try {
    var appJSON = {};
    appJSON.nextButtonCallback = 'setDeviceInfo';
    var isAndroid = navigator.userAgent.toLowerCase().indexOf('android');
    if (isAndroid > -1) {
      window.Android.getDeviceInfo(JSON.stringify(appJSON));
    } else {
      setupWebViewJavascriptBridge(function (bridge) {
        bridgeObj = bridge;
        bridgeObj.callHandler('getDeviceInfo', JSON.stringify(appJSON), function (response) { });
        bridgeObj.registerHandler('setDeviceInfo', function (responseData, responseCallback) {
          setDeviceInfo(responseData)
        });
      });
    }
  } catch (err) {
    console.log('Error in getDeviceInfo', err);
  }
}


function setDeviceInfo(response) {
  try {
    if (response) {
      deviceInfo = response;
    }
  } catch (err) {
    console.log('Error in setDeviceInfo', err);
  }
}


function getbannerImage() {
  var paramsType = {};
  //   paramsType.tokenKey = getParameterByName('tokenKey');
  //   paramsType.secretKey = getParameterByName('secretKey');
  //getCountProcessBeforeCallbannerimageupload6(paramsType, function (processBeforeRes) {
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  ajaXCallURL = 'https://milestone.hokuapps.com';
  $.ajax({
    url: ajaXCallURL + '/api/showslider_app_Splash_Splashbanner5da73cac545050343288ce7alblbannerbannerimageupload',
    data: paramsType,
    type: 'POST',
    success: function (response) {
      localStorage.setItem('bannerimages', JSON.stringify(response));

      if (response.status == 0) {
        makeSlidesbannerimageupload6(response.data);
      } else {
        makeSlidesbannerimageupload6([]);
      }
    },
    error: function (xhr, status, error) { },
  });
  // });
}

function makeSlidesbannerimageupload6(data) {
  var slide = '';
  var htmlString = '';
  // https://d1hlq0tvec6h4x.cloudfront.net
  var CDN_PATH = 'https://d1hlq0tvec6h4x.cloudfront.net/5e22017115dcb4102be65911/5da73cac545050343288ce7a/';
  let title = '';
  let description = '';
  if (data && data.length == 1) {
    title = data[0].title || '';
    description = data[0].description || '';
    data = data[0].userphotoupload ? data[0].userphotoupload : [];

  }
  if (data && data.length > 0) {
    for (let index = 0; index < data.length; index++) {
      const element = data[index];
      var mediaID;
      if (element && element.userphotoupload && element.userphotoupload[0]) {
        mediaID = element.userphotoupload[0].mediaID;
      } else if (element && element.mediaID) {
        mediaID = element.mediaID;
      }
      if (data[index] && data.length != 1) {
        title = data[index].title || '';
        description = data[index].description || '';
      }
      slide += ' <div class="swiper-slide" href="#one!" >';
      slide += '    <div class="row  col s12" style="padding: 0px" !important;>';
      slide += '       <div id="image6_div" style="text-align: center;">';
      slide += '          <img  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + mediaID + '_compressed.png" class="slashimg">';
      slide += '       </div>';
      slide += '    </div>';
      slide += '    <div class="row  col s12 spashtitle"> ' + title + '';
      slide += '    </div>';
      slide += '    <div class="row  col s12 spashdescription"> ' + description + '';
      slide += '    </div>';
      slide += '        </div>';
    }
    if (slide) {
      $('#bannerimageupload6').html(slide);
    }
    swiper = new Swiper('.swiper-container .swiper1', {
      autoplay: {
        delay: 2500,
        disableOnInteraction: false,
      },
      watchOverflow: true,
      pagination: {
        el: '.swiper-pagination ',
      },
    });
    $('.dynamic-slider-view').removeClass('shimmer');
  }
}



