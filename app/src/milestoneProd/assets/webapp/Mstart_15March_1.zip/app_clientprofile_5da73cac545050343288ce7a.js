
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
  // $("#name11_div").hide();
  // $("#email12_div").hide();
  // $("#sg6921").hide();
  // $(".flag-container").hide();
  // $("#dateofbirth14_div").hide();
  // $("#gender15_div").hide();


  $(document).on('click','.profileImg', function() {
    $(this).parent().addClass('hide');
    $(this).parent().parent().find('.input-field').removeClass('hide');
  })

  $("#nameedit").click(function () {
    $("#nameTohide").hide();
    $("#name11_div").show();
  });

  $("#emailedit").click(function () {
    $("#emailTohide").hide();
    $("#email12_div").show();
  });

  $("#contactedit").click(function () {
    $("#contactTohide").hide();
    $("#sg6921").show();
    $(".flag-container").show();

  });

  $("#dobedit").click(function () {
    $("#dateofbirthTohide").hide();
    $("#dateofbirth14_div").show();
  });

  $("#genderedit").click(function () {
    $("#genderTohide").hide();
    $("#gender15_div").show();
  });

  $('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
    $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

  var objParamsToken = {};
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  objParamsToken.tokenKey = getParameterByName('tokenKey');
  objParamsToken.secretKey = getParameterByName('secretKey');

  var userRole = $('#userRole').val();
  var userID = $('#userID').val();
  var createrOfRecord = $('#createrOfRecord').val();
  var queryMode = getParameterByName('queryMode');
  var recordID = $.trim($('#recordID').val());
  var addSessionComments = [];
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on('click', '#update3', function () {
    var objParams = {};
    $('#display_loading').removeClass('hideme');

    var userphotoupload = $.trim($('#userphotoupload8').val());
    if ($('#userphotoupload8_div').is(':visible') && userphotoupload) {
      objParams.userphotoupload = userphotoupload;
    }
    var name = $.trim($('#name9').val());
    var obj = {}
    if ($('#name9_div').is(':visible')) {
      if (name == '') {
        $('#name9_error').show();
        if (!Object.keys(errorFields).length) errorFields['name9'] = 'divtag';
        validAll = false;
      } else {
        $('#name9_error').hide();
      }
    }
    if ($('#name9_div').is(':visible')) {
      objParams.name = name;
    }
    var userphotoupload = $.trim($('#userphotoupload8').val());
    if ($('#userphotoupload8_div').is(':visible') && userphotoupload) {
      objParams.userphotoupload = userphotoupload;
    }
    var name = $.trim($('#name9').val());
    var obj = {}
    if ($('#name9_div').is(':visible')) {
      if (name == '') {
        $('#name9_error').show();
        if (!Object.keys(errorFields).length) errorFields['name9'] = 'divtag';
        validAll = false;
      } else {
        $('#name9_error').hide();
      }
    }
    if ($('#name9_div').is(':visible')) {
      objParams.name = name;
    }
    var name = $.trim($('#name11').val());
    var obj = {}
    if ($('#name11_div').is(':visible')) {
      if (name == '') {
        $('#name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['name11'] = 'textbox';
        validAll = false;
      } else {
        $('#name11_error').hide();
      }
    }
    if ($('#name11_div').is(':visible')) {
      objParams.name = name;
    }
    var email = $.trim($('#email12').val());
    var obj = {}
    if ($('#email12_div').is(':visible')) {
      if (email == '') {
        $('#email12_error').html('Email is required');
        $('#email12_error').show();
        if (!Object.keys(errorFields).length) errorFields['email12'] = 'textbox';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email12_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email12'] = 'textbox';
        validAll = false;
      } else {
        $('#email12_error').hide();
      }
    }
    if ($('#email12_div').is(':visible')) {
      objParams.email = email;
    }
    var contactnumber = $.trim($('#contactnumber13').val());
    var obj = {}
    if ($('#contactnumber13_div').is(':visible')) {
      if (contactnumber == '') {
        $('#contactnumber13_error').show();
        if (!Object.keys(errorFields).length) errorFields['contactnumber13'] = 'textbox';
        validAll = false;
      } else {
        $('#contactnumber13_error').hide();
      }
    }
    if ($('#contactnumber13_div').is(':visible')) {
      var dialCode = $('#contactnumber13').attr('dialCode');
      var countryCode = $('#contactnumber13').attr('countryCode');
      var placeholder = $('#contactnumber13').attr('placeholder');
      contactnumber = contactnumber.replace(/[^0-9]/gi, '');
      placeholder = placeholder.replace(/[^0-9]/gi, '');
      if (placeholder.length != contactnumber.length) {
        $('#contactnumber13_error').html('Valid Mobile Number is required').show();
        $('#contactnumber13').fadeIn(1000);
        errorFields.push('contactnumber13');
      }
      contactnumber = '+' + dialCode + contactnumber;
      objParams.contactnumber_dialcode = dialCode;
      objParams.contactnumber_countrycode = countryCode;
    }
    if ($('#contactnumber13_div').is(':visible')) {
      objParams.contactnumber = contactnumber;
    }
    var dateofbirth = $.trim($('#dateofbirth14').val());
    var obj = {}
    //  if($('#dateofbirth14_div').is(':visible')){
    //   if(dateofbirth == ''){
    //     $('#dateofbirth14_error').show();
    //     if(!Object.keys(errorFields).length) errorFields['dateofbirth14'] = 'textbox';
    //      validAll = false;
    //   } else {
    //     $('#dateofbirth14_error').hide();
    //   }
    //   }
    if ($('#dateofbirth14_div').is(':visible')) {
      objParams.dateofbirth = dateofbirth;
    }
    var gender = $.trim($('#gender15').val());
    var obj = {}
    //  if($('#gender15_div').is(':visible')){
    //   if(gender == ''){
    //     $('#gender15_error').show();
    //     if(!Object.keys(errorFields).length) errorFields['gender15'] = 'dropdown';
    //      validAll = false;
    //   } else {
    //     objParams.gender_name = $("#gender15 option:selected").text();
    //     $('#gender15_error').hide();
    //   }
    //   }
    if ($('#gender15_div').is(':visible')) {
      objParams.gender = gender;
    }
    //   var password = $.trim($('#password16').val());
    //  var  obj  =  {}
    //  if($('#password16_div').is(':visible')){
    //   if(password == ''){
    //     $('#password16_error').show();
    //     if(!Object.keys(errorFields).length) errorFields['password16'] = 'textbox';
    //      validAll = false;
    //   } else {
    //     $('#password16_error').hide();
    //   }
    //   }
    //  if($('#password16_div').is(':visible')){
    //   objParams.password = password;
    //  }
    var name = $.trim($('#name11').val());
    var obj = {}
    if ($('#name11_div').is(':visible')) {
      if (name == '') {
        $('#name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['name11'] = 'textbox';
        validAll = false;
      } else {
        $('#name11_error').hide();
      }
    }
    if ($('#name11_div').is(':visible')) {
      objParams.name = name;
    }
    var userphotoupload = $.trim($('#userphotoupload8').val());
    if ($('#userphotoupload8_div').is(':visible') && userphotoupload) {
      objParams.userphotoupload = userphotoupload;
    }
    var name = $.trim($('#name9').val());
    var obj = {}
    if ($('#name9_div').is(':visible')) {
      if (name == '') {
        $('#name9_error').show();
        if (!Object.keys(errorFields).length) errorFields['name9'] = 'divtag';
        validAll = false;
      } else {
        $('#name9_error').hide();
      }
    }
    if ($('#name9_div').is(':visible')) {
      objParams.name = name;
    }
    var name = $.trim($('#name11').val());
    var obj = {}
    if ($('#name11_div').is(':visible')) {
      if (name == '') {
        $('#name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['name11'] = 'textbox';
        validAll = false;
      } else {
        $('#name11_error').hide();
      }
    }
    if ($('#name11_div').is(':visible')) {
      objParams.name = name;
    }
    var email = $.trim($('#email12').val());
    var obj = {}
    if ($('#email12_div').is(':visible')) {
      if (email == '') {
        $('#email12_error').html('Email is required');
        $('#email12_error').show();
        if (!Object.keys(errorFields).length) errorFields['email12'] = 'textbox';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email12_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email12'] = 'textbox';
        validAll = false;
      } else {
        $('#email12_error').hide();
      }
    }
    if ($('#email12_div').is(':visible')) {
      objParams.email = email;
    }
    var contactnumber = $.trim($('#contactnumber13').val());
    var obj = {}
    if ($('#contactnumber13_div').is(':visible')) {
      if (contactnumber == '') {
        $('#contactnumber13_error').show();
        if (!Object.keys(errorFields).length) errorFields['contactnumber13'] = 'textbox';
        validAll = false;
      } else {
        $('#contactnumber13_error').hide();
      }
    }
    if ($('#contactnumber13_div').is(':visible')) {
      var dialCode = $('#contactnumber13').attr('dialCode');
      var countryCode = $('#contactnumber13').attr('countryCode');
      var placeholder = $('#contactnumber13').attr('placeholder');
      contactnumber = contactnumber.replace(/[^0-9]/gi, '');
      placeholder = placeholder.replace(/[^0-9]/gi, '');
      if (placeholder.length != contactnumber.length) {
        $('#contactnumber13_error').html('Valid Mobile Number is required').show();
        $('#contactnumber13').fadeIn(1000);
        errorFields.push('contactnumber13');
      }
      contactnumber = '+' + dialCode + contactnumber;
      objParams.contactnumber_dialcode = dialCode;
      objParams.contactnumber_countrycode = countryCode;
    }
    if ($('#contactnumber13_div').is(':visible')) {
      objParams.contactnumber = contactnumber;
    }
    var dateofbirth = $.trim($('#dateofbirth14').val());
    var obj = {}
    //  if($('#dateofbirth14_div').is(':visible')){
    //   if(dateofbirth == ''){
    //     $('#dateofbirth14_error').show();
    //     if(!Object.keys(errorFields).length) errorFields['dateofbirth14'] = 'textbox';
    //      validAll = false;
    //   } else {
    //     $('#dateofbirth14_error').hide();
    //   }
    //   }
    if ($('#dateofbirth14_div').is(':visible')) {
      objParams.dateofbirth = dateofbirth;
    }
    var gender = $.trim($('#gender15').val());
    var obj = {}
    //  if($('#gender15_div').is(':visible')){
    //   if(gender == ''){
    //     $('#gender15_error').show();
    //     if(!Object.keys(errorFields).length) errorFields['gender15'] = 'dropdown';
    //      validAll = false;
    //   } else {
    //     objParams.gender_name = $("#gender15 option:selected").text();
    //     $('#gender15_error').hide();
    //   }
    //   }
    if ($('#gender15_div').is(':visible')) {
      objParams.gender = gender;
    }
    //   var password = $.trim($('#password16').val());
    //  var  obj  =  {}
    //  if($('#password16_div').is(':visible')){
    //   if(password == ''){
    //     $('#password16_error').show();
    //     if(!Object.keys(errorFields).length) errorFields['password16'] = 'textbox';
    //      validAll = false;
    //   } else {
    //     $('#password16_error').hide();
    //   }
    //   }
    //  if($('#password16_div').is(':visible')){
    //   objParams.password = password;
    //  }
    var userphotoupload = $.trim($('#userphotoupload8').val());
    if ($('#userphotoupload8_div').is(':visible') && userphotoupload) {
      objParams.userphotoupload = userphotoupload;
    }
    var name = $.trim($('#name9').val());
    var obj = {}
    if ($('#name9_div').is(':visible')) {
      if (name == '') {
        $('#name9_error').show();
        if (!Object.keys(errorFields).length) errorFields['name9'] = 'divtag';
        validAll = false;
      } else {
        $('#name9_error').hide();
      }
    }
    if ($('#name9_div').is(':visible')) {
      objParams.name = name;
    }
    var userphotoupload = $.trim($('#userphotoupload8').val());
    if ($('#userphotoupload8_div').is(':visible') && userphotoupload) {
      objParams.userphotoupload = userphotoupload;
    }
    var name = $.trim($('#name9').val());
    var obj = {}
    if ($('#name9_div').is(':visible')) {
      if (name == '') {
        $('#name9_error').show();
        if (!Object.keys(errorFields).length) errorFields['name9'] = 'divtag';
        validAll = false;
      } else {
        $('#name9_error').hide();
      }
    }
    if ($('#name9_div').is(':visible')) {
      objParams.name = name;
    }
    var name = $.trim($('#name11').val());
    var obj = {}
    if ($('#name11_div').is(':visible')) {
      if (name == '') {
        $('#name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['name11'] = 'textbox';
        validAll = false;
      } else {
        $('#name11_error').hide();
      }
    }
    if ($('#name11_div').is(':visible')) {
      objParams.name = name;
    }
    var email = $.trim($('#email12').val());
    var obj = {}
    if ($('#email12_div').is(':visible')) {
      if (email == '') {
        $('#email12_error').html('Email is required');
        $('#email12_error').show();
        if (!Object.keys(errorFields).length) errorFields['email12'] = 'textbox';
        validAll = false;
      } else if (!isEmail(email)) {
        $('#email12_error').html('Please enter valid email').show();
        if (!Object.keys(errorFields).length) errorFields['email12'] = 'textbox';
        validAll = false;
      } else {
        $('#email12_error').hide();
      }
    }
    if ($('#email12_div').is(':visible')) {
      objParams.email = email;
    }
    var contactnumber = $.trim($('#contactnumber13').val());
    var obj = {}
    if ($('#contactnumber13_div').is(':visible')) {
      if (contactnumber == '') {
        $('#contactnumber13_error').show();
        if (!Object.keys(errorFields).length) errorFields['contactnumber13'] = 'textbox';
        validAll = false;
      } else {
        $('#contactnumber13_error').hide();
      }
    }
    if ($('#contactnumber13_div').is(':visible')) {
      var dialCode = $('#contactnumber13').attr('dialCode');
      var countryCode = $('#contactnumber13').attr('countryCode');
      var placeholder = $('#contactnumber13').attr('placeholder');
      contactnumber = contactnumber.replace(/[^0-9]/gi, '');
      placeholder = placeholder.replace(/[^0-9]/gi, '');
      if (placeholder.length != contactnumber.length) {
        $('#contactnumber13_error').html('Valid Mobile Number is required').show();
        $('#contactnumber13').fadeIn(1000);
        errorFields.push('contactnumber13');
      }
      contactnumber = '+' + dialCode + contactnumber;
      objParams.contactnumber_dialcode = dialCode;
      objParams.contactnumber_countrycode = countryCode;
    }
    if ($('#contactnumber13_div').is(':visible')) {
      objParams.contactnumber = contactnumber;
    }
    var dateofbirth = $.trim($('#dateofbirth14').val());
    var obj = {}
    //  if($('#dateofbirth14_div').is(':visible')){
    //   if(dateofbirth == ''){
    //     $('#dateofbirth14_error').show();
    //     if(!Object.keys(errorFields).length) errorFields['dateofbirth14'] = 'textbox';
    //      validAll = false;
    //   } else {
    //     $('#dateofbirth14_error').hide();
    //   }
    //   }
    if ($('#dateofbirth14_div').is(':visible')) {
      objParams.dateofbirth = dateofbirth;
    }
    var gender = $.trim($('#gender15').val());
    var obj = {}
    //  if($('#gender15_div').is(':visible')){
    //   if(gender == ''){
    //     $('#gender15_error').show();
    //     if(!Object.keys(errorFields).length) errorFields['gender15'] = 'dropdown';
    //      validAll = false;
    //   } else {
    //     objParams.gender_name = $("#gender15 option:selected").text();
    //     $('#gender15_error').hide();
    //   }
    //   }
    if ($('#gender15_div').is(':visible')) {
      objParams.gender = gender;
    }
    //   var password = $.trim($('#password16').val());
    //  var  obj  =  {}
    //  if($('#password16_div').is(':visible')){
    //   if(password == ''){
    //     $('#password16_error').show();
    //     if(!Object.keys(errorFields).length) errorFields['password16'] = 'textbox';
    //      validAll = false;
    //   } else {
    //     $('#password16_error').hide();
    //   }
    //   }
    //  if($('#password16_div').is(':visible')){
    //   objParams.password = password;
    //  }
    var name = $.trim($('#name9').val());
    var obj = {}
    if ($('#name9_div').is(':visible')) {
      if (name == '') {
        $('#name9_error').show();
        if (!Object.keys(errorFields).length) errorFields['name9'] = 'divtag';
        validAll = false;
      } else {
        $('#name9_error').hide();
      }
    }
    if ($('#name9_div').is(':visible')) {
      objParams.name = name;
    }
    var contactnumber = $.trim($('#contactnumber13').val());
    var obj = {}
    if ($('#contactnumber13_div').is(':visible')) {
      if (contactnumber == '') {
        $('#contactnumber13_error').show();
        if (!Object.keys(errorFields).length) errorFields['contactnumber13'] = 'textbox';
        validAll = false;
      } else {
        $('#contactnumber13_error').hide();
      }
    }
    if ($('#contactnumber13_div').is(':visible')) {
      var dialCode = $('#contactnumber13').attr('dialCode');
      var countryCode = $('#contactnumber13').attr('countryCode');
      var placeholder = $('#contactnumber13').attr('placeholder');
      contactnumber = contactnumber.replace(/[^0-9]/gi, '');
      placeholder = placeholder.replace(/[^0-9]/gi, '');
      if (placeholder.length != contactnumber.length) {
        $('#contactnumber13_error').html('Valid Mobile Number is required').show();
        $('#contactnumber13').fadeIn(1000);
        errorFields.push('contactnumber13');
      }
      contactnumber = '+' + dialCode + contactnumber;
      objParams.contactnumber_dialcode = dialCode;
      objParams.contactnumber_countrycode = countryCode;
    }
    if ($('#contactnumber13_div').is(':visible')) {
      objParams.contactnumber = contactnumber;
    }
    //   var password = $.trim($('#password16').val());
    //  var  obj  =  {}
    //  if($('#password16_div').is(':visible')){
    //   if(password == ''){
    //     $('#password16_error').show();
    //     if(!Object.keys(errorFields).length) errorFields['password16'] = 'textbox';
    //      validAll = false;
    //   } else {
    //     $('#password16_error').hide();
    //   }
    //   }
    //  if($('#password16_div').is(':visible')){
    //   objParams.password = password;
    //  }
    var name = $.trim($('#name11').val());
    var obj = {}
    if ($('#name11_div').is(':visible')) {
      if (name == '') {
        $('#name11_error').show();
        if (!Object.keys(errorFields).length) errorFields['name11'] = 'textbox';
        validAll = false;
      } else {
        $('#name11_error').hide();
      }
    }
    if ($('#name11_div').is(':visible')) {
      objParams.name = name;
    }
    var contactnumber = $.trim($('#contactnumber13').val());
    var obj = {}
    if ($('#contactnumber13_div').is(':visible')) {
      if (contactnumber == '') {
        $('#contactnumber13_error').show();
        if (!Object.keys(errorFields).length) errorFields['contactnumber13'] = 'textbox';
        validAll = false;
      } else {
        $('#contactnumber13_error').hide();
      }
    }
    if ($('#contactnumber13_div').is(':visible')) {
      var dialCode = $('#contactnumber13').attr('dialCode');
      var countryCode = $('#contactnumber13').attr('countryCode');
      var placeholder = $('#contactnumber13').attr('placeholder');
      contactnumber = contactnumber.replace(/[^0-9]/gi, '');
      placeholder = placeholder.replace(/[^0-9]/gi, '');
      if (placeholder.length != contactnumber.length) {
        $('#contactnumber13_error').html('Valid Mobile Number is required').show();
        $('#contactnumber13').fadeIn(1000);
        errorFields.push('contactnumber13');
      }
      contactnumber = '+' + dialCode + contactnumber;
      objParams.contactnumber_dialcode = dialCode;
      objParams.contactnumber_countrycode = countryCode;
    }
    if ($('#contactnumber13_div').is(':visible')) {
      objParams.contactnumber = contactnumber;
    }
    //   var password = $.trim($('#password16').val());
    //  var  obj  =  {}
    //  if($('#password16_div').is(':visible')){
    //   if(password == ''){
    //     $('#password16_error').show();
    //     if(!Object.keys(errorFields).length) errorFields['password16'] = 'textbox';
    //      validAll = false;
    //   } else {
    //     $('#password16_error').hide();
    //   }
    //   }
    //  if($('#password16_div').is(':visible')){
    //   objParams.password = password;
    //  }
    var tempobjParams = getParams(window.location.href)
    function extend(obj, src) {
      for (var key in src) {
        if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
      }
      return obj;
    }
    objParams = extend(objParams, tempobjParams);
    var recordID = $('#recordID').val();
    objParams.isDelete = 0;
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParams.tokenKey = getParameterByName('tokenKey');
    objParams.secretKey = getParameterByName('secretKey');
    objParams.offlineDataID = localStorage.getItem("offlineDataID");
    var queryMode = getParameterByName('queryMode')
    if (queryMode == 'updaterecord') {
      objParams.callUrl = ajaXCallURL + '/milestone003/saveAjaxusermanagement7555updateapp_clientprofile';
    } else {
      objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxusermanagement7555updateapp_clientprofile';
      objParams.recordID = recordID;
    }
    if (errorFields && Object.keys(errorFields).length) {
      $('#display_loading').addClass('hideme');
      for (var firstErrorField in errorFields) {
        var controlType = errorFields[firstErrorField];
        errorFields = []
        var errField = $('#' + firstErrorField);
        if (controlType == 'dropdown') {
          errField.prev().prev().focus();
        } else {
          errField.focus()
        }
        validAll = true;
        return false;
      }
    }
    if (!validAll) {
      validAll = true;
      return false;
    }
    $('#update3').prop('disabled', true);
    $('#display_loading').removeClass('hideme');
    if (addSessionComments.length > 0) {
      objParams.addSessionComments = addSessionComments;
    } else {
      objParams.addSessionComments = [];
    }
    var parentID = $('#parentID').val();
    var parentName = $('#parentName').val();
    if (parentID != '') {
      objParams.parentID = parentID;
      objParams.parentName = parentName
    }
    if (typeof (addedFiles) != "undefined" && addedFiles && addedFiles.length > 0) {
      objParams.addedFiles = addedFiles;
    }
    objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    objParams.organizationID = $("#organizationID").val();;
    objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    objParams.organizationID = $("#organizationID").val();;

    objParams.enableNotifications =  $("#togBtn").is(':checked'); //$("#organizationID").val();;

    processBeforeCallForSave7555update(objParams, {}, function (processBeforeRes) {
      objParams.offlineDataID = localStorage.getItem('offlineDataID');
      var tokenKey = getParameterByName('tokenKey');
      var secretKey = getParameterByName('secretKey');
      var queryMode = getParameterByName('queryMode');
      var ajaXCallURL = $.trim($('#ajaXCallURL').val());
      var addedFiles = localStorage.getItem('localImages');
      if (typeof (addedFiles) != "undefined" && addedFiles && addedFiles.length > 0) {
        objParams.addedFiles = addedFiles;
      }
      localStorage.setItem('objParamsData', JSON.stringify(objParams))
      sendOfflineusermanagementupdate3MediaDetails(tokenKey, queryMode, secretKey, ajaXCallURL, objParams, objParams.callUrl);
    });// End of process Before call
  });//end of Event Update_is_click 
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on('click', '#userphotoupload8', function () {
    var mediaMeta = {};
    var obj = $(this);
    mediaMeta.canDelete = obj.attr('canDelete');
    mediaMeta.targetID = obj.attr('targetID') ? obj.attr('targetID') : obj.attr('id');
    mediaMeta.displayType = obj.attr('displayType');
    mediaMeta.fieldMappingID = obj.attr('fieldMappingID');
    mediaMeta.name = obj.attr('name');
    var allowType = obj.attr('allowType');
    var multiple = obj.attr('multiple') ? obj.attr('multiple') : 0;
    var tokenKey = getParameterByName('tokenKey');;
    var secretKey = getParameterByName('secretKey');;
    var queryMode = getParameterByName('queryMode');;
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());;
    loadNativeusermanagement_userphotouploadFileUpload(tokenKey, queryMode, secretKey, ajaXCallURL, mediaMeta, allowType, multiple);;
  });//end of Event usermanagement_userphotoupload_is_click 
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};
  var recordID = localStorage.getItem('userID');
  if (recordID != '') {
    $('#display_loading').removeClass('hideme');
    var paramsEdit = {};
    paramsEdit.recordID = recordID;
    getRecordByIdUsermanagement5da73cac545050343288ce7a(paramsEdit);
  }

  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#backbutton1', function (e) {
    try {
      var element = $(this);
      var appUser = JSON.parse(localStorage.getItem("appUser"));
      var nextPage = 'app_custmoreinfodetails';

      if (appUser.rolename.toLowerCase() === "consultant") {
        nextPage = 'app_consultantcustmoreinfodetails';
      }
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "update";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error)
    }
  })
});//end of ready
function getParams(url) {
  var urlParams = {};
  url.replace(
    new RegExp("([^?=&]+)(=([^&]*))?", "g"),
    function ($0, $1, $2, $3) {
      if ($3 && $3 != 'undefined') urlParams[$1] = $3;
    }
  );
  return urlParams;
}
function processBeforeCallForSave7555update(objParams, response, callback) {

  callback();
}
function processAfterCallForSave7555update(response, callback) {

  callback();
}
//IOS Code Start
function sendOfflineusermanagementupdate3MediaDetails(tokenKey, queryMode, secretKey, ajaXCallURL, objParams, callUrl) {
  try {
    var appJSON = {};
    appJSON.tokenKey = tokenKey;
    appJSON.secretKey = secretKey;
    appJSON.queryMode = queryMode;
    appJSON.ajaXCallURL = ajaXCallURL;
    appJSON.callUrl = callUrl;
    appJSON.pageTitle = '';
    appJSON.nextButtonTitle = '';
    appJSON.nextRedirectionURL = "";
    appJSON.nextButtonCallback = 'saveusermanagementupdate3';
    appJSON.isReadOnly = false;
    appJSON.offlineDataID = offlineDataID;
    if (DEVICE_TYPE == 'ios') {
      bridgeObj.callHandler('sendOfflineMediaDetails', appJSON, function (response) {
      });
      bridgeObj.registerHandler('saveusermanagementupdate3', function (responseData, responseCallback) {
        saveusermanagementupdate3(responseData);
      });
    } else {
      window.Android.sendOfflineMediaDetails(JSON.stringify(appJSON));
    }
  } catch (err) {
    // console.log('Error in sendOffline', err) 
  }
}
function saveusermanagementupdate3(responseData) {
  try {
    var objParams = JSON.parse(localStorage.getItem('objParamsData'));
    if (responseData) {
      if (responseData.appMediaArrayForUploadArray) {
        for (var iFileCount = 0; iFileCount < responseData.appMediaArrayForUploadArray.length; iFileCount++) {
          var objUploadedFile = responseData.appMediaArrayForUploadArray[iFileCount];
          if (objUploadedFile) {
            var fileNameCleaned = objUploadedFile.fileNm.replace(/[^a-z0-9s]/gi, "").replace(/[_s]/g, "-");
            var mediaMeta = {};
            if (fileNameCleaned && typeof (arrAllMedia[fileNameCleaned]) != 'undefined') {
              mediaMeta = arrAllMedia[fileNameCleaned]
            }
            mediaMeta.mediaID = objUploadedFile.mediaID;
            mediaMeta.fileNm = objUploadedFile.fileNm;
            mediaMeta.S3FilePath = objUploadedFile.S3FilePath;
            var name = mediaMeta.name;
            var targetID = '';
            if (mediaMeta && mediaMeta.fieldMappingID && mediaMeta.targetID) {
              targetID = mediaMeta.fieldMappingID ? mediaMeta.fieldMappingID : mediaMeta.targetID.replace(/[0-9]/g, "");
            }
            if (arrEditMedia[targetID] && !objParams[targetID]) {
              objParams[targetID] = [];
              for (var key in arrEditMedia[targetID]) {
                objParams[targetID].push(arrEditMedia[targetID][key]);
              }
            } else if (!objParams[targetID]) {
              objParams[targetID] = [];
            }

            objParams[targetID].push(mediaMeta);
          }
        }
      }
      objParams.recordID = localStorage.getItem('userID');
      if (objParams['userphotoupload'] && !objParams['userphotoupload'].length) {
        delete objParams['userphotoupload'];
      }
      $.ajax({
        url: responseData.dataDictionay.callUrl,
        data: objParams,
        type: 'POST',
        success: function (response) {
          if (response.status == 0) {
            $('#display_loading').addClass('hideme');
            var tokenKey = getParameterByName('tokenKey');
            var secretKey = getParameterByName('secretKey');
            var queryMode = getParameterByName('queryMode');
            if (queryMode && queryMode != null && queryMode != 'null' && queryMode != '') {
              queryMode = queryMode.replace('edit', '');
            }
            localStorage.setItem("headerPageName", 'addcircular');
            if (response.data) {
              localStorage.setItem('appUser', JSON.stringify(response.data));
            }
            if (response.data && response.data['userphotoupload']) {
              var objGetUserDetailsWithmenu = localStorage.getItem('objGetUserDetailsWithmenu');
              var profilethumb = response.data['userphotoupload'][0];
              var mediaID = profilethumb.mediaID;
              localStorage.setItem('profileThumb', mediaID);
              var targateuserid = response.data._id;
              var name = '';
              updateProfileInfo(response.data);

              var xmlhttp;
              if (window.XMLHttpRequest) { // code for IE7+, Firefox, Chrome, Opera, Safari     
                xmlhttp = new XMLHttpRequest();
              } else { // code for IE6, IE5        
                xmlhttp = new ActiveXObject('Microsoft.XMLHTTP');
              }
              xmlhttp.onreadystatechange = function () {
                if (xmlhttp.readyState == 4 && xmlhttp.status == 200) {
                  var shareData = {
                    type: 'toast',
                    data: 'Profile Updated Successfully.'
                  };
                  var isAndroid = navigator.userAgent.toLowerCase().indexOf('android');
                  if (isAndroid > -1) {
                    window.Android.shareAppData(JSON.stringify(shareData));
                  } else {
                    bridgeObj.callHandler('shareAppData', JSON.stringify(shareData), function (response) { });
                  }
                  $('#display_loading').addClass('hideme');

                  var appUser = JSON.parse(localStorage.getItem("appUser"));
                  let nextpage = 'app_custmoreinfodetails';
                  if (appUser.rolename.toLowerCase() === "consultant") {
                    nextpage = 'app_consultantcustmoreinfodetails';
                  }
                  window.location.href = nextpage + '_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                  return false;
                }
              }
              try {
                // xmlhttp.open('POST', 'https://devfiles.' + $('#domainName').val() + '.com/upthumb', true);
                xmlhttp.open('POST', 'https://devfiles.' + $('#domainName').val() + '.com/upload', true);
                xmlhttp.setRequestHeader('HTTP_X_REQUESTED_WITH', 'XMLHttpRequest');
                xmlhttp.setRequestHeader('apptoken', tokenKey);
                xmlhttp.setRequestHeader('mediaid', mediaID);
                xmlhttp.setRequestHeader('targateuserid', targateuserid);
                xmlhttp.setRequestHeader('name', name);
                xmlhttp.send();

                var appUser = JSON.parse(localStorage.getItem("appUser"));
                let nextpage = 'app_custmoreinfodetails';
                if (appUser.rolename.toLowerCase() === "consultant") {
                  nextpage = 'app_consultantcustmoreinfodetails';
                }
                window.location.href = nextpage + '_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                return false;
              } catch (e) {
                console.log(e);
              }
            } else {
              if (recordID == '') {

                var appUser = JSON.parse(localStorage.getItem("appUser"));
                let nextpage = 'app_custmoreinfodetails';
                if (appUser.rolename.toLowerCase() === "consultant") {
                  nextpage = 'app_consultantcustmoreinfodetails';
                }
                window.location.href = nextpage + '_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;

                // window.location.href = 'app_consultantcustmoreinfodetails_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey;  
              } else {

                var appUser = JSON.parse(localStorage.getItem("appUser"));
                let nextpage = 'app_custmoreinfodetails';
                if (appUser.rolename.toLowerCase() === "consultant") {
                  nextpage = 'app_consultantcustmoreinfodetails';
                }
                window.location.href = nextpage + '_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
                // window.location.href = 'app_consultantcustmoreinfodetails_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey;  
              }
            }
            return false;
          } else {
            $('#display_loading').addClass('hideme');
            $('#update3_error').html(response.error);
            $('#update3_error').show();
          }
          $('#391757').removeProp('disabled');
        },
        error: function (xhr, status, error) {
          $('#display_loading').addClass('hideme');
          $('#update3').removeProp('disabled');
        },
      });

    }
  } catch (err) {
    // console.log("Error in native", err)  
  }
}
function loadNativeusermanagement_userphotouploadFileUpload(tokenKey, queryMode, secretKey, ajaXCallURL, mediaMeta, allowType, multiple) {
  var appJSON = {};
  appJSON.tokenKey = tokenKey;
  appJSON.secretKey = secretKey;
  appJSON.queryMode = queryMode;
  appJSON.action = queryMode;
  appJSON.mediaMeta = mediaMeta;
  appJSON.isFileFormat = true;
  appJSON.fileMimeType = allowType;
  appJSON.step = count++;
  appJSON.multiple = multiple;
  appJSON.ajaXCallURL = ajaXCallURL;
  appJSON.organizationID = $("#organizationID").val();
  appJSON.userID = $("#userID").val();
  appJSON.appID = $("#appID").val();
  appJSON.callbackFunction = "setNativeusermanagement_userphotouploadUploadedFiles";
  appJSON.offlineDataID = offlineDataID;
  if (DEVICE_TYPE == "ios") {
    bridgeObj.callHandler("LoadNativeFileUpload", appJSON, function (response) {
    });
    bridgeObj.registerHandler("setNativeusermanagement_userphotouploadUploadedFiles", function (responseData, responseCallback) {
      setNativeusermanagement_userphotouploadUploadedFiles(responseData);
    });
  } else {
    window.Android.LoadNativeFileUpload(JSON.stringify(appJSON));
  }
}

function setNativeusermanagement_userphotouploadUploadedFiles(responseData) {
  try {
    var fileName = responseData.fileName;
    if (responseData.dataDictionary) {
      responseData = responseData.dataDictionary;
      responseData.fileName = fileName;
    }
    var mediaMeta = responseData.mediaMeta;
    mediaMeta.fileName = responseData.fileName;
    mediaMeta.multiple = responseData.multiple;
    var fileNameCleaned = responseData.fileName.replace(/[^a-z0-9s]/gi, "").replace(/[_s]/g, "-");
    arrAllMedia[fileNameCleaned] = mediaMeta;
    var parent = $('#userphotoupload8').parent()
    switch (mediaMeta.displayType) {
      case "src":
        if ($('input[targetid="' + mediaMeta.targetID + '"]').length) {
          $('input[targetid="' + mediaMeta.targetID + '"]').attr('src', getuploadedfilepreview(responseData.fileName));
        } else {
          ;
          $('#' + mediaMeta.targetID).attr('src', getuploadedfilepreview(responseData.fileName));
        };
        break;
      case "text":
        $("#" + mediaMeta.targetID).val(getuploadedfilepreview(responseData.fileName));
        break;
      case 'html':
        var html = '<img class="uploadthumb" src="' + getuploadedfilepreview(responseData.fileName) + '" />';
        parent.append(html);
        break;
      case 'audio':
        var html = '<audio controls><source src="' + responseData.filePath + '" type="audio/mpeg"></audio>';
        parent.append(html);
        break;
      default:
        break;

    }
  } catch (err) {
    // console.log('Error in setNativeUploadedFiles', err); 
  }
}
function getRecordByIDProcessBeforeCallusermanagement(paramsType, callback) {
  callback();
}
function getRecordByIDProcessAfterCallusermanagement(response, callback) {
  callback();
}
function getRecordByIdUsermanagement5da73cac545050343288ce7a(paramsEdit) {
  var ajaXCallURL = $("#ajaXCallURL").val();
  getRecordByIDProcessBeforeCallusermanagement(paramsEdit, function (processBeforeRes) {
    paramsEdit.tokenKey = getParameterByName('tokenKey');
    paramsEdit.secretKey = getParameterByName('secretKey');
    var isMobile = $('#isMobile').val();
    $.ajax({
      url: ajaXCallURL + '/milestone003/get_data_by_record_Usermanagement5da73cac545050343288ce7aapp_clientprofile',
      data: paramsEdit,
      type: 'POST',
      jsonpCallback: 'callback',
      success: function (response) {
        $('#display_loading').addClass('hideme');
        if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
          var objParamsList = {};
          objParamsList.queryMode = queryMode;;
          var tokenKey = getParameterByName('tokenKey');
          objParamsList.tokenKey = tokenKey;;
          objParamsList.isMobile = isMobile;
          var tempobj = response.recordDetails[0]
          response.recordDetails = tempobj;
          getRecordByIDProcessAfterCallusermanagement(response.recordDetails, function (processBeforeRes) {
            if (!$('#backbutton1').html()) {
              $('#backbutton1').append(response.recordDetails.undefined);
            }
            if (response.recordDetails.dateofbirth != undefined) $('#dateofbirth14').val(response.recordDetails.dateofbirth), $('#dobtodisplay').append(response.recordDetails.dateofbirth), $('#profileDateOfBirth').append(response.recordDetails.dateofbirth);
            if (response.recordDetails.email != undefined) $('#email12').val(response.recordDetails.email), $('#email122').append(response.recordDetails.email), $('#profileEmail').append(response.recordDetails.email);
            if (response.recordDetails.gender) {
              $('#gender15').val(response.recordDetails.gender);
              $('#profileGender').html(response.recordDetails.gender);
              $('#gender15').material_select();
              if (dropdownvalues) dropdownvalues['gender'] = response.recordDetails.gender;
              $('#gender15').val(response.recordDetails.gender);
              $('#gender155').append(response.recordDetails.gender);
            }
            if (response.recordDetails.contactnumber != undefined) {
              if (response.recordDetails.contactnumber_dialcode) {
                response.recordDetails.contactnumber = response.recordDetails.contactnumber.toString();
                response.recordDetails.contactnumber = response.recordDetails.contactnumber.replace('+' + response.recordDetails.contactnumber_dialcode, '');
                $('#contactnumber13').intlTelInput('setCountry', response.recordDetails.contactnumber_countrycode);
                var sampleNumber = intlTelInputUtils.getExampleNumber(response.recordDetails.contactnumber_countrycode, false, 1);
                var placeholder = sampleNumber.replace('+' + response.recordDetails.contactnumber_dialcode + ' ', '');
                var mask1 = placeholder.replace(/[0-9]/g, 0);
                $('#contactnumber13').val(response.recordDetails.contactnumber);
                // var demoNumber = response.recordDetails.contactnumber;
                // var demoCode = response.recordDetails.contactnumber_dialcode;
                // var numberWithCode = demoCode + " " + demoNumber;
                // $('#contactedit').append(numberWithCode);
                $('#contactnumber13').mask(mask1);
                $('#contactnumber13').val($('#contactnumber13').masked(response.recordDetails.contactnumber));
                $('#profileContactNumber').html(response.recordDetails.contactnumber);
              } else {
                $('#contactnumber13').val(response.recordDetails.contactnumber);
                $('#profileContactNumber').html(response.recordDetails.contactnumber);
              }
            }

             
            $('#togBtn').prop('checked', response.recordDetails.enableNotifications);

            
            if (response.recordDetails.name != undefined) $('#name11').val(response.recordDetails.name), $('#profileuserName').html(response.recordDetails.name),$('#name111').append(response.recordDetails.name);;
            // if(response.recordDetails.password != undefined) $('#password16').val(response.recordDetails.password);
            if (!$('#profile2').html()) {
              $('#profile2').append(response.recordDetails.undefined);
            }
            if (!$('#update3').html()) {
              $('#update3').append(response.recordDetails.undefined);
            }
            if (!$('#name9').html()) {
              $('#name9').append(response.recordDetails.name);
            }
            if (response.recordDetails.userphotoupload && response.recordDetails.userphotoupload[0] && response.recordDetails.userphotoupload[0].mediaID) {
              var url = CDN_PATH + response.recordDetails.userphotoupload[0].mediaID + '_compressed.png';
            } else {
              var url = 'image_logo.png'
            }
            $('#userphotoupload8').attr("src", url).attr('onerror', "this.src='https://appscdn-us.hokuapps.com/card.png'");
            if (response.recordDetails.offlineDataID) {
              localStorage.setItem("offlineDataID", response.recordDetails.offlineDataID);
            }
          }) // end of process after call 
          $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

          Materialize.updateTextFields();


        }
      },
      error: function (xhr, status, error) {
      },
    });
  }); // end of getRecord By ID
}
