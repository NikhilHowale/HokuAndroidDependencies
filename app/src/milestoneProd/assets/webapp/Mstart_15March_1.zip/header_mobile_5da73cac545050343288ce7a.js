var isOffline = false;
var arrUniqueFindings = [];
var globalVar = {};
var DEVICE_TYPE = "";
var ORG_ID = localStorage.getItem("organizationID");
var globalImgPath = 'https://d1hlq0tvec6h4x.cloudfront.net/5e22017115dcb4102be65911/5da73cac545050343288ce7a/{{mediaID}}_compressed.png'
var CDN_PATH =
  localStorage.getItem("CDN_PATH") +
  "/" +
  ORG_ID +
  "/5da73cac545050343288ce7a/"; // for HokuApps
var CDN_THUMB =
  localStorage.getItem("CDN_THUMB") +
  "/" +
  ORG_ID +
  "/5da73cac545050343288ce7a/";
if (localStorage.getItem("locationPingJson")) {
  var locationPingJson = JSON.parse(localStorage.getItem("locationPingJson"));
} else {
  var locationPingJson = {};
}
var addSessionComments = [];
function processBeforeCallForSaveredeemedvouchers(
  objParams,
  response,
  callback
) {
  objParams.type = "Event";

  objParams.referralAmount = 1;
  objParams.displayAmount = 1;
  objParams.status = "Approved";
  objParams.clientID = localStorage.getItem("userID");
  objParams.recordID = localStorage.getItem("voucherID");
  objParams.status = "Handed Over";
  objParams.handoverdate = new Date();
  callback();
}
function setCurrentLocationOfUser(responseData, response) {
  try {
    var apiParams = {};
    if (responseData) {
      $("#display_loading").addClass("hideme");
      // Add Custome function Call here
      localStorage.setItem("locationPingJson", JSON.stringify(responseData));
      var userDeviceObj = responseData.userDeviceObj;
      if (responseData.data) {
        responseData = responseData.data;
      }
      var tokenKey = response.appTokenDetails.authToken;
      var secretKey = response.appTokenDetails.authSecretKey;
      var queryMode = "mylist";
      var roleName = localStorage.getItem("roleName");
      if (roleName == "consultant") {
        window.location.href =
          "app_consultantuserhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=" +
          tokenKey +
          "&secretKey=" +
          secretKey;
        return false;
      }
      if (roleName == "customer") {
        window.location.href =
          "app_userhome_5da73cac545050343288ce7a.html?queryMode=mylist&tokenKey=" +
          tokenKey +
          "&secretKey=" +
          secretKey;
        return false;
      }
    }
  } catch (err) {}
}
$(document).ready(function () {

  // set header color
  // setHeaderColor();

  var appJSON = {};
  appJSON.nextButtonCallback = "offlineMode";
  var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
  if (isAndroid === -1) {
    setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler("getNetworkStatus", appJSON, function (response) { });
      bridge.registerHandler("offlineMode", function (responseData, responseCallback) {
        offlineMode(responseData);
      });
    });
  } else {
    window.Android.getNetworkStatus(JSON.stringify(appJSON));
  }

  $(".tooltipped").tooltip();
  var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
  if (isAndroid > -1) {
    DEVICE_TYPE = "andriod";
  } else {
    DEVICE_TYPE = "ios";
  }
  setDynamicHeight();
  $(".modal").modal();
  var isProduction = false;
  var ISDEV_MODE = false;
  var ISSTARGATE_MODE = false;
  localStorage.setItem("ISDEV_MODE", ISDEV_MODE);
  //Change your device type here ie. ios or andriod
  if (isProduction) {
    $("#ajaXCallURL").val("https://apps.hokuapps.com");
    $("#s3BasePath").val("https://s3.amazonaws.com/hokuappsapps");
    $("#filePath").val("https://devfiles.hokuapps.com");
    $("#domainName").val("hokuapps");
  } else if (ISDEV_MODE) {
     $("#ajaXCallURL").val("https://milestone003.beepup.com");
   // $("#ajaXCallURL").val("http://milestone003qa1.mybeep.com:8081");
    $("#s3BasePath").val("https://s3.amazonaws.com/hokuappsapps");
    $("#filePath").val("https://devfiles.hokuapps.com");
    $("#domainName").val("mybeep");
  } else if (ISSTARGATE_MODE) {
    $("#ajaXCallURL").val("##appurl##");
    $("#s3BasePath").val("https://s3.amazonaws.com/hokuappsapps");
    $("#filePath").val("https://devfiles.##env##.com");
    $("#domainName").val("##env##");
  } else {
    $("#ajaXCallURL").val(
      "https://gateway.hokuapps.com/5da73cac545050343288ce7a"
    );
    $("#s3BasePath").val("https://s3.amazonaws.com/hokuappsapps");
    $("#filePath").val("https://devfiles.hokuapps.com");
    $("#domainName").val("hokuapps");
  }

  // $('#ajaXCallURL').val('http://milestone003qa1.mybeep.com:8080');
  //   $("#ajaXCallURL").val("https://milestone.hokuapps.com");
  $("#ajaXCallURL").val(
    "https://gateway.hokuapps.com/5da73cac545050343288ce7a"
  );
 // $('#ajaXCallURL').val('http://milestone.mybeep.com:8080');
  var ajaxUrl = $("#ajaXCallURL").val();
  if (ajaxUrl.indexOf("gateway") != -1) {
    var IS_IAMUSER = localStorage.getItem("IS_IAMUSER");
    if (IS_IAMUSER) {
      $("#ajaXCallURL").val(
        "https://gateway.hokuapps.com/5da73cac545050343288ce7aIAM"
      );
    } else {
      $("#ajaXCallURL").val(
        "https://gateway.hokuapps.com/5da73cac545050343288ce7a"
      );
    }
    var IDENTITY_TOKEN = localStorage.getItem("IDENTITY_TOKEN");
    var tokenData = JSON.parse(localStorage.getItem("tokenData"));
    if (!tokenData) tokenData = {};

    $.ajaxSetup({
      headers: {
        Authorization: IDENTITY_TOKEN,
        tokenKey: tokenData.authToken,
        authSecretKey: tokenData.authSecretKey,
      },
      beforeSend: function (request) {
        var IS_IAMUSER = localStorage.getItem("IS_IAMUSER");
		
        if (
          IS_IAMUSER &&
          this.url.indexOf("undefined") === -1 &&
          this.url.includes(".com")
        ) {
          var ajaXCallURL = $.trim($("#ajaXCallURL").val());
          var callURL = this.url;
          var objParams = {};
          if (this.data != undefined) {
            objParams = form2Json(this.data);
          }
          objParams.appID = "5da73cac545050343288ce7a";
          objParams.tokenKey = getParameterByName("tokenKey");
          objParams.secretKey = getParameterByName("secretKey");
          objParams.apiName = this.url.split(".com")[1];
          var GATEWAY_URL = "https://gateway.hokuapps.com";
          var apigClient = apigClientFactory.newClient(
            GATEWAY_URL + objParams.apiName
          );
          var params = {
            "Content-Type": "application/json",
          };
          var additionalParams = {};
          allRequests.push(this);
          apigClient
            .rootPost(params, objParams, additionalParams)
            .then(function (response) {
              if (response.status == 200) {
                $.each(allRequests, function (keyList, objList) {
                  if (objList.apiName == response.config.url) {
                    objList.success(response.data);
                  }
                });
                return false;
              }
            });
          return false;
        } else {
                    var tokenKey = getParameterByName('tokenKey');
                    var secretKey = getParameterByName('secretKey');
                    if (tokenKey && secretKey && CognitoConfig && CognitoConfig.USER_POOL_ID != '') {
                        $('#display_loading').removeClass('hideme');
                        refreshAWSToken(function (response) {
                            if (response) {
                                $('#display_loading').addClass('hideme');
                                var IDENTITY_TOKEN = localStorage.getItem('IDENTITY_TOKEN');
                                request.setRequestHeader('Authorization', IDENTITY_TOKEN);
                                var appJSON = {};
                                appJSON.idToken = IDENTITY_TOKEN;
                                var playload = JSON.parse(atob(IDENTITY_TOKEN.split('.')[1]));
                                if (playload.exp) {
                                    appJSON.ExpiryTime = playload.exp;
                                }
                                if (DEVICE_TYPE == 'ios') {
                                    setupWebViewJavascriptBridge(function (bridge) {
                                        bridgeObj.callHandler('updateToken', appJSON, function (response) { });
                                    });
                                } else {
                                    window.Android.updateToken(JSON.stringify(appJSON));
                                }
                            } 
                            return true;
                        });
                    }
			}
      },
    });
  }

  var tokenKey = getParameterByName("tokenKey");
  var secretKey = getParameterByName("secretKey");
  if (tokenKey && secretKey) {
    // refreshAWSToken(function (response) {
    //   if (response) {
    //     //do nothing
    //   } else {
    //     setTimeout(function () {
    //       //window.location.href = 'index.html';
    //       return false;
    //     }, 2000);
    //   }
    // });

    getClientList();
    getUserDetails();
  }

  if ($("#loadHeader").val() == undefined) {
  }
  $(document).on("click", "#continue56", function () {
    localStorage.setItem("IS_IAMUSER", "");
    writeLog("weblog : logout continue click header_mobile.js");
    window.location.href = "login_cognito.html";
    return false;
  });
  $(document).on("click", ".cross-icon", function () {
    $(".button-collapse").sideNav("hide");
  });
  $(document).on("click", ".nav-profile", function () {
    var tokenKey = getParameterByName("tokenKey");
    var secretKey = getParameterByName("secretKey");
    var queryMode = getParameterByName("queryMode");
    window.location.href =
      "userprofile_5da73cac545050343288ce7a.html?queryMode=" +
      queryMode +
      "&tokenKey=" +
      tokenKey +
      "&secretKey=" +
      secretKey;
    return false;
  });
  $(document).on("click", ".showMoreDetails", function () {
    if (
      $(
        "#" + $(this).attr("displayShowMoreMainID") + "ParcialCompleteText"
      ).attr("isShowMore") == 0
    ) {
      $(
        "#" + $(this).attr("displayShowMoreMainID") + "showMoreDetailsText"
      ).html("");
      $(
        "#" + $(this).attr("displayShowMoreMainID") + "showMoreDetailsText"
      ).after(
        "<div style='display:inline;'>" +
          $(
            "#" + $(this).attr("displayShowMoreMainID") + "CompleteText"
          ).html() +
          "</div>"
      );
      $("#" + $(this).attr("displayShowMoreMainID") + "showMoreDetailsText")
        .next("div")
        .slideDown();
      $(
        "#" + $(this).attr("displayShowMoreMainID") + "ParcialCompleteText"
      ).attr("isShowMore", 1);
    }
    return false;
  });
  var objGetUserDetailsWithmenu = localStorage.getItem(
    "objGetUserDetailsWithmenu"
  );
  if (
    objGetUserDetailsWithmenu &&
    objGetUserDetailsWithmenu != "" &&
    objGetUserDetailsWithmenu != "undefined"
  ) {
    objGetUserDetailsWithmenu = JSON.parse(objGetUserDetailsWithmenu);
    if (
      objGetUserDetailsWithmenu.status &&
      objGetUserDetailsWithmenu.status == 1
    ) {
      objGetUserDetailsWithmenu = "";
      //getMenuList();
    } else {
      renderMenuList(objGetUserDetailsWithmenu);
    }
  } else {
    //getMenuList();
  }
  $(document).on("click", ".redirecttopage", function () {
    localStorage.setItem("headerPageName", $(this).attr("headerPageName"));
    var fileName = $(this).attr("fileName");
    if (
      fileName == undefined ||
      fileName == null ||
      fileName == "" ||
      (fileName.indexOf("undefined") != -1 &&
        $(this).attr("id").toLowerCase() == "more")
    ) {
      return;
    }
    var queryMode = $(this).attr("queryMode");
    var nativeredirect = $(this).attr("nativeredirect");
    var tokenKey = getParameterByName("tokenKey");
    var secretKey = getParameterByName("secretKey");
    $(".side-nav div").removeClass("active");
    $(this).addClass("active");
    localStorage.setItem("activeMenu", $(this).attr("id"));
    var menuID = $(this).attr("id");
    var ajaXCallURL = $.trim($("#ajaXCallURL").val());
    if (typeof menuID != "undefined") {
      menuID = menuID.toLowerCase();
    }
    if (menuID == "chat" || menuID == "groupchat") {
      loadNativeChatControl(
        tokenKey,
        queryMode,
        secretKey,
        ajaXCallURL,
        menuID
      );
    } else if (menuID == "scan") {
      openAllScan();
    } else if (nativeredirect) {
      var appJSON = { redirectToPage: fileName };
      var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
      if (isAndroid > -1) {
        window.Android.redirectPage(JSON.stringify(appJSON));
      } else {
        setupWebViewJavascriptBridge(function (bridgeObj) {
          bridgeObj.callHandler("redirectPage", appJSON, function (
            response
          ) {});
        });
      }
    } else {
      window.location.href =
        fileName +
        "?queryMode=" +
        queryMode +
        "&tokenKey=" +
        tokenKey +
        "&secretKey=" +
        secretKey;
      return false;
    }
  });

  $(document).on("click", "#nativeLogut", function () {
    var queryMode = "add";
    var ajaXCallURL = getParameterByName("ajaXCallURL");
    var tokenKey = getParameterByName("tokenKey");
    var secretKey = getParameterByName("secretKey");
    localStorage.setItem("IS_IAMUSER", "");
    writeLog('weblog : logoutNativeCall logout click event header_mobile.js');
     logoutNativeCall(tokenKey, queryMode, secretKey, ajaXCallURL);
  });

  // Check App Version for update
  updateApp();


    $(document).on('click', '#retiremetfund11', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_financialplanstep1';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "add";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - childuniversityfund9", error)
    }
  })


  $(document).on('click', '#retiremetgoal11', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_retirementgoalstep1';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "add";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - childuniversityfund9", error)
    }
  })

  $(document).on('click', '#childfund11', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_childfundstep1';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "add";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - childuniversityfund9", error)
    }
  });

  $(document).on('click', '#financialfund11', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_financialstep1';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "add";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - childuniversityfund9", error)
    }
  })

}); //end of ready

$(document).on("click", "#nav-mobile-sort", function (e) {
  if ($("#displaysort").val() != undefined) {
    applyLocalSort($(this));
  }
});
function openAllScan() {
  var tokenKey = getParameterByName("tokenKey");
  var secretKey = getParameterByName("secretKey");
  var queryMode = getParameterByName("queryMode");
  var ajaXCallURL = $.trim($("#ajaXCallURL").val());
  loadNativeopenqrscannerControl(tokenKey, queryMode, secretKey, ajaXCallURL);
}
function refreshAWSTokenOnForeground() {
  writeLog("weblog : Inside refreshAWSTokenOnForeground -  header_mobile.js");

  var tokenKey = getParameterByName("tokenKey");
  var secretKey = getParameterByName("secretKey");

  writeLog("weblog : Inside refreshAWSTokenOnForeground - tokenKey " + tokenKey + " -  header_mobile.js");
  writeLog("weblog : Inside refreshAWSTokenOnForeground - secretKey " + secretKey + " -  header_mobile.js");
  writeLog("weblog : Inside refreshAWSTokenOnForeground - CognitoConfig " + CognitoConfig + " -  header_mobile.js");
  writeLog("weblog : Inside refreshAWSTokenOnForeground - CognitoConfig.USER_POOL_ID " + CognitoConfig.USER_POOL_ID + " -  header_mobile.js");

  if (tokenKey && secretKey && CognitoConfig && CognitoConfig.USER_POOL_ID != "") {
    //$("#display_loading").removeClass("hideme");
    var appJSON = {};
    appJSON.nextButtonCallback = "offlineModeWithRefreshToken";
    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
    writeLog("weblog : call getNetworkStatus bridge 1 -  header_mobile.js");
    if (isAndroid === -1) {
      setupWebViewJavascriptBridge(function (bridge) {
        writeLog("weblog : call getNetworkStatus bridge 2 -  header_mobile.js");
        bridge.callHandler("getNetworkStatus", appJSON, function (response) { });
        bridge.registerHandler("offlineModeWithRefreshToken", function (responseData, responseCallback) {
          offlineModeWithRefreshToken(responseData);
        });
      });
    } else {
      window.Android.getNetworkStatus(JSON.stringify(appJSON));
    }
  } else {
    writeLog("weblog : Inside tokenKey || secretKey || CognitoConfig is missing -  header_mobile.js");
  }
}
function getUserDetails() {
  var objParamsToken = {};
  var ajaXCallURL = $.trim($("#ajaXCallURL").val());
  objParamsToken.tokenKey = getParameterByName("tokenKey");
  objParamsToken.secretKey = getParameterByName("secretKey");
  objParamsToken.recordID = localStorage.getItem("userID");
  $.ajax({
    url:
      ajaXCallURL +
      "/milestone003/get_data_by_record_Usermanagement5da73cac545050343288ce7aapp_clientprofile",
    data: objParamsToken,
    type: "POST",
    success: function (response) {
      if (response && response.status == 0 && response.recordDetails) {
        if (
          response.recordDetails.length > 0 &&
          response.recordDetails[0].consultantid
        ) {
          var consultantid = response.recordDetails[0].consultantid;
          var membership = response.recordDetails[0].membership;
          localStorage.setItem("consultantid", consultantid);
          localStorage.setItem("membership", membership);
          var clientList = [];
          //  for (i = 0; i < response.data.length; i++) {
          clientList.push(consultantid);
        }

        // }
        if (
          response.recordDetails[0].appointmentunreadcount != null &&
          response.recordDetails[0].appointmentunreadcount != undefined
        ) {
          $("#appointmentCount").html(
            response.recordDetails[0].appointmentunreadcount
          );
        }
        if (
          response.recordDetails[0].notificationunreadcount != null &&
          response.recordDetails[0].notificationunreadcount != undefined
        ) {
          $("#notificationcount5").html(
            response.recordDetails[0].notificationunreadcount
          );
        }
        if(response.recordDetails[0].earnedpoints &&   $("#totalrewards7")){
          $("#totalrewards7").html(response.recordDetails[0].earnedpoints);
      }

      if(response.recordDetails[0].consultantphotoupload){
        localStorage.setItem('consultantphoto', JSON.stringify(response.recordDetails[0].consultantphotoupload));
      }
      $('#togBtn').prop('checked', response.recordDetails[0].enableNotifications);
    }
  }
});
}

function refreshAWSTokenFromNative() {
  refreshAWSTokenOnForeground();
}

function loadNativeChatControl(
  tokenKey,
  queryMode,
  secretKey,
  ajaXCallURL,
  menuID
) {
  try {
    var appJSON = {};
    appJSON.tokenKey = tokenKey;
    appJSON.secretKey = secretKey;
    appJSON.queryMode = queryMode;
    appJSON.action = queryMode;
    appJSON.ajaXCallURL = ajaXCallURL;
    appJSON.organizationID = $("#organizationID").val();
    appJSON.appID = $("#appID").val();
    var consultantid = "";
    var appUser = JSON.parse(localStorage.getItem("appUser"));
    var users = [];
    var isgroupchat = false;
    if (appUser && appUser !== "") {
      if (appUser && appUser.rolename == "customer") {
        var objParamsToken = {};
        var ajaXCallURL = $.trim($("#ajaXCallURL").val());
        objParamsToken.tokenKey = getParameterByName("tokenKey");
        objParamsToken.secretKey = getParameterByName("secretKey");
        objParamsToken.recordID = localStorage.getItem("userID");

        $.ajax({
          url:
            ajaXCallURL +
            "/milestone003/get_data_by_record_Usermanagement5da73cac545050343288ce7aapp_clientprofile",
          data: objParamsToken,
          type: "POST",
          success: function (response) {
            if (
              response &&
              response.status == 0 &&
              response.recordDetails &&
              response.recordDetails.length > 0 &&
              response.recordDetails[0].consultantid
            ) {
              localStorage.setItem("consultantid", consultantid);
              consultantid = response.recordDetails[0].consultantid;
              appJSON.chatTabType = 10;
              objParamsToken.userID = consultantid;

              appJSON.userID = consultantid;
              appJSON.recordID = consultantid;
              if (DEVICE_TYPE == "ios") {
                setupWebViewJavascriptBridge(function (bridgeObj) {
                  bridgeObj.callHandler(
                    "loadNativeChatIndivisualWindow",
                    appJSON,
                    function (response) {}
                  );
                });
              } else {
                window.Android.loadNativeChatIndivisualWindow(
                  JSON.stringify(appJSON)
                );
              }
            } else {
              $("#display_loading1").addClass("hideme");

              shareAppData(
                "Thank you! Your designated consultant will be contacting you.",
                "toast"
              );
              return false;
            }
          },
          error: function (xhr, status, error) {},
        });
      } else {
        appJSON.chatTabType = 10;
        appJSON.contactSegmentTitle = "Customers";
        
        var userlist = localStorage.getItem("clientList");
        if (userlist && userlist != undefined && userlist != "undefined") {
          isgroupchat = true;

          var users = JSON.parse(userlist);
          appJSON.users = users;
        }

        appJSON.hideGroupTab = true;
        if (DEVICE_TYPE == "ios") {
          setupWebViewJavascriptBridge(function (bridgeObj) {
            bridgeObj.callHandler("openChatWindow", appJSON, function (
              response
            ) {});
          });
        } else {
          window.Android.openChatWindow(JSON.stringify(appJSON));
        }
      }
    }

    //        if (menuID != "groupchat") {
    //            appJSON.userID = consultantid;
    //            appJSON.recordID = consultantid;
    //
    //        }
    //
    //        if (menuID == "groupchat" || isgroupchat == true) {
    //            if (DEVICE_TYPE == 'ios') {
    //                setupWebViewJavascriptBridge(function (bridgeObj) {
    //                                             bridgeObj.callHandler('openChatWindow', appJSON, function (response) { });
    //                                             });
    //            } else {
    //                window.Android.openChatWindow(JSON.stringify(appJSON));
    //            }
    //        } else {
    //            if (DEVICE_TYPE == 'ios') {
    //                setupWebViewJavascriptBridge(function (bridgeObj) {
    //                                             bridgeObj.callHandler('loadNativeChatIndivisualWindow', appJSON, function (response) { });
    //                                             });
    //            } else {
    //                window.Android.loadNativeChatIndivisualWindow(JSON.stringify(appJSON));
    //            }
    //        }
  } catch (err) {}
}
function getClientList() {
  var appUser = JSON.parse(localStorage.getItem("appUser"));
  var users = [];
  var isgroupchat = false;
  if (appUser && appUser !== "") {
    if (appUser && appUser.rolename == "consultant") {
      var clist = localStorage.getItem("clientList");
      if (clist && clist != undefined && clist != "undefined") {
        // var clientList = JSON.parse(localStorage.getItem("clientList"));
        getUnreadCount();
      } else {
        var objParamsToken = {};
        var ajaXCallURL = $.trim($("#ajaXCallURL").val());
        objParamsToken.tokenKey = getParameterByName("tokenKey");
        objParamsToken.secretKey = getParameterByName("secretKey");
        objParamsToken.userID = localStorage.getItem("userID");
        $.ajax({
          url:
            ajaXCallURL +
            "/milestone003/getClientForConsultant5da73cac545050343288ce7a",
          data: objParamsToken,
          type: "POST",
          success: function (response) {
            var clientList = [];
            if(response.data  && response.data.length) {
              for (i = 0; i < response.data.length; i++) {
                clientList.push(response.data[i].clientid);
              }
            }
           

            localStorage.setItem("clientList", JSON.stringify(clientList));

            getUnreadCount();
          },
          error: function (xhr, status, error) {},
        });
      }
    } else {
      //  getUserDetails();
    }
  }
}

function applyLocalSort(thisObj) {
  var sortColumnName = $("#displaysort").val();
  var tokenKey = getParameterByName("tokenKey");
  var secretKey = getParameterByName("secretKey");
  var queryMode = getParameterByName("queryMode");
  if (gListData && gListData.data) {
    var sortType = thisObj.attr("sort");
    if (sortType == "0") {
      $("#btnSort").children().children().attr("src", "a_z_up.svg");
      //do asc by alaphabet
      gListData.data.sort(function (a, b) {
        //Turn your strings into dates, and then subtract them
        //to get a value that is either negative, positive, or zero.
        if (a[sortColumnName] && b[sortColumnName]) {
          var textA = a[sortColumnName].toUpperCase();
          var textB = b[sortColumnName].toUpperCase();
          return textA < textB ? -1 : textA > textB ? 1 : 0;
        }
      });
      thisObj.attr("sort", "1");
    } else if (sortType == "1") {
      $("#btnSort").children().children().attr("src", "a_z_down.svg");
      //do asc by alaphabet
      gListData.data.sort(function (a, b) {
        //Turn your strings into dates, and then subtract them
        //to get a value that is either negative, positive, or zero.
        if (a[sortColumnName] && b[sortColumnName]) {
          var textA = a[sortColumnName].toUpperCase();
          var textB = b[sortColumnName].toUpperCase();
          return textB < textA ? -1 : textB > textA ? 1 : 0;
        }
      });
      thisObj.attr("sort", "2");
    } else if (sortType == "2") {
      $("#btnSort").children().children().attr("src", "a_z.svg");
      //do normal by updateOn
      gListData.data.sort(function (a, b) {
        // Turn your strings into dates, and then subtract them
        // to get a value that is either negative, positive, or zero.
        if (a.updatedOn && b.updatedOn) {
          return new Date(b.updatedOn) - new Date(a.updatedOn);
        }
      });
      thisObj.attr("sort", "0");
    }
    showMobileList(gListData, tokenKey, queryMode);
  }
}
function logoutNativeCall(tokenKey, queryMode, secretKey, ajaXCallURL) {
  var appJSON = {};
  appJSON.tokenKey = tokenKey;
  appJSON.secretKey = secretKey;
  appJSON.queryMode = queryMode;
  appJSON.ajaXCallURL = ajaXCallURL;
  appJSON.organizationID = $("#organizationID").val();
  appJSON.userID = $("#userID").val();
  appJSON.appID = $("#appID").val();
  appJSON.nextButtonCallback = "logoutNativeCallBack";
  appJSON.action = queryMode;
  appJSON.step = 1;
  var objParams = {};
  objParams.organizationID = appJSON.organizationID;
  objParams.userID = appJSON.userID;
  objParams.appID = appJSON.appID;
  objParams.isLogout = true;
  var ajaXCallURL = CognitoConfig.GATEWAY_URL;
  appJSON.Authorization = localStorage.getItem("IDENTITY_TOKEN");

  appJSON.apiName =
    ajaXCallURL + "/api/addUserDeviceForApp_5da73cac545050343288ce7a";
  appJSON.addDeviceObject = objParams;
  try {
    localStorage.clear();
    //removeLocalVariables5da73cac545050343288ce7a();
  } catch (err) {
    // console.log('Error in removeLocalVariables', err);
  }
  localStorage.setItem("tokenKey", "");
  localStorage.setItem("secretKey", "");
  localStorage.setItem("objGetUserDetailsWithmenu", "");
  localStorage.setItem("perms", "");
  localStorage.setItem("user", "");
  localStorage.setItem("organizationID", "");
  localStorage.setItem("userID", "");
  localStorage.setItem("CDN_PATH", "");
  localStorage.setItem("CDN_THUMB", "");
  localStorage.setItem("profileThumb", "");
  localStorage.setItem("activeMenu", "");
  if (DEVICE_TYPE == "ios") {
    setupWebViewJavascriptBridge(function (bridgeObj) {
      bridgeObj.callHandler("logoutNativeCall", appJSON, function (
        response
      ) {});
    });
  } else {
    window.Android.logoutNativeCall(JSON.stringify(appJSON));
  }
   writeLog("weblog : logout header_mobile.js");
  window.location.href = "login_cognito.html";
  return false;
}
function nativeWebBackNav(response) {
  if (response) {
    var currentPageName = response.pageName;
    var navBackCntrl = $('div[id^="backbutton"]');
    if (
      currentPageName != "login_5da73cac545050343288ce7a" &&
      navBackCntrl.length > 0 &&
      navBackCntrl.is(":visible")
    ) {
     writeLog('logoutNativeCall nativeWebBackNav.js');
      navBackCntrl.trigger("click");
    } else {
      var appJSON = {};
      appJSON.isFinishDelay = true;
      appJSON.isShowDialog = false;
      appJSON.finishDelayMsg = "Press again to exit.";
      appJSON.dialogMessage = "Application exit?";
      appJSON = JSON.stringify(appJSON);
      window.Android.handleNativeBack(appJSON);
    }
  }
}
var isfromweb = getParameterByName("isfromweb");
if (isfromweb == 1 || isfromweb == "1") {
  var objParamsToken = {};
  objParamsToken.appID = $("#hdnAppID").val();
  var ajaXCallURL = "https://milestone003.hokuapps.com";
  objParamsToken.tokenKey = getParameterByName("tokenKey");
  objParamsToken.secretKey = getParameterByName("secretKey");
  objParamsToken.userID = getParameterByName("userID");
  objParamsToken.isFBSignup = true;
  $.ajax({
    url:
      ajaXCallURL + "/milestone003/sendOTPToMobileNo5da73cac545050343288ce7a",
    data: objParamsToken,
    type: "POST",
    success: function (response) {
      localStorage.setItem("tokenKey", response.appTokenDetails.authToken);
      localStorage.setItem("secretKey", response.appTokenDetails.authSecretKey);
      localStorage.setItem(
        "objGetUserDetailsWithmenu",
        JSON.stringify(response.objGetUserDetailsWithmenu)
      );
      localStorage.setItem("perms", JSON.stringify(response.perms));
      localStorage.setItem("user", JSON.stringify(response.user));
      localStorage.setItem("appUser", JSON.stringify(response.appUser));
      localStorage.setItem("organizationID", response.user.organizationId);
      localStorage.setItem("userID", response.user.userId);
      localStorage.setItem("CDN_PATH", response.CDN_PATH);
      localStorage.setItem("CDN_THUMB", response.CDN_THUMB);
      if (
        response.appUser &&
        response.appUser.userphotoupload &&
        response.appUser.userphotoupload[0]
      ) {
        localStorage.setItem(
          "profileThumb",
          response.appUser.userphotoupload[0].mediaID
        );
      } else {
        localStorage.removeItem("profileThumb");
      }
      localStorage.setItem("tokenData", JSON.stringify(response.tokenData));
      localStorage.setItem("roleName", response.appTokenDetails.roleName);
      renderMenuList(response.objGetUserDetailsWithmenu);
    },
    error: function (xhr, status, error) {},
  });
}
function getUnreadCount() {
  //    var appJSON = {}
  //
  //    var userlist = localStorage.getItem('clientList');
  //    if(userlist)
  //    {
  //        var users = JSON.parse(userlist);
  //
  //        appJSON.nextButtonCallback = "setUnreadCount";
  //        appJSON.users = users;
  //        if (users) {
  //            if (DEVICE_TYPE == 'ios') {
  //                // setupWebViewJavascriptBridge(function (bridgeObj) {
  //                bridgeObj.registerHandler('setUnreadCount', function (responseData, responseCallback) {
  //                                          setUnreadCount(responseData);
  //                                          });
  //                bridgeObj.callHandler('GetUnreadCountFromNativeForUsers', appJSON, function (response) {
  //                                      //                                                           bridgeObj.registerHandler('setUnreadCount', function (responseData, responseCallback) {
  //                                      //                                                                                     setUnreadCount(responseData);
  //                                      //                                                                                     });
  //                                      });
  //                //  });
  //            } else {
  //                window.Android.GetUnreadCountFromNativeForUsers(JSON.stringify(appJSON));
  //            }
  //        }
  //    }
}

function loadNativeopenqrscannerControl(
  tokenKey,
  queryMode,
  secretKey,
  ajaXCallURL
) {
  try {
    var appJSON = {};
    appJSON.tokenKey = tokenKey;
    appJSON.secretKey = secretKey;
    appJSON.queryMode = queryMode;
    appJSON.action = queryMode;
    appJSON.ajaXCallURL = ajaXCallURL;
    var AWSCredentials = localStorage.getItem("AWSCredentials");
    if (localStorage.IDENTITY_TOKEN) {
      var token = localStorage.IDENTITY_TOKEN;
      var playload = JSON.parse(atob(token.split(".")[1]));
      appJSON.Authorization = token;
      appJSON.Expiration = playload.exp;
    } else if (AWSCredentials) {
      AWSCredentials = JSON.parse(AWSCredentials);
      appJSON.accessKeyId = AWSCredentials.accessKeyId;
      appJSON.secretAccessKey = AWSCredentials.secretAccessKey;
      appJSON.sessionToken = AWSCredentials.sessionToken;
      appJSON.Expiration = AWSCredentials.Expiration;
    }
    appJSON.organizationID = $("#organizationID").val();
    appJSON.userID = $("#userID").val();
    appJSON.callbackFunction = "setNativeopenqrscannerControl";
    appJSON.nextButtonCallback = "setNativeopenqrscannerControl";
    appJSON.appID = $("#appID").val();
    var element = element ? element : null;
    clientbeforeNativeopenqrscanner(appJSON, element, function (pbcRes) {
      if (DEVICE_TYPE == "ios") {
        setupWebViewJavascriptBridge(function (bridgeObj) {
          bridgeObj.callHandler(
            "loadNativeQRCodeScannerUpload",
            appJSON,
            function (response) {}
          );
          bridgeObj.registerHandler("setNativeopenqrscannerControl", function (
            responseData,
            responseCallback
          ) {
            setNativeopenqrscannerControl(responseData);
          });
        });
      } else {
        window.Android.loadNativeQRCodeScannerUpload(JSON.stringify(appJSON));
      }
    }); // end of process before call
  } catch (err) {}
}
function clientbeforeNativeopenqrscanner(appJSON, element, callback) {
  var response = appJSON;
  callback();
}
function setNativeopenqrscannerControl(responseData) {
  try {
    if (responseData) {
      // Add Custome function Call here
      clientafterNativeopenqrscanner(responseData, function (pbcRes) {
        // handle client after call
      });
    }
  } catch (err) {}
}
function clientafterNativeopenqrscanner(response, callback) {
  if (response) {
    // Add Custome function Call here
    var barcode = response.data.split("&&");
    var objParams = {};
    if (barcode != "") {
      if (barcode && barcode.length >= 3) {
        var recordID = barcode[0];
        localStorage.setItem("voucherID", recordID);
        objParams.isDelete = 0;
        var ajaXCallURL = $.trim($("#ajaXCallURL").val());
        objParams.tokenKey = getParameterByName("tokenKey");
        objParams.secretKey = getParameterByName("secretKey");
        objParams.offlineDataID = localStorage.getItem("offlineDataID");
        var queryMode = getParameterByName("queryMode");
        objParams.userId = localStorage.getItem("userID");
        objParams.callUrl =
          ajaXCallURL +
          "/milestone003/getRecordByCustomeQuery_app_sacaner_Redeemedvouchers5da73cac545050343288ce7a";
        objParams.recordID = recordID;
        $.ajax({
          url: objParams.callUrl,
          data: objParams,
          type: "POST",
          success: function (response) {
            if (response.status == 0) {
              $("#display_loading").addClass("hideme");
              var objParams = {};
              if (response.recordDetails) {
                updatevoucherstatus9();
              } else {
                shareAppData("Invalid QR Code.", "toast");
              }
            } else {
              $("#display_loading").addClass("hideme");
              shareAppData("Invalid QR Code.", "toast");
            }
          },
          error: function (xhr, status, error) {
            $("#display_loading").addClass("hideme");
            shareAppData("Invalid QR Code.", "toast");
          },
        });
      } else {
        var objParams = {};
        var recordID = barcode[0];
        objParams.isDelete = 0;
        var ajaXCallURL = $.trim($("#ajaXCallURL").val());
        objParams.tokenKey = getParameterByName("tokenKey");
        objParams.secretKey = getParameterByName("secretKey");
        objParams.offlineDataID = localStorage.getItem("offlineDataID");
        var queryMode = getParameterByName("queryMode");
        localStorage.setItem("eventID", recordID);
        objParams.recordID = recordID;
        objParams.callUrl =
          ajaXCallURL + "/milestone003/updateStatuseventorders";
        objParams.status = "Attended";
        $.ajax({
          url: objParams.callUrl,
          data: objParams,
          type: "POST",
          success: function (response) {
            if (response.status == 0) {
              shareAppData("Thanks for attending the event.", "toast");
            } else {
              var objParams = {};
              var recordID = barcode[0];
              objParams.isDelete = 0;
              var ajaXCallURL = $.trim($("#ajaXCallURL").val());
              objParams.tokenKey = getParameterByName("tokenKey");
              objParams.secretKey = getParameterByName("secretKey");
              objParams.offlineDataID = localStorage.getItem("offlineDataID");
              //   var merchantID = getParameterByName("merchantID");
              // if (recordID == merchantID) {
              objParams.clientid = localStorage.getItem("userID");

              objParams.merchantid = recordID;

              var queryMode = getParameterByName("queryMode");
              // localStorage.setItem("eventID", recordID);
              objParams.callUrl =
                ajaXCallURL + "/milestone003/saveAjaxordersclientstampweb";
              objParams.recordID = recordID;
              $.ajax({
                url: objParams.callUrl,
                data: objParams,
                type: "POST",
                success: function (response) {
                  if (response.status == 0) {
                    $("#display_loading").addClass("hideme");
                    shareAppData(
                      "Congratulations! You have earned a stamp. Redeem Stamp from My Reward Points to get exciting offers.",
                      "toast"
                    );
                    var objParams = {};
                    //                        if (response.recordDetails && response.recordDetails[0]) {
                    //                            $("#addstampcards28").trigger("click");
                    //
                    //                        } else {
                    //                            shareAppData("Invalid QR Code.", "toast");
                    //                        }
                  } else {
                    $("#display_loading").addClass("hideme");
                    shareAppData(response.error, "toast");
                  }
                },
                error: function (xhr, status, error) {
                  $("#display_loading").addClass("hideme");
                  shareAppData("Invalid QR Code.", "toast");
                },
              });
              //  }
              // shareAppData("Invalid QR Code.", "toast");
            }
          },
          error: function (xhr, status, error) {
            $("#display_loading").addClass("hideme");
            shareAppData("Invalid QR Code.", "toast");
          },
        });
        // var objParams = {};
        // var recordID = barcode[0];
        // objParams.isDelete = 0;
        // var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        // objParams.tokenKey = getParameterByName('tokenKey');
        // objParams.secretKey = getParameterByName('secretKey');
        // objParams.offlineDataID = localStorage.getItem("offlineDataID");
        // var queryMode = getParameterByName('queryMode');
        // localStorage.setItem("eventID", recordID);
        // objParams.recordID = recordID;
        // objParams.callUrl = ajaXCallURL + '/milestone003/get_data_by_record_Bazaar5da73cac545050343288ce7aadditionalenquuiryweb';

        // $.ajax({
        //     url: objParams.callUrl,
        //     data: objParams,
        //     type: 'POST',
        //     success: function (response) {

        //         if (response.status == 0) {
        //             var objParams = {};
        //             objParams.isDelete = 0;
        //             var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        //             objParams.tokenKey = getParameterByName('tokenKey');
        //             objParams.secretKey = getParameterByName('secretKey');
        //             objParams.offlineDataID = localStorage.getItem("offlineDataID");
        //             var queryMode = getParameterByName('queryMode');

        //             objParams.callUrl = ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_sacaner_Referraldetails5da73cac545050343288ce7a';
        //             objParams.clientID = localStorage.getItem("userID");
        //             objParams.productid = localStorage.getItem("eventID");;

        //             $.ajax({
        //                 url: objParams.callUrl,
        //                 data: objParams,
        //                 type: 'POST',
        //                 success: function (response) {

        //                     if (response.status == 1) {
        //                         shareAppData("Thanks for attending the event.", "toast");
        //                         $("#addeventpoints8").trigger("click");
        //                         return false;
        //                     } else if (response.status == 0) {
        //                         $('#display_loading').addClass('hideme');
        //                         var objParams = {};
        //                         if (response.recordDetails) {
        //                             shareAppData("Thanks for attending the event.", "toast");
        //                             return false;
        //                         }
        //                     } else {

        //                         $('#display_loading').addClass('hideme');
        //                         shareAppData("Invalid QR Code.", "toast");
        //                     }
        //                 },
        //                 error: function (xhr, status, error) {
        //                     $('#display_loading').addClass('hideme');
        //                     shareAppData("Invalid QR Code.", "toast");
        //                 },
        //             });

        //         } else {

        //             shareAppData("Invalid QR Code.", "toast");

        //         }

        //     },
        //     error: function (xhr, status, error) {
        //         $('#display_loading').addClass('hideme');
        //         shareAppData("Invalid QR Code.", "toast");
        //     },
        // });
        //    return false;
      }
    } else {
      shareAppData("Invalid QR Code.", "toast");
    }
  }
  console.log("last one");
}

function setUnreadCount(responseData) {
  var count = 0;
  var userUnreadCount = responseData.userUnreadCount;
  var appUser = JSON.parse(localStorage.getItem("appUser"));
  var users = [];
  var isgroupchat = false;
  // if (appUser && appUser !== '') {
  if (appUser && appUser.rolename == "customer") {
    for (i = 0; i < userUnreadCount.length; userUnreadCount++) {
      count = count + userUnreadCount[i].unreadCount;
    }
    //        }
    //        else {
    //            count = userUnreadCount.unreadCount;
    //        }
  }
  $("#chatCount").html(count);
  return false;
}
function updatevoucherstatus9() {
  var objParams = {};
  var expirationdate = $.trim($("#expirationdate11").val());
  if ($("#expirationdate11_div").is(":visible")) {
    objParams.expirationdate = expirationdate;
  }
  var tempobjParams = getParams(window.location.href);
  function extend(obj, src) {
    for (var key in src) {
      if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
    }
    return obj;
  }
  objParams = extend(objParams, tempobjParams);
  var recordID = $("#recordID").val();
  objParams.isDelete = 0;
  var ajaXCallURL = $.trim($("#ajaXCallURL").val());
  objParams.tokenKey = getParameterByName("tokenKey");
  objParams.secretKey = getParameterByName("secretKey");
  objParams.offlineDataID = localStorage.getItem("offlineDataID");
  var queryMode = getParameterByName("queryMode");
  if (queryMode == "mylista") {
    objParams.callUrl =
      ajaXCallURL + "/milestone003/saveAjaxredeemedvouchersapp_sacaner";
  } else {
    objParams.callUrl =
      ajaXCallURL + "/milestone003/updateAjaxredeemedvouchersapp_sacaner";
    objParams.recordID = recordID;
  }
  if (errorFields && Object.keys(errorFields).length) {
    $("#display_loading1").addClass("hideme");
    for (var firstErrorField in errorFields) {
      var controlType = errorFields[firstErrorField];
      errorFields = [];
      var errField = $("#" + firstErrorField);
      if (controlType == "dropdown") {
        errField.prev().prev().focus();
      } else {
        errField.focus();
      }
      validAll = true;
      return false;
    }
  }
  if (!validAll) {
    validAll = true;
    return false;
  }
  $("#updatevoucherstatus9").prop("disabled", true);
  $("#display_loading1").removeClass("hideme");
  if (addSessionComments.length > 0) {
    objParams.addSessionComments = addSessionComments;
  } else {
    objParams.addSessionComments = [];
  }
  var parentID = $("#parentID").val();
  var parentName = $("#parentName").val();
  if (parentID != "") {
    objParams.parentID = parentID;
    objParams.parentName = parentName;
  }
  if (typeof addedFiles != "undefined" && addedFiles && addedFiles.length > 0) {
    objParams.addedFiles = addedFiles;
  }
  objParams.ajaXCallURL = $("#ajaXCallURL").val();
  objParams.organizationID = $("#organizationID").val();
  objParams.ajaXCallURL = $("#ajaXCallURL").val();
  objParams.organizationID = $("#organizationID").val();
  processBeforeCallForSaveredeemedvouchers(objParams, {}, function (
    processBeforeRes
  ) {
    $.ajax({
      url: objParams.callUrl,
      data: objParams,
      type: "POST",
      success: function (response) {
        if (response.status == 0) {
          $("#display_loading1").addClass("hideme");
          response.nextPage = "app_userhome";
          processAfterCallForSaveredeemedvouchers(response, function (
            processAfterRes
          ) {
            var tokenKey = getParameterByName("tokenKey");
            var secretKey = getParameterByName("secretKey");
            var queryMode = getParameterByName("queryMode");
            queryMode = queryMode.replace("edit", "");
            localStorage.setItem("headerPageName", "app_userhome");
            var queryString = window.location.search.slice(1);
            var newQuery =
              queryString +
              "&queryMode=mylist&tokenKey=" +
              tokenKey +
              "&secretKey=" +
              secretKey;
            var queryParams = queryStringToJSON(newQuery);
            queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            if (recordID == "") {
              window.location.href =
                response.nextPage +
                "_5da73cac545050343288ce7a.html?" +
                queryString;
            } else {
              window.location.href =
                response.nextPage +
                "_5da73cac545050343288ce7a.html?" +
                queryString;
            }
            return false;
          }); // End of After Process
        } else {
          $("#display_loading1").addClass("hideme");
          $("#2656d_error").html(response.error);
          $("#2656d_error").show();
        }
        //    $('#updatevoucherstatus9').removeProp('disabled');
      },
      error: function (xhr, status, error) {
        $("#display_loading1").addClass("hideme");
        // $('#updatevoucherstatus9').removeProp('disabled');
      },
    });
    return false;
  }); // End of Before Process
}
//Start of renderMenuList
function renderMenuList(response) {
  try {
    var fieldTags = {};
    if (typeof response.fieldTags != "undefined") {
      $.each(response.fieldTags, function (keyList, objTag) {
        fieldTags[objTag.name] = objTag.value;
      });
    }
    var ajaXCallURL = $.trim($("#ajaXCallURL").val());
    var html = "";
    if (
      response != undefined &&
      response.status != undefined &&
      response.data != undefined
    ) {
      $("#userID").val(response.data.userID);
      localStorage.setItem("userRole", response.data.roleName);
      localStorage.setItem("userID", response.data.userID);
      $("#organizationID").val(response.data.organizationID);
      $("#appID").val(response.data.appID);
      var objList = {};
      objList.thumbImage = response.thumbImage;
      objList.userNameDetails = response.userNameDetails;
      objList.userEmailDetails = response.userEmailDetails;
      if (typeof objList.thumbImage == "undefined") {
        var profileThumb = localStorage.getItem("profileThumb");
        objList.thumbImage = profileThumb
          ? CDN_PATH + profileThumb + ""
          : "nouserprofile.svg";
        localStorage.setItem("profileThumbURL", objList.thumbImage);
      } else {
        localStorage.setItem("profileThumbURL", objList.thumbImage);
      }
      html += '      <div class="row nav-profile" >';
      html += '           <div class="col s12">';
      html +=
        '               <div id="thumbImage" class="profileSmallThumbnail" style="background-image: url(' +
        objList.thumbImage +
        ')"></div>';
      html += "           </div>";
      html += '           <div class="col s12">';
      html +=
        '            <div id="userNameDetails">' +
        objList.userNameDetails +
        "</div>";
      html +=
        '            <div id="userEmailDetails" >' +
        objList.userEmailDetails +
        "</div>";
      html += "            </div>";
      html += "     </div>";

      if (response.menuList != undefined) {
        var menuHtml = "";
        var indexCount = 0;
        $.each(response.menuList, function (keyList, objList) {
          var menuName = objList.name;
          if (
            typeof currentLanguage != "undefined" &&
            currentLanguage != "" &&
            currentLanguage != "en"
          ) {
            objList.fn = objList.fn.replace(
              ".html",
              "_" + currentLanguage + ".html"
            );
          }
          objList.upName = objList.name;
          menuName = menuName.toLowerCase();
          menuName = menuName.replace(/ /g, "_");
          var menuNameIcon = menuName + "_menu_list_icon";
          if (objList.isMainHeader && objList.isMainHeader == 1) {
            objList.menuLable = objList.name;
            var headerID = objList.name.replace(/ /g, "_");
            var regExpr = /[^a-zA-Z0-9-. ]/g;
            headerID = headerID.replace(regExpr, "");
            html +=
              '      <div class="row menu-item redirecttopage" id="' +
              headerID +
              '" fileName="' +
              objList.fn +
              '" queryMode="' +
              objList.qm +
              '" >';
            html += '           <div class="col s2 menu-icon">';
            html +=
              '               <img recordID="' +
              objList._id +
              '" class="menuicon"  src="' +
              objList.name +
              '.svg">';
            html += "           </div>";
            html += '           <div class="col s10 menu-label">';
            html +=
              '            <div class="menuname languagetranslation" >' +
              objList.name +
              "</div>";
            html += "            </div>";
            html += "     </div>";
          }
        });
        if (
          localStorage.getItem("roleName") &&
          localStorage.getItem("roleName") == "guest"
        ) {
          html +=
            '      <div class="row menu-item" id="continue56" style="cursor: pointer;">';
          html += '           <div class="col s2 menu-icon" >';
          html += '               <img   src="Logout.svg">';
          html += "           </div>";
          html += '           <div class="col s10 menu-label">';
          html += "                <div>Login</div>";
          html += "           </div>";
          html += "      </div>";
        } else {
          html += '      <div class="row menu-item" id="nativeLogut" >';
          html += '           <div class="col s2 menu-icon" >';
          html += '               <img   src="Logout.svg">';
          html += "           </div>";
          html += '           <div class="col s10 menu-label">';
          html += "                <div>Logout</div>";
          html += "           </div>";
          html += "      </div>";
        }
        $("#slide-out").html(html);
      }
    }

    var tokenKey = getParameterByName("tokenKey");
    var url = "nouserprofile.svg";
    var obj = findObjectByKey("_id", $("#userID").val());
    if (response.thumbImage) {
      url = response.thumbImage;
    } else if (
      obj &&
      obj.userphotoupload &&
      obj.userphotoupload[0] &&
      obj.userphotoupload[0].mediaID
    ) {
      url =
        $("#filePath").val() +
        "/download?f=" +
        obj.userphotoupload[0].mediaID +
        ".png&t=" +
        tokenKey;
    }
    $("#thumbImage").attr("src", url);
    var activeMenu = localStorage.getItem("activeMenu");
    if (activeMenu != "") {
      $("#" + activeMenu + "").addClass("active");
    } else {
      $(".menu-item:first").addClass("active");
    }
    if ($("#displayBack").val() == undefined) {
      setTimeout(function () {
        $("#slide-out").removeClass("hideme");
        $(".button-collapse").sideNav({
          menuWidth: 240, // Default is 240
          closeOnClick: true,
          draggable: true,
          edge: "left", // Choose the horizontal origin
        });
      }, 1000);
    }
  } catch (err) {
    // console.log("Error in renderMenuList", err);
  }
}
// End of  renderMenuList

//$(document).on('focus', 'input', function(){ $(this).select(); })

$(document).on("click", "#retrybutton", function () {
  window.location.reload();
});

function handleError(xhr, status, error) {
  try {
    //if(!ISDEV_MODE){
    // if (XMLHttpRequest.readyState == 4) {
    //     //HTTP error (can be checked by XMLHttpRequest.status and XMLHttpRequest.statusText)
    //     $('#display_error').fadeOut(0).fadeIn(1000).removeClass('hideme');
    // } else if (XMLHttpRequest.readyState == 0) {
    //     //Network error (i.e. connection refused, access denied due to CORS, etc.)
    //     $('#display_error').fadeOut(0).fadeIn(1000).removeClass('hideme');
    // } else {
    //     //something weird is happening
    //     $('#display_error').fadeOut(0).fadeIn(1000).removeClass('hideme');
    // }
    // }
  } catch (err) {
    // error
  }
}
function getuploadedfilepreview(filename) {
  var pdfextension = ["pdf"];
  var docextension = ["doc", "docx"];
  var sheetextension = ["xls", "xlsx"];
  var result = filename;
  if (filename) {
    var extension = filename.split(".");
    if (extension && extension.length > 1) {
      extension = extension[1];
      if (pdfextension.indexOf(extension) > -1) {
        result = "sg_pdficon.png";
      } else if (docextension.indexOf(extension) > -1) {
        result = "sg_docicon.png";
      } else if (sheetextension.indexOf(extension) > -1) {
        result = "sg_sheeticon.png";
      }
    }
  }
  return result;
}
function getCurrancy(amount, country, currancysymbol) {
  try {
    if (amount) {
      if (country == "INR") {
        return amount.toLocaleString();
      } else if (country) {
        switch (country.toLowerCase()) {
          case "usd":
            country = "$";
            break;
          case "sgd":
            country = "S$";
            break;
          case "inr":
            country = "";
            break;
        }
        country = currancysymbol ? currancysymbol : country;
        return (
          country +
          parseFloat(amount)
            .toFixed(2)
            .replace(/(d)(?=(d{3})+(?!d))/g, "$1,")
        );
      } else {
        return parseFloat(amount)
          .toFixed(2)
          .replace(/(d)(?=(d{3})+(?!d))/g, "$1,");
      }
    } else {
      return 0;
    }
  } catch (err) {
    return amount;
  }
}
function queryStringToJSON(url) {
  var pairs = location.search.slice(1).split("&");
  if (url) {
    pairs = url.split("&");
  }
  var result = {};
  pairs.forEach(function (pair) {
    pair = pair.split("=");
    result[pair[0]] = decodeURIComponent(pair[1] || "");
  });

  return JSON.parse(JSON.stringify(result));
}
setDateTimePicker();
setTimeout(function () {
  setDateTimePicker();
}, 200);
setTimeout(function () {
  setDateTimePicker();
}, 2000);
function setDateTimePicker() {
  if ($(".datepicker").length) {
    $(".datepicker").pickadate({
      selectMonths: true,
      selectYears: 150,
      dateFormat: "d mmmm, yyyy",
      onSet: function (arg) {
        if ("select" in arg) {
          this.close();
        }
      },
    });
    $(".datepicker").on("mousedown", function (event) {
      event.preventDefault();
    });
  }
  if ($(".datepickerpast").length) {
    $(".datepickerpast").pickadate({
      selectMonths: true,
      selectYears: 150,
      dateFormat: "d mmmm, yyyy",
      max: new Date(),
      onSet: function (arg) {
        if ("select" in arg) {
          this.close();
        }
      },
    });
    $(".datepickerpast").on("mousedown", function (event) {
      event.preventDefault();
    });
  }
  if ($(".datepickerfuture").length) {
    $(".datepickerfuture").pickadate({
      selectMonths: true,
      selectYears: 150,
      dateFormat: "d mmmm, yyyy",
      min: new Date(),
      onSet: function (arg) {
        if ("select" in arg) {
          this.close();
        }
      },
    });
    $(".datepickerfuture").on("mousedown", function (event) {
      event.preventDefault();
    });
  }
  if ($(".timepicker").length) {
    $(".timepicker").pickatime({
      default: "now",
      fromnow: 0,
      twelvehour: true,
      donetext: "OK",
      cleartext: "Clear",
      canceltext: "Cancel",
      autoclose: false,
    });
    $(".timepicker").on("mousedown", function (event) {
      event.preventDefault();
    });
  }
}
function isEmail(email) {
  var regex = /^([a-zA-Z0-9_.+-])+@(([a-zA-Z0-9-])+.)+([a-zA-Z0-9]{2,4})+$/;
  return regex.test(email);
}
$(document).on("click", ".removeItem", function () {
  var mid = $(this).attr("mid");
  var targate = $(this).attr("targate");
  if (arrEditMedia[targate] && arrEditMedia[targate][mid]) {
    delete arrEditMedia[targate][mid];
    $("div[mid=" + mid + "][targate=" + targate + "]").remove();
  }
});
setupWebViewJavascriptBridge(function (bridgeObj) {
  bridgeObj.registerHandler("nativeRedirectPageCallback", function (
    responseData,
    responseCallback
  ) {
    nativeRedirectPageCallback(responseData);
  });
});

function nativeRedirectPageCallback(responseLocations) {
  try {
    if (responseLocations) {
      if (responseLocations.bridgeData) {
        var response = responseLocations.bridgeData;
      } else {
        var response = responseLocations;
      }
      response.recordID = response.recordID ? response.recordID : response._id;
      var recordID = response.recordID ? response.recordID : response._id;
      if (recordID) {
        var tokenKey = getParameterByName("tokenKey");
        var secretKey = getParameterByName("secretKey");
        var queryMode = getParameterByName("queryMode");
        var nextPage = getParameterByName("redirectPage");
        window.location.href =
          nextPage +
          "_5da73cac545050343288ce7a.html?queryMode=" +
          queryMode +
          "&tokenKey=" +
          tokenKey +
          "&secretKey=" +
          secretKey +
          "&recordID=" +
          recordID +
          "&bazaarid=" +
          recordID +
          "&ordersid=" +
          recordID;
        return false;
      }
    }
  } catch (err) {
    // console.log(err);
  }
}

function redirectPageCallbackV2(responseLocations) {
  try {
    if (responseLocations) {
      if (responseLocations.bridgeData) {
        var response = responseLocations.bridgeData;
      } else {
        var response = responseLocations;
      }
      response.recordID = response.recordID ? response.recordID : response._id;
      var tokenKey = getParameterByName("tokenKey")
        ? getParameterByName("tokenKey")
        : response.tokenKey;
      var secretKey = getParameterByName("secretKey")
        ? getParameterByName("secretKey")
        : response.secretKey;
      var queryMode = getParameterByName("queryMode")
        ? getParameterByName("queryMode")
        : response.queryMode;
      var recordID = getParameterByName("recordID")
        ? getParameterByName("recordID")
        : response.recordID;
      queryMode = "mylist";
      localStorage.setItem("isFilterFromMap", 1);
      window.location.href =
        response.redirectPage +
        "_5da73cac545050343288ce7a.html?queryMode=" +
        queryMode +
        "&tokenKey=" +
        tokenKey +
        "&secretKey=" +
        secretKey +
        "&ordersid=" +
        response.ordersid +
        "&bazaarid=" +
        response.bazaarid +
        "&recordID=" +
        recordID +
        "&applyFilter=true";
      return false;
    }
  } catch (err) {
    // console.log(err);
  }
}
function getParams(url) {
  var urlParams = {};
  url.replace(new RegExp("([^?=&]+)(=([^&]*))?", "g"), function (
    $0,
    $1,
    $2,
    $3
  ) {
    if ($3 && $3 != "undefined") urlParams[$1] = $3;
  });
  return urlParams;
}
function processAfterCallForSaveredeemedvouchers(response, callback) {
  shareAppData("Your voucher is successfuly handover", "toast");

  callback();
}
/**
 * start:: token changes
 */

function offlineMode({ mode }) {
  try {
    if (mode) {
      isOffline = mode;
      $("#networkerror").remove();
      $("#networkerrors").remove();
      $("#full-body-container").prepend('<div id="networkerror"><h5>No Connection Found</h5><h6>Please check your network connection</h6></div>');
      $("#signupcls").prepend('<div id="networkerrors"><h5>No Connection Found</h5><h6>Please check your network connection</h6></div>');

    } else {
      $("#networkerror").remove();
      $("#networkerrors").remove();
      isOffline = false;
    }
  } catch (error) {
    console.log("Error in offline mode", error);
  }
}

function offlineModeWithRefreshToken({ mode }) {
  $("#display_loading").addClass("hideme");
  writeLog("weblog : Inside offlineModeWithRefreshToken - " + mode + " -  header_mobile.js");
  try {
    if (mode) {
      writeLog("weblog : Inside offlineModeWithRefreshToken - Internet Offline  -  header_mobile.js");
      isOffline = mode;
      $("#networkerror").remove();
       $("#networkerrors").remove();
      $("#full-body-container").prepend('<div id="networkerror"><h5>No Connection Found</h5><h6>Please check your network connection</h6></div>');
      $("#signupcls").prepend('<div id="networkerrors"><h5>No Connection Found</h5><h6>Please check your network connection</h6></div>');

    } else {
      writeLog("weblog : Inside offlineModeWithRefreshToken - Internet Online  -  header_mobile.js");
      $("#networkerror").remove();
      $("#networkerrors").remove();
      isOffline = false;
      writeLog("weblog : Inside offlineModeWithRefreshToken - call refreshAWSToken  -  header_mobile.js");
      refreshAWSToken(function (response) {
        writeLog("weblog : Inside offlineModeWithRefreshToken -  refreshAWSToken response " + response + "  -  header_mobile.js");

        if (response) {
          writeLog("weblog : Inside offlineModeWithRefreshToken - token refreshed  -  header_mobile.js");
          $("#display_loading").addClass("hideme");
          var IDENTITY_TOKEN = localStorage.getItem("IDENTITY_TOKEN");
          if (IDENTITY_TOKEN) {
            var appJSON = {};
            appJSON.idToken = IDENTITY_TOKEN;
            var playload = JSON.parse(atob(IDENTITY_TOKEN.split(".")[1]));
            if (playload.exp) {
              appJSON.ExpiryTime = playload.exp;
            }
            if (DEVICE_TYPE == "ios") {
              setupWebViewJavascriptBridge(function (bridge) {
                bridgeObj.callHandler("updateToken", appJSON, function (response) { });
              });
            } else {
              window.Android.updateToken(JSON.stringify(appJSON));
            }
          }
        }
      });
    }
  } catch (error) {
    writeLog("weblog : Inside offlineModeWithRefreshToken - error  -  header_mobile.js");
    console.log("Error in offline mode", error);
  }
}

function setHeaderColor() {
  var appJSON = {};
  appJSON.colourHexString = "#052c8a";
  appJSON.isWhiteColour = false;
  if (window.location.href.indexOf("app_inspectorhome") !== -1 || window.location.href.indexOf("login") !== -1) {
    appJSON.colourHexString = "#ffffff";
    appJSON.isWhiteColour = true;
  }
  var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
  if (isAndroid === -1) {
    setupWebViewJavascriptBridge(function (bridge) {
      bridge.callHandler("changeStatusBarColour", appJSON, function (response) { });
    });
  } else {
    window.Android.changeStatusBarColour(JSON.stringify(appJSON));
  }
}

function updateApp() {
  var appJSON = {};
  appJSON.userId = localStorage.userID;
  appJSON.tokenKey = getParameterByName('tokenKey');
  appJSON.secretKey = getParameterByName('secretKey');
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  appJSON.queryMode = "mylist";
  appJSON.ajaXCallURL = ajaXCallURL;
  appJSON.apiName = "https://milestone.hokuapps.com/milestone003/GetAppVersionDetails5da73cac545050343288ce7a";
  appJSON.showNativeDialog = true;
  appJSON.organizationID = $('#organizationID').val();
  appJSON.userID = $('#userID').val();
  appJSON.appID = $('#appID').val();
  appJSON.nextButtonCallback = 'loadcompleteCheckAppVersion';
  appJSON.action = queryMode;
  var IDENTITY_TOKEN = getParameterByName('IDENTITY_TOKEN');
  IDENTITY_TOKEN = IDENTITY_TOKEN ? IDENTITY_TOKEN : localStorage.getItem('IDENTITY_TOKEN')
  appJSON.Authorization = IDENTITY_TOKEN;

  var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
  if (isAndroid > -1) {
    window.Android.updateAppVersion(JSON.stringify(appJSON));
  } else {
    setupWebViewJavascriptBridge(function (bridge) {
      bridgeObj = bridge;
      var appJSON = {};
      appJSON.nextButtonCallback = 'loadcompleteCheckAppVersion';
      bridgeObj.callHandler('updateAppVersion', appJSON, function (response) { });

      bridgeObj.registerHandler('updateAppVersion', function (responseData, responseCallback) {
        loadcompleteCheckAppVersion(responseData);
      });
    });
  }
}

function loadcompleteCheckAppVersion(responseData) {
  if (responseData) {
    if (responseData.newVersionFound == true) {
      var tokenKey = getParameterByName('tokenKey');
      var secretKey = getParameterByName('secretKey');
      var queryMode = getParameterByName('queryMode');
      var nextPage = 'updateappmessage';
      if (!nextPage) {
        return false;
      }
      localStorage.updateappmessage = "true";
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?queryMode=' + queryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey;
      return false;
    }
  }
}
/**
End:: tokecn chnages
*/
