
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var financialCalculator = JSON.parse(localStorage.financialCalculator)
$(document).ready(function () {
  $('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
    $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

  var objParamsToken = {};
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  objParamsToken.tokenKey = getParameterByName('tokenKey');
  objParamsToken.secretKey = getParameterByName('secretKey');

  var userRole = $('#userRole').val();
  var userID = $('#userID').val();
  var createrOfRecord = $('#createrOfRecord').val();
  var queryMode = getParameterByName('queryMode');
  var recordID = $.trim($('#recordID').val());
  var addSessionComments = [];
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on('click', '#result18', function () {
    var objParams = {};
    var currentage = $.trim($('#currentage13').val());
    var obj = {}
    if ($('#currentage13_div').is(':visible')) {
      if (currentage == '') {
        $('#currentage13_error').show();
        if (!Object.keys(errorFields).length) errorFields['currentage13'] = 'textbox';
        validAll = false;
      } else {
        $('#currentage13_error').hide();
      }
    }
    if ($('#currentage13_div').is(':visible')) {
      objParams.currentage = currentage;
    }
    var retirementage = $.trim($('#retirementage14').val());
    var obj = {}
    if ($('#retirementage14_div').is(':visible')) {
      if (retirementage == '') {
        $('#retirementage14_error').show();
        if (!Object.keys(errorFields).length) errorFields['retirementage14'] = 'textbox';
        validAll = false;
      } else {
        $('#retirementage14_error').hide();
      }
    }
    if ($('#retirementage14_div').is(':visible')) {
      objParams.retirementage = retirementage;
    }
    var monthlyincome = $.trim($('#monthlyincome15').val());
    var obj = {}
    if ($('#monthlyincome15_div').is(':visible')) {
      if (monthlyincome == '') {
        $('#monthlyincome15_error').show();
        if (!Object.keys(errorFields).length) errorFields['monthlyincome15'] = 'textbox';
        validAll = false;
      } else {
        $('#monthlyincome15_error').hide();
      }
    }
    if ($('#monthlyincome15_div').is(':visible')) {
      objParams.monthlyincome = monthlyincome;
    }
    var incomeyearsrequired = $.trim($('#incomeyearsrequired16').val());
    var obj = {}
    if ($('#incomeyearsrequired16_div').is(':visible')) {
      if (incomeyearsrequired == '') {
        $('#incomeyearsrequired16_error').show();
        if (!Object.keys(errorFields).length) errorFields['incomeyearsrequired16'] = 'textbox';
        validAll = false;
      } else {
        $('#incomeyearsrequired16_error').hide();
      }
    }
    if ($('#incomeyearsrequired16_div').is(':visible')) {
      objParams.incomeyearsrequired = incomeyearsrequired;
    }
    var inflationrate = $.trim($('#inflationrate17').val());
    var obj = {}
    if ($('#inflationrate17_div').is(':visible')) {
      if (inflationrate == '') {
        $('#inflationrate17_error').show();
        if (!Object.keys(errorFields).length) errorFields['inflationrate17'] = 'textbox';
        validAll = false;
      } else {
        $('#inflationrate17_error').hide();
      }
    }
    if ($('#inflationrate17_div').is(':visible')) {
      objParams.inflationrate = inflationrate;
    }
    var fundnumber = $.trim($('#fundnumber19').val());
    if ($('#fundnumber19_div').is(':visible')) {
      objParams.fundnumber = fundnumber;
    }
    var tempobjParams = getParams(window.location.href)
    function extend(obj, src) {
      for (var key in src) {
        if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
      }
      return obj;
    }
    objParams = extend(objParams, tempobjParams);
    var recordID = $('#recordID').val();
    objParams.isDelete = 0;
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParams.tokenKey = getParameterByName('tokenKey');
    objParams.secretKey = getParameterByName('secretKey');
    objParams.offlineDataID = localStorage.getItem("offlineDataID");
    var queryMode = getParameterByName('queryMode')
    if (queryMode == 'add121') {
      objParams.callUrl = ajaXCallURL + '/milestone003/saveAjaxusermanagement4524resultapp_retirementcalculateadd';
    } else {
      objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxusermanagement4524resultapp_retirementcalculateadd';
      objParams.recordID = recordID;
    }
    if (errorFields && Object.keys(errorFields).length) {
      $('#display_loading1').addClass('hideme');
      for (var firstErrorField in errorFields) {
        var controlType = errorFields[firstErrorField];
        errorFields = []
        var errField = $('#' + firstErrorField);
        if (controlType == 'dropdown') {
          errField.prev().prev().focus();
        } else {
          errField.focus()
        }
        validAll = true;
        return false;
      }
    }
    if (!validAll) {
      validAll = true;
      return false;
    }
    $('#result18').prop('disabled', true);
    $('#display_loading1').removeClass('hideme');
    if (addSessionComments.length > 0) {
      objParams.addSessionComments = addSessionComments;
    } else {
      objParams.addSessionComments = [];
    }
    var parentID = $('#parentID').val();
    var parentName = $('#parentName').val();
    if (parentID != '') {
      objParams.parentID = parentID;
      objParams.parentName = parentName
    }
    if (typeof (addedFiles) != "undefined" && addedFiles && addedFiles.length > 0) {
      objParams.addedFiles = addedFiles;
    }
    objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    objParams.organizationID = $("#organizationID").val();;
    objParams.ajaXCallURL = $("#ajaXCallURL").val();;
    objParams.organizationID = $("#organizationID").val();;
    processBeforeCallForSave4524result(objParams, {}, function (processBeforeRes) {
      $.ajax({
        url: objParams.callUrl,
        data: objParams,
        type: 'POST',
        success: function (response) {
          if (response.status == 0) {
            $('#display_loading1').addClass('hideme');
            response.nextPage = 'app_retirementdetails'
            processAfterCallForSave4524result(response, function (processAfterRes) {
              var tokenKey = getParameterByName('tokenKey');
              var secretKey = getParameterByName('secretKey');
              var queryMode = getParameterByName('queryMode');
              queryMode = queryMode.replace('edit', '');
              localStorage.setItem("headerPageName", 'app_retirementdetails');
              var queryString = window.location.search.slice(1);
              var newQuery = queryString + '&queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&queryMode=mylist' + '&fundid=' + response.data._id + '&recordID=' + response.data._id
              var queryParams = queryStringToJSON(newQuery);
              queryString = $.param(queryParams);
              queryString = queryString.replace(/\+/g, "%20");
              queryString = decodeURIComponent(queryString);
              if (recordID == '') {
                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
              } else {
                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
              }
              return false;
            }); // End of After Process
          } else {
            $('#display_loading1').addClass('hideme');
            $('#2656d_error').html(response.error);
            $('#2656d_error').show();
          }
          $('#result18').removeProp('disabled');
        },
        error: function (xhr, status, error) {
          $('#display_loading1').addClass('hideme');
          $('#result18').removeProp('disabled');
        },
      });
      return false;
    }); // End of Before Process
  });//end of Event Result_is_click 
  var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  var objParams = {};
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#backbutton1,.prevbtn123', function (e) {
    try {
      var element = $(this);
      var rolename = localStorage.getItem("roleName");
      // var nextPage = 'app_custmoreinfodetails';
      var nextPage = 'app_childfundstep2';
      // if (rolename == "consultant") {
      //   nextPage = "app_consultantcustmoreinfodetails";
      // }

      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "update";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error)
    }
  })
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#financialgoals8', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_financialcalculateadd';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "add";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - financialgoals8", error)
    }
  })
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#childuniversityfund9', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_childcalculateadd';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "add";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - childuniversityfund9", error)
    }
  });

  $(document).on('click', '.selectedOption', function (e) {
    $(this).parent().find('img').each(function(e) {
      let imgSrc = $(this).attr('src');
      imgSrc = imgSrc.replace('active.png','.png')
      $(this).attr('src',imgSrc);
    });
    $(this).parent().find('.age').removeClass('ageactive');
    let typeValue = $(this).attr('typeValue');
    financialCalculator[typeValue] = $(this).attr(financialCalculator.school);
    financialCalculator.country = $(this).attr('country');
    let imgSrc = $(this).find('img').attr('src');
    imgSrc = imgSrc.replace('.png','active.png')
    $(this).find('img').attr('src',imgSrc);
    $(this).find('.age').addClass('ageactive')
  })

  $(document).on('click', '#retiremetgoal11', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_retirementgoalstep1';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "add";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - childuniversityfund9", error)
    }
  })

    $(document).on('click', '#childfund11', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_childfundstep1';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "add";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - childuniversityfund9", error)
    }
  })



  $(document).on('click', '.nextbtn123', function (e) {
    try {
        var element = $(this);
        var parent = getParameterByName('parent');
        var nextPage = 'app_childfundfinal';
        var queryParams = queryStringToJSON();
        queryParams["queryMode"] = "mylist";
        var recordID = $(this).attr("recordID");
        if (recordID) {
            queryParams["recordID"] = recordID;
        }
        localStorage.financialCalculator = JSON.stringify(financialCalculator)
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
        return false;
    } catch (error) {
        console.log("Error in pageredirect workflow - backbutton1", error)
    }
  })

});//end of ready
function getParams(url) {
  var urlParams = {};
  url.replace(
    new RegExp("([^?=&]+)(=([^&]*))?", "g"),
    function ($0, $1, $2, $3) {
      if ($3 && $3 != 'undefined') urlParams[$1] = $3;
    }
  );
  return urlParams;
}
function processBeforeCallForSave4524result(objParams, response, callback) {


  objParams.recordID = localStorage.userID;

  var currentage13 = $("#currentage13").val();
  var retirementage14 = $("#retirementage14").val();
    if(retirementage14 < currentage13 )
    {
        $('#retirementage15_error').show();
        $('#result18').removeProp('disabled');
        $('#display_loading1').addClass('hideme');


        return false;
        
    }
    {
        $('#retirementage15_error').hide();

    }
  var monthlyincome15 = $("#monthlyincome15").val();
  var incomeyearsrequired16 = parseInt($("#incomeyearsrequired16").val());
  var inflationrate17 = $("#inflationrate17").val();
  inflationrate17 = inflationrate17 / 100;
  var yeartoachive = retirementage14 - currentage13;

  var inflationrate17value = (1 + inflationrate17);
  var inflationrate17value1 = inflationrate17value;
  for (var i = 1; i < yeartoachive; i++) {
    inflationrate17value1 = inflationrate17value1 * inflationrate17value
  }
  var firstlevelvalue0 = monthlyincome15 * 12 * incomeyearsrequired16;
  firstlevelvalue = firstlevelvalue0 * inflationrate17value1



  objParams.result1 = firstlevelvalue //monthlyincome15 * 12 * incomeyearsrequired16;
  objParams.result2 = firstlevelvalue / yeartoachive;
  objParams.result2 = objParams.result2 / 12
  callback();
}
function processAfterCallForSave4524result(response, callback) {

  callback();
}
