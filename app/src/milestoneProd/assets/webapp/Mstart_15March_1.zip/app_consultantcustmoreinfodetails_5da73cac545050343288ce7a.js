
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
	$('#recordID').val(getParameterByName('recordID'));
	var recordID = localStorage.getItem('userID');
	if (recordID != '') {
		$('#display_loading').removeClass('hideme');
		var paramsEdit = {};
		paramsEdit.recordID = recordID;
		getRecordByIdUsermanagement5da73cac545050343288ce7a(paramsEdit);
	}
	var queryMode = getParameterByName('queryMode');
	localStorage.removeItem('filterCategoryId');
	localStorage.removeItem('filterCategoryIdSingle');

	var authKey = $('#authKey').val();
	var appID = $('#hdnAppID').val();
	if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
		$("#headerPageName").html(localStorage.getItem("headerPageName"))
	}

	var objParamsToken = {};
	var ajaXCallURL = $.trim($('#ajaXCallURL').val());
	objParamsToken.tokenKey = getParameterByName('tokenKey');
	objParamsToken.secretKey = getParameterByName('secretKey');

	var userRole = $('#userRole').val();
	var userID = $('#userID').val();
	var createrOfRecord = $('#createrOfRecord').val();
	var queryMode = getParameterByName('queryMode');
	var recordID = $.trim($('#recordID').val());
	var addSessionComments = [];
	$(document).on('click', '#logout44', function (e) {
		try {
			var element = $(this);
			var objParams = {};
			objParams.recordID = getParameterByName('recordID');
			if ($(this).attr('recordID')) {
				objParams.recordID = $(this).attr('recordID');
			}

			customcodeLogout(objParams, element, {}, function (processCustomcode) {
				return false;
			});
		} catch (error) {
			console.log('Error in customcode click', error);
		}
	});
	$(document).on('click', '#sg5920999', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_mystampcardlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - stampcardsoffers21", error)
		}
	});
	$(document).on('click', '#sg682299', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_allofferlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - stampcardsoffers21", error)
		}
	});
	$(document).on('click', '#myfinancialcalculator6', function (e) {
		try {
			var element = $(this);
		//	var nextPage = 'app_consultantallfinancialsteplist';

		
		var rolename =             localStorage.getItem('roleName');
		var nextPage = 'app_allfinancialservicesstepfinallist';

if(rolename.toLowerCase() == "consultant")
		{
		nextPage = "app_consultantallfinancialsteplist";
		}
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "add";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - myfinancialcalculator6", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#myclients6', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_consultantclientlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - myclients6", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext17', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_consultantclientlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext17", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#vouchersrequets9', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_consultantrequestvoucherlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - vouchersrequets9", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext510', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_consultantrequestvoucherlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext510", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#shareapplink12', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_referaurl';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - shareapplink12", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext413', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_referaurl';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext413", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);

	
	$(document).on('click', '#sg16221', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_merchantlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - sg16221", error)
		}
	})

	$(document).on('click', '#sg1622', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_consultantrequestappointmentslisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - myappointnments15", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext1016', function (e) {
		try {
			// var element = $(this);
			// var nextPage = 'app_sacaner'; 
			// var queryParams = queryStringToJSON(); 
			// queryParams["queryMode"] = "mylist"; 
			// var recordID = $(this).attr("recordID"); 
			// if(recordID){ 
			// 	queryParams["recordID"] = recordID; 
			// }
			// var queryString = $.param(queryParams);
			// queryString = queryString.replace(/\+/g, "%20");
			// queryString = decodeURIComponent(queryString);
			// window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
			// return false;  
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext1016", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#notifications18', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_customernotificationlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			queryParams["applyFilters"] = "false";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - notifications18", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext619', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_customernotificationlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext619", error)
		}
	})
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#sg59201', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_merchantlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - merchants18", error)
		}
	})

	$(document).on('click', '#iconnextmerchants_img', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_consultantnotificationlisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext619", error)
		}
	})

	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#contactsupport21', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_consultantcontactuslisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - contactsupport21", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext822', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_consultantcontactuslisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext822", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#aboutapp24', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_consultantaboutapplisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - aboutapp24", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext725', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_consultantaboutapplisting';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext725", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#profile27', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_clientprofile';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - profile27", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#iconnext928', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_clientprofile';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - iconnext928", error)
		}
	})
	var addedRecords = [];
	localStorage.setItem('addedRecords', []);
	$(document).on('click', '#sg61323', function (e) {
		try {
			var element = $(this);
			var nextPage = 'app_clientprofile';
			var queryParams = queryStringToJSON();
			queryParams["queryMode"] = "mylist";
			var recordID = $(this).attr("recordID");
			if (recordID) {
				queryParams["recordID"] = recordID;
			}
			var queryString = $.param(queryParams);
			queryString = queryString.replace(/\+/g, "%20");
			queryString = decodeURIComponent(queryString);
			window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
			return false;
		} catch (error) {
			console.log("Error in pageredirect workflow - profile36", error)
		}
	})
	var paramsEdit = {};
	paramsEdit.tokenKey = getParameterByName('tokenKey');
	paramsEdit.secretKey = getParameterByName('secretKey')
	getRecordByIDProcessBeforeCall996816(paramsEdit, function (processBeforeRes) {
		$.ajax({
			url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_consultantcustmoreinfodetails_Bazaar5da73cac545050343288ce7a',
			data: paramsEdit,
			type: 'POST',
			jsonpCallback: 'callback',
			success: function (response) {
				getRecordByIDProcessAfterCall996816(response, function (processBeforeRes) {
					if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
						var objParamsList = {};
						var queryMode = $('#queryMode').val();
						objParamsList.queryMode = queryMode;;
						var tokenKey = $('#tokenKey').val();;
						objParamsList.tokenKey = tokenKey;;
						if (!$('#aboutapp24').html()) {
							$('#aboutapp24').append(response.recordDetails.undefined);
						}
						if (!$('#bottommenu30').html()) {
							$('#bottommenu30').append(response.recordDetails.undefined);
						}
						if (!$('#contactsupport21').html()) {
							$('#contactsupport21').append(response.recordDetails.undefined);
						}
						var url = 'icon_next1.png'
						$('#iconnext17').attr("src", url);
						var url = 'icon_next10.png'
						$('#iconnext1016').attr("src", url);
						var url = 'icon_next4.png'
						$('#iconnext413').attr("src", url);
						var url = 'icon_next5.png'
						$('#iconnext510').attr("src", url);
						var url = 'icon_next6.png'
						$('#iconnext619').attr("src", url);
						var url = 'icon_next7.png'
						$('#iconnext725').attr("src", url);
						var url = 'icon_next8.png'
						$('#iconnext822').attr("src", url);
						var url = 'icon_next9.png'
						$('#iconnext928').attr("src", url);
						if (!$('#more1').html()) {
							$('#more1').append(response.recordDetails.undefined);
						}
						if (!$('#myappointnments15').html()) {
							$('#myappointnments15').append(response.recordDetails.undefined);
						}
						if (!$('#myclients6').html()) {
							$('#myclients6').append(response.recordDetails.undefined);
						}
						if (!$('#notifications18').html()) {
							$('#notifications18').append(response.recordDetails.undefined);
						}
						if (!$('#profile27').html()) {
							$('#profile27').append(response.recordDetails.undefined);
						}
						if (!$('#shareapplink12').html()) {
							$('#shareapplink12').append(response.recordDetails.undefined);
						}
						if (!$('#vouchersrequets9').html()) {
							$('#vouchersrequets9').append(response.recordDetails.undefined);
						}

						Materialize.updateTextFields();
						$('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

					}
				}); // end of getRecord By ID
			},
			error: function (xhr, status, error) {
				handleError(xhr, status, error);
			},
		});
	}); // end of getRecord By ID

	showBottomMenu();
});//end of ready
function customcodeLogout(objParams, element, response, callback) {
	try {
		var queryMode = 'add';
		var ajaXCallURL = getParameterByName('ajaXCallURL');
		var tokenKey = getParameterByName('tokenKey');
		var secretKey = getParameterByName('secretKey');
		logoutNativeCall(tokenKey, queryMode, secretKey, ajaXCallURL);
		return false;
		callback();
	} catch (err) {
		callback();
		// console.log('Error in customcode', err);
	}
}
function getRecordByIDProcessBeforeCall996816(paramsType, callback) {
	var response = paramsType;

	if (getParameterByName('bazaarid') && getParameterByName('bazaarid') != 'undefined') { paramsType.recordID = getParameterByName('bazaarid') } else if (getParameterByName('recordID') && getParameterByName('recordID') != 'undefined') { paramsType.recordID = getParameterByName('recordID') }; callback();
}
function getRecordByIDProcessAfterCall996816(response, callback) {
	callback();
}
function getRecordByIdUsermanagement5da73cac545050343288ce7a(paramsEdit) {
	var ajaXCallURL = $("#ajaXCallURL").val();
	//	getRecordByIDProcessBeforeCallusermanagement(paramsEdit, function (processBeforeRes) {
	paramsEdit.tokenKey = getParameterByName('tokenKey');
	paramsEdit.secretKey = getParameterByName('secretKey');
	var isMobile = $('#isMobile').val();
	$.ajax({
		url: ajaXCallURL + '/milestone003/get_data_by_record_Usermanagement5da73cac545050343288ce7aapp_clientprofile',
		data: paramsEdit,
		type: 'POST',
		jsonpCallback: 'callback',
		success: function (response) {
			$('#display_loading').addClass('hideme');
			if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
				var objParamsList = {};
				objParamsList.queryMode = queryMode;;
				var tokenKey = getParameterByName('tokenKey');
				objParamsList.tokenKey = tokenKey;;
				objParamsList.isMobile = isMobile;
				var tempobj = response.recordDetails[0]
				response.recordDetails = tempobj;
				//usenamediv
				if (response.recordDetails.name != undefined)
					$('#usenamediv').html(response.recordDetails.name);
				$('#usenamediv').html(response.recordDetails.name);
				let createdOn = response.recordDetails.createdOn ? moment(response.recordDetails.createdOn).format('DD/MM/YY') : ''
				if (createdOn != '') $('#joineddate156').html(`Joined on ${createdOn}`);
				// $('#profileuserName2').html(response.recordDetails.name),$('#name111').append(response.recordDetails.name);;
				// getRecordByIDProcessAfterCallusermanagement(response.recordDetails, function (processBeforeRes) {
				//   if (!$('#backbutton1').html()) {
				// 	$('#backbutton1').append(response.recordDetails.undefined);
				//   }
				//   if (response.recordDetails.dateofbirth != undefined) $('#dateofbirth14').val(response.recordDetails.dateofbirth), $('#dobtodisplay').append(response.recordDetails.dateofbirth), $('#profileDateOfBirth').append(response.recordDetails.dateofbirth);
				//   if (response.recordDetails.email != undefined) $('#email12').val(response.recordDetails.email), $('#email122').append(response.recordDetails.email), $('#profileEmail').append(response.recordDetails.email);
				//   if (response.recordDetails.gender) {
				// 	$('#gender15').val(response.recordDetails.gender);
				// 	$('#profileGender').html(response.recordDetails.gender);
				// 	$('#gender15').material_select();
				// 	if (dropdownvalues) dropdownvalues['gender'] = response.recordDetails.gender;
				// 	$('#gender15').val(response.recordDetails.gender);
				// 	$('#gender155').append(response.recordDetails.gender);
				//   }
				//   if (response.recordDetails.contactnumber != undefined) {
				// 	if (response.recordDetails.contactnumber_dialcode) {
				// 	  response.recordDetails.contactnumber = response.recordDetails.contactnumber.toString();
				// 	  response.recordDetails.contactnumber = response.recordDetails.contactnumber.replace('+' + response.recordDetails.contactnumber_dialcode, '');
				// 	  $('#contactnumber13').intlTelInput('setCountry', response.recordDetails.contactnumber_countrycode);
				// 	  var sampleNumber = intlTelInputUtils.getExampleNumber(response.recordDetails.contactnumber_countrycode, false, 1);
				// 	  var placeholder = sampleNumber.replace('+' + response.recordDetails.contactnumber_dialcode + ' ', '');
				// 	  var mask1 = placeholder.replace(/[0-9]/g, 0);
				// 	  $('#contactnumber13').val(response.recordDetails.contactnumber);
				// 	  // var demoNumber = response.recordDetails.contactnumber;
				// 	  // var demoCode = response.recordDetails.contactnumber_dialcode;
				// 	  // var numberWithCode = demoCode + " " + demoNumber;
				// 	  // $('#contactedit').append(numberWithCode);
				// 	  $('#contactnumber13').mask(mask1);
				// 	  $('#contactnumber13').val($('#contactnumber13').masked(response.recordDetails.contactnumber));
				// 	  $('#profileContactNumber').html(response.recordDetails.contactnumber);
				// 	} else {
				// 	  $('#contactnumber13').val(response.recordDetails.contactnumber);
				// 	  $('#profileContactNumber').html(response.recordDetails.contactnumber);
				// 	}
				//   }
				//   if (response.recordDetails.name != undefined) $('#name11').val(response.recordDetails.name), $('#profileuserName2').html(response.recordDetails.name),$('#name111').append(response.recordDetails.name);;
				//   // if(response.recordDetails.password != undefined) $('#password16').val(response.recordDetails.password);
				//   if (!$('#profile2').html()) {
				// 	$('#profile2').append(response.recordDetails.undefined);
				//   }
				//   if (!$('#update3').html()) {
				// 	$('#update3').append(response.recordDetails.undefined);
				//   }
				//   if (!$('#name9').html()) {
				// 	$('#name9').append(response.recordDetails.name);
				//   }
				if (response.recordDetails.userphotoupload && response.recordDetails.userphotoupload[0] && response.recordDetails.userphotoupload[0].mediaID) {
					var url = CDN_PATH + response.recordDetails.userphotoupload[0].mediaID + '_compressed.png';
				} else {
					var url = 'image_logo.png'
				}
				$('#userphotoupload8').attr("src", url).attr('onerror', "this.src='https://appscdn-us.hokuapps.com/card.png'");
				//   if (response.recordDetails.offlineDataID) {
				// 	localStorage.setItem("offlineDataID", response.recordDetails.offlineDataID);
				//   }
				// }) // end of process after call 
				$('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

				Materialize.updateTextFields();


			}
		},
		error: function (xhr, status, error) {
		},
		// });
	}); // end of getRecord By ID
}
function showBottomMenu() {
	var menuObj = localStorage.getItem('objGetUserDetailsWithmenu');
	if (menuObj) {
		menuObj = JSON.parse(menuObj);
		if (menuObj.data && menuObj.data.roleName) {
			var roleName = menuObj.data.roleName;
		}
	}
	try {
		var roleName = localStorage.getItem('roleName');
		var clientIcon = "icon_clientactive.svg"
		var notificationicon = "icon_calendar.svg"

		if (roleName == "consultant") {
			clientIcon = "icon_team.png";
			notificationicon = "icon_calendar.svg"

		}
		var appUser = JSON.parse(localStorage.getItem("appUser"));
		var notificationCount = 0
		if (appUser.notificationunreadcount) {
			notificationCount = appUser.notificationunreadcount
		}
		$("#notificationcount5").html(notificationCount)
		var appointmentunreadcount = 0
		if (appUser.appointmentunreadcount) {
			appointmentunreadcount = appUser.appointmentunreadcount
		}
		var roleName = localStorage.getItem('roleName');
		var clientIcon = "icon_client.svg"
		var notificationicon = "icon_notification.svg"

		if (roleName == "consultant") {
			clientIcon = "icon_team.png";
			notificationicon = "icon_calendar.svg"

		}
		var appUser = JSON.parse(localStorage.getItem("appUser"));
		var notificationCount = 0
		if (appUser.notificationunreadcount) {
			notificationCount = appUser.notificationunreadcount
		}
		$("#notificationcount5").html(notificationCount)
		var appointmentunreadcount = 0
		if (appUser.appointmentunreadcount) {
			appointmentunreadcount = appUser.appointmentunreadcount
		}
		var roleName = localStorage.getItem('roleName');
		var clientIcon = "icon_client.svg"
		var notificationicon = "icon_notification.svg"

		if (roleName == "consultant") {
			clientIcon = "icon_team.png";
			notificationicon = "icon_calendar.svg"

		}
		var bottommenu = '';
		// bottommenu += '<div class="mobilebottommenu">'
		// bottommenu += '    <div class="row">'
		// bottommenu += '    <div class="menuwrapper " style="width: 16% !important;"><a class="redirecttopage" nativeredirect="" id="Home" fileName="app_consultantuserhome_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_home.svg"><span>Home</span></a></div>'
		// bottommenu += '    <div class="menuwrapper " style="width: 15% !important;"><a class="redirecttopage" nativeredirect="" id="Client" fileName="app_consultantclientlisting_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="' + clientIcon + '"><span>Clients</span></a></div>'
		// bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Appointments" fileName="app_consultantrequestappointmentslisting_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="AppointmentWhite.svg"><span>Appointments</span></a><div  id="appointmentCount"  class="chatunreadcount active">0</div></div>'
		// bottommenu += '    <div class="menuwrapper "><a class="redirecttopage" nativeredirect="" id="Chat" fileName="undefined_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_chat.svg"><span>Messages</span></a><div id="chatCount" style="display:none !important"  class="chatunreadcount active">0</div></div>'
		// bottommenu += '    <div class="menuwrapper " style="width: 18% !important;"><a class="redirecttopage" nativeredirect="" id="More" fileName="undefined_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_moreactive.svg"><span>Account</span></a></div>'
		// bottommenu += '    </div>'
		// bottommenu += '</div>'


		bottommenu += '<div class="mobilebottommenu">'
        bottommenu += '    <div class="row">'
        bottommenu += '    <div class="menuwrapper " style="width: 16% !important;"><a class="redirecttopage" nativeredirect="" id="Home" fileName="app_consultantuserhome_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_home.svg"><span>Home</span></a></div>'
        bottommenu += '    <div class="menuwrapper " style="width: 15% !important;"><a class="redirecttopage" nativeredirect="" id="Client" fileName="app_consultantclientlisting_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="' + clientIcon + '"><span>Clients</span></a></div>'
        bottommenu += '    <div class="menuwrapper " style="width: 27% !important;"><a class="redirecttopage" nativeredirect="" id="Appointments" fileName="app_consultantrequestappointmentslisting_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="AppointmentWhite.svg"><span>Appointments</span></a><div  id="appointmentCount"  class="chatunreadcount active">0</div></div>'
        bottommenu += '    <div class="menuwrapper " style="width: 19% !important;"><a class="redirecttopage" nativeredirect="" id="Chat" fileName="undefined_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_chat.svg"><span>Messages</span></a><div id="chatCount" style="display:none !important"   class="chatunreadcount active">0</div></div>'
        bottommenu += '    <div class="menuwrapper " style="width: 18% !important;"><a class="redirecttopage" nativeredirect="" id="More" fileName="app_consultantcustmoreinfodetails_5da73cac545050343288ce7a.html" queryMode="mylist"  href="javascript:void(0);"><img src="icon_moreactive.svg"><span>Account</span></a></div>'
        bottommenu += '    </div>'
        bottommenu += '</div>'
		$('#bottommenu30').html(bottommenu)
	} catch (err) {
		// console.log('Error in showBottomMenu', err);
	}
}
