
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
     var totaldcard_collectioncontainer = 0;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];


  var queryMode = getParameterByName('queryMode');
      var isMobile = $('#isMobile').val();
      var isiPad = $('#isiPad').val();
      if(queryMode != ''){
          var tokenKey = $('#tokenKey').val();
          var objParamsList = {};
          objParamsList.queryMode = queryMode;
          var ajaXCallURL = $.trim($('#ajaXCallURL').val());
          objParamsList.tokenKey = getParameterByName('tokenKey');
          objParamsList.secretKey = getParameterByName('secretKey');
          objParamsList.ajaXCallURL = ajaXCallURL;
          objParamsList.isMobile = isMobile;
          objParamsList.isiPad = isiPad;
          objParamsList.applyFilter = false;
          getDataProcessBeforeCalldcard_collectioncontainerFaq5da73cac545050343288ce7a(objParamsList,function(processBeforeRes){
 var  applyFilter = getParameterByName('applyFilter');
 if(applyFilter == null && objParamsList.applyFilter == false ){
 objParamsList.type =  'faq';
    objParamsList.applystaticfilter = true;
 }
          var dcard_collectioncontainerapp_consultantfaqlisting = localStorage.getItem('dcard_collectioncontainerapp_consultantfaqlisting');
          var  applyFilter = getParameterByName('applyFilter');
          $('#display_loading').removeClass('hideme');
          if (dcard_collectioncontainerapp_consultantfaqlisting && applyFilter != 'true' ) {
              response = JSON.parse(dcard_collectioncontainerapp_consultantfaqlisting);
              $('#collectioncontainerDivdcard_collectioncontainer').html('');
              getdcard_collectioncontainerapp_consultantfaqlistingMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
              dcard_collectioncontainerapp_consultantfaqlistingSync(response.timestamp);   
          } else {
         show_dcard_collectioncontainerapp_consultantfaqlisting_Details(objParamsList)
          }
          });//End of get data process before call.
  }

		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_consultantcustmoreinfodetails'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "update"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
});//end of ready
 function getDataProcessBeforeCalldcard_collectioncontainerFaq5da73cac545050343288ce7a(objParamsList,callback){
      var response = objParamsList

      callback();
 }
 function dcard_collectioncontainerapp_consultantfaqlistingSync(timestamp) {
     try {
         var objParamsList = {};
         objParamsList.queryMode = 'mylist';
         var ajaXCallURL = $.trim($('#ajaXCallURL').val());
         objParamsList.tokenKey = getParameterByName('tokenKey');
         objParamsList.secretKey = getParameterByName('secretKey');
         objParamsList.ajaXCallURL = ajaXCallURL;
         objParamsList.isMobile = true;
         objParamsList.timestamp = timestamp;
         $.ajax({
             url: objParamsList.ajaXCallURL + '/milestone003/syncListDetails_Faq5da73cac545050343288ce7a_app_consultantfaqlisting',
             data: objParamsList,
             type: 'POST',
             success: function (response) {
              $('#display_loading').addClass('hideme');
                 if (response.status != undefined && response.status == 1) {
                     localStorage.removeItem('dcard_collectioncontainerapp_consultantfaqlisting');
                     var objParamsList = {};
                     objParamsList.queryMode = 'mylist';
                     var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                     objParamsList.tokenKey = getParameterByName('tokenKey');
                     objParamsList.secretKey = getParameterByName('secretKey');
                     objParamsList.ajaXCallURL = ajaXCallURL;
                     objParamsList.isMobile = 'true';
                     objParamsList.isiPad = false;
                     objParamsList.timestamp = timestamp; 
 var  applyFilter = getParameterByName('applyFilter');
 if(applyFilter == null && objParamsList.applyFilter == false ){
 objParamsList.type =  'faq';
    objParamsList.applystaticfilter = true;
 }
         show_dcard_collectioncontainerapp_consultantfaqlisting_Details(objParamsList)
                 }
             },
             error: function (xhr, status, error) { 
                 handleError(xhr, status, error); 
             } 
         });
     } catch (err) {
        // console.log('Error in workingtoolsSync', err);
     }
 }
         function show_dcard_collectioncontainerapp_consultantfaqlisting_Details(objParamsList){ 
 var  applyFilter = getParameterByName('applyFilter');
 if(applyFilter == null && objParamsList.applyFilter == false ){
 objParamsList.type =  'faq';
    objParamsList.applystaticfilter = true;
 }
         localStorage.setItem('appconsultantfaqlistingFilterBox','');
 
          $.ajax({
              url: objParamsList.ajaXCallURL+'/milestone003/getListDetails_Faq5da73cac545050343288ce7a_app_consultantfaqlisting_dcard_collectioncontainer',
              data: objParamsList,
              type: 'POST',
              success: function (response) {
                      getDataProcessAfterCalldcard_collectioncontainerFaq5da73cac545050343288ce7a(response, function(){
                      if (response.status != undefined && response.status == 0) {
                     if (objParamsList.isMobile == 'true') {    
                             $('#collectioncontainerDivdcard_collectioncontainer').html('');
                             localStorage.removeItem('dcard_collectioncontainerapp_consultantfaqlisting');
                              getdcard_collectioncontainerapp_consultantfaqlistingMobileView(response, objParamsList.tokenKey, objParamsList.queryMode);
                          } else if (objParamsList.isiPad == 'true') {    
                              getdcard_collectioncontainerapp_consultantfaqlistingiPadView(response, objParamsList.tokenKey, objParamsList.queryMode);
                          } else {
                              getdcard_collectioncontainerapp_consultantfaqlistingWebView(response, objParamsList.tokenKey,objParamsList.queryMode);
                          }
                          $('#display_loading').addClass('hideme');
                     } else {   
                          $('#display_loading').addClass('hideme')
                     }   
                   });   
                  },        
                  error: function (xhr, status, error) {        
                          $('#display_loading').addClass('hideme')
                          handleError(xhr, status, error); 
                  },        
              });  
        } // end of function     
                  
 function getDataProcessAfterCalldcard_collectioncontainerFaq5da73cac545050343288ce7a(response,callback){

      callback();
 }

        function getdcard_collectioncontainerapp_consultantfaqlistingMobileView(response, tokenKey, queryMode) {
              var html = '';
              if (response.data.length == 0) {
                  html += '<div class="nodatafound">';
                  html +=     '<img src="nodatafound.gif" width="100%">';
                  html +=         '<br>';
                  html +=     '<!-- span>No record found</span -->';
                  html += '</div>';
                  $('#collectioncontainerDivdcard_collectioncontainer').html(html); ;
             } else {
              html =       '';
              var radioGroups =       [];
              $.each(response.data, function (keyList, objList) {
                  
               
 html += '      <div class="row plain-card search" search="'+ removeSpecialChars(  objList.question  + objList.answer) +'">';
 html += '      		<div class="col s12 m12">';
 html += '               <div class="card-content">';
 html += '                  <div     status="'+ objList.status+ '"  recordID="'+objList._id+'" class="shimmer card  view_list_record dcard_collectioncontainer" style="" >';
 html += '      <div class="row  element" style=""  >';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg9150  '+adddbclass+' " style=" cursor: pointer;">';
 objList['question'] = objList['question'] ? objList['question'] : '';
 if(response.showShimmer){
    objList['question'] = '';
 }
 var question = objList['question'];
 html += '           <div recordID="' + objList._id +'"   id="question9" class="languagetranslation " style="" >'+ question+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg1250  '+adddbclass+' " style=" cursor: pointer;">';
 objList['answer'] = objList['answer'] ? objList['answer'] : '';
 if(response.showShimmer){
    objList['answer'] = '';
 }
 var answer = objList['answer'];
 html += '           <div recordID="' + objList._id +'"   id="answer10" class="languagetranslation " style="" >'+ answer+'</div>';
 html += '     </div>';
 html += '     </div>';
 html += '      				</div>';
 html += '          </div>';
 html += '        </div>';
 html += '     </div>';
 html += '   </div>';
             });
                          $('#collectioncontainerDivdcard_collectioncontainer').html(html)
                   $('#full-body-container').addClass('fadeInUp');
                  if(!response.showShimmer){
                      dcardLoaded['dcard_collectioncontainer'] = true;
                      $('#collectioncontainerDivdcard_collectioncontainer').find('.view_list_record').removeClass('shimmer');
                  }
                  $('.carddropdown').material_select();
                  $('<input>').attr({type: 'hidden',class: 'cardtoggleswitch',id: 'togleswitchvalue'}).appendTo('body')
                  if($('.js-candlestick').length) $('.js-candlestick').candlestick({afterSetting: function(input, wrapper, value) {$('#togleswitchvalue').val(value).attr('recordID', input.attr('id')).trigger('click');}});
                  if(radioGroups && radioGroups.length){
                      for(var key in radioGroups){
                          var groupName = radioGroups[key];
                          $('input:radio[name='+ groupName +']:first').prop('checked', true);
                          $('input:radio[name='+ groupName +']:first').trigger('change');
                      }
                  }
              };
            };
            function getLocalImagedcard_collectioncontainer(objList, mediaID, fileName) {
                try {
                    var appJSON = {};
                    appJSON.nextButtonCallback = 'handleLocalImagedcard_collectioncontainer';
                    appJSON.url = CDN_PATH + mediaID+ '_compressed.png';
                    appJSON.fileMimeType = 'image/png';
                    appJSON.fileName = fileName;
                    appJSON.objList = objList;
                    var isAndroid = navigator.userAgent.toLowerCase().indexOf("android");
                    if (isAndroid > -1) {
                        window.Android.getLocalImage(JSON.stringify(appJSON))
                    } else {
                        setupWebViewJavascriptBridge(function (bridge) {
                            bridgeObj = bridge;
                            bridgeObj.callHandler('getLocalImage', appJSON, function (response) { });
                            bridgeObj.registerHandler('handleLocalImagedcard_collectioncontainer', function (responseData, responseCallback) {
                                handleLocalImagedcard_collectioncontainer(responseData)
                            });
                        });
                    }
                } catch (err) {
            
                }
            }
            function handleLocalImagedcard_collectioncontainer(response) {
               var objList = response.dataDictionay.objList;
               var html = '';
               
 html += '      <div class="row plain-card search" search="'+ removeSpecialChars(  objList.question  + objList.answer) +'">';
 html += '      		<div class="col s12 m12">';
 html += '               <div class="card-content">';
 html += '                  <div     status="'+ objList.status+ '"  recordID="'+objList._id+'" class="shimmer card  view_list_record dcard_collectioncontainer" style="" >';
 html += '      <div class="row  element" style=""  >';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg9150  '+adddbclass+' " style=" cursor: pointer;">';
 objList['question'] = objList['question'] ? objList['question'] : '';
 if(response.showShimmer){
    objList['question'] = '';
 }
 var question = objList['question'];
 html += '           <div recordID="' + objList._id +'"   id="question9" class="languagetranslation " style="" >'+ question+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg1250  '+adddbclass+' " style=" cursor: pointer;">';
 objList['answer'] = objList['answer'] ? objList['answer'] : '';
 if(response.showShimmer){
    objList['answer'] = '';
 }
 var answer = objList['answer'];
 html += '           <div recordID="' + objList._id +'"   id="answer10" class="languagetranslation " style="" >'+ answer+'</div>';
 html += '     </div>';
 html += '     </div>';
 html += '      				</div>';
 html += '          </div>';
 html += '        </div>';
 html += '     </div>';
 html += '   </div>';
               $('#collectioncontainerDivdcard_collectioncontainer').append(html)
              $('#full-body-container').addClass('fadeInUp');
        dcardLoaded['dcard_collectioncontainer'] = true;
        $('#collectioncontainerDivdcard_collectioncontainer').find('.view_list_record').removeClass('shimmer');
        // after html bining code
        };

        function getdcard_collectioncontainerapp_consultantfaqlistingPadView(response, tokenKey, queryMode) {
              var html = '';
              if (response.data.length == 0) {
                              html += '<tr>';
                              html +=     '<td colspan="1" class="text_center first_row_table_td">';
                              html +=         'No record found';
                              html +=     '</td>';
                              html += '</tr>';
             } else {
              html =       '';
              $.each(response.data, function (keyList, objList) {
               
 html += '      <div class="row plain-card search" search="'+ removeSpecialChars(  objList.question  + objList.answer) +'">';
 html += '      		<div class="col s12 m12">';
 html += '               <div class="card-content">';
 html += '                  <div     status="'+ objList.status+ '"  recordID="'+objList._id+'" class="shimmer card  view_list_record dcard_collectioncontainer" style="" >';
 html += '      <div class="row  element" style=""  >';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg9150  '+adddbclass+' " style=" cursor: pointer;">';
 objList['question'] = objList['question'] ? objList['question'] : '';
 if(response.showShimmer){
    objList['question'] = '';
 }
 var question = objList['question'];
 html += '           <div recordID="' + objList._id +'"   id="question9" class="languagetranslation " style="" >'+ question+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg1250  '+adddbclass+' " style=" cursor: pointer;">';
 objList['answer'] = objList['answer'] ? objList['answer'] : '';
 if(response.showShimmer){
    objList['answer'] = '';
 }
 var answer = objList['answer'];
 html += '           <div recordID="' + objList._id +'"   id="answer10" class="languagetranslation " style="" >'+ answer+'</div>';
 html += '     </div>';
 html += '     </div>';
 html += '      				</div>';
 html += '          </div>';
 html += '        </div>';
 html += '     </div>';
 html += '   </div>';
              }); // end of each loop
            };
              $('#collectioncontainerDivdcard_collectioncontainer').html(html)
        };

        function getdcard_collectioncontainerapp_consultantfaqlistingWebView(response, tokenKey, queryMode) {
              var html = '';
              if (response.data.length == 0) {
                              html += '<tr>';
                              html +=     '<td colspan="1" class="text_center first_row_table_td">';
                              html +=         'No record found';
                              html +=     '</td>';
                              html += '</tr>';
             } else {
              html =       '';
              $.each(response.data, function (keyList, objList) {
               
 html += '      <div class="row plain-card search" search="'+ removeSpecialChars(  objList.question  + objList.answer) +'">';
 html += '      		<div class="col s12 m12">';
 html += '               <div class="card-content">';
 html += '                  <div     status="'+ objList.status+ '"  recordID="'+objList._id+'" class="shimmer card  view_list_record dcard_collectioncontainer" style="" >';
 html += '      <div class="row  element" style=""  >';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg9150  '+adddbclass+' " style=" cursor: pointer;">';
 objList['question'] = objList['question'] ? objList['question'] : '';
 if(response.showShimmer){
    objList['question'] = '';
 }
 var question = objList['question'];
 html += '           <div recordID="' + objList._id +'"   id="question9" class="languagetranslation " style="" >'+ question+'</div>';
 html += '     </div>';
 var adddbclass = ''
 html += '           <div recordID="'+objList._id+'" class="col s12 clssg1250  '+adddbclass+' " style=" cursor: pointer;">';
 objList['answer'] = objList['answer'] ? objList['answer'] : '';
 if(response.showShimmer){
    objList['answer'] = '';
 }
 var answer = objList['answer'];
 html += '           <div recordID="' + objList._id +'"   id="answer10" class="languagetranslation " style="" >'+ answer+'</div>';
 html += '     </div>';
 html += '     </div>';
 html += '      				</div>';
 html += '          </div>';
 html += '        </div>';
 html += '     </div>';
 html += '   </div>';
             }); // end of each loop 1
            };
              $('#collectioncontainerDivdcard_collectioncontainer').html(html)
        };