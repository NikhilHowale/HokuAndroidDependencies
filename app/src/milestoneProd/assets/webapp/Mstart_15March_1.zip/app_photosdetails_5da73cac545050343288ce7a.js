
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_photoslisting'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "mylist"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
      var paramsEdit = {};
      paramsEdit.tokenKey = getParameterByName('tokenKey');
      paramsEdit.secretKey = getParameterByName('secretKey') 
                       getRecordByIDProcessBeforeCall197166(paramsEdit, function (processBeforeRes) {
      $.ajax({
          url: ajaXCallURL+'/milestone003/getRecordByCustomeQuery_app_photosdetails_Photos5da73cac545050343288ce7a',
          data: paramsEdit,
          type: 'POST',
          jsonpCallback: 'callback',
          success: function (response) { 
                       getRecordByIDProcessAfterCall197166(response, function (processBeforeRes) {
              if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                  var objParamsList = {};
                  var queryMode = $('#queryMode').val(); 
                  objParamsList.queryMode = queryMode;;
                  var tokenKey = $('#tokenKey').val();;
                  objParamsList.tokenKey = tokenKey;;
  if(!$('#backbutton1').html()){
            $('#backbutton1').append(response.recordDetails.undefined);
 }
    // getrecordbycustomquery - Stage - 111111111111
    if(response.recordDetails['photoupload'] && response.recordDetails['photoupload'].length > 0 ) {
    	if(response.recordDetails['photoupload'][0].displayType = 'html'){
    		var eleParent = $('#photoupload6').parent();
    	    for(var key in response.recordDetails['photoupload']){
    	        var objImage = response.recordDetails['photoupload'][key];
if(response.recordDetails['photoupload'][key].name=='Audio'){
         var token =  $('#tokenKey').val();
         if( token && token != '' ){
             token = $('#tokenKey').val();
         }else {
             token = getParameterByName('tokenKey');
         }
         var mediaIDa = response.recordDetails['photoupload'][0].mediaID
         var filenamea = response.recordDetails['photoupload'][0].fileName
          var CDN_PATH2 = 'https://devfiles.hokuapps.com/downloadOriginal?f='+mediaIDa+'&fn='+filenamea+'&t='+token
          var url = CDN_PATH2
}else{
 var filetodisplay = getuploadedfilepreview(objImage.fileNm); 
 if(filetodisplay && filetodisplay != objImage.fileNm){
          var url = filetodisplay ;
 } else {
          var url = CDN_PATH + objImage.mediaID+'_compressed.png';
 }
}
if(response.recordDetails['photoupload'][key].name=='Audio'){
    	        var html = '';
               html+='<div class="col s12" style="float: right;">'
               html+='<audio class="" src="' + url + '" controls></audio>'
               html+='</div>'
}else{
               var html = '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + url + '" />';
}
    	        if(!key || key == '0'){
    	        	eleParent.html(html);
    	        } else {
    	        	eleParent.append(html);
    	        } 
    	    }                
    	} else {
if(response.recordDetails['photoupload'][key].name=='Audio'){
    	    var url = CDN_PATH + response.recordDetails['photoupload'][0].mediaID;
}else{
    	    var url = CDN_PATH + response.recordDetails['photoupload'][0].mediaID+'_compressed.png';
}
    	    $('#photoupload6').attr("src", url);
    	}
    } 
  if(!$('#photos2').html()){
            $('#photos2').append(response.recordDetails.undefined);
 }

              Materialize.updateTextFields();
                $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);
  
              } 
              }); // end of getRecord By ID
          },
          error: function (xhr, status, error) {
              handleError(xhr, status, error); 
          },
      }); 
              }); // end of getRecord By ID
   
});//end of ready 
                 function getRecordByIDProcessBeforeCall197166(paramsType,callback) { 
                 var response = paramsType;
 
if(getParameterByName('photosid') && getParameterByName('photosid') != 'undefined'){paramsType.recordID = getParameterByName('photosid')} else if(getParameterByName('recordID') && getParameterByName('recordID') != 'undefined'){paramsType.recordID = getParameterByName('recordID')};callback(); 
                 } 
                 function getRecordByIDProcessAfterCall197166(response,callback) {
 callback(); 
                 }