
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
var totaldcard_topimage2_collectioncontainer = 0;
$(document).ready(function () {
    $(".bodytabs").scrollLeft( 500 );
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"))
    }
                  var roleName = localStorage.getItem('roleName');
                  if (roleName == "consultant") {
                  
                  $("#sg1907").hide()
                  }
    var objParamsToken = {};
                  
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsToken.tokenKey = getParameterByName('tokenKey');
    objParamsToken.secretKey = getParameterByName('secretKey');

    var userRole = $('#userRole').val();
    var userID = $('#userID').val();
    var createrOfRecord = $('#createrOfRecord').val();
    var queryMode = getParameterByName('queryMode');
    var recordID = $.trim($('#recordID').val());
    var addSessionComments = [];
    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#backbutton1', function (e) {
        try {
            var element = $(this);
            var parent = getParameterByName('parent');
            var nextPage = 'app_allfinancialservicessteponelist';
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "mylist";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - backbutton1", error)
        }
    })
    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    getbannerImage();
    // $(document).on('click', '#myevents7', function (e) {
    //     try {
    //         var element = $(this);
    //         var nextPage = 'app_myupcomingeventslist';
    //         var queryParams = queryStringToJSON();
    //         queryParams["queryMode"] = "mylist";
    //         var recordID = $(this).attr("recordID");
    //         if (recordID) {
    //             queryParams["recordID"] = recordID;
    //         }
    //         var queryString = $.param(queryParams);
    //         queryString = queryString.replace(/\+/g, "%20");
    //         queryString = decodeURIComponent(queryString);
    //         window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
    //         return false;
    //     } catch (error) {
    //         console.log("Error in pageredirect workflow - myevents7", error)
    //     }
    // })
});//end of ready




$(document).on('click', '#myevents7', function (e) {
    try {
        var element = $(this);
        var nextPage = 'app_allmerchantdiscountslist';
        var queryParams = queryStringToJSON();
        queryParams["queryMode"] = "mylist";
        var recordID = $(this).attr("recordID");
        if (recordID) {
            queryParams["recordID"] = recordID;
        }
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
        return false;
    } catch (error) {
        console.log("Error in pageredirect workflow - myevents7", error)
    }
});


$(document).on('click', '#allevents8', function (e) {
    try {
        var element = $(this);
        var nextPage = 'app_alleventpromotionslist';
        var queryParams = queryStringToJSON();
        queryParams["queryMode"] = "mylist";
        var recordID = $(this).attr("recordID");
        if (recordID) {
            queryParams["recordID"] = recordID;
        }
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
        return false;
    } catch (error) {
        console.log("Error in pageredirect workflow - myevents7", error)
    }
});

$(document).on('click', '#financeevents7', function (e) {
    try {
        var element = $(this);
        var nextPage = 'app_allfinancialserviceslist';
        var queryParams = queryStringToJSON();
        queryParams["queryMode"] = "mylist";
        var recordID = $(this).attr("recordID");
        if (recordID) {
            queryParams["recordID"] = recordID;
        }
        var queryString = $.param(queryParams);
        queryString = queryString.replace(/\+/g, "%20");
        queryString = decodeURIComponent(queryString);
        window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
        return false;
    } catch (error) {
        console.log("Error in pageredirect workflow - myevents7", error)
    }
});



function getbannerImage() {
    var paramsType = {};
    paramsType.tokenKey = getParameterByName("tokenKey");
    paramsType.secretKey = getParameterByName("secretKey");
    paramsType.bannershowtype = 'Financial Planning Step 2';
    //getCountProcessBeforeCallbannerimageupload6(paramsType, function (processBeforeRes) {
    var ajaXCallURL = $.trim($("#ajaXCallURL").val());
    $.ajax({
      url: ajaXCallURL + "/milestone003/showslider_app_allfinancialserviceslist_Financialbanner5da73cac545050343288ce7alblbannerbannerimageupload",
      data: paramsType,
      type: "POST",
      success: function (response) {
        // localStorage.setItem("bannerimages", JSON.stringify(response));

        if (response.status == 0) {
          makeSlidesbannerimageupload6(response.data);
        } else {
          makeSlidesbannerimageupload6([]);
        }
      },
      error: function (xhr, status, error) {},
    });
    // });
}
  

function makeSlidesbannerimageupload6(data) {
    var slide = "";
    var htmlString = "";
    let title = '';
    let description = '';
    if (data && data.length == 1) {
        title = data[0].title || '';
        description = data[0].description || '';
      data = data[0].userphotoupload ? data[0].userphotoupload : [];
    }
    if (data && data.length > 0) {
      for (let index = 0; index < data.length; index++) {
        const element = data[index];
        var mediaID;
        if (element && element.userphotoupload && element.userphotoupload[0]) {
          mediaID = element.userphotoupload[0].mediaID;
        } else if (element && element.mediaID) {
          mediaID = element.mediaID;
        }
        if (data[index] && data.length != 1) {
            title = data[index].title || '';
            description = data[index].description || '';
         }
        slide += ' <div class="swiper-slide" href="#one!" >';
        slide += '    <div class="row  col s12" style="padding: 0px" !important;>';
        slide += '       <div id="image6_div" style="text-align: center;">';
        slide += '          <img  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'" src="' + CDN_PATH + mediaID + '_compressed.png" style="width:100%; height:364px;">';
        slide += "       </div>";
        slide += "    </div>";
        slide += '    <div class="row  col s12" style="padding: 0px;font-size:21px;font-weight:bold;color:#b18d4f; text-align:center !important;font-size: 18px !important; line-height: 22px !important;font-weight : bold !important;font-family: \'Roboto\', sans-serif !important; color : #af935d !important;margin-top:5px !important;padding: 0px 50px !important;"> '+title+'';
      slide += '    </div>';
      slide += '    <div class="row  col s12" style="padding: 0px;font-size:14px;font-weight:bold;color:#000000a8; text-align:center !important;font-size: 16px !important; line-height: 20px !important;font-weight : bold !important;font-family: \'Roboto\', sans-serif !important; color : #000000b5 !important;margin-top:5px !important;padding: 0px 50px !important;"> '+description+'';
      slide += '    </div>';
        slide += "        </div>";
      }
      if (slide) {
        $("#bannerimageupload6").html(slide);
      }
      var swiper = new Swiper(".swiper-container", {
        autoplay: {
          delay: 2500,
          disableOnInteraction: false,
        },
        watchOverflow: true,
        pagination: {
          el: ".swiper-pagination",
        },
      });
      $(".dynamic-slider-view").removeClass("shimmer");
    }
}
  



// $(document).on('click', '#next7', function (e) {
//   try {
//       var element = $(this);
//       var parent = getParameterByName('parent');
//       var nextPage = 'app_allfinancialservicesstepfinallist';
//       var queryParams = queryStringToJSON();
//       queryParams["queryMode"] = "mylist";
//       var recordID = $(this).attr("recordID");
//       if (recordID) {
//           queryParams["recordID"] = recordID;
//       }
//       var queryString = $.param(queryParams);
//       queryString = queryString.replace(/\+/g, "%20");
//       queryString = decodeURIComponent(queryString);
//       window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
//       return false;
//   } catch (error) {
//       console.log("Error in pageredirect workflow - backbutton1", error)
//   }
// })

$(document).on('click', '#next7', function (e) {
  try {
      var element = $(this);
      var parent = getParameterByName('parent');
      var nextPage = 'app_allfinancialservicesstepfinallist';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "mylist";
      var recordID = $(this).attr("recordID");
      if (recordID) {
          queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
  } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error)
  }
})
