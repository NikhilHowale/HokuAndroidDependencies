
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
         var paramsType = {};
             getRegion(paramsType);
      var paramsEdit = {};
      paramsEdit.tokenKey = getParameterByName('tokenKey');
      paramsEdit.secretKey = getParameterByName('secretKey') 
                       getRecordByIDProcessBeforeCall934410(paramsEdit, function (processBeforeRes) {
      $.ajax({
          url: ajaXCallURL+'/milestone003/getRecordByCustomeQuery_app_addressedit_Addresses5da73cac545050343288ce7a',
          data: paramsEdit,
          type: 'POST',
          jsonpCallback: 'callback',
          success: function (response) { 
                       getRecordByIDProcessAfterCall934410(response, function (processBeforeRes) {
              if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                  var objParamsList = {};
                  var queryMode = $('#queryMode').val(); 
                  objParamsList.queryMode = queryMode;;
                  var tokenKey = $('#tokenKey').val();;
                  objParamsList.tokenKey = tokenKey;;
             if(response.recordDetails.address != undefined) $('#address13').val(response.recordDetails.address);
             if(response.recordDetails.addressline != undefined) $('#addressline14').val(response.recordDetails.addressline);
              $('#addressesnumber21_value').html(response.recordDetails.addressesnumber);
  if(!$('#backbutton1').html()){
            $('#backbutton1').append(response.recordDetails.undefined);
 }
             if(response.recordDetails.city != undefined) $('#city16').val(response.recordDetails.city);
              if(response.recordDetails.country){
              $('#country18').val(response.recordDetails.country);
              $('#country18').material_select();
                   if(dropdownvalues) dropdownvalues['country'] = response.recordDetails.country;
               $('#country18').val(response.recordDetails.country);
              }
  if(!$('#enteraddress8').html()){
            $('#enteraddress8').append(response.recordDetails.undefined);
 }
             if(response.recordDetails.fullname != undefined) $('#fullname10').val(response.recordDetails.fullname);
             if(response.recordDetails.addressstring != undefined) $('#addressstring19').val(response.recordDetails.addressstring);
             if(response.recordDetails.fulladdress != undefined) $('#fulladdress20').val(response.recordDetails.fulladdress);
             if(response.recordDetails.mobilenumber != undefined) { 
               if(response.recordDetails.mobilenumber_dialcode){
                  response.recordDetails.mobilenumber = response.recordDetails.mobilenumber.toString(); 
                   response.recordDetails.mobilenumber = response.recordDetails.mobilenumber.replace('+' + response.recordDetails.mobilenumber_dialcode, ''); 
                   $('#mobilenumber11').intlTelInput('setCountry', response.recordDetails.mobilenumber_countrycode);
                   var sampleNumber = intlTelInputUtils.getExampleNumber(response.recordDetails.mobilenumber_countrycode, false, 1);
                   var placeholder = sampleNumber.replace('+'+ response.recordDetails.mobilenumber_dialcode +' ', '');
                   var mask1 = placeholder.replace(/[0-9]/g, 0);
                   $('#mobilenumber11').val(response.recordDetails.mobilenumber); 
                   $('#mobilenumber11').mask(mask1);
                   $('#mobilenumber11').val($('#mobilenumber11').masked(response.recordDetails.mobilenumber));
               } else {
                   $('#mobilenumber11').val(response.recordDetails.mobilenumber); 
               }
             }
             if(response.recordDetails.pincode != undefined) $('#pincode12').val(response.recordDetails.pincode);
              if(response.recordDetails.region){
              $('#region15').val(response.recordDetails.region);
              $('#region15').material_select();
                   if(dropdownvalues) dropdownvalues['region'] = response.recordDetails.region;
               $('#region15').val(response.recordDetails.region);
              }
             if(response.recordDetails.state != undefined) $('#state17').val(response.recordDetails.state);
  if(!$('#update3').html()){
            $('#update3').append(response.recordDetails.undefined);
 }
  if(!$('#youraddresses2').html()){
            $('#youraddresses2').append(response.recordDetails.undefined);
 }

              Materialize.updateTextFields();
                $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);
  
              } 
              }); // end of getRecord By ID
          },
          error: function (xhr, status, error) {
              handleError(xhr, status, error); 
          },
      }); 
              }); // end of getRecord By ID
    
    $(document).on('click', '#backbutton1', function(e) { 
    		window.history.back();  
    		return false;  
    })
});//end of ready
 function processBeforeCallForgetfromothertable_app_addressedit_region_5da73cac545050343288ce7a_Region(paramsType,callback){
var response = paramsType;
 callback();
 }
 function processAfterCallForgetfromothertable_app_addressedit_region_5da73cac545050343288ce7a_Region(data,response,callback){
      callback();
 }
         function getRegion(paramsType){
         var ajaXCallURL = $.trim($('#ajaXCallURL').val());
         paramsType.tokenKey = getParameterByName('tokenKey');
         paramsType.secretKey = getParameterByName('secretKey');
         if(getParameterByName('recordID') && getParameterByName('recordID') != null && getParameterByName('recordID') != 'null'){
         		paramsType.recordID = getParameterByName('recordID');
         }
  		processBeforeCallForgetfromothertable_app_addressedit_region_5da73cac545050343288ce7a_Region(paramsType,function(processBeforeRes){
         $.ajax({
             url: ajaXCallURL+'/milestone003/getfromothertable_app_addressedit_region_5da73cac545050343288ce7a_Region',
             data: paramsType,
             type: 'POST',
             success: function(response) {
                 if (response.status == 0) {
  				processAfterCallForgetfromothertable_app_addressedit_region_5da73cac545050343288ce7a_Region(response.data,response, function(processBeforeRes){
 						//var selectOptionHtml = '<option value="">Region</option>';
 						var selectOptionHtml = '<option disabled selected value="">Select</option>';
 						$.each( response.data, function( keyList, objList ) {
								selectOptionHtml += '<option  value="'+objList._id+'">'+objList.regionname+'</option>';
 						});
 						$('#region15').html(selectOptionHtml);
 						$('#region15').material_select();
 						var region15 =  getParameterByName('region');
 						if(region15 != "" && region15 != null && region15 != 'null' ){
 						   $('#region15').val(region15);
 						   $('#region15').material_select();
 						}
               	})
                 } else {
                     
                 }
                 
             },
             error: function(xhr, status, error) {
                 
             },
         });
         });
                 } 
                 function getRecordByIDProcessBeforeCall934410(paramsType,callback) { 
                 var response = paramsType;
 
if(getParameterByName('addressesid') && getParameterByName('addressesid') != 'undefined'){paramsType.recordID = getParameterByName('addressesid')} else if(getParameterByName('recordID') && getParameterByName('recordID') != 'undefined'){paramsType.recordID = getParameterByName('recordID')};callback(); 
                 } 
                 function getRecordByIDProcessAfterCall934410(response,callback) {
 callback(); 
                 }