
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
  $('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
    $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

  var objParamsToken = {};
  var ajaXCallURL = $.trim($('#ajaXCallURL').val());
  objParamsToken.tokenKey = getParameterByName('tokenKey');
  objParamsToken.secretKey = getParameterByName('secretKey');

  var userRole = $('#userRole').val();
  var userID = $('#userID').val();
  var createrOfRecord = $('#createrOfRecord').val();
  var queryMode = getParameterByName('queryMode');
  var recordID = $.trim($('#recordID').val());
  var addSessionComments = [];
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#backbutton1', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_childcalculateadd';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "add";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - backbutton1", error)
    }
  })
  var addedRecords = [];
  localStorage.setItem('addedRecords', []);
  $(document).on('click', '#ok19', function (e) {
    try {
      var element = $(this);
      var nextPage = 'app_childcalculateadd';
      var queryParams = queryStringToJSON();
      queryParams["queryMode"] = "add";
      var recordID = $(this).attr("recordID");
      if (recordID) {
        queryParams["recordID"] = recordID;
      }
      var queryString = $.param(queryParams);
      queryString = queryString.replace(/\+/g, "%20");
      queryString = decodeURIComponent(queryString);
      window.location.href = nextPage + '_5da73cac545050343288ce7a.html?' + queryString
      return false;
    } catch (error) {
      console.log("Error in pageredirect workflow - ok19", error)
    }
  })
  $('#display_loading1').removeClass('hideme');
  var paramsEdit = {};
  paramsEdit.tokenKey = getParameterByName('tokenKey');
  paramsEdit.secretKey = getParameterByName('secretKey')
  getRecordByIDProcessBeforeCall685072(paramsEdit, function (processBeforeRes) {
    $.ajax({
      url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_financialchilddetails_Usermanagement5da73cac545050343288ce7a',
      data: paramsEdit,
      type: 'POST',
      jsonpCallback: 'callback',
      success: function (response) {
        getRecordByIDProcessAfterCall685072(response, function (processBeforeRes) {

          $('#display_loading1').addClass('hideme');
          $('#sg6833').removeClass('hideme');

          if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
            var objParamsList = {};
            var queryMode = $('#queryMode').val();
            objParamsList.queryMode = queryMode;;
            var tokenKey = $('#tokenKey').val();;
            objParamsList.tokenKey = tokenKey;;
            if (!$('#backbutton1').html()) {
              $('#backbutton1').append(response.recordDetails.undefined);
            }
            response.recordDetails['date_preserved'] = response.recordDetails['date'];
            response.recordDetails['date'] = response.recordDetails['date'] ? moment(new Date(response.recordDetails['date'])).format('DD MMM YYYY') : '';
            if (!$('#date8').html()) {
              $('#date8').append(response.recordDetails.date);
            }
            response.recordDetails['date'] = response.recordDetails['date_preserved'];
            if (!$('#time9').html()) {
              $('#time9').append(response.recordDetails.time);
            }
            if (!$('#childhooduniversityfunddetails2').html()) {
              $('#childhooduniversityfunddetails2').append(response.recordDetails.undefined);
            }
            if (response.recordDetails.fundrange1 != undefined) $('#fundrange115').val(response.recordDetails.fundrange1);
            if (response.recordDetails.fundrange2 != undefined) $('#fundrange216').val(response.recordDetails.fundrange2);
            if (response.recordDetails.incomerange1 != undefined) $('#incomerange117').val(response.recordDetails.incomerange1);
            if (response.recordDetails.incomerange2 != undefined) $('#incomerange218').val(response.recordDetails.incomerange2);
            //if (!$('#resultmessage12').html()) {
            //  var message = "Your Targeted Child University Fund Ranges From " + formatNumber(response.recordDetails.fundrange1) + " - "  + formatNumber(response.recordDetails.fundrange2)
              $('#resultmessage12').html(response.recordDetails.resultmessage);
           // }
            if (!$('#status10').html()) {
              $('#status10').append(response.recordDetails.status);
            }
            if (!$('#results7').html()) {
              $('#results7').append(response.recordDetails.undefined);
            }
            if (response.recordDetails.shortfall1 != undefined) $('#shortfall113').val(response.recordDetails.shortfall1);
            if (response.recordDetails.shortfall2 != undefined) $('#shortfall214').val(response.recordDetails.shortfall2);

            Materialize.updateTextFields();
            $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

          }
        }); // end of getRecord By ID
      },
      error: function (xhr, status, error) {
        handleError(xhr, status, error);
      },
    });
  }); // end of getRecord By ID

});//end of ready 
function getRecordByIDProcessBeforeCall685072(paramsType, callback) {
  var response = paramsType;

  paramsType.recordID = localStorage.userID;
  callback();
}
function formatNumber(num) {
  return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, '$1,')
}
function getRecordByIDProcessAfterCall685072(response, callback) {

var university14 =   localStorage.getItem("univesity");
var coursename16 = localStorage.getItem("course");
response.recordDetails.incomerange1 = response.recordDetails.incomerange1 ? response.recordDetails.incomerange1 : 0;
response.recordDetails.incomerange2 = response.recordDetails.incomerange2 ? response.recordDetails.incomerange2 : 0; 
  var resultmessage = 'Something went wrong, please try again later.';
  if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
    resultmessage = "For "+university14+" and "+coursename16+" courses, your targeted Child University Fund ranges from <b>$" +  formatNumber(response.recordDetails.fundrange1) + " - $" +  formatNumber(response.recordDetails.fundrange2) + "</b>.<br/> <br/> ";
    resultmessage += "To achieve your goal, the amount that you need to save per month is <b>$" +  formatNumber(response.recordDetails.incomerange1.toFixed(2)) + "</b> to <b>$" +  formatNumber(response.recordDetails.incomerange2.toFixed(2)) + "</b>.<br/><br/>"; //Based on average inflation rate of <b>" +  formatNumber(response.recordDetails.inflationrate) + "% </b>, you need to save <b>$" +  formatNumber(response.recordDetails.incomerange1.toFixed(2)) + " - $" + response.recordDetails.incomerange2.toFixed(2) + "</b> per month in order to achieve this goal before your child reaches <b>" + response.recordDetails.universityage + "</b>.<br/><br/>";
    resultmessage += "To find out how you can save up for your Child’s education fund efficiently, you might want to seek advice from a professional financial consultant.<br/>";
  }
  $('div[id^="resultmessage"]').html(resultmessage);
  callback();
}