
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
     var totalshowaddresslist = 0;
$(document).ready(function() {
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '.delivertoaddress', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_ordersummarydetails'; 
				var queryParams = queryStringToJSON(); 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
      		var objResponse = {};
      		objResponse.recordID = recordID;
      		pageredirectProcessBeforeCallDelivertothisaddress(element, queryParams,objResponse, function(updatedNextPage){
     		 	if(objResponse.nextPage){
     		 		nextPage = objResponse.nextPage
     		 	}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
    		}) 
		} catch(error){ 
			console.log("Error in pageredirect workflow - delivertoaddress", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '.editaddress', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_addressedit'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "edit"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - editaddress", error) 
		} 
	})
	$(document).on('change', '.cardradiobutton', function(e) {
	    var recordID = $(this).attr('recordID');
	        $('.deleteaddress').addClass('hide')    
	        $('.deleteaddress[recordID=' + recordID + ']').removeClass('hide')   
	        $('.editaddress').addClass('hide')    
	        $('.editaddress[recordID=' + recordID + ']').removeClass('hide')   
	        $('.delivertoaddress').addClass('hide')    
	        $('.delivertoaddress[recordID=' + recordID + ']').removeClass('hide')   
	});
	$(document).on('click', '.deleteaddress', function(e) {
		try {
			e.preventDefault();
			var element = $(this);
			var plaincard = $(this).closest('.plain-card');
			var objParams = {};
			objParams.recordID = getParameterByName('recordID');
			if ($(this).attr('recordID')) {
				objParams.recordID = $(this).attr('recordID');
			}
		
			updatereferanceAddresses5da73cac545050343288ce7aDelete(objParams, plaincard);
			return false;
		} catch (error) {
			console.log('Error in updatereferance click', error);
		}
	});
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_addnoteedit'; 
				var queryParams = queryStringToJSON(); 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#addanewaddress20', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_addressadd'; 
				var queryParams = queryStringToJSON(); 
    			queryParams["queryMode"] = "add"; 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - addanewaddress20", error) 
		} 
	})
});//end of ready
function pageredirectProcessBeforeCallDelivertothisaddress(element, objParams,response,callback) {
	try{
 localStorage.setItem('addressesid', objParams.recordID);

$('a[id^=saveaddress]').trigger('click');
return false;
	} catch(error) { 
		console.log('Error in pageredirectProcessBeforeCallDelivertothisaddress', error);
		callback();
	}
}
	function updatereferanceAddresses5da73cac545050343288ce7aDelete(objParams, element) {
		try {
			objParams.userId = localStorage.getItem('userID');
			var ajaXCallURL = $.trim($('#ajaXCallURL').val());
			objParams.tokenKey = getParameterByName('tokenKey');
			objParams.secretKey = getParameterByName('secretKey');
	
			var callUrl = ajaXCallURL + '/milestone003/updatereferance_Addresses5da73cac545050343288ce7a_app_addresslist_Delete';
			$('#display_loading').removeClass('hideme'); 
         updatereferanceProcessBeforeCallAddresses5da73cac545050343288ce7aDelete(objParams, function(){
			  $.ajax({
				url: callUrl,
				data: objParams,
				type: 'POST',
				success: function (response) {
					$('#display_loading').addClass('hideme'); 
                 updatereferanceProcessAfterCallAddresses5da73cac545050343288ce7aDelete(response, function(){
					   if (response.status == 0) {
	
	
          undefined
			element.fadeOut(500);
						return;
					} else {
						return;
					}
			  });
				},
				error: function (xhr, status, error) {
					$('#display_loading').addClass('hideme');
				},
			});
		  });
		} catch (error) {
			$('#display_loading').addClass('hideme');
			console.log('Error in updatereferance_fieldname', error);
		}
	} 
 function updatereferanceProcessBeforeCallAddresses5da73cac545050343288ce7aDelete(objParams,callback) {
 callback(); 
 } 
 function updatereferanceProcessAfterCallAddresses5da73cac545050343288ce7aDelete(response,callback) {
 callback(); 
 }