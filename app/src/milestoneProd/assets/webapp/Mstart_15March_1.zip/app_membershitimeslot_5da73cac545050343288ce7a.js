
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID ='';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
  function changeRangeDateChangeCallbackslotdate6(target,range) {
      var date = moment(range.start).format('DD MMM YYYY');
      $('#slotdate6bookdate13').val(date);
      $('#selectedDate').html(date);
      if(date != undefined && date != ''){
         getTimeSlots_Detailsslotdate6($('#slotdate6bookdate13').val());
      }
  }
$(document).ready(function() {
    $('#slotdate6').rangeCalendar({
                       startRangeWidth:1,
                       weekends:true,
                       start:'+0',
                       endDate: moment().add('days', 5),
                       width:'280px',
                       cellWidth:70,
                       theme:'red-light-theme',
                       changeRangeCallback:changeRangeDateChangeCallbackslotdate6
      });
    $('.datepicker2').pickadate({
                      selectMonths: true,
                       selectYears: 200,
                       dateFormat: 'd mmmm, yyyy',
                       min:new Date(),
                       max:new Date(moment().add('days', 4)),
                       onSet: function (arg) {
                         if ('select' in arg) {
                            this.close();
                         }
                        }
      });
      $('#slotdate6bookdate13').val(moment().format('DD MMM YYYY'));
      $(document).on('change', '#slotdate6bookdate13', function () {
         var date = $('#slotdate6bookdate13').val();
             if(date != undefined && date != ''){
                 var dateId = moment(date).format('YYYYMMD');
                 var dateCell = $('#slotdate6').find('.cell[date-id='+dateId+']');
                 dateCell.trigger('click');
             }
             return false;
        });
      $(document).on('click', '.slidercalenderIcon', function () {
         $('#slotdate6bookdate13').focus();
         return false;
      });
$('#recordID').val(getParameterByName('recordID'));
  var queryMode = getParameterByName('queryMode');
  var authKey = $('#authKey').val();
  var appID = $('#hdnAppID').val();
  if(localStorage.getItem("headerPageName") != "" && queryMode != null){
          $("#headerPageName").html(localStorage.getItem("headerPageName"))
  }

 var objParamsToken = {};
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParamsToken.tokenKey = getParameterByName('tokenKey');
   objParamsToken.secretKey = getParameterByName('secretKey');

   var userRole = $('#userRole').val();
   var userID = $('#userID').val();
   var createrOfRecord = $('#createrOfRecord').val();
   var queryMode = getParameterByName('queryMode');
   var recordID = $.trim($('#recordID').val());
   var addSessionComments = [];
 var forwardChekbox = [];
  var isOpenForwardPopup = 0;
  $(document).on('click', '#continue14', function () {
  var objParams = {};
  var opendelivery = $.trim($('#opendelivery12').val());
 if($('#opendelivery12_div').is(':visible')){
  objParams.opendelivery = opendelivery;
 }
  var opendelivery = $.trim($('#opendelivery12').val());
 if($('#opendelivery12_div').is(':visible')){
  objParams.opendelivery = opendelivery;
 }
   var tempobjParams  =  getParams(window.location.href)
   function extend(obj, src) {
          for (var key in src) {
              if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
          }
          return obj;
    }
    objParams = extend(objParams, tempobjParams);
   var recordID = $('#recordID').val();
   objParams.isDelete = 0;
   var ajaXCallURL = $.trim($('#ajaXCallURL').val());
   objParams.tokenKey = getParameterByName('tokenKey');
   objParams.secretKey = getParameterByName('secretKey');
   objParams.offlineDataID =  localStorage.getItem("offlineDataID");
   var queryMode = getParameterByName('queryMode')
 if (queryMode == 'mylist123') {
  objParams.callUrl = ajaXCallURL + '/milestone003/saveAjaxordersapp_membershitimeslot';
  } else {
  objParams.callUrl = ajaXCallURL +'/milestone003/updateAjaxordersapp_membershitimeslot';
  objParams.recordID = recordID;
 }
  if(errorFields && Object.keys(errorFields).length){
      $('#display_loading1').addClass('hideme');
      for(var firstErrorField in errorFields){
          var controlType = errorFields[firstErrorField];
          errorFields = []
          var errField = $('#'+ firstErrorField);
          if(controlType == 'dropdown'){
              errField.prev().prev().focus();
          } else {
              errField.focus()
          }
          validAll = true;
          return false;
      }
  }
  if(!validAll){
      validAll = true;
      return false;
  }
  $('#continue14').prop('disabled', true);
  $('#display_loading1').removeClass('hideme');
  if (addSessionComments.length > 0) {
      objParams.addSessionComments = addSessionComments;
  } else {
      objParams.addSessionComments = [];
  }
   var parentID = $('#parentID').val();
   var parentName = $('#parentName').val();
   if(parentID != ''){
      objParams.parentID = parentID;
      objParams.parentName = parentName
   }
   if (typeof(addedFiles) != "undefined" && addedFiles && addedFiles.length > 0 ) {
       objParams.addedFiles = addedFiles;
   }
   objParams.ajaXCallURL = $("#ajaXCallURL").val();;
   objParams.organizationID = $("#organizationID").val();;
   objParams.ajaXCallURL = $("#ajaXCallURL").val();;
   objParams.organizationID = $("#organizationID").val();;
  processBeforeCallForSaveorders(objParams,{},function(processBeforeRes){
  $.ajax({
      url: objParams.callUrl,
      data: objParams,
      type: 'POST',
      success: function (response) {
          if(response.status == 0){
              $('#display_loading1').addClass('hideme');
              response.nextPage = 'app_appointmentsdetails'
  processAfterCallForSaveorders(response,function(processAfterRes){
             var tokenKey = getParameterByName('tokenKey');
             var secretKey = getParameterByName('secretKey');
            var queryMode = getParameterByName('queryMode');
            queryMode = queryMode.replace('edit', '');
  localStorage.setItem("headerPageName", 'app_appointmentsdetails'); 
    		var queryString = window.location.search.slice(1); 
    		var newQuery = queryString +'&queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey 
    		var queryParams = queryStringToJSON(newQuery); 
    		queryString = $.param(queryParams); 
         queryString = queryString.replace(/\+/g, "%20"); 
    		queryString = decodeURIComponent(queryString);
              if (recordID == '') { 
                  window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?'+ queryString
              }else{
                  window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?'+ queryString
              }
              return false;
 }); // End of After Process
          } else {
              $('#display_loading1').addClass('hideme');
              $('#2656d_error').html(response.error);
              $('#2656d_error').show();
          }
          $('#continue14').removeProp('disabled');
      },
      error: function (xhr, status, error) {
          $('#display_loading1').addClass('hideme');
          $('#continue14').removeProp('disabled');
      },
  });
 return false;
  }); // End of Before Process
  });//end of Event CONTINUE_is_click 
 var forwardChekbox = [];
 var isOpenForwardPopup = 0;
 var objParams = {}; 
                 localStorage.removeItem('slotID'); 
                 $(document).on('click', '.slotsBtn', function () { 
                 		var recordID = $(this).attr('recordID'); 
                 		localStorage.setItem('slotID', recordID); 
                 		$('.slotsBtn').removeClass('selected'); 
                 		$(this).addClass('selected'); 
                 		return false; 
                 }); 
                 //getTimeSlots_Detailsslotdate6($('#slotdate6bookdate13').val()); 
		var addedRecords = [];
		localStorage.setItem('addedRecords',[]);
		$(document).on('click', '#backbutton1', function(e) {
			try{ 
				var element = $(this);
				var nextPage = 'app_rewardsupdate'; 
				var queryParams = queryStringToJSON(); 
    			var recordID = $(this).attr("recordID"); 
    			if(recordID){ 
    				queryParams["recordID"] = recordID; 
    			}
				var queryString = $.param(queryParams);
				queryString = queryString.replace(/\+/g, "%20");
				queryString = decodeURIComponent(queryString);
				window.location.href = nextPage + '_5da73cac545050343288ce7a.html?'+ queryString 
    			return false;  
		} catch(error){ 
			console.log("Error in pageredirect workflow - backbutton1", error) 
		} 
	})
});//end of ready
 function getParams(url) {
      var urlParams = {};
      url.replace(
                  new RegExp("([^?=&]+)(=([^&]*))?", "g"),
                  function($0, $1, $2, $3) {
                     if($3 && $3 != 'undefined') urlParams[$1] = $3;
                  }
                 );
                return urlParams;
     }
 function processBeforeCallForSaveorders(objParams,response,callback){ 

 
var slotID = localStorage.getItem('slotID');
if(slotID && slotID != 'undefined'){
	objParams.slotid = slotID;
objParams.temp = slotID;

var usermanagementid = getParameterByName('usermanagementid');
if(usermanagementid && usermanagementid != ''){
  objParams.consultantid  = usermanagementid;
}

objParams.recordID = localStorage.getItem("appointmentID");;
	callback();
} else {
	shareAppData('No time slot is availble today', 'toast');
	return false;
}
 }
 function processAfterCallForSaveorders(response,callback){ 

 callback();
 } 
                 function getTimeSlots_Detailsslotdate6(slotdate) {  
                     var ajaXCallURL = $.trim($('#ajaXCallURL').val());  
                     var callUrl = ajaXCallURL + '/milestone003/getCalenderSlot_app_membershitimeslot_Timeslotsdetails5da73cac545050343288ce7a' 
                     var objParams = {};  
                     objParams.tokenKey = getParameterByName('tokenKey');  
                     objParams.secretKey = getParameterByName('secretKey');  
                     objParams.queryMode = getParameterByName('queryMode');  
                     objParams.slotdate = slotdate;  
                     //objParams.slotdate = moment(new Date(slotdate)).utc().format('YYYY-MM-DDTHH:mm:ssZ'); 
                     objParams.deliveryslotconstraint = getParameterByName('deliveryslotconstraint');; 
                     $('#display_loading').removeClass('hideme'); 
      	getcalendarslotProcessBeforeCallTimeslotsdetails5da73cac545050343288ce7aslidercalender(objParams, function(){ 
                     $.ajax({  
                         url: callUrl,  
                         data: objParams,  
                         type: 'POST',  
                         success: function (response) {  
                             //$('.slotsContainer').html(html);  
                             if (response.status != undefined && response.status == 0) {  
                               
                                 getshowTimeSlotlist1MobileViewslotdate6(response);  
                                 $('#display_loading').addClass('hideme');  
                             } else {  
                                 $('#display_loading').addClass('hideme');  
                             }  
                         },  
                         error: function (xhr, status, error) {  
                             $('#display_loading').addClass('hideme')  
                         },  
                     });  
             });  
                 }  
                   
 function getcalendarslotProcessBeforeCallTimeslotsdetails5da73cac545050343288ce7aslidercalender(objParams, callback) { 
 var usermanagementid = getParameterByName('usermanagementid');
if (usermanagementid && usermanagementid != '') {
    objParams.productid = usermanagementid;
} else {
    var appUser = localStorage.getItem("appUser");
    if (appUser && appUser !== '') {
        appUser = JSON.parse(appUser);
        if (appUser && appUser.consultantid) {
            objParams.productid = appUser.consultantid;
        }
    }
}
	callback(); 
 } 
                 function getshowTimeSlotlist1MobileViewslotdate6(response) {  
                     var html = '';  
                     if (response.data.length == 0) {  
                         html += '<div class="nodatafound">';  
                         html += '<span>No record found</span>';  
                         html += '</div>';  
                         $('.slotsContainer').html(html);  
                     } else {  
                         html = '';  
                         $.each(response.data, function (keyList, objList) {  
                             var openDeliver = 0;  
                             if (objList.opendelivery != undefined) {  
                                 openDeliver = parseInt(objList.opendelivery);  
                             }  
                             var hrs = moment(objList.starttime,'HH:mm a').format('HH');  
                             var min = moment(objList.starttime,'HH:mm a').format('mm');  
                             var date = new Date($('#slotdate6bookdate13').val());  
                             date.setHours(hrs);  
                             date.setMinutes(min);  
                             var diff = moment().diff(date, 'minutes');  
                             if(diff <= 0){  
                                 if(openDeliver <= 0){  
                                     html += '      <div class="slotsBtn disabled">';  
                                     html += '       <span class="btnText">' + objList.starttime+'-'+ objList.endtime + '</span>';  
                             		 html += '   </div>';  
                                 }else{  
                                     html += '    <div class="slotsBtn" recordID=' + objList._id + '>';  
                                     html += '       <span class="btnText">' + objList.starttime+'-'+ objList.endtime + '</span>';  
                             		 html += '   </div>';  
                                 }  
                             }  
                               
                         });  
                         $('.slotsContainer').html(html);  
                     };  
                 }; 