
var offlineDataID = randomString();
var arrEditMedia = {};
var arrAllMedia = [];
var count = 0;
var validAll = true;
var passwordchanged = 0;
var errorFields = [];
var dcardLoaded = [];
var gMediaOfflineDataID = '';
var locationJson = {};
var dropdownvalues = {};
var isFetch = true;
var isLock = false;
$(document).ready(function () {
    $('#recordID').val(getParameterByName('recordID'));
    var queryMode = getParameterByName('queryMode');
    var authKey = $('#authKey').val();
    var appID = $('#hdnAppID').val();
    if (localStorage.getItem("headerPageName") != "" && queryMode != null) {
        $("#headerPageName").html(localStorage.getItem("headerPageName"))
    }

    var objParamsToken = {};
    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
    objParamsToken.tokenKey = getParameterByName('tokenKey');
    objParamsToken.secretKey = getParameterByName('secretKey');

    var userRole = $('#userRole').val();
    var userID = $('#userID').val();
    var createrOfRecord = $('#createrOfRecord').val();
    var queryMode = getParameterByName('queryMode');
    var recordID = $.trim($('#recordID').val());
    var addSessionComments = [];
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('click', '#redeem28', function () {
        var objParams = {};
        var bazaarid = $.trim($('#bazaarid33').val());
        if ($('#bazaarid33_div').is(':visible')) {
            objParams.bazaarid = bazaarid;
        }
        var bazaarid = $.trim($('#bazaarid33').val());
        if ($('#bazaarid33_div').is(':visible')) {
            objParams.bazaarid = bazaarid;
        }
        var bazaarid = $.trim($('#bazaarid33').val());
        if ($('#bazaarid33_div').is(':visible')) {
            objParams.bazaarid = bazaarid;
        }
        var tempobjParams = getParams(window.location.href)
        function extend(obj, src) {
            for (var key in src) {
                if (src.hasOwnProperty(key) && src[key]) obj[key] = src[key];
            }
            return obj;
        }
        objParams = extend(objParams, tempobjParams);
        if (!objParams['bazaarid']) { delete objParams['bazaarid']; }
        if (!objParams['bazaarid']) { delete objParams['bazaarid']; }
        if (!objParams['bazaarid']) { delete objParams['bazaarid']; }
        var recordID = $('#recordID').val();
        objParams.isDelete = 0;
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        objParams.tokenKey = getParameterByName('tokenKey');
        objParams.secretKey = getParameterByName('secretKey');
        objParams.offlineDataID = localStorage.getItem("offlineDataID");
        var queryMode = getParameterByName('queryMode')
        if (queryMode == 'update') {
            objParams.callUrl = ajaXCallURL + '/milestone003/saveAjaxredeemedstampcard8321redeemapp_offerdetails';
        } else {
            objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxredeemedstampcard8321redeemapp_offerdetails';
            objParams.recordID = recordID;
        }
        if (errorFields && Object.keys(errorFields).length) {
            $('#display_loading1').addClass('hideme');
            for (var firstErrorField in errorFields) {
                var controlType = errorFields[firstErrorField];
                errorFields = []
                var errField = $('#' + firstErrorField);
                if (controlType == 'dropdown') {
                    errField.prev().prev().focus();
                } else {
                    errField.focus()
                }
                validAll = true;
                return false;
            }
        }
        if (!validAll) {
            validAll = true;
            return false;
        }
        $('#redeem28').prop('disabled', true);
        $('#display_loading1').removeClass('hideme');
        if (addSessionComments.length > 0) {
            objParams.addSessionComments = addSessionComments;
        } else {
            objParams.addSessionComments = [];
        }
        var parentID = $('#parentID').val();
        var parentName = $('#parentName').val();
        if (parentID != '') {
            objParams.parentID = parentID;
            objParams.parentName = parentName
        }
        if (typeof (addedFiles) != "undefined" && addedFiles && addedFiles.length > 0) {
            objParams.addedFiles = addedFiles;
        }
        objParams.ajaXCallURL = $("#ajaXCallURL").val();;
        objParams.organizationID = $("#organizationID").val();;
        objParams.ajaXCallURL = $("#ajaXCallURL").val();;
        objParams.organizationID = $("#organizationID").val();;
        processBeforeCallForSave8321redeem(objParams, {}, function (processBeforeRes) {
            $.ajax({
                url: objParams.callUrl,
                data: objParams,
                type: 'POST',
                success: function (response) {
                    if (response.status == 0) {
                        $('#display_loading1').addClass('hideme');
                        response.nextPage = 'app_offersuccess'
                        processAfterCallForSave8321redeem(response, function (processAfterRes) {
                            var tokenKey = getParameterByName('tokenKey');
                            var secretKey = getParameterByName('secretKey');
                            var queryMode = getParameterByName('queryMode');
                            queryMode = queryMode.replace('edit', '');
                            localStorage.setItem("headerPageName", 'app_offersuccess');
                            var queryString = window.location.search.slice(1);
                            var newQuery = queryString + '&queryMode=mylist&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&queryMode=mylist' + '&bazaarid=' + response.data._id + '&recordID=' + response.data._id
                            var queryParams = queryStringToJSON(newQuery);
                            queryString = $.param(queryParams);
                            queryString = queryString.replace(/\+/g, "%20");
                            queryString = decodeURIComponent(queryString);
                            if (recordID == '') {
                                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
                            } else {
                                window.location.href = response.nextPage + '_5da73cac545050343288ce7a.html?' + queryString
                            }
                            return false;
                        }); // End of After Process
                    } else {
                        $('#display_loading1').addClass('hideme');
                        $('#2656d_error').html(response.error);
                        $('#2656d_error').show();
                    }
                    $('#redeem28').removeProp('disabled');
                },
                error: function (xhr, status, error) {
                    $('#display_loading1').addClass('hideme');
                    $('#redeem28').removeProp('disabled');
                },
            });
            return false;
        }); // End of Before Process
    });//end of Event Redeem_is_click 

    $(document).on('click', '#redeemscan28', function () {
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = getParameterByName('queryMode');
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        loadNativescanqrcodeControl(tokenKey, queryMode, secretKey, ajaXCallURL);
    });//end of Event Scan QR Code_is_click 

    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    $(document).on('click', '#address_loadmapviewbyconfig12', function () {
        var tokenKey = getParameterByName('tokenKey');
        var secretKey = getParameterByName('secretKey');
        var queryMode = getParameterByName('queryMode');
        var ajaXCallURL = $.trim($('#ajaXCallURL').val());
        var lat = parseFloat($(this).attr('lat')) != NaN ? parseFloat($(this).attr('lat')) : 0;
        var long = parseFloat($(this).attr('long')) != NaN ? parseFloat($(this).attr('long')) : 0;
        var addressText = $(this).attr('addressText');

        loadNativebazaar_address_loadmapviewbyconfigControl(tokenKey, queryMode, secretKey, ajaXCallURL, lat, long, addressText);
    });//end of Event bazaar_address_loadmapviewbyconfig_is_click 
    var forwardChekbox = [];
    var isOpenForwardPopup = 0;
    var objParams = {};
    var paramsEdit = {};
    paramsEdit.tokenKey = getParameterByName('tokenKey');
    paramsEdit.secretKey = getParameterByName('secretKey')
    paramsEdit.recordID = getParameterByName('stampofferid');
    paramsEdit.outletId = getParameterByName('outletId');
    getRecordByIDProcessBeforeCall935849(paramsEdit, function (processBeforeRes) {
        $.ajax({
            url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_offerdetails_Stampcardoffers5da73cac545050343288ce7a',
            data: paramsEdit,
            type: 'POST',
            jsonpCallback: 'callback',
            success: function (response) {
                getRecordByIDProcessAfterCall935849(response, function (processBeforeRes) {
                    if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                        var objParamsList = {};
                        var queryMode = $('#queryMode').val();
                        objParamsList.queryMode = queryMode;;
                        var tokenKey = $('#tokenKey').val();;
                        objParamsList.tokenKey = tokenKey;;
                        $('#accumalatedstampcard34').html(response.recordDetails.accumalatedstampcard);
                        if (response.recordDetails.address != undefined) $('#address29').val(response.recordDetails.address);
                        $('#bazaarnumber31_value').html(response.recordDetails.bazaarnumber);
                        $('#stampcardofferid32').html(response.recordDetails.stampcardofferid);
                        $('#bazaarid33').html(response.recordDetails.bazaarid);
                        if (!$('#backbutton1').html()) {
                            $('#backbutton1').append(response.recordDetails.undefined);
                        }
                        // getrecordbycustomquery - Stage - 111111111111
                        if (response.recordDetails['address_loadmapviewbyconfig'] && response.recordDetails['address_loadmapviewbyconfig'].length > 0) {
                            if (response.recordDetails['address_loadmapviewbyconfig'][0].displayType = 'html') {
                                var eleParent = $('#address_loadmapviewbyconfig12').parent();
                                for (var key in response.recordDetails['address_loadmapviewbyconfig']) {
                                    var objImage = response.recordDetails['address_loadmapviewbyconfig'][key];
                                    if (response.recordDetails['address_loadmapviewbyconfig'][key].name == 'Audio') {
                                        var token = $('#tokenKey').val();
                                        if (token && token != '') {
                                            token = $('#tokenKey').val();
                                        } else {
                                            token = getParameterByName('tokenKey');
                                        }
                                        var mediaIDa = response.recordDetails['address_loadmapviewbyconfig'][0].mediaID
                                        var filenamea = response.recordDetails['address_loadmapviewbyconfig'][0].fileName
                                        var CDN_PATH2 = 'https://devfiles.hokuapps.com/downloadOriginal?f=' + mediaIDa + '&fn=' + filenamea + '&t=' + token
                                        var url = CDN_PATH2
                                    } else {
                                        var filetodisplay = getuploadedfilepreview(objImage.fileNm);
                                        if (filetodisplay && filetodisplay != objImage.fileNm) {
                                            var url = filetodisplay;
                                        } else {
                                            var url = CDN_PATH + objImage.mediaID + '_compressed.png';
                                        }
                                    }
                                    if (response.recordDetails['address_loadmapviewbyconfig'][key].name == 'Audio') {
                                        var html = '';
                                        html += '<div class="col s12" style="float: right;">'
                                        html += '<audio class="" src="' + url + '" controls></audio>'
                                        html += '</div>'
                                    } else {
                                        var html = '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + url + '" />';
                                    }
                                    if (!key || key == '0') {
                                        eleParent.html(html);
                                    } else {
                                        eleParent.append(html);
                                    }
                                }
                            } else {
                                if (response.recordDetails['address_loadmapviewbyconfig'][key].name == 'Audio') {
                                    var url = CDN_PATH + response.recordDetails['address_loadmapviewbyconfig'][0].mediaID;
                                } else {
                                    var url = CDN_PATH + response.recordDetails['address_loadmapviewbyconfig'][0].mediaID + '_compressed.png';
                                }
                                $('#address_loadmapviewbyconfig12').attr("src", url);
                            }
                        }
                        // var outletaddress = response.recordDetails.outletaddress
                        // if (outletaddress.coordinates.length >= 2) {
                        //     $('#address_loadmapviewbyconfig12').attr('long', outletaddress.coordinates[0]);
                        //     $('#address_loadmapviewbyconfig12').attr('lat', outletaddress.coordinates[1]);
                        //     $('#address_loadmapviewbyconfig12').attr('addressText', response.recordDetails.outletaddress_name && response.recordDetails.outletaddress_name != '' ? response.recordDetails.outletaddress_name : '');
                        //     $('#address_loadmapviewbyconfig12_img').attr("src", 'icon_location.png');
                        // } else {
                        //     $('#address_loadmapviewbyconfig12_img').attr("src", 'icon_location.png');
                        // }

                        if (response.recordDetails.description) {
                            $('#address_name11').append(response.recordDetails.description);
                            $('#termsandconditions27').append(response.recordDetails.description);
                        }
                        response.recordDetails['expirationdate_preserved'] = response.recordDetails['expirationdate'];
                        response.recordDetails['expirationdate'] = response.recordDetails['expirationdate'] ? moment(new Date(response.recordDetails['expirationdate'])).format('DD MMM YYYY') : '';
                        if (response.recordDetails.expirationdate) {
                            $('#expirationdate20').append('Expired on: ' + response.recordDetails.expirationdate);
                        }
                        response.recordDetails['expirationdate'] = response.recordDetails['expirationdate_preserved'];
                        if (!$('#outlets23').html()) {
                            if (!response.recordDetails.outlets) {
                                response.recordDetails.outlets = '0';
                            }
                            $('#outlets23').append(response.recordDetails.outlets);
                        }
                        $('#redeemedstampqty17').html(response.recordDetails.redeemedstampqty);
                        if (!$('#termsandconditions27').html()) {
                            $('#termsandconditions27').append(response.recordDetails.termsandconditions);
                        }
                        if (!$('#details2').html()) {
                            $('#details2').append(response.recordDetails.undefined);
                        }
                        if (!$('#expireson19').html()) {
                            $('#expireson19').append(response.recordDetails.undefined);
                        }
                        // getrecordbycustomquery - Stage - 111111111111
                        if (response.recordDetails['merchantimage'] && response.recordDetails['merchantimage'].length > 0) {
                            if (response.recordDetails['merchantimage'][0].displayType = 'html') {
                                var eleParent = $('#merchantimage6').parent();
                                for (var key in response.recordDetails['merchantimage']) {
                                    var objImage = response.recordDetails['merchantimage'][key];
                                    if (response.recordDetails['merchantimage'][key].name == 'Audio') {
                                        var token = $('#tokenKey').val();
                                        if (token && token != '') {
                                            token = $('#tokenKey').val();
                                        } else {
                                            token = getParameterByName('tokenKey');
                                        }
                                        var mediaIDa = response.recordDetails['merchantimage'][0].mediaID
                                        var filenamea = response.recordDetails['merchantimage'][0].fileName
                                        var CDN_PATH2 = 'https://devfiles.hokuapps.com/downloadOriginal?f=' + mediaIDa + '&fn=' + filenamea + '&t=' + token
                                        var url = CDN_PATH2
                                    } else {
                                        var filetodisplay = getuploadedfilepreview(objImage.fileNm);
                                        if (filetodisplay && filetodisplay != objImage.fileNm) {
                                            var url = filetodisplay;
                                        } else {
                                            var url = CDN_PATH + objImage.mediaID + '_compressed.png';
                                        }
                                    }
                                    if (response.recordDetails['merchantimage'][key].name == 'Audio') {
                                        var html = '';
                                        html += '<div class="col s12" style="float: right;">'
                                        html += '<audio class="" src="' + url + '" controls></audio>'
                                        html += '</div>'
                                    } else {
                                        var html = '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + url + '" />';
                                    }
                                    if (!key || key == '0') {
                                        eleParent.html(html);
                                    } else {
                                        eleParent.append(html);
                                    }
                                }
                            } else {
                                if (response.recordDetails['merchantimage'][key].name == 'Audio') {
                                    var url = CDN_PATH + response.recordDetails['merchantimage'][0].mediaID;
                                } else {
                                    var url = CDN_PATH + response.recordDetails['merchantimage'][0].mediaID + '_compressed.png';
                                }
                                $('#merchantimage6').attr("src", url);
                            }
                        }
                        if (!$('#loyaltystampcards16').html()) {
                            $('#loyaltystampcards16').append(response.recordDetails.undefined);
                        }
                        if (!$('#new9').html()) {
                            $('#new9').append(response.recordDetails.undefined);
                        }
                        if (!$('#termsconditions25').html()) {
                            $('#termsconditions25').append(response.recordDetails.undefined);
                        }
                        //  if (!$('#name10').html()) {
                        $('#name10').html(response.recordDetails.name);
                        // }
                        if (!$('#two28may20198').html()) {
                            $('#two28may20198').append(response.recordDetails.undefined);
                        }
                        if (!$('#validity22').html()) {
                            $('#validity22').append(response.recordDetails.undefined);
                        }
                        if (!$('#voucherdetails14').html()) {
                            $('#voucherdetails14').append(response.recordDetails.undefined);
                        }

                        Materialize.updateTextFields();
                        $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

                    }
                }); // end of getRecord By ID
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            },
        });
    }); // end of getRecord By ID

    var addedRecords = [];
    localStorage.setItem('addedRecords', []);
    $(document).on('click', '#backbutton1', function (e) {
        try {
            var element = $(this);
            var nextPage = 'app_redeemedvoucherlisting';
            // var nextPage = 'app_allofferlisting';
            var merchantStampCardOfferURL = '';
            var secretKey = getParameterByName('secretKey');
            var tokenKey = getParameterByName('tokenKey');
            if (localStorage.getItem('isFromStampCard') == 'false') {
                nextPage = 'app_redeemedvoucherlisting';
                // nextPage = 'app_stampcardlisting';
                var stampCardQueryMode = 'mylist';
                var bazaarid = getParameterByName('outletId');
                var merchantID = localStorage.getItem('stampCardMerchantId');
                merchantStampCardOfferURL = nextPage + '_5da73cac545050343288ce7a.html?queryMode=' + stampCardQueryMode + '&tokenKey=' + tokenKey + '&secretKey=' + secretKey + '&bazaarid=' + bazaarid + '&merchantID=' + merchantID + '&recordID=' + bazaarid + '&applyFilter=true';
            }
            var queryParams = queryStringToJSON();
            queryParams["queryMode"] = "mylist";
            var recordID = $(this).attr("recordID");
            if (recordID) {
                queryParams["recordID"] = recordID;
            }
            if (!nextPage) {
                return false;
            }
            var queryString = $.param(queryParams);
            queryString = queryString.replace(/\+/g, "%20");
            queryString = decodeURIComponent(queryString);
            //Check - whether we came from merchant-> stamp card list OR More-> Stamp cards offers.
            window.location.href = localStorage.getItem('isFromStampCard') == 'false' ? merchantStampCardOfferURL : nextPage + '_5da73cac545050343288ce7a.html?' + queryString
            return false;
        } catch (error) {
            console.log("Error in pageredirect workflow - backbutton1", error)
        }
    })
    var paramsEdit = {};
    paramsEdit.tokenKey = getParameterByName('tokenKey');
    paramsEdit.secretKey = getParameterByName('secretKey')
    getRecordByIDProcessBeforeCallbackbutton1(paramsEdit, function (processBeforeRes) {
        $.ajax({
            url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_offerdetails_Usermanagement5da73cac545050343288ce7a',
            data: paramsEdit,
            type: 'POST',
            jsonpCallback: 'callback',
            success: function (response) {
                getRecordByIDProcessAfterCallbackbutton1(response, function (processBeforeRes) {
                    if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                        var objParamsList = {};
                        var queryMode = $('#queryMode').val();
                        objParamsList.queryMode = queryMode;;
                        var tokenKey = $('#tokenKey').val();;
                        objParamsList.tokenKey = tokenKey;;
                        $('#accumalatedstampcard34').html(response.recordDetails.accumalatedstampcard);
                        if (response.recordDetails.address != undefined) $('#address29').val(response.recordDetails.address);
                        $('#bazaarnumber31_value').html(response.recordDetails.bazaarnumber);
                        $('#stampcardofferid32').html(response.recordDetails.stampcardofferid);
                        $('#bazaarid33').html(response.recordDetails.bazaarid);
                        if (!$('#backbutton1').html()) {
                            $('#backbutton1').append(response.recordDetails.undefined);
                        }
                        // getrecordbycustomquery - Stage - 111111111111
                        if (response.recordDetails['address_loadmapviewbyconfig'] && response.recordDetails['address_loadmapviewbyconfig'].length > 0) {
                            if (response.recordDetails['address_loadmapviewbyconfig'][0].displayType = 'html') {
                                var eleParent = $('#address_loadmapviewbyconfig12').parent();
                                for (var key in response.recordDetails['address_loadmapviewbyconfig']) {
                                    var objImage = response.recordDetails['address_loadmapviewbyconfig'][key];
                                    if (response.recordDetails['address_loadmapviewbyconfig'][key].name == 'Audio') {
                                        var token = $('#tokenKey').val();
                                        if (token && token != '') {
                                            token = $('#tokenKey').val();
                                        } else {
                                            token = getParameterByName('tokenKey');
                                        }
                                        var mediaIDa = response.recordDetails['address_loadmapviewbyconfig'][0].mediaID
                                        var filenamea = response.recordDetails['address_loadmapviewbyconfig'][0].fileName
                                        var CDN_PATH2 = 'https://devfiles.hokuapps.com/downloadOriginal?f=' + mediaIDa + '&fn=' + filenamea + '&t=' + token
                                        var url = CDN_PATH2
                                    } else {
                                        var filetodisplay = getuploadedfilepreview(objImage.fileNm);
                                        if (filetodisplay && filetodisplay != objImage.fileNm) {
                                            var url = filetodisplay;
                                        } else {
                                            var url = CDN_PATH + objImage.mediaID + '_compressed.png';
                                        }
                                    }
                                    if (response.recordDetails['address_loadmapviewbyconfig'][key].name == 'Audio') {
                                        var html = '';
                                        html += '<div class="col s12" style="float: right;">'
                                        html += '<audio class="" src="' + url + '" controls></audio>'
                                        html += '</div>'
                                    } else {
                                        var html = '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + url + '" />';
                                    }
                                    if (!key || key == '0') {
                                        eleParent.html(html);
                                    } else {
                                        eleParent.append(html);
                                    }
                                }
                            } else {
                                if (response.recordDetails['address_loadmapviewbyconfig'][key].name == 'Audio') {
                                    var url = CDN_PATH + response.recordDetails['address_loadmapviewbyconfig'][0].mediaID;
                                } else {
                                    var url = CDN_PATH + response.recordDetails['address_loadmapviewbyconfig'][0].mediaID + '_compressed.png';
                                }
                                $('#address_loadmapviewbyconfig12').attr("src", url);
                            }
                        }
                        if (!$('#address_name11').html()) {
                            $('#address_name11').append(response.recordDetails.address_name);
                        }
                        response.recordDetails['expirationdate_preserved'] = response.recordDetails['expirationdate'];
                        response.recordDetails['expirationdate'] = response.recordDetails['expirationdate'] ? moment(new Date(response.recordDetails['expirationdate'])).format('DD MMM YYYY') : '';
                        if (!$('#expirationdate20').html()) {
                            $('#expirationdate20').append(response.recordDetails.expirationdate);
                        }
                        response.recordDetails['expirationdate'] = response.recordDetails['expirationdate_preserved'];
                        if (!$('#outlets23').html()) {
                            if (!response.recordDetails.outlets) {
                                response.recordDetails.outlets = '0';
                            }
                            $('#outlets23').append(response.recordDetails.outlets);
                        }
                        $('#redeemedstampqty17').html(response.recordDetails.redeemedstampqty);
                        if (!$('#termsandconditions27').html()) {
                            $('#termsandconditions27').append(response.recordDetails.termsandconditions);
                        }
                        if (!$('#details2').html()) {
                            $('#details2').append(response.recordDetails.undefined);
                        }
                        if (!$('#expireson19').html()) {
                            $('#expireson19').append(response.recordDetails.undefined);
                        }
                        // getrecordbycustomquery - Stage - 111111111111
                        if (response.recordDetails['merchantimage'] && response.recordDetails['merchantimage'].length > 0) {
                            if (response.recordDetails['merchantimage'][0].displayType = 'html') {
                                var eleParent = $('#merchantimage6').parent();
                                for (var key in response.recordDetails['merchantimage']) {
                                    var objImage = response.recordDetails['merchantimage'][key];
                                    if (response.recordDetails['merchantimage'][key].name == 'Audio') {
                                        var token = $('#tokenKey').val();
                                        if (token && token != '') {
                                            token = $('#tokenKey').val();
                                        } else {
                                            token = getParameterByName('tokenKey');
                                        }
                                        var mediaIDa = response.recordDetails['merchantimage'][0].mediaID
                                        var filenamea = response.recordDetails['merchantimage'][0].fileName
                                        var CDN_PATH2 = 'https://devfiles.hokuapps.com/downloadOriginal?f=' + mediaIDa + '&fn=' + filenamea + '&t=' + token
                                        var url = CDN_PATH2
                                    } else {
                                        var filetodisplay = getuploadedfilepreview(objImage.fileNm);
                                        if (filetodisplay && filetodisplay != objImage.fileNm) {
                                            var url = filetodisplay;
                                        } else {
                                            var url = CDN_PATH + objImage.mediaID + '_compressed.png';
                                        }
                                    }
                                    if (response.recordDetails['merchantimage'][key].name == 'Audio') {
                                        var html = '';
                                        html += '<div class="col s12" style="float: right;">'
                                        html += '<audio class="" src="' + url + '" controls></audio>'
                                        html += '</div>'
                                    } else {
                                        var html = '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + url + '" />';
                                    }
                                    if (!key || key == '0') {
                                        eleParent.html(html);
                                    } else {
                                        eleParent.append(html);
                                    }
                                }
                            } else {
                                if (response.recordDetails['merchantimage'][key].name == 'Audio') {
                                    var url = CDN_PATH + response.recordDetails['merchantimage'][0].mediaID;
                                } else {
                                    var url = CDN_PATH + response.recordDetails['merchantimage'][0].mediaID + '_compressed.png';
                                }
                                $('#merchantimage6').attr("src", url);
                            }
                        }
                        if (!$('#loyaltystampcards16').html()) {
                            $('#loyaltystampcards16').append(response.recordDetails.undefined);
                        }
                        if (!$('#new9').html()) {
                            $('#new9').append(response.recordDetails.undefined);
                        }
                        if (!$('#termsconditions25').html()) {
                            $('#termsconditions25').append(response.recordDetails.undefined);
                        }
                        // if (!$('#name10').html()) {
                        //     $('#name10').append(response.recordDetails.name);
                        // }
                        if (!$('#two28may20198').html()) {
                            $('#two28may20198').append(response.recordDetails.undefined);
                        }
                        if (!$('#validity22').html()) {
                            $('#validity22').append(response.recordDetails.undefined);
                        }
                        if (!$('#voucherdetails14').html()) {
                            $('#voucherdetails14').append(response.recordDetails.undefined);
                        }

                        Materialize.updateTextFields();
                        $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

                    }
                }); // end of getRecord By ID
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            },
        });
    }); // end of getRecord By ID

    var paramsEdit = {};
    paramsEdit.tokenKey = getParameterByName('tokenKey');
    paramsEdit.secretKey = getParameterByName('secretKey')
    if (getParameterByName('bazaarid') && getParameterByName('bazaarid') != null && getParameterByName('bazaarid') != '') {
        paramsEdit.bazaarid = getParameterByName('bazaarid');
    }
    getRecordByIDProcessBeforeCallgroup13row7(paramsEdit, function (processBeforeRes) {
        $.ajax({
            url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_offerdetails_Redeemedstampcard5da73cac545050343288ce7a',
            data: paramsEdit,
            type: 'POST',
            jsonpCallback: 'callback',
            success: function (response) {
                getRecordByIDProcessAfterCallgroup13row7(response, function (processBeforeRes) {
                    if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                        var objParamsList = {};
                        var queryMode = $('#queryMode').val();
                        objParamsList.queryMode = queryMode;;
                        var tokenKey = $('#tokenKey').val();;
                        objParamsList.tokenKey = tokenKey;;
                        $('#accumalatedstampcard34').html(response.recordDetails.accumalatedstampcard);
                        if (response.recordDetails.address != undefined) $('#address29').val(response.recordDetails.address);
                        $('#bazaarnumber31_value').html(response.recordDetails.bazaarnumber);
                        $('#stampcardofferid32').html(response.recordDetails.stampcardofferid);
                        $('#bazaarid33').html(response.recordDetails.bazaarid);
                        if (!$('#backbutton1').html()) {
                            $('#backbutton1').append(response.recordDetails.undefined);
                        }
                        // getrecordbycustomquery - Stage - 111111111111
                        if (response.recordDetails['address_loadmapviewbyconfig'] && response.recordDetails['address_loadmapviewbyconfig'].length > 0) {
                            if (response.recordDetails['address_loadmapviewbyconfig'][0].displayType = 'html') {
                                var eleParent = $('#address_loadmapviewbyconfig12').parent();
                                for (var key in response.recordDetails['address_loadmapviewbyconfig']) {
                                    var objImage = response.recordDetails['address_loadmapviewbyconfig'][key];
                                    if (response.recordDetails['address_loadmapviewbyconfig'][key].name == 'Audio') {
                                        var token = $('#tokenKey').val();
                                        if (token && token != '') {
                                            token = $('#tokenKey').val();
                                        } else {
                                            token = getParameterByName('tokenKey');
                                        }
                                        var mediaIDa = response.recordDetails['address_loadmapviewbyconfig'][0].mediaID
                                        var filenamea = response.recordDetails['address_loadmapviewbyconfig'][0].fileName
                                        var CDN_PATH2 = 'https://devfiles.hokuapps.com/downloadOriginal?f=' + mediaIDa + '&fn=' + filenamea + '&t=' + token
                                        var url = CDN_PATH2
                                    } else {
                                        var filetodisplay = getuploadedfilepreview(objImage.fileNm);
                                        if (filetodisplay && filetodisplay != objImage.fileNm) {
                                            var url = filetodisplay;
                                        } else {
                                            var url = CDN_PATH + objImage.mediaID + '_compressed.png';
                                        }
                                    }
                                    if (response.recordDetails['address_loadmapviewbyconfig'][key].name == 'Audio') {
                                        var html = '';
                                        html += '<div class="col s12" style="float: right;">'
                                        html += '<audio class="" src="' + url + '" controls></audio>'
                                        html += '</div>'
                                    } else {
                                        var html = '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + url + '" />';
                                    }
                                    if (!key || key == '0') {
                                        eleParent.html(html);
                                    } else {
                                        eleParent.append(html);
                                    }
                                }
                            } else {
                                if (response.recordDetails['address_loadmapviewbyconfig'][key].name == 'Audio') {
                                    var url = CDN_PATH + response.recordDetails['address_loadmapviewbyconfig'][0].mediaID;
                                } else {
                                    var url = CDN_PATH + response.recordDetails['address_loadmapviewbyconfig'][0].mediaID + '_compressed.png';
                                }
                                $('#address_loadmapviewbyconfig12').attr("src", url);
                            }
                        }
                        if (!$('#address_name11').html()) {
                            $('#address_name11').append(response.recordDetails.address_name);
                        }
                        response.recordDetails['expirationdate_preserved'] = response.recordDetails['expirationdate'];
                        response.recordDetails['expirationdate'] = response.recordDetails['expirationdate'] ? moment(new Date(response.recordDetails['expirationdate'])).format('DD MMM YYYY') : '';
                        if (!$('#expirationdate20').html()) {
                            $('#expirationdate20').append(response.recordDetails.expirationdate);
                        }
                        response.recordDetails['expirationdate'] = response.recordDetails['expirationdate_preserved'];
                        if (!$('#outlets23').html()) {
                            if (!response.recordDetails.outlets) {
                                response.recordDetails.outlets = '0';
                            }
                            $('#outlets23').append(response.recordDetails.outlets);
                        }
                        $('#redeemedstampqty17').html(response.recordDetails.redeemedstampqty);
                        if (!$('#termsandconditions27').html()) {
                            $('#termsandconditions27').append(response.recordDetails.termsandconditions);
                        }
                        if (!$('#details2').html()) {
                            $('#details2').append(response.recordDetails.undefined);
                        }
                        if (!$('#expireson19').html()) {
                            $('#expireson19').append(response.recordDetails.undefined);
                        }
                        // getrecordbycustomquery - Stage - 111111111111
                        if (response.recordDetails['merchantimage'] && response.recordDetails['merchantimage'].length > 0) {
                            if (response.recordDetails['merchantimage'][0].displayType = 'html') {
                                var eleParent = $('#merchantimage6').parent();
                                for (var key in response.recordDetails['merchantimage']) {
                                    var objImage = response.recordDetails['merchantimage'][key];
                                    if (response.recordDetails['merchantimage'][key].name == 'Audio') {
                                        var token = $('#tokenKey').val();
                                        if (token && token != '') {
                                            token = $('#tokenKey').val();
                                        } else {
                                            token = getParameterByName('tokenKey');
                                        }
                                        var mediaIDa = response.recordDetails['merchantimage'][0].mediaID
                                        var filenamea = response.recordDetails['merchantimage'][0].fileName
                                        var CDN_PATH2 = 'https://devfiles.hokuapps.com/downloadOriginal?f=' + mediaIDa + '&fn=' + filenamea + '&t=' + token
                                        var url = CDN_PATH2
                                    } else {
                                        var filetodisplay = getuploadedfilepreview(objImage.fileNm);
                                        if (filetodisplay && filetodisplay != objImage.fileNm) {
                                            var url = filetodisplay;
                                        } else {
                                            var url = CDN_PATH + objImage.mediaID + '_compressed.png';
                                        }
                                    }
                                    if (response.recordDetails['merchantimage'][key].name == 'Audio') {
                                        var html = '';
                                        html += '<div class="col s12" style="float: right;">'
                                        html += '<audio class="" src="' + url + '" controls></audio>'
                                        html += '</div>'
                                    } else {
                                        var html = '<img class="element"  onerror="this.src=\'https://appscdn-us.hokuapps.com/card.png\'"  src="' + url + '" />';
                                    }
                                    if (!key || key == '0') {
                                        eleParent.html(html);
                                    } else {
                                        eleParent.append(html);
                                    }
                                }
                            } else {
                                if (response.recordDetails['merchantimage'][key].name == 'Audio') {
                                    var url = CDN_PATH + response.recordDetails['merchantimage'][0].mediaID;
                                } else {
                                    var url = CDN_PATH + response.recordDetails['merchantimage'][0].mediaID + '_compressed.png';
                                }
                                $('#merchantimage6').attr("src", url);
                            }
                        }
                        if (!$('#loyaltystampcards16').html()) {
                            $('#loyaltystampcards16').append(response.recordDetails.undefined);
                        }
                        if (!$('#new9').html()) {
                            $('#new9').append(response.recordDetails.undefined);
                        }
                        if (!$('#termsconditions25').html()) {
                            $('#termsconditions25').append(response.recordDetails.undefined);
                        }
                        if (!$('#name10').html()) {
                            $('#name10').append(response.recordDetails.name);
                        }
                        if (!$('#two28may20198').html()) {
                            $('#two28may20198').append(response.recordDetails.undefined);
                        }
                        if (!$('#validity22').html()) {
                            $('#validity22').append(response.recordDetails.undefined);
                        }
                        if (!$('#voucherdetails14').html()) {
                            $('#voucherdetails14').append(response.recordDetails.undefined);
                        }

                        Materialize.updateTextFields();
                        $('.languagetranslation.fieldshimmer').removeClass('fieldshimmer').fadeOut(0).fadeIn(100);

                    }
                }); // end of getRecord By ID
            },
            error: function (xhr, status, error) {
                handleError(xhr, status, error);
            },
        });
    }); // end of getRecord By ID

});//end of ready

function loadNativescanqrcodeControl(tokenKey, queryMode, secretKey, ajaXCallURL) {
    try {
        var appJSON = {};
        appJSON.tokenKey = tokenKey;
        appJSON.secretKey = secretKey;
        appJSON.queryMode = queryMode;
        appJSON.action = queryMode;
        appJSON.ajaXCallURL = ajaXCallURL;
        var AWSCredentials = localStorage.getItem("AWSCredentials");
        if (localStorage.IDENTITY_TOKEN) {
            var token = localStorage.IDENTITY_TOKEN;
            var playload = JSON.parse(atob(token.split(".")[1]));
            appJSON.Authorization = token;
            appJSON.Expiration = playload.exp;
        } else if (AWSCredentials) {
            AWSCredentials = JSON.parse(AWSCredentials);
            appJSON.accessKeyId = AWSCredentials.accessKeyId;
            appJSON.secretAccessKey = AWSCredentials.secretAccessKey;
            appJSON.sessionToken = AWSCredentials.sessionToken;
            appJSON.Expiration = AWSCredentials.Expiration;
        }
        appJSON.msgText = "<b><b><b><b><b><b><b><b><b>undefined</b></b></b></b></b></b></b></b></b>";
        appJSON.organizationID = $('#organizationID').val();
        appJSON.userID = $('#userID').val();
        appJSON.callbackFunction = 'setNativescanqrcodeControl';
        appJSON.nextButtonCallback = 'setNativescanqrcodeControl';
        appJSON.appID = $('#appID').val();
        var element = element ? element : null;
        clientbeforeNativescanqrcode(appJSON, element, function (pbcRes) {
            if (DEVICE_TYPE == 'ios') {
                setupWebViewJavascriptBridge(function (bridgeObj) {
                    bridgeObj.callHandler('loadNativeQRCodeScannerUpload', appJSON, function (response) {
                    });
                    bridgeObj.registerHandler('setNativescanqrcodeControl', function (responseData, responseCallback) {
                        setNativescanqrcodeControl(responseData);
                    });
                });
            } else {
                window.Android.loadNativeQRCodeScannerUpload(JSON.stringify(appJSON));
            }
        }); // end of process before call 
    } catch (err) {

    }
}
function clientbeforeNativescanqrcode(appJSON, element, callback) {
    var response = appJSON;
    callback();
}
function setNativescanqrcodeControl(responseData) {

    if (responseData) {
        var response = responseData;
        var appUser = JSON.parse(localStorage.getItem("appUser"));

        var barcode = response.data.split("&&");
        if (barcode != '') {
            var objParams = {};
            var recordID = barcode[0];
            if (recordID != localStorage.getItem('bazaarid')) {
                $('#display_loading').addClass('hideme');
                shareAppData("Invalid QR Code.", "toast");
            } else {
                objParams.isDelete = 0;
                var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                objParams.tokenKey = getParameterByName('tokenKey');
                objParams.secretKey = getParameterByName('secretKey');
                objParams.clientid = localStorage.getItem("userID");
                objParams.stampOfferID = getParameterByName('stampcardoffersid');
                objParams.userName = appUser.name;
                objParams.organizationID = appUser.organizationId;
                // //objParams.merchantID =recordID;
                //  objParams.merchantid =recordID;

                // objParams.stampOfferID
                // objParams.offlineDataID = localStorage.getItem("offlineDataID");
                var queryMode = getParameterByName('queryMode');
                objParams.callUrl = ajaXCallURL + '/milestone003/updateAjaxordersclientstamredeemv2';
                objParams.recordID = recordID;
                $.ajax({
                    url: objParams.callUrl,
                    data: objParams,
                    type: 'POST',
                    success: function (response) {
                        if (response.status == 0) {
                            $('#display_loading').addClass('hideme');
                            var objParams = {};
                            if (response.data) {
                                // $("#redeem28").trigger("click");
                                shareAppData("Stamp redeemed sucessfully.", "toast");

                            } else {
                                shareAppData("Invalid QR Code.", "toast");
                            }
                        } else {

                            shareAppData(response.error, "toast");
                        }

                        //    else {
                        //    $('#display_loading').addClass('hideme');
                        //    shareAppData("Invalid QR Code.", "toast");
                        //    }
                    },
                    error: function (xhr, status, error) {
                        $('#display_loading').addClass('hideme');
                        shareAppData("Invalid  QR Code.", "toast");
                    },
                });
            }
            return false;
        } else {
            shareAppData("Invalid  QR Code.", "toast");
        }
        // Add Custome function Call here                 
        //            clientafterNativebazaar_address_loadmapviewbyconfig(responseData, function (pbcRes) {
        //                // handle client after call
        //            })

        // Add Custome function Call here                 
        // clientafterNativescanqrcode(responseData, function (pbcRes) {
        //     // handle client after call 
        // })
    }
    return false;
}
function clientafterNativescanqrcode(response, callback) {
    if (response) {
        // Add Custome function Call here                 

    }
    console.log('last one');
}

function getParams(url) {
    var urlParams = {};
    url.replace(
        new RegExp("([^?=&]+)(=([^&]*))?", "g"),
        function ($0, $1, $2, $3) {
            if ($3 && $3 != 'undefined') urlParams[$1] = $3;
        }
    );
    return urlParams;
}
function processBeforeCallForSave8321redeem(objParams, response, callback) {


    objParams.type = 'merchantstampcard';
    objParams.status = 'Redeemed';
    objParams.stampcardofferid = getParameterByName('stampcardoffersid');
    objParams.bazaarid = localStorage.getItem('bazaarid');

    var accumalatedstampcard = localStorage.getItem('accumalatedstampcard');
    var redeemedstampqty = $("#redeemedstampqty17").html();
    if (redeemedstampqty != '' && accumalatedstampcard != '' && accumalatedstampcard != null) {
        redeemedstampqty = parseInt(redeemedstampqty);
        accumalatedstampcard = parseInt(accumalatedstampcard);
        if (accumalatedstampcard >= redeemedstampqty) {
            objParams.redeemedstampqty = redeemedstampqty;
            var paramsEdit = {};
            paramsEdit.tokenKey = getParameterByName('tokenKey');
            paramsEdit.secretKey = getParameterByName('secretKey');
            var ajaXCallURL = $.trim($('#ajaXCallURL').val());;
            paramsEdit.todaydate = new Date();
            paramsEdit.bazaarid = localStorage.getItem('bazaarid');
            $.ajax({
                url: ajaXCallURL + '/milestone003/getRecordByCustomeQuery_app_offerdetails_Redeemedstampcard5da73cac545050343288ce7a',
                data: paramsEdit,
                type: 'POST',
                jsonpCallback: 'callback',
                success: function (response) {
                    if (response.status != undefined && response.status == 0 && response.recordDetails != undefined) {
                        $('#display_loading1').addClass('hideme');
                        $('#redeem28').removeProp('disabled');
                        shareAppData('You have already redeemed stamp for this merchant today.', 'toast');
                        return false;
                    } else {
                        callback();
                    }
                },
                error: function (xhr, status, error) {
                    handleError(xhr, status, error);
                },
            });
        } else {
            $('#display_loading1').addClass('hideme');
            $('#redeem28').removeProp('disabled');
            shareAppData('You dont have  sufficient stamps to redeem this stamp card.', 'toast');
            return false;
        }
    } else {
        $('#display_loading1').addClass('hideme');
        $('#redeem28').removeProp('disabled');
        shareAppData('You dont have  sufficient stamps to redeem this stamp card.', 'toast');
        return false;
    }
}
function processAfterCallForSave8321redeem(response, callback) {

    callback();
}
function loadNativebazaar_address_loadmapviewbyconfigControl(tokenKey, queryMode, secretKey, ajaXCallURL, lat, long, addressText) {
    try {
        var appJSON = {};
        appJSON.tokenKey = tokenKey;
        appJSON.secretKey = secretKey;
        appJSON.queryMode = queryMode;
        appJSON.action = queryMode;
        appJSON.ajaXCallURL = ajaXCallURL;

        appJSON.lat = lat;
        appJSON.long = long;
        appJSON.sourceAddressString = addressText;

        var AWSCredentials = localStorage.getItem("AWSCredentials");
        if (localStorage.IDENTITY_TOKEN) {
            var token = localStorage.IDENTITY_TOKEN;
            var playload = JSON.parse(atob(token.split(".")[1]));
            appJSON.Authorization = token;
            appJSON.Expiration = playload.exp;
        } else if (AWSCredentials) {
            AWSCredentials = JSON.parse(AWSCredentials);
            appJSON.accessKeyId = AWSCredentials.accessKeyId;
            appJSON.secretAccessKey = AWSCredentials.secretAccessKey;
            appJSON.sessionToken = AWSCredentials.sessionToken;
            appJSON.Expiration = AWSCredentials.Expiration;
        }
        appJSON.msgText = "<b><b><b><b><b><b><b><b><b>undefined</b></b></b></b></b></b></b></b></b>";
        appJSON.organizationID = $('#organizationID').val();
        appJSON.appID = $('#appID').val();
        appJSON.userID = $('#userID').val();
        var element = element ? element : null;
        appJSON.isOtherNearbyLocation =true;
        clientbeforeNativebazaar_address_loadmapviewbyconfig(appJSON, element, function (pbcRes) {
            if (DEVICE_TYPE == 'ios') {
                setupWebViewJavascriptBridge(function (bridgeObj) {
                    bridgeObj.callHandler('loadMapViewByConfig', appJSON, function (response) {
                    });
                });
            } else {
                window.Android.loadMapViewByConfig(JSON.stringify(appJSON));
            }
        }); // end of process before call 
    } catch (err) {

    }
}
function clientbeforeNativebazaar_address_loadmapviewbyconfig(appJSON, element, callback) {
    var response = appJSON;
    appJSON.openMapApp = false;
    appJSON.isShowDirections = false;
    appJSON.isPlotAddressLocation = true;

    appJSON.isReadOnly = true;


    appJSON.mapZoomLevel = 16;
    appJSON.isNavigation = 1;

    appJSON.pageTitle = 'Get Direction';
    appJSON.isShowBottomButton = 0;
    appJSON.isPlotAddressLocation = true;
    appJSON.isSelectLocation = 0;
    //appJSON.readOnly = 1;
    //appJSON.addressString = $("div[id^='location_name']").html();
    appJSON.selectedLocationFromSearch = appJSON.sourceAddressString;
    callback();
}
function setNativebazaar_address_loadmapviewbyconfigControl(responseData) {
    try {
        if (responseData) {

            var barcode = response.data.split("&&");
            if (barcode != '') {
                var objParams = {};
                var recordID = barcode[0];
                if (recordID != localStorage.getItem('bazaarid')) {
                    $('#display_loading').addClass('hideme');
                    shareAppData("Invalid QR Code.", "toast");
                } else {
                    objParams.isDelete = 0;
                    var ajaXCallURL = $.trim($('#ajaXCallURL').val());
                    objParams.tokenKey = getParameterByName('tokenKey');
                    objParams.secretKey = getParameterByName('secretKey');
                    objParams.clientid = localStorage.getItem("userID");
                    objParams.stampOfferID = getParameterByName('stampofferid');
                    //objParams.merchantID =recordID;
                    objParams.merchantid = recordID;

                    // objParams.stampOfferID
                    // objParams.offlineDataID = localStorage.getItem("offlineDataID");
                    var queryMode = getParameterByName('queryMode');

                    objParams.callUrl = ajaXCallURL + '/milestone003/syncListDetails_Orders5da73cac545050343288ce7a_app_myupcomingeventslist';
                    objParams.recordID = recordID;
                    $.ajax({
                        url: objParams.callUrl,
                        data: objParams,
                        type: 'POST',
                        success: function (response) {
                            if (response.status == 0) {
                                $('#display_loading').addClass('hideme');
                                var objParams = {};
                                if (response.data) {
                                    // $("#redeem28").trigger("click");
                                    shareAppData("Stamp redeemed sucessfully.", "toast");

                                } else {
                                    shareAppData("Invalid QR Code.", "toast");
                                }
                            } else {
                                $('#display_loading').addClass('hideme');
                                shareAppData(response.error, "toast");
                            }
                        },
                        error: function (xhr, status, error) {
                            $('#display_loading').addClass('hideme');
                            shareAppData("Invalid  QR Code.", "toast");
                        },
                    });
                }
                return false;
            } else {
                shareAppData("Invalid  QR Code.", "toast");
            }
            // Add Custome function Call here                 
            //            clientafterNativebazaar_address_loadmapviewbyconfig(responseData, function (pbcRes) {
            //                // handle client after call
            //            })
        }
    } catch (err) {

    }
}
function clientafterNativebazaar_address_loadmapviewbyconfig(response, callback) {
    callback();
}
function getRecordByIDProcessBeforeCall935849(paramsType, callback) {
    var response = paramsType;

    if (getParameterByName('bazaarid') && getParameterByName('bazaarid') != 'undefined') { paramsType.recordID = getParameterByName('bazaarid') } else if (getParameterByName('recordID') && getParameterByName('recordID') != 'undefined') { paramsType.recordID = getParameterByName('recordID') }; callback();
}
function getRecordByIDProcessAfterCall935849(response, callback) {

    if (response && response.recordDetails.bazaaridKey && response.recordDetails.bazaaridKey) {

        localStorage.setItem('bazaarid', response.recordDetails.bazaaridKey);
    }

    callback();
}
function getRecordByIDProcessBeforeCallbackbutton1(paramsType, callback) {
    var response = paramsType;

    paramsType.recordID = localStorage.getItem("userID");
    callback();
}
function getRecordByIDProcessAfterCallbackbutton1(response, callback) {

    if (response && response.recordDetails.accumalatedstampcard && response.recordDetails.accumalatedstampcard) {

        localStorage.setItem('accumalatedstampcard', response.recordDetails.accumalatedstampcard);
    }

    callback();
}
function getRecordByIDProcessBeforeCallgroup13row7(paramsType, callback) {
    var response = paramsType;

    paramsType.todaydate = new Date();
    paramsType.bazaarid = localStorage.getItem('bazaarid');
    callback();
}
function getRecordByIDProcessAfterCallgroup13row7(response, callback) {
    callback();
}
